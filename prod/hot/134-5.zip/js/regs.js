// 24. 11. 2026 (owner): what an article's status means and which code a stock adjustment (Regulacija) takes, from
// StoreFront itself (its status and reason code names, its list of codes the store may pick) and JYSK's rules in MYJYSK:
// SOR 6.03 Usklađivanje zaliha (778), Reguliranje zalihe - MASTER (44527), Otpisivanje artikala - smjernice (188968),
// SOR 1.01 Općenito o naručivanju (736), Smjernice za clearance (2199), Samo online - smjernice (2149), Artikli
// blokirani za naručivanje (St. kod 31) (162243), Allocation (229636), Pretraga artikala - MASTER (140428),
// Pregled Usklađivanja zaliha po danima (44009). Read 24. 11. 2026; nothing here writes to StoreFront.

/** The statuses StoreFront knows (its own enum, BS name as StoreFront shows it), what they mean and what to do. */
export const ST = {
  '01': { name: 'Novo', short: 'novi', order: false,
    mean: 'Novi artikal koji još nije aktivan. StoreFront ga ne ubraja u aktivne (filter „Ne prikazuj 01, 02, 81“).' },
  '02': { name: 'Novo za Online only', short: 'novi online', order: false,
    mean: 'Novi artikal koji će se prodavati samo online. StoreFront ga ne ubraja u aktivne.' },
  '11': { name: 'Aktivan', short: 'aktivan', order: true,
    mean: 'Redovan aktivan artikal. Prodavnica ga naručuje iz DC-a ili od dobavljača. StoreFrontov filter „Prikaži samo aktivne“ = 11, 12, 41.' },
  '12': { name: 'Aktivan, alokacija', short: 'alokacija', order: false,
    mean: 'Aktivan, ali robu šalje DC sam (alokacija: centralno napravljene narudžbe za kampanje i sezone). Prodavnica ga sama ne naručuje.' },
  '21': { name: 'Ukinut (Discontinued)', short: 'ukinut', order: false,
    mean: 'Prvi korak izlaska iz asortimana.',
    todo: [
      'Datum ukidanja (DD) u budućnosti: ostaje na mjestu po planogramu i isporučuje se do ažuriranja planograma.',
      'DD prošao: više nije dio planograma, mora biti izložen na clearance poziciji.',
      'Cijenu određuje S&E; dodatni popusti nisu dozvoljeni.',
      'SM/DM ukloniti (Ostali alati → SM i DM).',
    ] },
  '31': { name: 'Privremeno blokiran za naručivanje', short: 'blokiran', order: false,
    mean: 'Najčešće pitanje kvalitete; u DC-u nema zalihe. Bez zadatka iz HO (Usklađenost i kvalitet) tretira se kao aktivan bez naručivanja.',
    todo: [
      'Zamijeni cjenovnik (stiže u red za štampu zbog promjene statusa).',
      'Namještaj, madraci, vrtni namještaj, novi datum isporuke vidljiv: izložbeni model se ne rasprodaje, narudžbe kupaca se prave.',
      'Novi datum isporuke nije vidljiv: izložbeni model na rasprodaju kad nestane zalihe, narudžbe kupaca se ne prave.',
      'Zabrana prodaje uvijek dolazi kao zadatak u MYJYSK-u: tada popuni prostor najbližim artiklom, okreni etiketu, bez narudžbi kupaca, ponudi zamjenu.',
    ] },
  '32': { name: 'Rezerviran za prodaju', short: 'rezervisan', order: false,
    mean: 'StoreFrontov status „Reserved for sales“. MYJYSK za njega nema posebno uputstvo.' },
  '41': { name: 'Procured (nabavni)', short: 'nabavni', order: true,
    mean: 'Artikal koji prodavnica može naručiti (SOR 1.01). StoreFront ga ubraja u aktivne.' },
  '42': { name: 'Samo online (Online only)', short: 'online', order: false,
    mean: 'Prodaje se kupcu kao narudžba kupca: unaprijed plaćena u cijelosti, stiže s redovnom isporukom iz DC-a.',
    todo: [
      'Ne izlagati i ne stavljati natpise za 42 koji fizički nemaš u prodavnici.',
      'Ako je na zalihi (npr. povrat): mora biti vidljiv u prodavnici s cijenom (najmanje IDG znak).',
      'AR ih prati najmanje jednom mjesečno (Clearance lista, filter 42).',
    ] },
  '43': { name: 'Online only u DC-u', short: 'online DC', order: false,
    mean: 'Samo online, roba je na zalihi DC-a. StoreFront ga ne ubraja u aktivne (kao 01, 02 i 81).' },
  '51': { name: 'Drop Shipment', short: 'direktno', order: false,
    mean: 'Direktna isporuka od dobavljača, ne preko DC-a.' },
  '81': { name: 'Označen za brisanje (MFD)', short: 'za brisanje', order: false,
    mean: 'Zadnji korak prije izlaska iz asortimana. Na Clearance listi (filter 81).',
    todo: [
      'AR redovno pregleda MFD artikle na Clearance listi (StoreFront ili GK).',
      'Ne proda se 30 dana: procijeni nižu cijenu.',
      'Izložen po konceptu, s najnovijom cijenom; zalihu provjeravaj od najveće vrijednosti.',
      'SM/DM ukloniti prije kraja ažuriranja prostora.',
      'Stariji od 13 mjeseci: ponuditi dobrotvornoj organizaciji (bez JYSK oznaka); ako ga niko ne želi, otpis kodom 50 sa sprejom, u dogovoru s District Managerom.',
    ] },
  '91': { name: 'Blokirana distribucija podataka', short: 'blokiran (91)', order: false,
    mean: 'StoreFront ga zove BLOCK_MASTERDATA_DISTRIBUTION i nema mu bosanski naziv. MYJYSK nema uputstvo.' },
};
export const ST_ORDER = ['01', '02', '11', '12', '21', '31', '32', '41', '42', '43', '51', '81', '91'];

/** The reason codes of a stock adjustment: StoreFront's name and when JYSK's rules (SOR 6.03, 44527, 188968) use it. */
export const REG = {
  '50': { name: 'Rastur, lom', dir: 'Ukloni',
    when: 'Oštećeno u prodavnici; oštećenje iz prijevoza primijećeno tek poslije prijema; ostaci stolnjaka; artikal koji se ne može prodati ni uz popust (kod 4); MFD stariji od 13 mjeseci koji niko ne želi donirati.' },
  '57': { name: 'Oštećenja u prijevozu', dir: 'Ukloni',
    when: 'Oštećeno u prijevozu iz DC-a ili u DC-u. Ako je primijećeno tek poslije prijema: 50.' },
  '52': { name: 'Reklamacija', dir: 'Ukloni', claim: true,
    when: 'Greška kvalitete za koju odgovara proizvođač. Radi se kroz Reklamaciju u StoreFrontu. Jorgani, jastuci, madraci: tek kad dobavljač odobri reklamaciju.' },
  '81': { name: 'BOM, rezervni dio, popravak', dir: 'Ukloni ili Dodaj',
    when: '−81 kad artikal privremeno nije za prodaju (čeka BOM, rezervni dio ili popravak), najviše 2 mjeseca. +81 kad je popravljen ili prodan s popustom. Ne može se spasiti: prvo +81, pa otpis 50, 52 ili 57. LR provjerava kod 81 svake sedmice.' },
  '53': { name: 'Regulacija skladišta', dir: 'Ukloni ili Dodaj',
    when: 'Greška inventure, pogrešan prijem robe, krađa, ispravka Minus liste, izložbeni model po smjernicama zamjene. Ne tokom inventure.' },
  '51': { name: 'Vlastita potrošnja', dir: 'Ukloni',
    when: 'Stalna dekoracija prodavnice, namještaj za zajedničke prostorije, sredstva za čišćenje i njegu, artikal trajno oštećen ugradnjom (npr. na zid). Ne skupe stvari ni velike količine. Privremeno izloženo (studio madraci, dekoracija) ostaje na zalihi.' },
  '55': { name: 'Viša sila', dir: 'Ukloni ili Dodaj',
    when: 'Provala, pljačka, požar, poplava. Samo uz kontakt s Regionalnim voditeljem i Internom revizijom.' },
  '80': { name: 'Marketinške aktivnosti', dir: 'Ukloni',
    when: 'Eventi, sajmovi, promocije, posudba blogerima i medijima.' },
  '103': { name: 'Inventura i Minus lista', dir: 'auto', auto: true,
    when: 'Dodjeljuje se sam: inventura poslije prihvatanja i artikli regulisani s Minus liste. Ne bira se.' },
  // StoreFront knows these too, but they are not in the Regulacija of BiH stores (owner 24. 11. 2026, and the store's
  // own list in StoreFront): only their names, for a history row that would carry one
  // SOR 6.03 (24. 11. 2026) names 85 „Kontrola kvalitete robe“; StoreFront calls it Foto uzorci and the BiH Regulacija
  // does not offer it (BIH_CODES), so it stays out of the list
  '85': { name: 'Foto uzorci', hide: true, sor: 'Kontrola kvalitete robe' },
  '128': { name: 'Višak artikla iz DC-a', hide: true },
  '129': { name: 'Višak od vanjskog dobavljača', hide: true },
};
/** What the Regulacija of a BiH store offers (StoreFront user-details storeInfo.reasonCodes, X704 24. 11. 2026). */
export const BIH_CODES = ['50', '51', '53', '55', '57', '80', '81'];
export const REG_ORDER = ['50', '57', '52', '81', '53', '51', '55', '80', '103'];

/** The rules around every adjustment (SOR 6.03, 44527, 44009, 188968). */
export const REG_RULES = [
  'Komentar odmah, svaki dan, za svaku korekciju iznad 8 € (15,65 KM) i svaku pogrešnu. Bez korekcija iznad 8 €: u Store BI napomena „Izvještaj provjeren“.',
  'Svako jutro AR i uprava prodavnice pregledaju „Pregled usklađivanja zaliha po danima“ (Store reports) i komentarišu velike korekcije.',
  'Otpis: uz dva djelatnika skinuti JYSK oznaku i sprejom označiti stražnju ili donju stranu, pa donacija ili kontejner.',
  'Odobrenje uništenja: do 20 KM voditelj prodavnice; iznad 20 KM Regionalni voditelj, potpisom na mjesečnom izvještaju.',
  'Odjeća (ogrtači, papuče) se ne otpisuje: pokušaj donirati (3 organizacije, s fotografijama i opisom), inače reklamacija u StoreFrontu s fotografijama.',
  'Otpisano se ne nosi kući; zaposleni ga može kupiti na blagajni s kodom popusta 4.',
  'Slanje traži SAP HR broj (6 cifara) i lozinku StoreFronta. Regulacija se vidi za 1–2 min, u GK nekoliko minuta kasnije.',
];

/** StoreFront's reason code as the app shows it: '0053' -> '53', '0103' -> '103' (as StoreFront's own page). */
export function regCode(c) {
  const s = String(c == null ? '' : c).trim();
  return /^\d+$/.test(s) ? s.replace(/^0+(?=\d{2})/, '') : s;
}

export const day = (t) => { const d = new Date(t); return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}.`; };
const DAY = 86400000;

/**
 * What the master data of an article says about its status, as short sentences: since when, what it becomes and when,
 * the discontinuation date (DD) and what that means now. md: { st, stIso, fut, futAt, dd } (js/store-task.js article()).
 */
export function stContext(md, now = Date.now()) {
  if (!md || !md.st) return [];
  const out = [];
  const since = /^\d{4}-\d{2}-\d{2}$/.test(String(md.stIso || '')) ? Date.parse(`${md.stIso}T12:00:00`) : NaN;
  if (Number.isFinite(since)) {
    const a = new Date(since), b = new Date(now); // whole calendar months (24. 9. -> 24. 11. is 2)
    const months = Math.max(0, (b.getFullYear() - a.getFullYear()) * 12 + b.getMonth() - a.getMonth() - (b.getDate() < a.getDate() ? 1 : 0));
    out.push({ k: 'since', t: `Status ${md.st} od ${day(since)}${months >= 1 ? ` (${months} ${months === 1 ? 'mjesec' : months < 5 ? 'mjeseca' : 'mjeseci'}).` : ''}` });
    if (md.st === '81' && months >= 13) out.push({ k: 'mfd13', warn: true, t: 'Označen za brisanje duže od 13 mjeseci: ponuditi dobrotvornoj organizaciji ili otpisati kodom 50, u dogovoru s District Managerom.' });
  }
  if (md.fut && md.fut !== md.st && Number.isFinite(+md.futAt) && +md.futAt > now - DAY) {
    const f = ST[md.fut];
    out.push({ k: 'fut', warn: md.fut === '21' || md.fut === '81', t: `Od ${day(+md.futAt)} postaje ${md.fut}${f ? ` (${f.short})` : ''}.` });
  }
  if ((md.st === '21' || md.fut === '21') && Number.isFinite(+md.dd) && +md.dd > 0) {
    const past = +md.dd < now;
    out.push({ k: 'dd', warn: past && md.st === '21', t: `Datum ukidanja (DD): ${day(+md.dd)}${md.st === '21' ? (past ? ' Prošao: više nije dio planograma, ide na clearance poziciju.' : ' Do tada ostaje na mjestu po planogramu.') : ''}` });
  }
  return out;
}

/**
 * The store's adjustments as the app keeps them (js/store-task.js regs()): [num, t, qty, code, amount, comment, title].
 * These helpers only read that list.
 */
export function regsOf(rows, num) {
  const n = String(num);
  return (rows || []).filter((r) => r[0] === n).sort((a, b) => b[1] - a[1]);
}

/** Articles taken off the stock with −81 and not yet put back with +81 (in the period StoreFront gives, ~6 months). */
export function open81(rows, now = Date.now()) {
  const by = new Map();
  for (const r of rows || []) {
    if (r[3] !== '81') continue;
    const x = by.get(r[0]) || { num: r[0], title: r[6] || '', q: 0, lastOut: 0 };
    x.q += r[2];
    if (r[2] < 0 && r[1] > x.lastOut) x.lastOut = r[1];
    if (!x.title && r[6]) x.title = r[6];
    by.set(r[0], x);
  }
  return [...by.values()].filter((x) => x.q < 0 && x.lastOut).map((x) => ({ ...x, days: Math.floor((now - x.lastOut) / DAY) }))
    .sort((a, b) => b.days - a.days);
}

/** 8 € in KM (the fixed rate 1,95583): SOR 6.03 since 24. 11. 2026 says the limit in euros. */
export const COMMENT_KM = 15.65;
/** Adjustments above `km` (by value) without a comment, in the last `days` days (SOR 6.03: comment every one above 8 €). */
export function noComment(rows, now = Date.now(), days = 30, km = COMMENT_KM) {
  return (rows || []).filter((r) => r[1] >= now - days * DAY && Number.isFinite(r[4]) && Math.abs(r[4]) > km && !String(r[5] || '').trim())
    .sort((a, b) => b[1] - a[1]);
}

/** Per code over the last `days` days: { code, out, in, km } (units taken off, put on, value). */
export function byCode(rows, now = Date.now(), days = 7) {
  const m = new Map();
  for (const r of rows || []) {
    if (r[1] < now - days * DAY) continue;
    const x = m.get(r[3]) || { code: r[3], out: 0, in: 0, km: 0, n: 0 };
    if (r[2] < 0) x.out += -r[2]; else x.in += r[2];
    if (Number.isFinite(r[4])) x.km += r[4];
    x.n++;
    m.set(r[3], x);
  }
  return [...m.values()].sort((a, b) => b.n - a.n);
}

// ---------------------------------------------------------------------------------------------------------------
// 24. 11. 2026 (owner: "what if the SOR changes or a new code comes?"): what the texts above were written from, so the
// app itself sees a change. MYJYSK: each article's text fingerprint (myjysk-ar.js 'rules', FNV-1a of its sections'
// text) and its lastUpdated as read on 24. 11. 2026; a change of both is a change of the rule. StoreFront: the codes
// its Regulacija offers and its own names of codes and statuses (store-task.js 'regs' with names).

/** The MYJYSK articles behind these texts, as read 24. 11. 2026 (kb, topic: the path the app opens). */
export const RULE_SRC = [
  { id: '778', kb: 12, topic: 46, title: 'SOR 6.03 Usklađivanje zaliha', h: '90690b53', upd: '2026-11-24T09:12:34' }, // verzija 293 (24. 11. 10:12): komentar iznad 8 €, kod 85
  { id: '44527', kb: 11, topic: 121, title: 'Reguliranje zalihe - MASTER verzija', h: 'e9f06eee', upd: '2026-09-25T10:39:44' },
  { id: '188968', kb: 17, topic: 517, title: 'Otpisivanje artikala - smjernice', h: '39c06ce4', upd: '2026-09-23T16:26:01' },
  { id: '736', kb: 12, topic: 49, title: 'SOR 1.01 Općenito o naručivanju artikala', h: 'ca32a90b', upd: '2026-11-19T08:51:11' },
  { id: '2199', kb: 17, topic: 517, title: 'Smjernice za clearance', h: '801df880', upd: '2026-11-16T14:20:59' },
  { id: '2149', kb: 17, topic: 518, title: 'Samo online - smjernice', h: '5432ddce', upd: '2026-09-24T09:57:53' },
  { id: '162243', kb: 17, topic: 519, title: 'Artikli blokirani za naručivanje (St. kod 31)', h: '00dc25a5', upd: '2026-08-17T10:18:53' },
  { id: '44009', kb: 11, topic: 244, title: 'Pregled Usklađivanja zaliha po danima', h: '8ab06ac9', upd: '2026-10-19T09:41:28' },
  // 28. 11. 2026 (owner chose O1; read in MYJYSK 28. 11., the same fingerprint as myjysk-ar.js): the articles the app's
  // reservation deadlines (js/reservations.js RULES: 14 days, C&C day + 48 h), Narudžbe „Kupac nije obaviješten“ and the
  // code 7 price come from. area 'rz': a change is also said in Narudžbe → Rezervacije.
  { id: '754', kb: 12, topic: 43, title: 'SOR 3.03 Narudžbe kupaca/Rezervacije', h: 'a7ae3172', upd: '2026-11-27T12:26:38', area: 'rz' },
  { id: '761', kb: 12, topic: 43, title: 'SOR 3.10 Click & Collect kupovina', h: 'eb2e7642', upd: '2026-11-27T12:31:07', area: 'rz' },
  { id: '756', kb: 12, topic: 43, title: 'SOR 3.05 Popusti (kod 7)', h: 'ea0ab8c5', upd: '2026-11-27T12:45:23' },
  { id: '220994', kb: 11, topic: 121, title: 'Smjernice za narudžbe kupaca', h: 'e21a15cd', upd: '2026-11-27T10:14:58' },
  { id: '18833', kb: 17, topic: 517, title: 'Rutine trgovine', h: '8df99129', upd: '2026-11-27T19:42:47' },
];
export const rulePath = (x) => (x && x.kb && x.topic ? `/ui/knowledge-bases/${x.kb}/topics/${x.topic}/articles/${x.id}` : '');

/**
 * The MYJYSK articles changed since the texts were written: another fingerprint AND a newer lastUpdated (a date alone
 * moves with a translation or a typo elsewhere; a fingerprint alone could be another language). `seen`: {id: h} the
 * employee marked as looked at. An article that could not be read is not taken as changed.
 */
export function rulesChanged(list, seen = {}) {
  const out = [];
  for (const x of list || []) {
    const src = RULE_SRC.find((r) => r.id === String(x && x.id));
    if (!src || !x.h || x.err) continue;
    if (x.h !== src.h && String(x.upd || '').slice(0, 19) > src.upd && seen[src.id] !== x.h) {
      out.push({ id: src.id, title: x.title || src.title, upd: String(x.upd || ''), h: x.h, path: rulePath({ id: src.id, kb: x.kb || src.kb, topic: x.topic || src.topic }), was: src.upd, area: src.area || '' });
    }
  }
  return out;
}

/**
 * What StoreFront says now against what these texts know: codes its Regulacija offers that are not described here,
 * codes described here that it no longer offers, statuses it has that are not described here. `offered`: the store's
 * reasonCodes (none known: nothing said); `names`: { rc, st } StoreFront's names.
 */
export function storeChanged(offered, names) {
  const nm = names || {};
  const rc = nm.rc || {}, st = nm.st || {};
  const off = Array.isArray(offered) && offered.length ? offered.map(String) : null;
  return {
    added: off ? off.filter((c) => !BIH_CODES.includes(c)).map((c) => ({ c, name: rc[c] || (REG[c] && REG[c].name) || '' })) : [],
    gone: off ? BIH_CODES.filter((c) => !off.includes(c)) : [],
    status: Object.keys(st).filter((c) => !ST[c]).map((c) => ({ c, name: st[c] || '' })),
  };
}

/** One signature of what StoreFront said (the employee's "Pregledao sam" is kept against it). */
export function storeSig(ch) {
  return [...ch.added.map((x) => `+${x.c}`), ...ch.gone.map((c) => `-${c}`), ...ch.status.map((x) => `s${x.c}`)].join(',');
}
