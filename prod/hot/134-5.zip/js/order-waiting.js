// Narudžbe (owner, 13. 11. 2026): which article customers wait for most, and who ordered it first. Pure functions over
// the orders the phone already has (no StoreFront call, works offline). Used by app.js; tests/order-waiting.test.mjs.
//
// Time of ordering, best first (orders-time.js info()): rank 0 = StoreFront's own creation / receipt time (confirmed),
// rank 1 = the first internal note (approximate), rank 2 = a date without a clock, rank 3 = nothing. The pickup date is
// never a time of ordering.

const T = () => globalThis.PolicaOrderTime;

// 27. 11. 2026 (real StoreFront, read only, 254 orders; docs/STOREFRONT-PROVJERA-2026-11-27.md): the oldest history
// entry is a colleague's note, always 1.5-37 min after the till (one 23 days), never the same minute; the order number
// holds the till moment: 9X999 · 1 · till · DDMMYY · HHMMSS (store clock). Owner „Da“: the number first.
const NO_TIME = /^#?\d?X\d{3}1\d{2}(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/;
/** The till moment in the order number as the store's clock text ("23.11.2026 16:07:55"), or '' for another shape. */
export function numberText(no) {
  const m = NO_TIME.exec(String(no || '').trim());
  if (!m) return '';
  const t = `${m[1]}.${m[2]}.20${m[3]} ${m[4]}:${m[5]}:${m[6]}`;
  return T().stamp(t) ? t : '';
}
/**
 * orders-time.js info() with the order number's time before the history: StoreFront's own receipt / order time (when an
 * answer has it) first, then the number, then the history (orders-time.js is also Java's StoreFront page script, so it
 * stays as it is).
 */
export function infoOf(ord) {
  const i = T().info(ord);
  if (i.rank === 0 && i.label !== 'Kreirano') return i;
  const t = numberText(ord && ord.no);
  return t ? { rank: 0, stamp: T().stamp(t), label: 'Kreirano' } : i;
}

/** The order's time of ordering: { tier: 0 clock | 1 date only | 2 none, key, text, label, sure } */
export function timeOf(ord) {
  const i = infoOf(ord);
  if (i.stamp && i.rank <= 1) return { tier: 0, key: i.stamp.key, text: i.stamp.text, label: i.label, sure: i.rank === 0 };
  if (i.stamp) return { tier: 1, key: i.stamp.key, text: i.stamp.text, label: i.label, sure: false };
  return { tier: 2, key: '', text: '', label: i.label, sure: false };
}

const noNum = (ord) => { const d = String(ord.no || '').replace(/\D/g, ''); return d ? Number(d) : NaN; };
const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
/**
 * A line's quantity still owed to the customer: { qty, sure } (sure: StoreFront gave how much was handed out).
 * 1.98: "Djelomično" (StoreFront PARTIALLY: part of the goods arrived) without a handed-out quantity: how much still
 * waits is not known, at most the ordered quantity (never a confirmed number).
 */
export function remaining(it) {
  const q = Math.max(0, +it.qty || 0);
  const h = it.hq;
  if (typeof h === 'number' && Number.isFinite(h) && h >= 0 && h <= q) return { qty: q - h, sure: true };
  return { qty: q, sure: false };
}
export const PART = 'Djelomično';
/**
 * A line counts as waiting: goods not received yet ("Otvoreno") or only partly ("Djelomično", 1.98: BiH StoreFront
 * gives this line state; before, such a customer dropped out of "Samo što još čeka") and something still owed.
 */
export const isWaiting = (it) => (it.st === 'Otvoreno' || it.st === PART) && remaining(it).qty > 0;

/**
 * Articles of the orders: one entry per code, an order counted once even when the code is on it twice (its lines are
 * summed), an order present in several StoreFront tabs counted once (by its number).
 * onlyWaiting: only what still waits for goods, with the remaining quantity; otherwise every line of every order.
 */
export function articles(list, { onlyWaiting = true } = {}) {
  const by = new Map();
  const seenOrder = new Set();
  for (const ord of list || []) {
    if (!ord || seenOrder.has(ord.no)) continue;
    seenOrder.add(ord.no);
    const mine = new Map(); // code -> { qty, st set, unsure }
    for (const it of ord.items || []) {
      if (!it || !/^\d{7}$/.test(numKey(it.num))) continue;
      const num = numKey(it.num); // 2.11: a number stored as a number is the same article
      if (onlyWaiting && !isWaiting(it)) continue;
      const r = onlyWaiting ? remaining(it) : { qty: Math.max(0, +it.qty || 0), sure: true };
      const m = mine.get(num) || { qty: 0, name: it.name || '', st: {}, unsure: false };
      m.qty += r.qty;
      if (onlyWaiting && !r.sure && (it.hq !== undefined || it.st === PART)) m.unsure = true;
      m.st[it.st || '?'] = (m.st[it.st || '?'] || 0) + r.qty;
      mine.set(num, m);
    }
    const t = timeOf(ord);
    for (const [num, m] of mine) {
      const e = by.get(num) || { num, name: m.name, qty: 0, n: 0, orders: [], st: {} };
      e.qty += m.qty;
      e.n += 1;
      if (m.unsure) e.unsure = true; // 1.97: a handed-out quantity StoreFront did not give: the waiting sum is not sure
      if (!e.name && m.name) e.name = m.name;
      for (const [k, v] of Object.entries(m.st)) e.st[k] = (e.st[k] || 0) + v;
      e.orders.push({ ord, qty: m.qty, t, ...(m.unsure ? { unsure: true } : {}) });
      by.set(num, e);
    }
  }
  for (const e of by.values()) {
    const timed = e.orders.filter((x) => x.t.tier === 0).map((x) => x.t);
    timed.sort((a, b) => cmp(a.key, b.key));
    e.oldest = timed[0] || e.orders.map((x) => x.t).find((t) => t.tier === 1) || null;
    e.newest = timed[timed.length - 1] || null;
    e.minNo = Math.min(...e.orders.map((x) => noNum(x.ord)).filter(Number.isFinite));
  }
  return [...by.values()];
}

// "Zapisi bez vremena na kraju i kod najstarijih i kod najnovijih": an article without any clock time goes last both ways
const tierOf = (t) => (t ? t.tier : 2);
export const ARTICLE_SORTS = {
  oldest: (a, b) => tierOf(a.oldest) - tierOf(b.oldest) || cmp(a.oldest ? a.oldest.key : '', b.oldest ? b.oldest.key : '') || cmp(a.num, b.num),
  newest: (a, b) => (a.newest ? 0 : 1) - (b.newest ? 0 : 1) || cmp(b.newest ? b.newest.key : '', a.newest ? a.newest.key : '') || cmp(a.num, b.num),
  qty: (a, b) => b.qty - a.qty || b.n - a.n || ARTICLE_SORTS.oldest(a, b),
  orders: (a, b) => b.n - a.n || b.qty - a.qty || ARTICLE_SORTS.oldest(a, b),
  number: (a, b) => (Number.isFinite(a.minNo) ? 0 : 1) - (Number.isFinite(b.minNo) ? 0 : 1) || a.minNo - b.minNo || cmp(a.num, b.num),
};
export function sortArticles(arr, how) { return arr.slice().sort(ARTICLE_SORTS[how] || ARTICLE_SORTS.oldest); }

// 25. 11. 2026 (owner): the order's value (StoreFront's totalAmount, whole fenings); unknown last both ways, never 0
const amtOf = (r) => (r.ord && Number.isInteger(r.ord.amt) && r.ord.amt >= 0 ? r.ord.amt : null);
const byValue = (dir) => (a, b) => {
  const x = amtOf(a), y = amtOf(b);
  if (x === null || y === null) return (x === null ? 1 : 0) - (y === null ? 1 : 0);
  return dir * (x - y);
};
/** Customers of one article: rows { ord, qty, t }. Untimed last in both time orders; ties by order number. */
export const CUSTOMER_SORTS = {
  oldest: (a, b) => a.t.tier - b.t.tier || cmp(a.t.key, b.t.key) || noNum(a.ord) - noNum(b.ord),
  newest: (a, b) => a.t.tier - b.t.tier || cmp(b.t.key, a.t.key) || noNum(b.ord) - noNum(a.ord),
  qty: (a, b) => b.qty - a.qty || CUSTOMER_SORTS.oldest(a, b),
  number: (a, b) => (Number.isFinite(noNum(a.ord)) ? 0 : 1) - (Number.isFinite(noNum(b.ord)) ? 0 : 1) || noNum(a.ord) - noNum(b.ord),
  valueDesc: (a, b) => byValue(-1)(a, b) || CUSTOMER_SORTS.oldest(a, b),
  valueAsc: (a, b) => byValue(1)(a, b) || CUSTOMER_SORTS.oldest(a, b),
};
export function sortCustomers(rows, how) { return rows.slice().sort(CUSTOMER_SORTS[how] || CUSTOMER_SORTS.oldest); }

/**
 * How far the order of customers can be trusted: { level: 'sure'|'approx'|'unknown', why }.
 * unknown: the first has no clock time, or the first two share the same time.
 */
export function reliability(rows) {
  const s = sortCustomers(rows, 'oldest');
  if (!s.length) return { level: 'unknown', why: '' };
  if (s.length === 1) return s[0].t.tier === 0 ? { level: s[0].t.sure ? 'sure' : 'approx', why: '' } : { level: 'unknown', why: 'nema vremena narudžbe' };
  const [a, b] = s;
  if (a.t.tier !== 0) return { level: 'unknown', why: 'Nijedna narudžba nema vrijeme. Ne zna se ko je prvi.' };
  if (b.t.tier === 0 && a.t.key === b.t.key) return { level: 'unknown', why: `Prve dvije narudžbe imaju isto vrijeme (${a.t.text}). Ne zna se ko je prvi.` };
  if (a.t.key.length < 14 && b.t.tier === 0 && b.t.key.startsWith(a.t.key.slice(0, 12))) return { level: 'unknown', why: 'Prve dvije narudžbe su iz iste minute, bez sekundi.' };
  const all = s.filter((x) => x.t.tier === 0);
  if (all.every((x) => x.t.sure)) return { level: 'sure', why: '' };
  return { level: 'approx', why: 'Dio vremena nije potvrđen: redoslijed je približan.' };
}

/**
 * Owner's approval (13. 11. 2026): does the order number follow the time of the first note? Every pair of orders:
 * agree / differ / not comparable (a time missing or equal, or no number). Agreement with notes does NOT confirm the
 * creation time. useful: enough comparable pairs and nearly all agree.
 */
export function numberCheck(list) {
  const rows = [];
  const seen = new Set();
  for (const ord of list || []) {
    if (!ord || seen.has(ord.no)) continue;
    seen.add(ord.no);
    rows.push({ n: noNum(ord), t: timeOf(ord) });
  }
  let agree = 0, differ = 0, none = 0;
  for (let i = 0; i < rows.length; i++) {
    for (let j = i + 1; j < rows.length; j++) {
      const a = rows[i], b = rows[j];
      if (!Number.isFinite(a.n) || !Number.isFinite(b.n) || a.n === b.n || a.t.tier !== 0 || b.t.tier !== 0 || a.t.key === b.t.key) { none++; continue; }
      if ((a.n < b.n) === (a.t.key < b.t.key)) agree++; else differ++;
    }
  }
  const cmpN = agree + differ;
  return { agree, differ, none, useful: cmpN >= 20 && agree / cmpN >= 0.9 };
}

// ---------------------------------------------------------------------------------------------------------------
// 2.08 (owner, 16. 11. 2026): Narudžbe redesign. One word per line and per order, taken ONLY from StoreFront's own line
// states (Otvoreno, Djelomično, Popunjeno, Završeno); nothing is guessed from days passed or from stock in the store.
// Payment ("Čeka plaćanje", ord.pay) is separate and never changes the goods state.

/** 2.11: an article number compared as text of 7 digits (a number from an old record or another reader keeps its leading zeros). */
export function numKey(v) {
  const t = String(v == null ? '' : v).trim();
  return /^\d{1,6}$/.test(t) ? t.padStart(7, '0') : t;
}
export const sameNum = (a, b) => numKey(a) === numKey(b);

/** A line's goods state: 'wait' | 'part' | 'ready' | 'done' | 'unknown'. */
export function lineKey(st) {
  if (st === 'Otvoreno') return 'wait';
  if (st === PART) return 'part';
  if (st === 'Popunjeno') return 'ready';
  if (st === 'Završeno') return 'done';
  return 'unknown';
}

/**
 * The goods state of a whole order, from its lines:
 *   ready   every line received (Popunjeno, or already handed out), and every line of the order was read
 *   wait    nothing received yet
 *   part    some lines received (or a line partly), others still waiting
 *   done    every line handed out
 *   unknown no lines, a line with a state we do not know, or "all received" while not every line was read
 * Returns { key, read, of } (read lines / lines StoreFront says the order has).
 */
export function orderState(ord) {
  const items = (ord && ord.items) || [];
  const of = Math.max(items.length, +(ord && ord.n) || 0);
  const keys = items.map((it) => lineKey(it.st));
  // partial (#23, 2.11): not every line of the order was read; the known state is kept, the card says it is incomplete
  const res = (key) => ({ key, read: items.length, of, partial: items.length < of });
  if (!keys.length || keys.includes('unknown')) return res('unknown');
  if (keys.every((k) => k === 'done')) return res(items.length < of ? 'unknown' : 'done');
  const got = keys.filter((k) => k === 'ready' || k === 'done').length;
  if (got === keys.length) return res(items.length < of ? 'unknown' : 'ready');
  if (got === 0 && !keys.includes('part')) return res('wait');
  return res('part');
}

/** Pieces on the order: { total, lines, unknown, partial, atLeast } (lines = different articles; an article on two lines counts once). */
export function orderPieces(ord) {
  const items = (ord && ord.items) || [];
  const nums = new Set(items.map((it) => numKey(it.num)));
  // unknown: a line without a quantity. partial (2.11): StoreFront says the order has more lines than were read.
  // Either way the total is only a lower bound ("1+ kom"): the missing lines are never guessed.
  const unknown = items.some((it) => !(+it.qty > 0));
  const partial = items.length < (+(ord && ord.n) || 0);
  return { total: items.reduce((n, it) => n + Math.max(0, +it.qty || 0), 0), lines: nums.size, unknown, partial, atLeast: unknown || partial };
}

/** Orders counted once by number (an order sits in several StoreFront tabs). */
export function uniqueOrders(list) {
  const seen = new Set();
  const out = [];
  for (const ord of list || []) {
    if (!ord || seen.has(ord.no)) continue;
    seen.add(ord.no);
    out.push(ord);
  }
  return out;
}
