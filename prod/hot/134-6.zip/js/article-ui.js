// The article screen: its places on the planograms (the drawn crop, kept and drawn ahead), stock and orders.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
import { noteBs } from './note-bs.js';

export function createArticleUi(ctx) {
  const { $, S, core, chainBox, createCropCache, dateBs, docs, esc, go, icon, isFav, locationsOf, note, ordersBlock, ordersHint, pills, rememberRecent, stockHtml, stockLoad, thumb, viewer, whole } = ctx;
  // every name the phone has for a code (planogram, StoreFront): only to tell what it is ("vaza") in a note
  const namesOf = ctx.namesOf || (() => '');
  const substNote = ctx.substNote || (() => ''); // 21. 11. 2026: an open StoreFront replacement (Zamjena)

/**
 * 1.72: the article was moved or is new in the planogram that replaced the old one (the change kept by the import,
 * S.user.changes; shown for 60 days after the replacement).
 */
function changeNote(planId, num) {
  const ch = S.user && S.user.changes ? S.user.changes[planId] : null;
  if (!ch || !(Date.now() - (ch.at || 0) < 60 * 86400000)) return '';
  const when = dateBs(ch.at);
  const mv = (ch.moved || []).find((x) => x.num === num);
  if (mv) {
    const pl = (x, old) => pills(x && x[0] ? x[0] : null).replace('class="pills"', `class="pills${old ? ' is-old' : ''}"`);
    return `<div class="chg-note">${icon('arrow')}<div><b>Premješten</b> u novom planogramu (${esc(when)})<span class="move">${pl(mv.from, true)}${icon('arrow')}${pl(mv.to)}</span></div></div>`;
  }
  if ((ch.added || []).some((x) => x.num === num)) return `<div class="chg-note is-new">${icon('info')}<div><b>Nov u planogramu</b> (${esc(when)})</div></div>`;
  return '';
}



// 14. 11. 2026: every code in a note leads to its article: on a planogram of this phone the article screen, otherwise
// StoreFront for that very code (before: plain text, the employee had to copy it)
function linkNums(text, self) {
  return esc(text).replace(/(?<!\d)(\d{7})(?!\d)/g, (m) => (m === self ? m : S.index.byNum.has(m)
    ? `<button class="link" type="button" data-num="${m}">${m}</button>`
    : `<button class="link" type="button" data-store="${m}" aria-label="Šifra ${m}: otvori u StoreFrontu">${m}</button>`));
}

function renderItem() {
  const { num, info } = S.item;
  const locs = locationsOf(num);
  const li = Math.min(S.item.loc || 0, Math.max(0, locs.length - 1));
  S.item.loc = li;
  const L = locs[li];
  const body = $('#itemBody');
  if (!L) {
    body.innerHTML = '<p class="empty">Ovaj artikal više nije u planogramima.</p>';
    return;
  }
  const plan = L.e.plan;
  const it = L.e.it;
  $('#itemPlan').textContent = core.planTitle(plan);
  let section = L.place ? L.place.section : null;
  if (!section && L.row) {
    const pg = plan.pages[L.row.p];
    const sec = pg && pg.sec >= 0 ? plan.meta.sections[pg.sec] : null;
    section = sec ? `${sec.code} ${sec.name}` : null;
  }
  let h = `<div class="head">
      ${thumb(num, 'thumb-lg', true)}
      <div class="head-text">
        <span class="head-acts"><button class="code-chip" type="button" data-copy="${esc(num)}" aria-label="Kopiraj šifru ${esc(num)}">${esc(num)} ${icon('copy', 'ico-sm')}</button>
          <button class="fav-btn" type="button" data-fav="${esc(num)}" aria-pressed="${isFav(num)}" aria-label="${isFav(num) ? 'Ukloni iz favorita' : 'Dodaj u favorite'}">${isFav(num) ? '★' : '☆'}</button></span>
        <h2 class="title">${esc(it.nm) || 'Bez naziva'}</h2>
        ${section ? `<p class="sub">${esc(section)}</p>` : ''}
      </div>
    </div>`;
  if (info && info.via === 'substitute') {
    h += `<p class="notice">${icon('info')}<span>Skenirana šifra ${esc(info.from)} je zamjena za ovaj artikal.</span></p>`;
  } else if (info && info.via === 'learned') {
    h += `<p class="notice">${icon('link')}<span>Barkod ${esc(info.code)} je povezan s ovim artiklom. <button class="link" type="button" data-unlink="${esc(info.code)}">Promijeni</button></span></p>`;
  }
  h += substNote(num);
  if (locs.length > 1) {
    const many = locs.some((y) => y.e.id !== L.e.id);
    h += `<div class="tabs" role="tablist">${locs.map((x, i) => `<button class="tab" type="button" role="tab" aria-selected="${i === li}" data-loc="${i}">Mjesto ${i + 1}${many ? `, ${esc(core.planTitle(x.e.plan))}` : ''}</button>`).join('')}</div>`;
  }
  // 2.08 (owner, phone 16. 11.): where the article stands comes first; the customers' orders get one short line here
  // (a tap goes to them) and their full block comes right under the drawing, before stock
  const ordFull = ordersBlock(num);
  if (ordFull) h += ordersHint(num);
  // 1.72: the drawing first, right under the article, then stock and sales
  h += changeNote(L.e.id, num);
  h += ctx.mjNoteBox ? ctx.mjNoteBox(num) : ''; // 28. 11. 2026 (P2): MYJYSK's department update about this article
  const page = L.oc ? L.oc.p : L.row ? L.row.p : null;
  // 1.96: places of this article on the same page and segment (BRONSIT: four labels of one floor display), left to right
  const sameSeg = L.oc && L.place && L.place.segment ? locs.filter((x) => x.oc && x.e.id === L.e.id && x.oc.p === L.oc.p && x.place && x.place.segment === L.place.segment)
    .sort((a, b) => a.oc.b[0] - b.oc.b[0]) : [];
  if (page != null) {
    h += `<section class="block">
      <div class="sec-head"><h3>Na planogramu</h3><button class="text-btn" type="button" id="openViewer">Otvori</button></div>
      <button class="plano" type="button" id="crop" aria-label="Otvori planogram na ovom mjestu">
        <canvas></canvas><svg preserveAspectRatio="none"></svg><span class="wait">Crtam planogram</span>
      </button>
      <p class="plano-cap">Stranica ${page + 1} od ${plan.pages.length}${L.place && L.place.segment ? `, segment ${esc(L.place.segment)}` : ''}${sameSeg.length > 1 ? `, oznaka ${sameSeg.indexOf(L) + 1} od ${sameSeg.length} s lijeva` : ''}${L.oc && L.oc.whole
        ? `<span class="plano-note" id="locNote">Mjesto je iz liste artikala (${esc(L.row && L.row.fx ? L.row.fx : `segment ${L.place ? L.place.segment : ''}`)}); tražim šifru na crtežu…</span>` : ''}</p>
    </section>`;
  }
  // 26. 11. 2026 (owner, evening): the customers' orders first right under the drawing, then the other codes of the
  // same article, then the rest
  h += ordFull;
  h += chainBox(num);
  h += `<div class="stock-box" data-stock="${esc(num)}">${stockHtml(num)}</div>`;
  h += ordersBlock(num, { after: true });
  // 27. 11. 2026 (owner, snapshot 01 Bed Linen): the card Modul / Polica / Notch and „Na istoj polici“ are not
  // wanted on the article screen; the drawing shows the place. Only an article without a drawn place keeps a line why.
  if (!(L.place && L.place.segment)) {
    if (L.row) {
      h += `<div class="loc loc-off">
      <div class="loc-grid"><div style="grid-column: span 3"><span>Na listi artikala</span><b class="is-long">${esc(L.row.fx || 'Bez mjesta')}</b></div></div>
      <div class="loc-foot"><p>Ovaj artikal je samo na listi, nije nacrtan na polici.</p></div>
    </div>`;
    } else {
      h += '<div class="loc loc-off"><div class="loc-foot" style="margin:0;padding:0;border:0"><p>Ovaj artikal se spominje u planogramu, ali nema svoje mjesto na crtežu.</p></div></div>';
    }
  }
  // the same note written at several labels ("Display in 4911295 ARE") is shown once
  const notes = new Map(); // text -> other articles it is written at
  for (const k of it.nt) {
    const n = plan.notes[k];
    if (!n) continue;
    if (!notes.has(n.t)) notes.set(n.t, []);
    const owners = notes.get(n.t);
    for (const o of n.o || []) if (o !== num && !owners.includes(o)) owners.push(o);
  }
  if (notes.size) {
    const numLink = (o) => (S.index.byNum.has(o) ? `<button class="link" type="button" data-num="${o}">${o}</button>` : o);
    const list = (xs) => (xs.length > 1 ? `${xs.slice(0, -1).join(', ')} i ${xs[xs.length - 1]}` : xs[0]);
    // 14. 11. 2026: in Bosnian where the instruction is certain (js/note-bs.js), the PDF's words under it
    h += `<section class="block"><div class="sec-head"><h3>${notes.size > 1 ? 'Napomene' : 'Napomena'} u planogramu</h3></div>${[...notes].map(([t, owners]) => {
      const bs = noteBs(t, namesOf);
      return `<p class="note">${linkNums(bs.text, num)}${bs.done ? `<small class="note-orig">U PDF-u: ${esc(bs.orig)}</small>` : ''}${owners.length
      ? `<small>${owners.length > 1 ? 'Uz artikle' : 'Uz artikal'} ${list(owners.map(numLink))}</small>` : ''}</p>`;
    }).join('')}</section>`;
  }
  body.innerHTML = h;
  stockLoad(num);
  if (page != null) paintCrop(L).catch((e) => {
    console.warn('crop', e);
    const w = $('#crop .wait');
    if (w) w.textContent = 'Planogram se ne može prikazati';
  });
}

const blockCache = new Map(); // "planId:page:x,y" -> box
let cropToken = 0;

// The drawn part of the planogram for an article's place, kept as a picture: going back to a place (another tab of
// the same article, the same article scanned again) shows it at once instead of drawing the PDF page again (pdf.js
// scales every product photo of the region on each drawing: most of the time of a crop). At most CROP_KEEP, newest
// kept; dropped when Android asks for memory. Only what is on the phone: nothing is asked from anywhere.
const cropCache = createCropCache(6); // key -> { bmp, w, h, reg, spot, note, focus } (js/crop-cache.js)
let prefetchToken = 0, prefetchTask = null;
const cropTimes = []; let cropHits = 0; // for the diagnostics
const cropDpr = () => Math.min(window.devicePixelRatio || 1, 2.5);
function cropKey(L, num, cw, ch) {
  const at = L.oc ? `o${L.oc.p}:${L.oc.b.join(',')}${L.oc.whole ? `:${num}` : ''}` : `r${L.row.p}:${L.row.b.join(',')}`;
  return `${L.e.id}:${at}:${cw}x${ch}@${cropDpr()}`;
}
function cropRemember(key, canvas, res) {
  if (typeof createImageBitmap !== 'function' || !canvas.width) return;
  createImageBitmap(canvas).then((bmp) => cropCache.put(key, { bmp, w: canvas.width, h: canvas.height, ...res })).catch(() => {});
}
function cropForget() { cropCache.clear(); }
window.onLowMemory = () => { cropForget(); blockCache.clear(); };

/** The planogram around the product, with everything else dimmed. */
let liveTask = null; // the drawing of the crop on screen: a new article or place stops it (fast scanning)
async function paintCrop(L) {
  const token = ++cropToken;
  stopPrefetch();
  if (liveTask) { try { liveTask.cancel(); } catch (e) { /* ended */ } liveTask = null; }
  const box = $('#crop');
  if (!box) return;
  const cw = box.clientWidth, ch = box.clientHeight;
  if (!cw || !ch) return;
  const num = S.item.num;
  const key = cropKey(L, num, cw, ch);
  const hit = cropCache.get(key);
  const canvas = $('#crop canvas');
  let res;
  if (hit) {
    canvas.width = hit.w;
    canvas.height = hit.h;
    canvas.getContext('2d').drawImage(hit.bmp, 0, 0);
    res = hit;
    cropHits++;
  } else {
    const t0 = Date.now();
    try {
      res = await makeCrop(L, num, canvas, cw, ch, () => token === cropToken, (t) => { liveTask = t; });
    } catch (e) {
      if (token !== cropToken || (e && e.name === 'RenderingCancelledException')) return; // replaced by a newer one
      throw e;
    }
    if (!res) return;
    cropTimes.push(Date.now() - t0);
    if (cropTimes.length >= 10) { note(`crtanje planograma (10 zadnjih, ms): ${cropTimes.join(' ')}; iz memorije ${cropHits}`); cropTimes.length = 0; cropHits = 0; }
    cropRemember(key, canvas, res);
  }
  if (token !== cropToken) return;
  // 27. 11. 2026: with the place card gone, the warning lives under the drawing: an article only on the product list
  // whose code is not on the drawing gets its shelf shown with nothing marked, and the employee must know that
  const noteEl = $('#locNote');
  if (noteEl && res.note != null) noteEl.textContent = res.note;
  if (res.spot) drawSpot($('#crop svg'), res.reg, res.spot);
  else svgClear($('#crop svg'), res.reg);
  $('#crop').classList.add('is-ready');
  const w = $('#crop .wait');
  if (w) w.remove();
  // 1.96: the focus belongs to THIS place ("Otvori" after a quick 1 -> 4 -> 2 opened the place drawn before)
  S.item.focus = res.focus ? { ...res.focus, loc: S.item.loc } : null;
  prefetchCrops(num, cw, ch);
}

function stopPrefetch() {
  prefetchToken++;
  if (prefetchTask) { try { prefetchTask.cancel(); } catch (e) { /* done already */ } prefetchTask = null; }
}

/**
 * The other places of the open article are drawn ahead, one after the other, while nothing else is drawn: switching
 * to them is then at once. Stopped as soon as another crop is to be drawn.
 */
function prefetchCrops(num, cw, ch) {
  const my = ++prefetchToken;
  const others = locationsOf(num).filter((x) => x !== undefined).filter((x, i) => i !== S.item.loc && (x.oc || x.row)).slice(0, 2);
  const alive = () => my === prefetchToken && S.item && S.item.num === num;
  (async () => {
    await new Promise((r) => setTimeout(r, 350));
    for (const L of others) {
      if (!alive()) return;
      const key = cropKey(L, num, cw, ch);
      if (cropCache.has(key)) continue;
      const c = document.createElement('canvas');
      let res = null;
      try { res = await makeCrop(L, num, c, cw, ch, alive, (t) => { prefetchTask = t; }); } catch (e) { res = null; }
      prefetchTask = null;
      if (!res || !alive()) return;
      cropRemember(key, c, res);
    }
  })();
}

/**
 * Draws the crop of place L into canvas (cw x ch CSS pixels). Answer { reg, spot, note, focus }: the region drawn, the
 * box to highlight (null: nothing to mark), the text for the list-only note (undefined: none), the focus for the
 * viewer; null when alive() turned false meanwhile.
 */
async function makeCrop(L, num, canvas, cw, ch, alive, onTask) {
  const plan = L.e.plan;
  const pageIdx = L.oc ? L.oc.p : L.row.p;
  const pg = plan.pages[pageIdx];
  const whole = !!(L.oc && L.oc.whole);
  const key = L.oc ? `${L.e.id}:${L.oc.p}:${L.oc.b.join(',')}${whole ? `:${num}` : ''}` : null;
  let blk = L.oc ? (whole ? blockCache.get(key) || null : L.oc.k || blockCache.get(key) || null) : null;
  let target = L.oc ? L.oc.b : L.row.b;
  const doc = await docs.openPlan(L.e.id);
  if (!alive()) return null;
  // only on the product list: its number is written on the drawing all the same (under its photo); mark that,
  // never the whole shelf. Not there: the shelf is shown with nothing marked.
  let label = null, note;
  if (whole) {
    try { label = await docs.findNumber(doc, pageIdx + 1, num, L.oc.b); } catch (e) { label = null; }
    if (!alive()) return null;
    if (label) target = label;
    note = label ? '' : `Na crtežu nema njegove šifre (na listi piše ${L.row && L.row.fx ? L.row.fx : 'ovaj segment'}): pokazana je samo polica.`;
  }
  const region = (focus) => {
    const fw = focus[2] - focus[0], fh = focus[3] - focus[1];
    let w = Math.max(fw * 2.8, fh * 2.8 * (cw / ch), 200);
    w = Math.min(w, pg.w);
    let h = (w * ch) / cw;
    if (h > pg.h) { h = pg.h; w = (h * cw) / ch; }
    let x0 = (focus[0] + focus[2]) / 2 - w / 2;
    let y0 = (focus[1] + focus[3]) / 2 - h / 2;
    x0 = Math.max(Math.min(x0, pg.w - w), Math.min(0, pg.w - w));
    y0 = Math.max(Math.min(y0, pg.h - h), Math.min(0, pg.h - h));
    return [x0, y0, x0 + w, y0 + h];
  };
  const guess = blk || (whole && !label ? L.oc.b : [target[0] - 10, target[1] - 50, target[2] + 10, target[3] + 30]);
  let reg = region(guess);
  const r = await docs.renderRegion(doc, pageIdx + 1, reg, canvas, cw, ch, { maxDpr: 2.5, onTask });
  if (!alive()) return null;
  if (whole && !label) return { reg, spot: null, note, focus: null }; // nothing to mark: the shelf without a highlight
  if (L.oc && !blk) {
    const extra = whole ? { b: label, nums: [num] } : undefined;
    // the photos of the whole page, not only of the part drawn here: facings outside the crop count too
    try { blk = docs.blockFor(plan, L.oc, await docs.photosOf(doc, pageIdx + 1), extra); } catch (e) { blk = null; }
    if (!blk) blk = docs.blockFor(plan, L.oc, r.photos, extra);
    if (blk) blockCache.set(key, blk);
    const inside = blk && blk[0] >= reg[0] && blk[2] <= reg[2] && blk[1] >= reg[1] && blk[3] <= reg[3];
    if (blk && !inside) {
      reg = region(blk);
      await docs.renderRegion(doc, pageIdx + 1, reg, canvas, cw, ch, { maxDpr: 2.5, onTask });
      if (!alive()) return null;
    }
  }
  // 1.96 (owner, BRONSIT 6112159 "Mjesto 1..4"): several labels of this article under one product block (a floor
  // display with a label on each side): the block was the same for all, so every place showed the same frame. Then
  // the label of THIS place is marked; the block stays in the picture around it.
  const inBlk = (b) => blk && (b[0] + b[2]) / 2 >= blk[0] - 2 && (b[0] + b[2]) / 2 <= blk[2] + 2 && b[1] >= blk[1] - 2 && b[1] <= blk[3] + 40;
  const shared = !!(blk && L.oc && !whole && L.e.it.oc.filter((o) => o.p === pageIdx && inBlk(o.b)).map((o) => o.b.map((v) => Math.round(v)).join(',')).filter((v, i, a) => a.indexOf(v) === i).length > 1);
  const spot = shared ? [target[0] - 3, target[1] - 3, target[2] + 3, target[3] + 3]
    : blk ? [Math.min(blk[0], target[0]), Math.min(blk[1], target[1]), Math.max(blk[2], target[2]), Math.max(blk[3], target[3])] : target;
  return { reg, spot, note, focus: { id: L.e.id, page: pageIdx, box: spot } };
}

function svgClear(svg, reg) {
  svg.setAttribute('viewBox', `${reg[0]} ${reg[1]} ${reg[2] - reg[0]} ${reg[3] - reg[1]}`);
  svg.innerHTML = '';
}

function drawSpot(svg, reg, b) {
  const pad = 2.5;
  const x0 = b[0] - pad, y0 = b[1] - pad, x1 = b[2] + pad, y1 = b[3] + pad;
  const r = Math.min(6, (x1 - x0) / 6, (y1 - y0) / 6);
  svg.setAttribute('viewBox', `${reg[0]} ${reg[1]} ${reg[2] - reg[0]} ${reg[3] - reg[1]}`);
  svg.innerHTML = `<path class="spot-dim" fill-rule="evenodd" d="M${reg[0] - 5} ${reg[1] - 5}H${reg[2] + 5}V${reg[3] + 5}H${reg[0] - 5}Z M${x0 + r} ${y0}H${x1 - r}Q${x1} ${y0} ${x1} ${y0 + r}V${y1 - r}Q${x1} ${y1} ${x1 - r} ${y1}H${x0 + r}Q${x0} ${y1} ${x0} ${y1 - r}V${y0 + r}Q${x0} ${y0} ${x0 + r} ${y0}Z"/>
    <rect class="spot-glow" x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" rx="${r}" vector-effect="non-scaling-stroke"/>
    <rect class="spot-edge" x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" rx="${r}" vector-effect="non-scaling-stroke"/>`;
}

function openItem(num, info = {}, opts = {}) {
  stopPrefetch(); // the places of the previous article are not needed any more
  rememberRecent(num);
  S.item = { num, info, loc: 0, focus: null };
  go('item', S.item, { replace: !!opts.replace });
  renderItem();
}

function openViewerForItem() {
  if (!S.item) return;
  const L = locationsOf(S.item.num)[S.item.loc];
  if (!L) return;
  const page = L.oc ? L.oc.p : L.row ? L.row.p : 0;
  // a list-only article whose number is not on the drawing: the page without a highlight (never the whole shelf)
  const focus = S.item.focus && S.item.focus.loc === S.item.loc && S.item.focus.page === page ? S.item.focus.box : L.oc ? (L.oc.whole ? null : L.oc.b) : L.row ? L.row.b : null;
  viewer.open(L.e.id, page, focus);
}


  return { cropForget, openItem, openViewerForItem, renderItem, stopPrefetch };
}
