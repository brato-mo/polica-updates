// 24. 11. 2026 (owner): "Regulacija i statusi". What a status means (a tap on the status of the article screen), which
// code a stock adjustment takes in a BiH store, the rules around it, and a look at the store's own adjustments of the
// last ~6 months (StoreFront "Povijest regulacije zalihe", read only): this article's adjustments with code and comment,
// articles taken off with −81 and not put back, and adjustments above 8 € (15,65 KM) without a comment. Nothing here writes.
import { ST, ST_ORDER, REG, REG_ORDER, REG_RULES, BIH_CODES, RULE_SRC, stContext, regsOf, open81, noComment, byCode, day, rulesChanged, storeChanged, storeSig } from './regs.js';

export function createRegsUi(ctx) {
  const { S, A, esc, icon, openSheet, closeSheet, stCall, offline, storeNow, openArticle, repaint, whole, money, ageText, saveUser, mjOn, toast } = ctx;
  const DAY = 86400000;
  // 24. 11. 2026: what the app last learned about the rules: MYJYSK's articles (rules, rulesAt), StoreFront's codes and
  // names (codes, names, namesAt), and what the employee marked as looked at (seen). Kept in user.json, small.
  const W = () => {
    const w = S.user.regWatch && typeof S.user.regWatch === 'object' ? S.user.regWatch : (S.user.regWatch = {});
    if (!w.seen || typeof w.seen !== 'object') w.seen = { rules: {}, sig: '' };
    if (!w.seen.rules) w.seen.rules = {};
    return w;
  };
  const EVERY = 15 * 60000; // an article screen reads the list again after 15 min (one request, ~1 s, in the background)
  const R = { at: 0, store: '', l: null, codes: null, busy: false, err: '', tried: 0 };
  const allOpen = new Set(); // articles whose whole adjustment list is shown

  const regName = (c) => (REG[c] ? REG[c].name : (W().names && W().names.rc && W().names.rc[c]) || '');
  const stName = (c) => (ST[c] ? ST[c].name : (W().names && W().names.st && W().names.st[c]) || '');
  const km = (v) => `${v < 0 ? '−' : ''}${money(Math.abs(v))} KM`; // a real minus, as the history's −1
  const mine = () => R.l && (!storeNow() || R.store === storeNow());
  const codes = () => (Array.isArray(R.codes) && R.codes.length ? R.codes : Array.isArray(W().codes) && W().codes.length ? W().codes : BIH_CODES);

  /** The store's adjustments, read in the background when older than 15 min (force: the employee asked, now). */
  function sync(force = false, done = null, names = false) {
    if (R.busy || !(S.user.store && S.user.store.ok) || S.user.sfSignedOut || offline()) { if (done) done(); return; }
    const fresh = mine() && Date.now() - R.at < EVERY;
    if (!force && !names && (fresh || Date.now() - R.tried < 5 * 60000)) { if (done) done(); return; }
    R.busy = true; R.tried = Date.now(); R.err = '';
    stCall({ mode: 'regs', bg: !force, names: !!names }, (r) => {
      R.busy = false;
      if (r && r.how === 'ok' && r.res && Array.isArray(r.res.l) && r.res.store) {
        R.at = Date.now(); R.store = String(r.res.store).slice(0, 12); R.l = r.res.l; R.codes = Array.isArray(r.res.codes) ? r.res.codes : null;
        learn(r.res);
      } else R.err = r && r.how === 'login' ? 'StoreFront traži prijavu' : offline() ? 'nema interneta' : 'StoreFront nije odgovorio';
      repaint();
      paintGuide();
      if (done) done();
    });
    paintGuide();
  }

  /** What StoreFront said about its codes (every reading) and names (once a day). */
  function learn(res) {
    const w = W();
    let ch = false;
    if (Array.isArray(res.codes) && res.codes.length && JSON.stringify(res.codes) !== JSON.stringify(w.codes)) { w.codes = res.codes.slice(0, 20); ch = true; }
    if (res.names && typeof res.names === 'object') { w.names = { rc: res.names.rc || {}, st: res.names.st || {} }; w.namesAt = Date.now(); ch = true; }
    if (ch) { saveUser(); paintAlert(); }
  }

  /** MYJYSK: the articles the texts come from (myjysk-ar.js 'rules', read only), at most once a day. */
  function rulesCheck(force = false) {
    const w = W();
    if (R.rulesBusy || !mjOn() || !A.myjyskAr || (S.ar && S.ar.busy)) return false;
    if (!force && (Date.now() - (w.rulesAt || 0) < DAY || Date.now() - (R.rulesTried || 0) < 3 * 3600000)) return false;
    R.rulesBusy = true; R.rulesTried = Date.now();
    const prev = window.onMjAr;
    // the answer comes on the AR form's callback (MyjyskTask): ours is the one that says 'rules', or an answer
    // without a result while no AR job runs (a sign-in or an error of this reading)
    window.onMjAr = (a) => {
      const mineAns = a && a.res && a.res.kind === 'rules';
      if (!mineAns && (a && a.res || (S.ar && S.ar.busy))) return prev ? prev(a) : undefined;
      window.onMjAr = prev;
      R.rulesBusy = false;
      if (mineAns && Array.isArray(a.res.list)) {
        w.rules = a.res.list.slice(0, 20).map((x) => ({ id: String(x.id), title: String(x.title || '').slice(0, 120), upd: String(x.upd || '').slice(0, 19), kb: +x.kb || 0, topic: +x.topic || 0, h: String(x.h || '').slice(0, 8), err: x.err ? String(x.err).slice(0, 40) : undefined }));
        w.rulesAt = Date.now();
        saveUser();
        paintGuide(); paintAlert();
        if (force) toast(notes().count ? 'Ima promjena u pravilima: pogledaj Regulacija i statusi.' : 'Pravila u MYJYSK-u nisu mijenjana.');
      } else if (force) toast(a && a.how === 'login' ? 'MYJYSK traži prijavu.' : 'MYJYSK nije odgovorio.');
      return undefined;
    };
    try { A.myjyskAr(JSON.stringify({ mode: 'rules', ids: RULE_SRC.map((x) => x.id) })); } catch (e) { window.onMjAr = prev; R.rulesBusy = false; return false; }
    return true;
  }

  /** Once a day while the app is open: MYJYSK's articles and StoreFront's codes and names. */
  function daily() {
    rulesCheck(false);
    if (Date.now() - (W().namesAt || 0) > DAY && Date.now() - (R.namesTried || 0) > 3 * 3600000 && !R.busy) {
      R.namesTried = Date.now();
      sync(false, null, true);
    }
  }

  /** What changed against the texts of this app version and was not marked as looked at. */
  function notes() {
    const w = W();
    const rules = rulesChanged(w.rules, w.seen.rules);
    const st = storeChanged(w.codes, w.names);
    const sig = storeSig(st);
    const store = sig && sig !== w.seen.sig ? st : { added: [], gone: [], status: [] };
    return { rules, store, sig, count: rules.length + store.added.length + store.gone.length + store.status.length };
  }

  function alertHtml() {
    const n = notes();
    if (!n.count) return '';
    const day0 = (iso) => (iso ? day(Date.parse(`${iso.slice(0, 19)}Z`)) : '');
    return `<div class="rg-alert">${icon('info')}<div><b>Promjena u pravilima</b>
      ${n.rules.map((x) => `<p>MYJYSK: „${esc(x.title)}“ promijenjeno ${esc(day0(x.upd))} Tekst u aplikaciji je od ${esc(day0(x.was))} ${x.path ? `<button class="text-btn" type="button" data-reg-mj="${esc(x.path)}">Otvori u MYJYSK-u</button>` : ''}</p>`).join('')}
      ${n.store.added.map((x) => `<p>StoreFront: Regulacija nudi novi kod <b>${esc(x.c)}</b>${x.name ? ` „${esc(x.name)}“` : ''}. Aplikacija ga još ne opisuje.</p>`).join('')}
      ${n.store.gone.map((c) => `<p>StoreFront: kod <b>${esc(c)}</b> više nije u Regulaciji.</p>`).join('')}
      ${n.store.status.map((x) => `<p>StoreFront ima novi status <b>${esc(x.c)}</b>${x.name ? ` „${esc(x.name)}“` : ''}. Aplikacija ga još ne opisuje.</p>`).join('')}
      <p class="rg-alert-foot">Dok se aplikacija ne ažurira, vrijedi ono što piše u MYJYSK-u i StoreFrontu. <button class="text-btn" type="button" data-reg-seen>Pregledao sam</button></p></div></div>`;
  }
  function paintAlert() {
    const el = document.querySelector('#rgAlert');
    if (el) el.innerHTML = alertHtml();
    const bar = document.querySelector('#regBar');
    if (bar) bar.innerHTML = barHtml();
  }

  // ---------------------------------------------------------------- the article screen

  /** The status on the article screen: a button that says what it means. */
  function stBtn(st, num) {
    const x = ST[st];
    const label = x ? x.short : stName(st);
    return `<button type="button" class="pill st-btn ${st === '21' || st === '81' ? 'pill-warn' : 'pill-muted'}" data-st-info="${esc(st)}" data-st-num="${esc(num || '')}">Status ${esc(st)}${label ? `: ${esc(label)}` : ''} <span aria-hidden="true">ⓘ</span></button>`;
  }

  /** One short line under the facts when the status is about to change or asks for something (DD past, MFD > 13 months). */
  function stLine(md) {
    const c = stContext(md).filter((x) => x.k !== 'since' && (x.warn || x.k === 'fut'));
    return c.length ? `<p class="stk-line st-ctx-line${c.some((x) => x.warn) ? ' is-warn' : ''}">${c.map((x) => esc(x.t)).join(' ')}</p>` : '';
  }

  /** This article's adjustments (code, quantity, comment), from the store's list. */
  function block(num) {
    const guide = '<button class="text-btn" type="button" data-reg-guide="kod">Koji kod?</button>';
    if (!mine()) {
      return R.busy ? `<p class="stk-regs-h"><b>Regulacije</b><span><i class="mj-busy"></i> učitavam…</span>${guide}</p>`
        : `<p class="stk-regs-h"><b>Regulacije</b><span>${R.err ? esc(R.err) : 'nisu učitane'}</span>${guide}</p>`;
    }
    const rows = regsOf(R.l, num);
    if (!rows.length) return `<p class="stk-regs-h"><b>Regulacije</b><span>nema zadnjih 6 mj.</span>${guide}</p>`;
    const all = allOpen.has(num), shown = all ? rows : rows.slice(0, 4);
    return `<div class="stk-regs"><p class="stk-regs-h"><b>Regulacije</b><span>zadnjih 6 mj. · ${rows.length}</span>${guide}</p>
      ${shown.map((r) => `<div><span>${esc(day(r[1]))}</span><span><b>${esc(r[3])}</b> ${esc(regName(r[3]) || 'kod')}${r[5] ? `<small>„${esc(r[5])}“</small>` : ''}</span><b class="${r[2] < 0 ? 'is-out' : 'is-in'}">${r[2] > 0 ? '+' : r[2] < 0 ? '−' : ''}${whole(Math.abs(r[2]))}</b></div>`).join('')}
      ${rows.length > 4 ? `<button class="text-btn" type="button" data-reg-all="${esc(num)}">${all ? 'Prikaži manje' : `Prikaži sve (${rows.length})`}</button>` : ''}</div>`;
  }

  // ---------------------------------------------------------------- the status sheet

  function stBody(st, md) {
    const x = ST[st];
    if (!x) return `<p>${stName(st) ? `StoreFront ga zove „${esc(stName(st))}“. ` : ''}Aplikacija ovaj status još ne opisuje: šta znači i šta raditi provjeri u MYJYSK-u ili kod voditelja.</p>`;
    const c = md && md.st === st ? stContext(md) : [];
    return `${c.map((y) => `<p class="st-ctx${y.warn ? ' is-warn' : ''}">${esc(y.t)}</p>`).join('')}
      <p>${esc(x.mean)}</p>
      <p class="st-order"><b>Naručivanje:</b> ${x.order ? 'iz DC-a ili od dobavljača, da.' : 'iz DC-a ili od dobavljača ne (naručuju se samo 11 i 41).'} Iz druge prodavnice može bilo koji status.</p>
      ${x.todo ? `<ul class="st-todo">${x.todo.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : ''}`;
  }

  function openStatus(st, num) {
    const x = ST[st];
    const d = num && S.stock && S.stock.get(num);
    const md = d && d.d && d.d.md;
    openSheet({
      title: `Status ${st}${stName(st) ? ` · ${stName(st)}` : ''}`,
      body: `${stBody(st, md)}<p class="hint">StoreFront (naziv i datumi statusa) i MYJYSK: SOR 1.01, Smjernice za clearance, Samo online, St. kod 31.</p>`,
      actions: [
        { label: 'Svi statusi i kodovi regulacije', kind: 'btn-soft', onClick: () => openGuide('st') },
        { label: 'Zatvori', onClick: () => closeSheet() },
      ],
    });
  }

  // ---------------------------------------------------------------- the guide

  function codesHtml() {
    const have = codes();
    const added = storeChanged(W().codes, W().names).added;
    return added.map((x) => `<div class="rg-row is-new"><b class="rg-code">${esc(x.c)}</b><div><p class="rg-name"><b>${esc(x.name || 'Novi kod')}</b><small>novo u StoreFrontu</small></p><p>Aplikacija ovaj kod još ne opisuje. Kada se koristi, piše u MYJYSK-u (SOR 6.03 Usklađivanje zaliha).</p></div></div>`).join('') + REG_ORDER.map((c) => {
      const r = REG[c];
      const tag = r.auto ? 'automatski' : r.claim ? 'kroz Reklamaciju' : have.includes(c) ? r.dir : 'nije u tvojoj Regulaciji';
      return `<div class="rg-row${!r.auto && !r.claim && !have.includes(c) ? ' is-off' : ''}"><b class="rg-code">${esc(c)}</b><div><p class="rg-name"><b>${esc(r.name)}</b><small>${esc(tag)}</small></p><p>${esc(r.when)}</p></div></div>`;
    }).join('');
  }

  function statusesHtml() {
    return ST_ORDER.map((c) => `<details class="st-row"><summary><b class="rg-code">${esc(c)}</b><span>${esc(ST[c].name)}</span></summary>${stBody(c, null)}</details>`).join('');
  }

  const artRow = (num, title, right, sub = '') => `<button type="button" class="rg-art" data-reg-open="${esc(num)}"><span><b>${esc(num)}</b> ${esc(title || '')}${sub ? `<small>${sub}</small>` : ''}</span><span>${right}</span></button>`;

  function controlHtml() {
    if (!mine()) {
      return `<p>${R.busy ? '<i class="mj-busy"></i> Čitam regulacije iz StoreFronta…' : R.err ? `Nije učitano: ${esc(R.err)}.` : 'Regulacije prodavnice zadnjih ~6 mjeseci iz StoreFronta (samo čitanje).'}</p>
        ${R.busy ? '' : '<button class="btn btn-soft btn-small" type="button" data-reg-load>Učitaj iz StoreFronta</button>'}`;
    }
    const now = Date.now();
    const o81 = open81(R.l, now), nc = noComment(R.l, now, 30), wk = byCode(R.l, now, 7);
    const from = R.l.length ? day(R.l[R.l.length - 1][1]) : '';
    return `<p class="rg-meta">${R.l.length} regulacija${from ? ` od ${esc(from)}` : ''} · pročitano ${esc(ageText(R.at))}${R.busy ? ' · <i class="mj-busy"></i>' : ' · <button class="text-btn" type="button" data-reg-load>Osvježi</button>'}</p>
      <h4>Kod 81: skinuto, nije vraćeno (${o81.length})</h4>
      ${o81.length ? o81.slice(0, 40).map((x) => artRow(x.num, x.title, `<b class="${x.days > 60 ? 'is-out' : ''}">${x.days} ${x.days === 1 ? 'dan' : 'dana'}</b>`, `${whole(-x.q)} kom${x.days > 60 ? ' · duže od 2 mjeseca' : ''}`)).join('') : '<p class="rg-ok">Nema artikala na kodu 81 bez povratka.</p>'}
      <p class="hint">Najviše 2 mjeseca; LR provjerava svake sedmice. Vidi se samo ono što je skinuto u periodu koji StoreFront daje.</p>
      <h4>Iznad 8 € (15,65 KM) bez komentara, 30 dana (${nc.length})</h4>
      ${nc.length ? nc.slice(0, 40).map((r) => artRow(r[0], r[6], `<b class="${r[2] < 0 ? 'is-out' : 'is-in'}">${km(r[4])}</b>`, `${esc(day(r[1]))} · kod ${esc(r[3])} · ${r[2] > 0 ? '+' : '−'}${whole(Math.abs(r[2]))} kom`)).join('') : '<p class="rg-ok">Sve korekcije iznad 8 € (15,65 KM) imaju komentar.</p>'}
      <h4>Zadnjih 7 dana po kodu</h4>
      ${wk.length ? `<div class="rg-week">${wk.map((x) => `<div><b class="rg-code">${esc(x.code)}</b><span>${esc(regName(x.code) || 'kod')}</span><span>${x.out ? `−${whole(x.out)}` : ''}${x.out && x.in ? ' / ' : ''}${x.in ? `+${whole(x.in)}` : ''} kom</span><span>${km(x.km)}</span></div>`).join('')}</div>` : '<p class="rg-ok">Nema regulacija zadnjih 7 dana.</p>'}`;
  }

  function paintGuide() {
    const el = document.querySelector('#rgControl');
    if (el) el.innerHTML = controlHtml();
  }

  function openGuide(open = 'kod') {
    openSheet({
      title: 'Regulacija i statusi',
      cls: 'sheet-regs',
      body: `<div id="rgAlert">${alertHtml()}</div><details class="rg-sec"${open === 'kod' ? ' open' : ''}><summary>Koji kod za koju situaciju</summary>${codesHtml()}
          <p class="hint">Regulacija u StoreFrontu: artikal → Prilagodi → Dodaj ili Ukloni → količina → kod → komentar → Pošalji.</p></details>
        <details class="rg-sec"><summary>Pravila: komentar, otpis, odobrenje</summary><ul class="st-todo">${REG_RULES.map((t) => `<li>${esc(t)}</li>`).join('')}</ul></details>
        <details class="rg-sec"${open === 'st' ? ' open' : ''}><summary>Statusi artikala</summary>${statusesHtml()}</details>
        <details class="rg-sec"${open === 'kontrola' ? ' open' : ''} data-rg-control><summary>Kontrola regulacija prodavnice</summary><div id="rgControl">${controlHtml()}</div></details>
        <p class="hint">Izvori: StoreFront (nazivi kodova i statusa, kodovi tvoje Regulacije) i MYJYSK: SOR 6.03 Usklađivanje zaliha, Reguliranje zalihe, Otpisivanje artikala, Pregled usklađivanja po danima, SOR 1.01, Smjernice za clearance. Tekst napisan 24. 11. 2026.
          ${W().rulesAt ? `Aplikacija ih provjerava jednom dnevno, zadnje ${esc(ageText(W().rulesAt))}.` : 'Aplikacija ih provjerava jednom dnevno.'} <button class="text-btn" type="button" data-reg-check>Provjeri sada</button></p>`,
      actions: [{ label: 'Zatvori', onClick: () => closeSheet() }],
    });
    for (const el of [document.querySelector('#sheet'), document.querySelector('#sheetBody')]) if (el) el.scrollTop = 0; // the alert first, not where the sheet was
    if (open === 'kontrola') sync(!mine());
  }

  /** Clicks of the article screen and the sheets; true when handled. */
  function onClick(t) {
    if (t.dataset.stInfo) { openStatus(t.dataset.stInfo, t.dataset.stNum || ''); return true; }
    if (t.dataset.regGuide !== undefined) { openGuide(t.dataset.regGuide || 'kod'); return true; }
    if (t.id === 'regBar') { openGuide('kod'); return true; }
    if (t.dataset.regLoad !== undefined) { sync(true); return true; }
    if (t.dataset.regAll) { const n = t.dataset.regAll; if (allOpen.has(n)) allOpen.delete(n); else allOpen.add(n); repaint(); return true; }
    if (t.dataset.regOpen) { const n = t.dataset.regOpen; closeSheet(); openArticle(n); return true; }
    if (t.dataset.regMj) { try { A.myjyskOpen(t.dataset.regMj); } catch (e) { toast('Ova verzija ne može otvoriti MYJYSK.'); } return true; }
    if (t.dataset.regCheck !== undefined) {
      if (!mjOn()) { toast('MYJYSK nije uključen u aplikaciji.'); return true; }
      if (!rulesCheck(true)) toast(R.rulesBusy ? 'Provjera već traje.' : 'Provjera sada nije moguća.');
      else toast('Provjeravam pravila u MYJYSK-u…');
      if (Date.now() - (W().namesAt || 0) > 3600000) sync(false, null, true);
      return true;
    }
    if (t.dataset.regSeen !== undefined) {
      const w = W(), n = notes();
      for (const x of n.rules) w.seen.rules[x.id] = x.h;
      if (n.sig) w.seen.sig = n.sig;
      saveUser();
      paintAlert();
      return true;
    }
    return false;
  }

  // the guide's "Kontrola" opened by hand reads the list (if it is not there yet)
  document.addEventListener('toggle', (ev) => {
    const d = ev.target;
    if (d && d.matches && d.matches('[data-rg-control]') && d.open) sync(!mine());
  }, true);

  const barHtml = () => {
    const n = notes().count;
    return `${icon('list')}<span><b>Regulacija i statusi</b><small${n ? ' class="rg-bar-warn"' : ''}>${n ? 'Promjena u pravilima: pogledaj' : 'Koji kod za otpis, šta znači status, kod 81 i komentari'}</small></span><span class="go">Otvori</span>`;
  };

  return { sync, daily, rulesCheck, notes, stBtn, stLine, block, openStatus, openGuide, onClick, bar: barHtml, state: R };
}
