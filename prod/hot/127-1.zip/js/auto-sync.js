// 2.15 (owner, 18. 11. 2026): Narudžbe and Minus lista keep themselves fresh while the app is on screen.
//   Narudžbe     every 10 min (store-task 'ordsync': the tab lists with their lines, ~40 kB, history only of new
//                orders); at start when older than 2 min, back from the background when older than 10, on opening
//                Narudžbe when older than 5
//   Minus lista  every 30 min a light look ('minuspeek', a few kB); only when it differs, the usual full reading
//                (MinusReader, with the replacement chains)
// Only READS. Never a Minus or a Regulacija, never a repeated sending, never a waiting state changed: the look does
// not run at all while a sending is under way or its outcome is unknown, and the app's own records (Čeka Regulaciju,
// picks, the sending record) are other keys of user.json that a reading never touches.
// Background work of the shared StoreFront queue (bg: true): what the employee does goes first (StoreTask.rank).
// A reading that fails keeps what was there (with the time of the last good one); a half list is never taken.
// One reading of a kind at a time; an answer that comes after a newer reading (Osvježi) or a sign-out is dropped.
import * as orderWaiting from './order-waiting.js';

export const ORD_EVERY = 10 * 60000;
export const ORD_BOOT = 2 * 60000;
export const ORD_OPEN = 5 * 60000;
export const MIN_EVERY = 30 * 60000;
export const MARK_MS = 3 * 3600000; // how long "Nova" / "Stiglo" stays on a card
const MAX_FAILS = 3; // then it waits for the next start, return to the app or opening of the screen

/**
 * One short mark of a minus list (the same function as msig in store-task.js; tests/auto-sync.test.mjs).
 * 2.15 audit: an unknown quantity is "?" (never the mark of a real 0), and the number of all rows of the list
 * (total, also the ones the app does not show) is part of it.
 */
export function minusSig(items, total) {
  const q = (v) => (typeof v === 'number' && Number.isFinite(v) ? String(v) : '?');
  const ok = (items || []).filter((x) => x && /^\d{7}$/.test(String(x.num)));
  const k = `n${typeof total === 'number' && Number.isFinite(total) ? total : '?'}|` + ok.map((x) => `${x.num}:${q(x.qty)}:${q(x.blocked)}`).sort().join(',');
  let h = 5381;
  for (let i = 0; i < k.length; i++) h = ((h * 33) ^ k.charCodeAt(i)) >>> 0;
  return `${ok.length}:${h.toString(16)}`;
}

/** What changed between two readings of one store's orders: new orders, goods that came in, other state changes. */
export function orderDiff(prev, next) {
  const P = new Map(orderWaiting.uniqueOrders(prev || []).map((o) => [o.no, o]));
  const out = { added: [], arrived: [], part: [], state: [] };
  const readyBy = (o) => {
    const m = new Map();
    for (const it of o.items || []) { const k = orderWaiting.numKey(it.num); if (orderWaiting.lineKey(it.st) === 'ready') m.set(k, (m.get(k) || 0) + 1); }
    return m;
  };
  for (const o of orderWaiting.uniqueOrders(next || [])) {
    const p = P.get(o.no);
    if (!p) { out.added.push(o.no); continue; }
    if (!p.items || !o.items) continue; // one of them was not read: nothing is concluded
    const a = orderWaiting.orderState(p), b = orderWaiting.orderState(o);
    // an order read only partly in either reading says nothing sure about its state (#23)
    if (a.partial || b.partial || a.key === 'unknown' || b.key === 'unknown') continue;
    const ra = readyBy(p), rb = readyBy(o);
    // goods came in: "Roba stigla" only when the whole order is in now, else "Stigao dio robe" (2.15 audit)
    if ([...rb].some(([k, c]) => c > (ra.get(k) || 0))) { (b.key === 'ready' ? out.arrived : out.part).push(o.no); continue; }
    if (a.key !== b.key) out.state.push(o.no);
  }
  return out;
}

/** What changed on the minus list: new articles, other quantities (gone ones are simply not there any more). */
export function minusDiff(prev, next) {
  const P = new Map((prev || []).map((x) => [x.num, x]));
  const out = { added: [], qty: [], gone: [] };
  const seen = new Set();
  for (const x of next || []) {
    seen.add(x.num);
    const p = P.get(x.num);
    if (!p) out.added.push(x.num);
    else if (+p.qty !== +x.qty || +(p.blocked || 0) !== +(x.blocked || 0)) out.qty.push(x.num);
  }
  for (const k of P.keys()) if (!seen.has(k)) out.gone.push(k);
  return out;
}

/** Everything of the orders that the screen shows: equal marks mean nothing is drawn again. */
export function listSig(list) {
  return JSON.stringify(orderWaiting.uniqueOrders(list || []).map((o) => [o.no, (o.tabs && o.tabs.length ? o.tabs : [o.tab]).join('/'), o.status || '', !!o.pay, o.date || '',
    o.n || 0, o.name || '', o.ph || '', o.note || '', o.made || '', (o.items || []).map((it) => [String(it.num), +it.qty || 0, it.st || '', it.hq ?? '', it.hs || ''])])
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)));
}

/** The oldest entry of an order's history (when the order was made, 14. 11. 2026) and its kind. */
export function madeOf(h, orderTime) {
  let first = null, type = '';
  for (const ev of h || []) {
    const at = orderTime.stamp(ev && ev.f);
    if (at && (!first || at.key < first.key)) { first = at; type = /^[A-Z][A-Z0-9_]{0,40}$/.test(ev.t || '') ? ev.t : ''; }
  }
  return first ? { made: first.text, madeType: type } : null;
}

/**
 * The orders of an ordsync answer as the app keeps them (the shape of OrdersActivity's reading, window.onOrders):
 * times turned into the app's own, and what only the history gives (made, note) kept from the earlier reading.
 */
export function mergeOrders(prevList, fresh, orderTime) {
  const prev = new Map((prevList || []).map((x) => [x.no, x]));
  return (fresh || []).map((x) => {
    const old = prev.get(x.no) || {};
    const { rcF, cF, cI, c, h, ...o } = x;
    const receipt = orderTime.stamp(rcF);
    const m = h ? madeOf(h, orderTime) : null;
    const made = orderTime.keepTime(m ? m.made : '', old.made);
    const madeType = made && m && made === m.made ? m.madeType : made && made === old.made ? old.madeType : undefined;
    const note = o.note || (h ? undefined : old.note);
    const out = { ...o, items: o.items || old.items || null,
      receiptCreated: orderTime.keepTime(receipt ? receipt.text : '', old.receiptCreated),
      orderCreated: orderTime.keepTime(orderTime.fromApi(cF, cI, c), old.orderCreated), made };
    if (madeType) out.madeType = madeType;
    if (note) out.note = note; else delete out.note;
    return out;
  });
}

export function createAutoSync(ctx) {
  const { S, cfg, stCall, saveUser, toast, top, plural, orderTime, minusop } = ctx;
  const now = () => (ctx.now ? ctx.now() : Date.now());
  const st = {
    ord: { busy: false, fails: 0, until: 0, gen: 0, err: '', every: ORD_EVERY, runs: 0 },
    min: { busy: false, fails: 0, until: 0, err: '', every: MIN_EVERY, runs: 0, reads: 0 },
  };
  let started = false;
  S.fg = S.fg !== false;

  // 2.15 audit: after "Odjavi se iz StoreFronta" nothing is read by itself until the employee signs in again
  const ordOn = () => cfg().autoOrders !== false && !!S.user.orders && !!ctx.A.storeTask && !S.user.sfSignedOut;
  const minOn = () => cfg().autoMinus !== false && !!(S.user.minus && S.user.minus.items) && !!ctx.A.storeTask && !S.user.sfSignedOut;
  // 2.15 audit (emulator): a reading "from the future" (the phone's clock was set back) has an unknown age: read now
  const age = (at) => { const a = now() - (at || 0); return a < 0 ? Infinity : a; };
  const ordAge = () => (S.user.orders ? age(S.user.orders.at) : Infinity);
  // the last check (a look or a reading: every reading sets seen too), not the larger of the two times
  const minAge = () => { const m = S.user.minus; return m ? age(m.seen || m.at) : Infinity; };
  // a Minus/Regulacija sending under way or with an unknown outcome: no look at all (nothing may look like its answer)
  const minusLocked = () => !!S.minusApplying || !!S.minusBusy || !!(minusop && minusop.locks && minusop.locks(S.minusOp));

  function fail(x, r) {
    x.fails++;
    x.err = r && r.how === 'login' ? 'login' : r && /offline/.test(String(r.err || '')) ? 'offline' : 'error';
    x.errAt = now();
    // a sign-in that ran out, or three failures in a row: no more tries until the employee comes back to the app
    x.until = x.err === 'login' || x.fails >= MAX_FAILS ? Infinity : now() + Math.min(x.every, 60000 * 2 ** x.fails);
  }
  function good(x) { x.fails = 0; x.err = ''; x.until = 0; x.okAt = now(); }

  // ---------------------------------------------------------------- Narudžbe
  function ordersDue(min) { return S.fg && ordOn() && !st.ord.busy && !S.ordReading && now() >= st.ord.until && ordAge() >= min; }
  function runOrders(why) {
    const o = S.user.orders;
    st.ord.busy = true;
    st.ord.runs++;
    const gen = st.ord.gen;
    const known = orderWaiting.uniqueOrders(o.list).filter((x) => x.items).map((x) => x.no);
    const tabs = ctx.tabs();
    const job = stCall({ mode: 'ordsync', bg: true, tabs, known, hist: 30 }, (r) => { st.ord.busy = false; ordAnswer(r, gen, why, tabs.join(',')); });
    if (!job) st.ord.busy = false;
    return !!job;
  }
  function addMarks(key, list, kind) {
    const m = S.user[key] || (S.user[key] = {});
    for (const id of list) m[id] = { k: kind, at: now() };
  }
  function prune(key) {
    const m = S.user[key];
    if (!m) return;
    for (const [k, v] of Object.entries(m)) if (!v || now() - v.at > MARK_MS) delete m[k];
  }
  function ordAnswer(r, gen, why, tabs) {
    // a newer reading (Osvježi) or a sign-out came in between: this answer is older than what the app has
    if (gen !== st.ord.gen || !S.user.orders) return;
    if (!r || r.how !== 'ok' || !r.res || !Array.isArray(r.res.orders)) { fail(st.ord, r); ctx.ageChanged(); return; }
    good(st.ord);
    const res = r.res, prev = S.user.orders;
    const other = !!(prev.store && res.store && prev.store !== res.store);
    const fresh = orderTime.sorted(mergeOrders(other ? [] : prev.list, res.orders, orderTime));
    const changed = other || listSig(prev.list) !== listSig(fresh);
    // the first look after a reading through the Customer Orders page does not know that reading's store: it only
    // learns it (no "Nova" marks), so another store's orders can never look like new ones. 2.15 audit: the same when
    // other tabs were read before (a tab switched on in Postavke is not a pile of new orders)
    const d = other || !prev.store || (prev.tabs && prev.tabs !== tabs) ? null : orderDiff(prev.list, fresh);
    S.user.orders = { ...prev, at: now(), list: fresh, store: res.store || prev.store || '', tabs, ...(res.tot ? { tot: res.tot } : {}) };
    S.site = null; // the numbers of the start's StoreFront check are older than this reading (as after Osvježi)
    if (other) S.user.ordMarks = {};
    prune('ordMarks');
    if (d) { addMarks('ordMarks', d.added, 'new'); addMarks('ordMarks', d.arrived, 'arrived'); addMarks('ordMarks', d.part, 'part'); addMarks('ordMarks', d.state, 'state'); }
    saveUser();
    ctx.syncWatch();
    if (!changed) { ctx.ageChanged(); return; }
    ctx.redraw('orders');
    const parts = d ? [
      d.added.length && `${d.added.length} ${plural(d.added.length, 'nova narudžba', 'nove narudžbe', 'novih narudžbi')}`,
      d.arrived.length && `roba stigla za ${d.arrived.length} ${plural(d.arrived.length, 'narudžbu', 'narudžbe', 'narudžbi')}`,
      d.part.length && `dio robe stigao za ${d.part.length} ${plural(d.part.length, 'narudžbu', 'narudžbe', 'narudžbi')}`,
      d.state.length && `${d.state.length} ${plural(d.state.length, 'promjena', 'promjene', 'promjena')} statusa`,
    ].filter(Boolean) : [];
    if (parts.length) toast(`Narudžbe: ${parts.join(', ')}`);
    else if (other) toast('Druga prodavnica: narudžbe su učitane iznova.');
    if (why) st.ord.lastWhy = why;
  }
  /** Osvježi (the Customer Orders page) is starting: a look still on its way is not taken after it. */
  function manualOrders() { st.ord.gen++; }

  // -------------------------------------------------------------- Minus lista
  function minusDue(min) { return S.fg && minOn() && !st.min.busy && !minusLocked() && now() >= st.min.until && minAge() >= min; }
  function runMinus() {
    st.min.busy = true;
    st.min.runs++;
    const seq = st.min.reads;
    const job = stCall({ mode: 'minuspeek', bg: true }, (r) => { st.min.busy = false; minusAnswer(r, seq); });
    if (!job) st.min.busy = false;
    return !!job;
  }
  function minusAnswer(r, seq) {
    const m = S.user.minus;
    if (!m) return;
    // 2.15 audit: a full reading (the employee's or another) landed after this look started: the look is older than
    // what the app has, so it neither marks it "checked" nor starts another reading (a count, not the clock)
    if (seq != null && seq !== st.min.reads) return;
    if (!r || r.how !== 'ok' || !r.res || !Array.isArray(r.res.items)) { fail(st.min, r); ctx.ageChanged(); return; }
    good(st.min);
    const res = r.res;
    const other = !!(m.store && res.store && m.store !== res.store);
    if (!other && minusSig(m.items, m.total) === res.sig) {
      m.seen = now();
      if (!m.store && res.store) m.store = res.store;
      saveUser();
      ctx.syncWatchMinus();
      ctx.ageChanged();
      return;
    }
    // changed: the usual full reading (it also reads the replacement chains); checked again right before it
    if (minusLocked()) return;
    S.minusNext = { store: res.store || '', other, auto: true, at: now() };
    ctx.loadMinus();
  }
  /** Every finished Minus reading (window.onMinus): what changed is marked; another store starts clean. */
  function minusRead(prev, next) {
    st.min.reads++;
    // the look's note belongs only to the reading it started (a failed one leaves it; it is not taken later)
    const n = S.minusNext && now() - S.minusNext.at < 5 * 60000 ? S.minusNext : null;
    S.minusNext = null;
    if (!(n && n.auto)) delete S.user.sfSignedOut; // a reading the employee asked for: signed in again
    next.store = (n && n.store) || (prev && prev.store) || '';
    next.seen = next.at;
    if (n && n.other) S.user.minusMarks = {};
    prune('minusMarks');
    if (prev && prev.items && !(n && n.other)) {
      const d = minusDiff(prev.items, next.items);
      addMarks('minusMarks', d.added, 'new');
      addMarks('minusMarks', d.qty, 'qty');
      if (n && n.auto && (d.added.length || d.qty.length || d.gone.length)) {
        const parts = [d.added.length && `${d.added.length} ${plural(d.added.length, 'novi artikal', 'nova artikla', 'novih artikala')}`,
          d.qty.length && `${d.qty.length} s drugom količinom`, d.gone.length && `${d.gone.length} ${plural(d.gone.length, 'riješen', 'riješena', 'riješenih')}`].filter(Boolean);
        toast(`Minus lista: ${parts.join(', ')}`);
      }
    }
    ctx.syncWatchMinus();
  }

  // ------------------------------------------------------------------ timing
  function tick() {
    if (!S.fg) return;
    if (ordersDue(ORD_EVERY)) runOrders('tick');
    if (minusDue(MIN_EVERY)) runMinus();
  }
  /** Start, return to the app, a screen opened: a stopped look may try again, then the rules of freshness. */
  function wake(why) {
    for (const x of [st.ord, st.min]) if (x.until === Infinity || /^(open|notify)-/.test(why)) { x.until = 0; x.fails = 0; } // the employee asked: no waiting
    if (why === 'boot') { if (ordersDue(ORD_BOOT)) runOrders(why); if (minusDue(MIN_EVERY)) runMinus(); return; }
    if (why === 'open-orders') { if (ordersDue(ORD_OPEN)) runOrders(why); return; }
    if (why === 'notify-orders') { if (ordersDue(0)) runOrders(why); return; }
    tick();
  }
  // 2.15 audit: no timer of its own; the app's one minute tick (app.js, also the online check) calls tick()
  function start() {
    if (started) return;
    started = true;
    wake('boot');
  }
  function foreground(on) {
    S.fg = !!on;
    if (on) wake('resume');
  }

  /** The line under the count: the time of the last good reading is shown anyway; this says why it is not newer. */
  function note(kind) {
    const x = kind === 'minus' ? st.min : st.ord;
    if (!x.err) return '';
    return x.err === 'login' ? ' · automatska provjera: StoreFront traži prijavu'
      : x.err === 'offline' ? ' · automatska provjera: nema mreže' : ' · zadnja automatska provjera nije uspjela';
  }
  function mark(key, id) {
    const v = S.user[key] && S.user[key][id];
    return v && now() - v.at <= MARK_MS ? v.k : '';
  }

  return { start, wake, tick, foreground, manualOrders, minusRead, note, mark, state: st, runOrders, runMinus };
}
