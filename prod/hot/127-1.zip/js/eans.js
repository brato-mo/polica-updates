// Barcodes of the planogram articles, from StoreFront (read only). A planogram has the 7-digit article numbers, the
// goods carry EAN barcodes; StoreFront has the barcodes in each article's master data. Asked once for every planogram
// article (again after 30 days) and kept in eans.json = { v, m: { ean: num }, done: { num: time }, sync, last }, so a
// scanned barcode opens its place at once, without StoreFront.
//
// 1.63-1.68 read the barcodes from StoreFront's search rows, which carry none: nothing was ever found (the phone showed
// "barkodova 0" in 1.69-test1). v: 2 forgets those empty answers so every article is asked again.
// v: 3 (1.72) asks again only the articles kept as "no barcode" (in 1.72-test1 they came right where StoreFront
// stopped answering, so some may not be true); every barcode already read is kept. An article without a barcode is
// asked again after a day, one with barcodes after 30 days.
//
// Taken out of app.js in 1.69. Everything it needs comes in through createEans():
//   store      read/write of the app's files (store.js)
//   stCall     a StoreFront job (StoreTask): stCall(arg, cb) -> false when this app version has none
//   plans      () => the planograms [{ imported, plan: { items } }]
//   ready      () => true once the planograms are loaded (the search index exists)
//   has        () => true when the phone can run StoreFront jobs
//   log        (text) => a line for the diagnostics
//   timers     { set, clear, now } (tests replace them)

export const FILE = 'eans.json';
export const VERSION = 3;
export const PER = 100; // articles read in one job: their barcodes are kept (and work) after every job
const MONTH = 30 * 86400000, DAY = 86400000;
export const GIVE_UP = 6; // rounds in a row with no answer at all (1+2+4+8+10+10 min): then not again until the next start

/**
 * The articles still without barcodes, the newest planogram first (the one being set up is the one scanned now), each
 * article once however many planograms have it.
 */
export function todo(plans, done, now = Date.now(), withEan = null) {
  const old = now - MONTH, day = now - DAY, seen = new Set(), out = [];
  for (const p of plans.slice().sort((a, b) => b.imported - a.imported)) {
    for (const n of Object.keys(p.plan.items)) {
      if (seen.has(n) || !/^\d{7}$/.test(n)) continue;
      seen.add(n);
      if (!(done[n] > (withEan && !withEan.has(n) ? day : old))) out.push(n);
    }
  }
  return out;
}

export function createEans({ store, stCall, plans, ready, has, defer = () => false, log = () => {}, timers = { set: (f, ms) => setTimeout(f, ms), clear: (t) => clearTimeout(t), now: () => Date.now() } }) {
  let data = null, busy = false, timer = 0, pause = 0, pausedBy = '', emptyRuns = 0;
  const withEan = (d) => new Set(Object.values(d.m));
  const T = timers;

  function load() {
    if (!data) {
      data = store.read(FILE, null);
      if (!data || typeof data !== 'object') data = {};
      data.m = data.m && typeof data.m === 'object' ? data.m : {};
      data.done = data.done && typeof data.done === 'object' ? data.done : {};
      if (data.v === 2) { // see above: the barcodes stay, the "no barcode" answers are asked again
        const w = withEan(data);
        for (const n of Object.keys(data.done)) if (!w.has(n)) delete data.done[n];
        data.v = VERSION;
        delete data.sync;
      } else if (data.v !== VERSION) { data.done = {}; data.v = VERSION; delete data.bulkAt; delete data.sync; }
    }
    return data;
  }

  // why the reads that brought nothing failed, for the diagnostics: "mreža 37, http 503: 2"
  function errs(inf) {
    const e = inf.err || {}, st = inf.status || {};
    return [e.net ? `mreža ${e.net}` : '', e.http ? `http ${Object.keys(st).map((c) => `${c}: ${st[c]}`).join(', ') || e.http}` : '',
      e.empty ? `prazno ${e.empty}` : '', e.odd ? `poruka greške ${e.odd}` : ''].filter(Boolean).join(', ');
  }

  function soon(ms) { T.clear(timer); timer = T.set(sync, ms); }

  function sync() {
    if (busy || !has() || T.now() < pause || !ready()) return;
    // A planogram's stock readings have priority over optional bulk barcode enrichment.
    if (defer()) { soon(7000); return; }
    const d = load();
    const list = todo(plans(), d.done, T.now(), withEan(d));
    if (!list.length) return;
    const nums = list.slice(0, PER);
    busy = true;
    const t0 = T.now();
    // one round of reading (from the first job with articles missing to the last): its time for the diagnostics
    if (!d.sync || d.sync.end) d.sync = { at: t0, ms: 0, work: 0, jobs: 0, n: 0, todo: list.length };
    const ok = stCall({ mode: 'eans', nums, per: PER, bg: true }, (r) => {
      busy = false;
      const now = T.now();
      if (r.how === 'login') { pause = now + 10 * 60000; pausedBy = 'login'; soon(10 * 60000 + 1000); return; } // until signedIn()
      const inf = (r.res && r.res.info) || {};
      const answered = r.how === 'ok' && r.res ? (r.res.list || []).length : 0;
      // nothing at all (no connection, StoreFront not answering, the job failed): not one article is marked; a pause
      // of 1, 2, 4, 8, 10, 10 min, then none until the next start (1.72-test1 asked 1200 times in 17 s instead)
      if (!answered) {
        emptyRuns++;
        const why = r.how !== 'ok' ? `posao: ${r.how}` : errs(inf) || 'nema odgovora';
        if (emptyRuns >= GIVE_UP) {
          pause = Infinity;
          pausedBy = 'empty';
          log(`barkodovi: ${emptyRuns}. put bez ijednog odgovora (${why}); dalje tek pri sljedećem pokretanju, ostalo ${list.length}`);
          return;
        }
        const wait = Math.min(10, 2 ** (emptyRuns - 1)) * 60000;
        pause = now + wait;
        pausedBy = 'empty';
        log(`barkodovi: ${Math.min(nums.length, +inf.per || nums.length)} pitano, 0 odgovoreno, ${now - t0} ms (${why}); pauza ${wait / 60000} min, ostalo ${list.length}`);
        soon(wait + 1000);
        return;
      }
      emptyRuns = 0;
      pausedBy = '';
      let got = 0;
      for (const x of r.res.list || []) {
        if (!/^\d{7}$/.test(String(x.num))) continue;
        d.done[x.num] = now;
        for (const e of x.eans || []) if (/^\d{8,14}$/.test(String(e))) { d.m[e] = x.num; got++; }
      }
      const asked = Math.min(nums.length, +inf.per || nums.length); // StoreTask may ask for fewer (sharing a page)
      d.last = { at: now, ms: now - t0, asked, answered, withEan: +inf.withEan || 0 };
      d.sync.jobs++;
      d.sync.n += answered;
      d.sync.ms = now - d.sync.at;
      d.sync.work = (+d.sync.work || 0) + (now - t0); // the jobs themselves, without the time the app was closed
      const more = todo(plans(), d.done, now, withEan(d)).length;
      if (!more) d.sync.end = now;
      store.write(FILE, d);
      const e = errs(inf);
      log(`barkodovi: ${asked} pitano, ${answered} odgovoreno, ${d.last.withEan} s barkodom, ${got} barkodova, ${d.last.ms} ms`
        + `${inf.none ? `; nema u StoreFrontu ${inf.none}` : ''}${e ? `; bez odgovora: ${e}` : ''}`
        + `${inf.keys ? `; polja: ${[].concat(inf.keys).join(',') || 'nema'}` : ''}; ostalo ${more}`
        + `${d.sync.end ? `; ukupno ${Math.round(d.sync.work / 1000)} s rada (${Math.round(d.sync.ms / 1000)} s od početka), ${d.sync.jobs} poslova` : ''}`);
      soon(1500); // the next ones, if there are more
    });
    if (!ok) busy = false;
  }

  /**
   * Another StoreFront job just went through: a pause that waited only for the sign-in ends now, so the barcodes do
   * not wait up to 10 minutes after the employee signed in (1.70; the phone showed it). Other errors keep their pause.
   */
  function signedIn() {
    if (pausedBy !== 'login' || busy) return;
    pausedBy = '';
    pause = 0;
    soon(1500);
  }

  /** The article a barcode belongs to by StoreFront's own list, or ''. */
  const of = (code) => (load().m[String(code || '').replace(/\s+/g, '')] || '');

  // 1.72-test3: the network is back and StoreFront answers: a pause for "no answers" ends now (not after its minutes);
  // what was read stays, the articles still left are asked from where it stopped
  function resume() {
    if (pausedBy !== 'empty') return;
    pause = 0;
    pausedBy = '';
    emptyRuns = 0;
    soon(1000);
  }

  return { soon, sync, of, signedIn, resume, data: load };
}
