// First run (1.73): five short steps in one full-height sheet, each a decision of the employee.
//   1 Prijava: StoreFront confirms who is signed in and which store (never built in: colleagues of other stores use
//     the same app); 2 glavni odjel and 3 dodatni odjeli: StoreFront's own departments; 4 lijeva / desna trgovina;
//   5 planogrami: MYJYSK's list for that side, the employee's departments chosen first; nothing is downloaded before
//     the employee says so. Then the settings are kept on this phone and the start screen is there.
// Never stores credentials. Can be skipped at every step and opened again from Postavke. A phone that already has
// planograms is not interrupted by it after an update (start() marks it done without touching anything).
export function createWelcomeSetup({ S, $, esc, stCall, saveUser, setCfg, openSheet, closeSheet, toast, planList, checkPlans, loadHierarchy, refreshMyjysk, getSide, canMyjysk = () => true, deptNo = defaultDeptNo }) {
  const STEPS = ['Prijava', 'Glavni odjel', 'Dodatni odjeli', 'Strana trgovine', 'Planogrami'];
  let active = false, loading = false, planLoading = false, main = '', extra = new Set(), chosen = new Set(), stage = 1, side = 'left', planError = '';
  let who = null, whoBusy = false, whoError = '', touchedPlans = false;
  let pendingPlanTimeout = null;
  const clearPending = () => { if (pendingPlanTimeout) clearTimeout(pendingPlanTimeout); pendingPlanTimeout = null; };
  /** Another sheet took the screen (1.73-test2: "Prijava za planograme" over step 5): the steps are not on screen. */
  const shown = () => { const sh = $('#sheet'); return !sh.hidden && (!sh.classList || sh.classList.contains('is-setup')); };
  const away = () => { const sh = $('#sheet'); return !!sh.classList && !sh.hidden && !sh.classList.contains('is-setup'); };
  const roots = () => (S.user.hier && S.user.hier.groups || [])
    .filter(g => /^\d{1,8}$/.test(String(g.id)));
  const allPlans = () => {
    try { return planList().filter(p => p && p.key && p.url); } catch (e) { return []; }
  };
  const name = id => (roots().find(g => String(g.id) === String(id)) || {}).title || id;
  /** StoreFront's top groups 1..11 are the departments ("5" is 05 Homeware); a longer number is no department code. */
  const code = id => /^\d{1,2}$/.test(String(id)) ? String(+id).padStart(2, '0') : '';
  const label = g => `${code(g.id) ? `${code(g.id)} · ` : ''}${g.title || g.id}`;
  const mine = () => new Set([main, ...extra].map(code).filter(Boolean));
  /** The planograms of the chosen departments; all of them when no department code is known. */
  const preselect = () => {
    const m = mine(), plans = allPlans().filter(p => !p.off);
    const own = plans.filter(p => m.has(deptNo(p.dept)));
    return new Set((m.size && own.length ? own : plans).map(p => p.key));
  };

  const complete = (how = 'done') => {
    if (!active) return;
    clearPending(); planLoading = false;
    S.user.welcomeSetup = { done: true, at: Date.now(), how, main, extra: [...extra], side, ...(who && who.num ? { user: who.num } : {}), ...(who && who.store ? { store: who.store } : {}) };
    saveUser();
    active = false;
    closeSheet();
  };
  const load = () => {
    if (loading) return;
    loading = true; draw();
    const ok = loadHierarchy({
      S, stCall, saveUser, toast,
      done: () => { loading = false; if (active) draw(); }
    });
    if (!ok) { loading = false; toast('StoreFront je nedostupan. Možeš preskočiti.'); draw(); }
  };
  /** Step 1: StoreFront says who is signed in (and in which store). Read only. */
  const checkWho = () => {
    if (whoBusy) return;
    whoBusy = true; whoError = ''; draw();
    const ok = stCall({ mode: 'me', bg: true }, r => {
      whoBusy = false;
      if (r && r.how === 'ok' && r.res && (r.res.name || r.res.num)) {
        who = { name: String(r.res.name || ''), num: String(r.res.num || ''), store: String(r.res.store || '') };
        if (!roots().length) load(); // the departments come from the same sign-in
      } else whoError = r && r.how === 'login' ? 'StoreFront traži prijavu: prijavi se svojim podacima pa pokušaj ponovo.'
        : r && r.err === 'offline' ? 'Nema interneta. Provjeri vezu pa pokušaj ponovo.' : 'StoreFront nije potvrdio prijavu. Pokušaj ponovo.';
      if (active) draw();
    });
    if (!ok) { whoBusy = false; whoError = 'Ova verzija ne može provjeriti StoreFront prijavu.'; draw(); }
  };
  const go = n => { stage = n; if (n === 5) enterPlans(); draw(); };
  /** Step 5: MYJYSK's list for the chosen side is read (read only) and the employee's departments are chosen first. */
  const enterPlans = () => {
    setCfg({ plSide: side }); // the side decides MYJYSK's list (not only its label); what was on or off stays until saved
    if (!touchedPlans) chosen = preselect();
    if (!allPlans().length && !planLoading) loadPlans();
  };
  const loadPlans = () => {
    if (planLoading) return;
    if (!canMyjysk()) { planError = 'MYJYSK nije dostupan u ovoj instalaciji. Postavke možeš sačuvati, a planograme preuzeti kasnije.'; draw(); return; }
    planError = '';
    planLoading = true; draw();
    const began = refreshMyjysk(false);
    clearPending();
    if (began === false) {
      planLoading = false;
      planError = 'MYJYSK zahtjev nije pokrenut. Provjeri vezu ili prijavu, pa pokušaj ponovo.';
      draw();
      return;
    }
    pendingPlanTimeout = setTimeout(() => {
      pendingPlanTimeout = null;
      if (!active || stage !== 5 || !planLoading) return;
      planLoading = false;
      planError = 'MYJYSK nije završio učitavanje u predviđenom vremenu. Provjeri MYJYSK prijavu ili pokušaj ponovo.';
      draw();
    }, 25000);
  };
  const save = (download) => {
    const items = allPlans();
    // what was not chosen is switched off (not downloaded); the side is kept
    setCfg({ plSide: side, plOff: Object.fromEntries(items.filter(p => !chosen.has(p.key)).map(p => [p.key, true])) });
    complete(download ? 'download' : 'saved');
    if (download && chosen.size) checkPlans();
    toast(download && chosen.size ? `Postavke su sačuvane. Preuzimam ${chosen.size} ${chosen.size === 1 ? 'planogram' : 'planograma'}.` : 'Postavke su sačuvane.');
  };
  const keepDepartments = () => {
    S.user.welcomeMainGroup = main;
    S.user.welcomeExtraGroups = [...extra];
    // StoreFront's top groups are the departments: group "5" is department 05 (what the app reads for "Moj odjel")
    if (code(main)) setCfg({ group: String(+main), dept: code(main) });
    saveUser();
  };
  const skip = { label: 'Preskoči podešavanje', onClick: () => complete('skipped') };
  const back = n => ({ label: 'Nazad', onClick: () => go(n) });

  const head = n => `<div class="setup-steps" aria-label="Korak ${n} od ${STEPS.length}"><span>Korak ${n} od ${STEPS.length} · ${STEPS[n - 1]}</span>
    <div class="setup-bar">${STEPS.map((_, i) => `<i class="${i < n ? 'is-on' : ''}"></i>`).join('')}</div></div>`;
  const row = (attr, id, title, sub, on, kind = 'radio') => `<button type="button" class="setup-row" ${attr}="${esc(id)}" role="${kind}" aria-checked="${on}">
    <span class="setup-row-txt"><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span><span class="setup-tick" aria-hidden="true"></span></button>`;
  const sideIcon = s => `<svg class="setup-store" viewBox="0 0 64 40" aria-hidden="true"><rect x="2" y="2" width="60" height="36" rx="5" class="st-floor"/>
    <rect x="${s === 'left' ? 4 : 33}" y="4" width="27" height="32" rx="3" class="st-half"/><rect x="28" y="33" width="8" height="5" rx="1" class="st-door"/></svg>`;

  function draw() {
    if (!active) return;
    // the step comes first, then the question (the sheet's own title stays for screen readers)
    const open = (title, body, actions) => openSheet({ title, body: head(stage) + `<p class="setup-title" aria-hidden="true">${esc(title)}</p>` + body, actions, dismissible: false, cls: 'is-setup' });
    if (stage === 1) {
      const status = whoBusy ? '<p class="setup-status"><i class="mj-busy"></i> Provjeravam tvoju StoreFront prijavu…</p>'
        : who ? `<div class="setup-card is-ok"><b>${esc(who.name || 'Prijavljen')}</b><small>${[who.num ? `broj ${esc(who.num)}` : '', who.store ? `prodavnica ${esc(who.store)}` : ''].filter(Boolean).join(' · ') || 'StoreFront prijava potvrđena'}</small></div>
          <p class="setup-help">Zalihe, SM/DM i liste uvijek su za prodavnicu u kojoj si prijavljen. Postavke koje sada izabereš čuvaju se samo na ovom telefonu.</p>`
        : `<div class="setup-card is-err"><b>Prijava nije potvrđena</b><small>${esc(whoError || 'Još nije provjereno.')}</small></div>`;
      open('Dobro došao u Jysk Reloaded', `<p class="setup-help">Za par koraka aplikacija je podešena za tebe: tvoj odjel, strana trgovine i planogrami koje želiš. Sve se kasnije može promijeniti u Postavkama.</p>${status}`, [
        { label: 'Dalje', kind: 'btn-primary', onClick: () => { if (!who) { if (!whoBusy) checkWho(); toast('Prvo se potvrdi StoreFront prijava.'); return; } go(2); } },
        ...(!who && !whoBusy ? [{ label: 'Pokušaj ponovo', onClick: checkWho }] : []),
        skip,
      ]);
    } else if (stage === 2) {
      const list = roots();
      const body = loading ? '<p class="setup-status"><i class="mj-busy"></i> Čitam odjele iz StoreFronta…</p>'
        : !list.length ? '<p class="setup-help">Odjeli iz StoreFronta još nisu učitani.</p><button class="btn btn-soft btn-block" type="button" data-setup-load="1">Učitaj odjele</button>'
        : `<p class="setup-help">Odjel u kojem najviše radiš. Po njemu aplikacija bira tvoje planograme, SM/DM i liste.</p><div class="setup-list">${list.map(g => row('data-setup-main', g.id, label(g), '', main === String(g.id))).join('')}</div>`;
      open('Koji je tvoj glavni odjel?', body, [
        { label: 'Dalje', kind: 'btn-primary', onClick: () => {
          if (!main || !roots().some(g => String(g.id) === main)) { toast('Prvo izaberi glavni odjel.'); return; }
          keepDepartments();
          go(3);
        } },
        back(1), skip,
      ]);
    } else if (stage === 3) {
      const list = roots().filter(g => String(g.id) !== main);
      open('Radiš li i u drugim odjelima?', `<p class="setup-help">Neobavezno. Njihovi planogrami se ponude zajedno s tvojim. Glavni odjel: <b>${esc(label({ id: main, title: name(main) }))}</b>.</p>
        <div class="setup-list">${list.map(g => row('data-setup-extra', g.id, label(g), '', extra.has(String(g.id)), 'checkbox')).join('')}</div>`, [
        { label: extra.size ? `Dalje · ${extra.size} ${extra.size === 1 ? 'dodatni odjel' : extra.size < 5 ? 'dodatna odjela' : 'dodatnih odjela'}` : 'Dalje bez dodatnih odjela', kind: 'btn-primary', onClick: () => { keepDepartments(); go(4); } },
        back(2), skip,
      ]);
    } else if (stage === 4) {
      open('Na kojoj strani je tvoja trgovina?', `<p class="setup-help">MYJYSK ima posebne planograme za lijevu i desnu trgovinu (gledano s ulaza).</p>
        <div class="setup-sides">${['left', 'right'].map(s => `<button type="button" class="setup-side-card" data-setup-side="${s}" role="radio" aria-checked="${side === s}">${sideIcon(s)}<b>${s === 'left' ? 'Lijeva' : 'Desna'} trgovina</b></button>`).join('')}</div>`, [
        { label: 'Dalje', kind: 'btn-primary', onClick: () => go(5) },
        back(3), skip,
      ]);
    } else {
      const plans = allPlans();
      const m = mine();
      const own = plans.filter(p => m.has(deptNo(p.dept))), rest = plans.filter(p => !m.has(deptNo(p.dept)));
      const list = (title, l) => l.length ? `<p class="setup-sub">${title}</p><div class="setup-list">${l.map(p => row('data-setup-plan', p.key, p.text || p.name || p.key, p.dept || '', chosen.has(p.key), 'checkbox')).join('')}</div>` : '';
      const body = plans.length
        ? `<p class="setup-help">${side === 'right' ? 'Desna' : 'Lijeva'} trgovina. Preuzimaju se samo označeni, tek kad potvrdiš.</p>
          <div class="chips setup-quick">${own.length ? '<button class="chip" type="button" data-setup-pick="mine">Samo moji odjeli</button>' : ''}<button class="chip" type="button" data-setup-pick="all">Označi sve</button><button class="chip" type="button" data-setup-pick="none">Ništa</button></div>
          ${own.length ? list('Tvoji odjeli', own) + list('Ostali odjeli', rest) : list('Planogrami', plans)}
          <p class="setup-help">Označeno: ${chosen.size} od ${plans.length}</p>`
        : `<p class="setup-status">${planLoading ? '<i class="mj-busy"></i> Čitam spisak planograma iz MYJYSK-a…' : esc(planError || 'Spisak MYJYSK planograma još nije učitan.')}</p>`;
      open('Koje planograme preuzeti?', body, plans.length ? [
        { label: chosen.size ? `Sačuvaj i preuzmi (${chosen.size})` : 'Sačuvaj bez preuzimanja', kind: 'btn-primary', onClick: () => save(chosen.size > 0) },
        { label: 'Sačuvaj, planograme kasnije', onClick: () => save(false) },
        back(4),
      ] : [
        ...(planLoading ? [] : [{ label: 'Učitaj spisak iz MYJYSK-a', kind: 'btn-primary', onClick: loadPlans }]),
        { label: 'Sačuvaj, planograme kasnije', onClick: () => { setCfg({ plSide: side }); complete('saved'); toast('Postavke su sačuvane.'); } },
        back(4),
      ]);
    }
  }
  document.addEventListener('click', e => {
    if (!active) return;
    const t = e.target.closest('[data-setup-main],[data-setup-extra],[data-setup-plan],[data-setup-load],[data-setup-side],[data-setup-pick]');
    if (!t) return;
    if (t.dataset.setupLoad) { load(); return; }
    if (t.dataset.setupPick) {
      if (stage !== 5) return;
      const how = t.dataset.setupPick;
      chosen = how === 'mine' ? preselect() : how === 'all' ? new Set(allPlans().map(p => p.key)) : new Set();
      touchedPlans = true; draw(); return;
    }
    if (t.dataset.setupSide) {
      if (stage !== 4 || !['left', 'right'].includes(t.dataset.setupSide)) return;
      if (side !== t.dataset.setupSide) { side = t.dataset.setupSide; touchedPlans = false; }
      planError = ''; draw(); return;
    }
    if (t.dataset.setupMain) {
      if (!roots().some(g => String(g.id) === t.dataset.setupMain)) return;
      main = t.dataset.setupMain; extra.delete(main); touchedPlans = false; draw();
    } else if (t.dataset.setupExtra) {
      const id = t.dataset.setupExtra;
      if (!roots().some(g => String(g.id) === id) || id === main) return;
      extra.has(id) ? extra.delete(id) : extra.add(id); touchedPlans = false; draw();
    } else if (t.dataset.setupPlan) {
      const id = t.dataset.setupPlan;
      if (!allPlans().some(p => p.key === id)) return;
      chosen.has(id) ? chosen.delete(id) : chosen.add(id); touchedPlans = true; draw();
    }
  });
  return {
    refreshed(result) {
      if (!active || stage !== 5 || !planLoading) return;
      clearPending(); planLoading = false;
      // another sheet is open (a sign-in, a question): it is never covered; the steps can be opened again in Postavke
      if (away()) { active = false; return; }
      const count = allPlans().length;
      if (!result || result.how === 'error') {
        planError = 'MYJYSK nije odgovorio. Pokušaj ponovo ili sačuvaj postavke bez preuzimanja.';
      } else if (result.how === 'login') {
        planError = 'MYJYSK traži prijavu. Prvo otvori MYJYSK prijavu pa ponovo učitaj spisak.';
      } else if (result.how === 'cancelled') {
        planError = 'MYJYSK učitavanje je otkazano.';
      } else if (!count) {
        planError = 'MYJYSK je odgovorio, ali nema PDF planograma za odabranu stranu i koncept trgovine. Provjeri lijevu/desnu stranu i Compact u Postavkama.';
      } else {
        planError = '';
      }
      if (!touchedPlans) chosen = preselect();
      draw();
    },
    start(force = false) {
      // the steps were pushed off the screen by another sheet (or it was closed): they can start again
      if (active && !shown()) { active = false; clearPending(); }
      if (active || (!force && S.user.welcomeSetup && S.user.welcomeSetup.done)) return;
      // 1.73: a phone that already has planograms was set up before this assistant existed. The update must not
      // interrupt it or touch its department and side; the assistant stays in Postavke for whoever wants it.
      if (!force && !S.user.welcomeSetup && Array.isArray(S.plans) && S.plans.length) {
        S.user.welcomeSetup = { done: true, at: Date.now(), existing: true };
        saveUser();
        return;
      }
      if (!$('#sheet').hidden) return; // never interrupt critical flows or warnings
      clearPending(); active = true; stage = 1; planLoading = false; planError = ''; touchedPlans = false;
      side = getSide() === 'right' ? 'right' : 'left';
      main = String(S.user.welcomeMainGroup || '');
      extra = new Set(S.user.welcomeExtraGroups || []);
      who = null; whoError = '';
      draw();
      checkWho();
      if (!roots().length) load(); // async and nonblocking; skip always available
    }
  };
}

/** "05 Homeware" -> "05" (MYJYSK's department folders start with the department number). */
function defaultDeptNo(topic) {
  const m = /^(\d{2})\b/.exec(String(topic || ''));
  return m ? m[1] : '';
}
