// Planograms from MYJYSK: noticing new ones and downloading them into the import.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createMjPlansUi(ctx) {
  const { A, S, ageText, cfg, closeSheet, core, drainImports, esc, mjOn, news, openSheet, plural, progress, queue, refreshMyjysk, renderPlans, renderSettings, saveUser, setCfg, showResults, toast, top } = ctx;


const sideName = () => `${cfg().plSide === 'right' ? 'desna' : 'lijeva'}${cfg().plCompact ? ' Compact' : ''} trgovina`;
const planOff = () => cfg().plOff || {};
function planList() {
  const st = S.user.mj;
  const all = news.planLinks(st && st.kb, { org: cfg().plOrg, side: cfg().plSide, compact: !!cfg().plCompact });
  // the Christmas planogram for stores with a wall is left out until the employee turns it on
  const off = cfg().plOff || Object.fromEntries(all.filter((p) => /zid|wall/i.test(`${p.text} ${p.key}`)).map((p) => [p.key, true]));
  return all.map((p) => ({ ...p, off: !!off[p.key] }));
}
function planCheckLine() {
  const last = S.user.planCheck;
  return `${sideName()[0].toUpperCase()}${sideName().slice(1)} · ${last ? `zadnja provjera ${ageText(last)}` : 'još nije provjereno'}`;
}
function planChips() {
  const list = planList();
  if (!list.length) return '<div class="set-row"><div class="set-txt"><b>Koji planogrami</b><small>Spisak se pojavi poslije prve provjere.</small></div></div>';
  if (!cfg().plOff) setCfg({ plOff: Object.fromEntries(list.filter((p) => p.off).map((p) => [p.key, true])) });
  return `<div class="set-row set-col"><div class="set-txt"><b>Koji planogrami</b><small>Isključeni se ne preuzimaju.</small></div>
    <div class="chips">${list.map((p) => `<button class="chip" type="button" role="checkbox" aria-checked="${!p.off}" data-ploff="${esc(p.key)}">${esc(news.deptName(p.dept))}${/zid|wall/i.test(`${p.text} ${p.key}`) ? ' sa zidom' : ''}</button>`).join('')}</div></div>`;
}

function checkPlans() {
  if (!mjOn()) return;
  if (S.busy) { toast('Sačekaj da se završi uvoz planograma.'); return; }
  if (planDl) { toast('Planogrami se već preuzimaju.'); return; } // e.g. one started from an article
  const st = S.user.mj;
  if (st && st.kb && Date.now() - st.at < 20 * 60 * 1000) { startPlanDownload(); return; }
  S.mj.after = 'plans';
  progress('Provjeravam planograme', 0.03, 'Čitam koncept trgovine u MYJYSK…', { cancel: cancelPlans });
  refreshMyjysk(false);
}

// 1.73-test3: the check and the download can always be left ("Prekini" or back); a late answer is then ignored, and
// a download with no news for a minute says so (the server may be slow or not answer at all)
let planWatch = 0;
function cancelPlans() {
  clearTimeout(planWatch); planWatch = 0;
  const was = !!planDl || S.mj.after === 'plans';
  const done = planDl && planDl.opts && planDl.opts.done;
  planDl = null;
  if (done) done({ cancelled: true });
  if (S.mj.after === 'plans') S.mj.after = null;
  closeSheet();
  try { if (A.cancelPlans) A.cancelPlans(); } catch (e) { /* an older app: its download ends by itself */ }
  if (was) toast('Provjera planograma prekinuta.');
}
function watchPlans() {
  clearTimeout(planWatch);
  planWatch = setTimeout(() => {
    planWatch = 0;
    if (!planDl) return;
    if (planDl.opts && planDl.opts.onProgress) { planDl.opts.onProgress(null, 'Server planograma ne odgovara već minutu.'); return; }
    progress('Preuzimam planograme', (S.prog && S.prog.pct || 5) / 100, 'Server planograma ne odgovara već minutu. Možeš prekinuti ili sačekati.', { cancel: cancelPlans });
  }, 60000);
}

let planDl = null; // the running download: { list }
/** The planogram of this MYJYSK link is on the phone (the one its last download became, or one of the same file name). */
function planOnPhone(p, r = (S.user.planSrc || {})[p.key]) {
  if (r && r.id && S.plans.some((x) => x.id === r.id)) return true;
  return S.plans.some((x) => x.name === p.name);
}
/**
 * 1.73-test4 (from the store: "preuzimao se planogram koji već imam"): the planogram server makes the PDF anew on every request
 * and does not say whether it changed, so every check downloaded every planogram again (25 MB for Homeware). Now a
 * link is not downloaded while MYJYSK has not changed the article that links it since its last download and that
 * planogram is still on the phone. One that came before MYJYSK's date was kept (downloaded by 1.73-test3, or added
 * by hand under the same name) counts as downloaded when it came after MYJYSK's last change. "Preuzmi ipak sve
 * ponovo" downloads them anyway.
 */
const SKEW = 3 * 3600000; // MYJYSK's date has no time zone: what came within 3 hours of it is not taken as newer
function unchanged(p) {
  const src = S.user.planSrc || (S.user.planSrc = {});
  let r = src[p.key];
  const at = Date.parse(p.upd || '');
  if (Number.isFinite(at) && !(r && r.upd)) {
    if (r && r.at >= at + SKEW && planOnPhone(p, r)) r.upd = p.upd;
    else if (!r) {
      const local = S.plans.find((x) => x.name === p.name);
      if (local && local.imported >= at + SKEW) r = src[p.key] = { upd: p.upd, id: local.id, at: Date.now(), seeded: true };
    }
  }
  return !!(r && p.upd && r.upd === p.upd && planOnPhone(p, r));
}

// opts: force (download even what did not change), only (these keys), onProgress(frac, line) and done(result) for a
// download started from an article (its own button shows the progress; no sheet), quiet (no results sheet) and
// after(results) once the downloaded planograms are read
function startPlanDownload(opts = {}) {
  if (planDl) { toast('Planogrami se već preuzimaju.'); return false; }
  const list = (opts.only ? planList().filter((p) => opts.only.includes(p.key)) : planList().filter((p) => !p.off));
  if (!list.length) {
    if (opts.done) { opts.done({ none: true }); return false; }
    openSheet({ title: 'Nema planograma', body: `<p>U MYJYSK nisam našao planograme za ${esc(sideName())}. Provjeri u postavkama stranu trgovine.</p>`, actions: [{ label: 'U redu', kind: 'btn-primary', onClick: closeSheet }] });
    return false;
  }
  const skip = opts.force ? [] : list.filter(unchanged);
  const need = list.filter((p) => !skip.includes(p));
  saveUser();
  if (!need.length) {
    S.user.planCheck = Date.now();
    saveUser();
    if (opts.done) { opts.done({ skipped: skip.length }); return true; }
    closeSheet();
    showResults([{ kind: 'checked', n: list.length, same: skip.length, fresh: 0, skipped: skip.length, side: sideName(), again: () => startPlanDownload({ ...opts, force: true }) }]);
    return true;
  }
  const src = S.user.planSrc || {};
  planDl = { list: need, skipped: skip.length, opts };
  if (opts.onProgress) opts.onProgress(0.02, `Preuzimam ${need[0].name}`);
  else {
    progress('Preuzimam planograme', 0.05, `${need.length} ${plural(need.length, 'planogram', 'planograma', 'planograma')} za ${sideName()}${skip.length ? ` (${skip.length} bez promjene u MYJYSK-u se ne preuzima${skip.length === 1 ? '' : 'ju'})` : ''}`, { cancel: cancelPlans });
  }
  watchPlans();
  try {
    A.downloadPlans(JSON.stringify(need.map((p) => ({ url: p.url, name: p.name, sha: (src[p.key] || {}).sha || '', etag: (src[p.key] || {}).etag || '', lm: (src[p.key] || {}).lm || '' }))));
  } catch (e) {
    planDl = null; clearTimeout(planWatch);
    if (opts.done) opts.done({ error: 'old' }); else closeSheet();
    toast('Ova verzija aplikacije ne zna preuzimati planograme.');
    return false;
  }
  return true;
}

window.onPlanDl = (r) => {
  if (!planDl) return; // prekinuto: a late answer changes nothing
  if (!r.done) {
    // 1.73-test3: within a file too (a big PDF on a slow network is minutes, not a stuck screen)
    const mb = (b) => (b / 1048576).toFixed(1).replace('.', ','); // the same on every phone (not the locale's)
    const part = r.got > 0 && r.total > 0 ? Math.min(1, r.got / r.total) : 0;
    const bytes = r.got > 0 ? ` · ${mb(r.got)}${r.total > 0 ? ` od ${mb(r.total)}` : ''} MB` : '';
    const frac = 0.05 + (0.9 * (r.i + part)) / Math.max(1, r.n);
    if (planDl.opts && planDl.opts.onProgress) planDl.opts.onProgress(frac, `${r.name}${bytes}`);
    else progress('Preuzimam planograme', frac, `${r.i + 1}. od ${r.n}: ${r.name}${bytes}`, { cancel: cancelPlans });
    watchPlans();
    return;
  }
  clearTimeout(planWatch); planWatch = 0;
  const { list, skipped = 0, opts = {} } = planDl;
  planDl = null;
  if (r.login) { if (opts.done) opts.done({ login: true }); planLogin(r, list, opts); return; }
  // 1.74: a public APK carries no server addresses; this phone has no planogram server address yet
  if (r.why === 'nohost') {
    if (opts.done) opts.done({ error: 'nohost' }); else closeSheet();
    toast('Adresa servera planograma nije podešena: Postavke → Adrese servera.', 5200);
    return;
  }
  S.user.planCheck = Date.now();
  const src = S.user.planSrc || (S.user.planSrc = {});
  const byUrl = new Map(list.map((p) => [p.url, p]));
  const fresh = [], pending = {}, info = [];
  let same = 0;
  for (const f of r.files || []) {
    const p = byUrl.get(f.url);
    if (!p) continue;
    // the same file as last time: remember MYJYSK's date too, so the next check does not download it again
    if (f.status === 'same') { same++; src[p.key] = { ...(src[p.key] || {}), sha: f.sha, etag: f.etag, lm: f.lm, upd: p.upd, at: Date.now() }; continue; }
    if (f.status === 'new') { fresh.push({ name: p.name, file: f.file, size: f.size }); pending[p.name] = { key: p.key, sha: f.sha, size: f.size, etag: f.etag, lm: f.lm, upd: p.upd, first: !src[p.key] || !!src[p.key].seeded }; continue; }
    info.push({ kind: 'dlerror', name: p.text, why: f.why });
  }
  saveUser();
  const again = () => startPlanDownload({ ...opts, force: true });
  const head = { kind: 'checked', n: list.length + skipped, same: same + skipped, fresh: fresh.length, skipped, side: sideName(), ...(skipped ? { again } : {}) };
  if (!fresh.length) {
    if (opts.done) opts.done({ same, errors: info.length });
    else { showResults([head, ...info]); if (top().id === 'plans') renderPlans(); }
    return;
  }
  if (opts.done) opts.done({ importing: fresh.length });
  queue.push({ list: fresh, target: null, auto: { pending, head, info, quiet: !!opts.quiet, after: opts.after } });
  drainImports();
};

/** The planogram server wants its own sign-in: a user and password once (kept on the phone), or its web page. */
function planLogin(r, list, opts = {}) {
  const d = String(r.detail || '');
  if (r.login === 'auth' && /ntlm|negotiate/i.test(d) && !/basic/i.test(d)) {
    openSheet({ title: 'Prijava za planograme', body: '<p>Server za planograme traži Windows prijavu, a nju ova verzija aplikacije još ne zna poslati. Javi to, pa ću je dodati.</p>', actions: [{ label: 'U redu', kind: 'btn-primary', onClick: closeSheet }] });
    return;
  }
  if (r.login === 'auth') {
    closeSheet();
    S.plWait = true;
    S.plWaitOpts = opts.only ? { only: opts.only } : null; // after the sign-in: the same download again
    A.plansLogin(r.kept ? 'Korisničko ime ili lozinka nisu prihvaćeni. Upiši ih ponovo.' : 'Server za planograme traži prijavu (samo prvi put).');
    return;
  }
  openSheet({
    title: 'Prijava za planograme',
    body: '<p>Server za planograme traži prijavu, istu kao za MYJYSK. Prijavi se, ekran se sam zatvori i provjera ide dalje.</p>',
    actions: [{ label: 'Prijavi se', kind: 'btn-primary', onClick: () => { closeSheet(); S.plWait = true; S.plWaitOpts = opts.only ? { only: opts.only } : null; A.plansWeb(list[0].url); } }, { label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }],
  });
}

window.onPlansLogin = (ok) => {
  if (S.loginWait) {
    S.loginWait = false;
    if (ok) toast('Sačuvano. Aplikacija se sama prijavljuje kad te sistem odjavi.');
    if (top().id === 'settings') renderSettings();
    return;
  }
  if (!S.plWait) return;
  S.plWait = false;
  const opts = S.plWaitOpts || {};
  S.plWaitOpts = null;
  if (ok) startPlanDownload(opts);
  else toast('Bez prijave se planogrami ne mogu preuzeti.');
};

/** After the downloaded planograms were read: remember which file each one was, and note the new ones under "Važno". */
function afterAutoImport(auto, results, from) {
  const src = S.user.planSrc || (S.user.planSrc = {});
  const mine = results.slice(from);
  for (const r of mine) {
    const p = auto.pending[r.name];
    if (!p || !['added', 'replaced', 'skipped'].includes(r.kind)) continue;
    // which planogram this download became (so a later check knows it is still on the phone) and MYJYSK's date
    // 1.75 evidence for a better "has it changed" sign than MYJYSK's date: when a planogram is downloaded again, the
    // diagnostics say whether MYJYSK's date, the file's size and its articles changed (no names, no addresses)
    const was = src[p.key];
    if (was && !was.seeded && was.sha && A.note) {
      const c0 = r.ch, n0 = c0 ? c0.added.length + c0.moved.length + c0.removed.length : null;
      try {
        A.note(`planogram ponovo preuzet: MYJYSK datum ${was.upd && was.upd === p.upd ? 'isti' : was.upd ? 'drugi' : 'ranije nepoznat'}, veličina ${was.size ? (was.size === p.size ? 'ista' : 'druga') : 'ranije nepoznata'}, datoteka ${was.sha === p.sha ? 'ista' : 'druga'}, artikli ${n0 == null ? 'nepoznato' : n0 ? `${n0} izmjena` : 'isti'}`);
      } catch (e) { /* older shell */ }
    }
    src[p.key] = { sha: p.sha, size: p.size, etag: p.etag, lm: p.lm, upd: p.upd, at: Date.now(), ...(r.meta && r.meta.id ? { id: r.meta.id } : {}) };
    if (p.first || !r.meta) continue; // the first download of a planogram is not news
    const c = r.ch;
    const n = c ? c.added.length + c.moved.length + c.removed.length : 0;
    (S.user.planLog || (S.user.planLog = [])).unshift({
      id: `p:${r.meta.id}`, kind: 'plan', at: Date.now(), dept: r.meta.title, date: new Date().toISOString().slice(0, 10), planId: r.meta.id,
      title: `Novi planogram: ${r.meta.title}`,
      text: `${r.meta.deadline ? `Rok za postavku ${core.deadlineLabel(r.meta.deadline)}. ` : ''}${n ? `${c.added.length} novih, ${c.moved.length} premještenih, ${c.removed.length} izbačenih artikala.` : ''}`,
    });
  }
  if (S.user.planLog) S.user.planLog = S.user.planLog.slice(0, 30);
  results.splice(from, 0, auto.head, ...auto.info);
  saveUser();
}


  return { afterAutoImport, cancelPlans, checkPlans, planCheckLine, planChips, planOff, planList, planOnPhone, startPlanDownload, busy: () => !!planDl };
}
