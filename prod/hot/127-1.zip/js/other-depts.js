// Shared, read-only picker for StoreFront's actual product hierarchy.
// Do not fabricate department/category IDs or trust arbitrary user-provided IDs.
export const validGroup = (h, id) => {
  const num = String(id || '');
  if (!/^\d{1,8}$/.test(num)) return null;
  for (const g of h && Array.isArray(h.groups) ? h.groups : []) {
    if (String(g.id) === num) return { id: num, title: String(g.title || '') };
    for (const x of g.subs || []) if (String(x.id) === num)
      return { id: num, title: String(g.title || '') + ' › ' + String(x.title || '') };
  }
  return null;
};

export function pickerHtml(h, esc, prefix, selected) {
  if (!h || !Array.isArray(h.groups)) {
    return '<p class="count-line">Odjeli se učitavaju iz StoreFronta, bez unaprijed upisanih šifri.</p>' +
      '<button class="btn btn-soft btn-block" type="button" data-' + prefix +
      '-hier="1">Učitaj odjele iz StoreFronta</button>';
  }
  const chip = (x, title) => '<button class="chip" type="button" data-' + prefix +
    '-pick="' + esc(x.id) + '" aria-pressed="' + (selected === String(x.id)) +
    '">' + esc(title || x.title) + '</button>';
  return '<p class="count-line">Izaberi odjel ili užu grupu. Uže grupe obično se učitavaju brže.</p>' +
    h.groups.map(g => '<details class="soon-grp"' +
      (selected && (String(selected) === String(g.id) ||
      (g.subs || []).some(x => String(x.id) === String(selected))) ? ' open' : '') +
      '><summary>' + esc(g.title) + '</summary><div class="chips">' +
      chip(g, 'Sve: ' + g.title) + (g.subs || []).map(x => chip(x, x.title)).join('') +
      '</div></details>').join('') +
    '<button class="text-btn" type="button" data-' + prefix +
    '-hier="1">Osvježi spisak odjela</button>';
}

export function loadHierarchy({ S, stCall, saveUser, toast, done }) {
  return stCall({ mode: 'hier' }, r => {
    if (r.how === 'ok' && r.res && Array.isArray(r.res.groups)) {
      S.user.hier = { at: Date.now(), groups: r.res.groups.slice(0, 40).map(g => ({
        id: String(g.id), title: String(g.title || ''),
        subs: (g.subs || []).slice(0, 60).map(x => ({ id: String(x.id), title: String(x.title || '') }))
      })) };
      saveUser();
    } else {
      toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Odjeli se nisu mogli učitati.');
    }
    done();
  });
}
