// The state of the last Minus lista / Regulacija zalihe sending, as the employee sees it, and the read-only check of
// a sending whose outcome is not known. Pure functions (no page, no phone): tested in tests/minusop.test.mjs.
//
// The record itself is kept by the phone (OpLog.java, data/minus-op.json), written before anything is sent.

export const LABEL = {
  prepared: 'Pripremljeno',
  confirming: 'Čeka potvrdu',
  sending: 'Slanje u toku',
  confirmed: 'Potvrđeno',
  partial: 'Djelimično završeno',
  failed: 'Neuspjelo',
  unknown: 'Ishod nepoznat – potrebna provjera',
  corrupt: 'Zapis slanja nečitljiv – potrebna provjera',
};

const STEP = { start: 'čitanje Minus liste', check: 'provjera liste', user: 'provjera korisnika', minus: 'Minus lista', adjust: 'Regulacija zalihe' };

/** The sending is still open: no new sending until it is resolved. */
export function locks(op) {
  if (!op) return false;
  if (op.state === 'sending' || op.state === 'corrupt') return true;
  return op.state === 'unknown' && !op.resolved;
}

/**
 * What the screen says about a record. Answer: { state, label, tone: ok | warn | bad | busy, text, lock } or null.
 * Words are chosen so that nothing reads as success unless StoreFront accepted it.
 */
export function describe(op) {
  if (!op || !op.state) return null;
  const n = (op.sent || op.items || []).length;
  const k = (op.skipped || []).length;
  const adjustOnly = op.kind === 'adjust';
  const where = STEP[op.step] || op.step || '';
  const base = { state: op.state, label: LABEL[op.state] || op.state, lock: locks(op) };
  switch (op.state) {
    case 'sending':
      return { ...base, tone: 'busy', text: `Šalje se u StoreFront (${where}). Ne zatvaraj aplikaciju.` };
    case 'corrupt':
      // the phone cannot read its own record: it does not know whether a sending was open, so it assumes one was
      return { ...base, tone: 'bad', text: 'Telefon ne može pročitati zapis posljednjeg slanja, pa ne zna je li neko slanje ostalo otvoreno. U StoreFrontu pogledaj Minus listu i Regulaciju zalihe za zadnjih nekoliko sati. Tek kad provjeriš, očisti zapis; do tada se ništa ne šalje.' };
    case 'confirmed':
      if (!n) return { ...base, tone: 'warn', text: `StoreFront nije ništa promijenio: ${k ? `${k} preskočeno jer se lista promijenila.` : 'ništa nije bilo za slanje.'}` };
      return { ...base, tone: 'ok', text: `StoreFront je prihvatio ${adjustOnly ? 'Regulaciju zalihe' : 'Minus listu i Regulaciju zalihe'} za ${n} ${n === 1 ? 'artikal' : 'artikala'}.${k ? ` Preskočeno ${k} (promijenilo se u međuvremenu).` : ''}` };
    case 'partial':
      return { ...base, tone: 'warn', text: 'Minus lista je ispravljena, Regulacija zalihe je odbijena. Pošalji samo Regulaciju ili je uradi u StoreFrontu.' };
    case 'failed':
      return { ...base, tone: 'bad', text: op.step === 'minus' ? 'StoreFront je odbio Minus listu. Ništa nije promijenjeno.' : 'Slanje nije počelo. Ništa nije promijenjeno.' };
    case 'unknown': {
      if (op.resolved) {
        return { ...base, label: op.resolved.how === 'done' ? 'Provjereno: prošlo je' : 'Provjereno: nije prošlo', lock: false, tone: op.resolved.how === 'done' ? 'ok' : 'warn',
          text: op.resolved.how === 'done'
            ? (op.step === 'minus' && !adjustOnly ? 'Provjereno u StoreFrontu: Minus lista je prošla. Regulacija zalihe još nije poslana, čeka u „Čeka Regulaciju“.' : 'Provjereno u StoreFrontu: prošlo je.')
            : 'Provjereno u StoreFrontu: nije prošlo. Možeš poslati ponovo.' };
      }
      // an answer that came but cannot be trusted (4xx, a sign-in page) is named as such, not as "no answer"
      const http = op.http || {};
      const ans = (k) => (http[k] ? `StoreFront je odgovorio HTTP ${http[k]}, a to ne potvrđuje da nije upisano.` : 'odgovor nije stigao.');
      const what = op.step === 'adjust'
        ? (adjustOnly ? `Regulacija zalihe je poslana, ${http.adjust ? '' : 'ali '}${ans('adjust')}` : `Minus lista je prihvaćena. Regulacija zalihe je poslana, ${http.adjust ? '' : 'ali '}${ans('adjust')}`)
        : op.step === 'minus' ? `Minus lista je poslana, ${http.minus ? '' : 'ali '}${ans('minus')} Regulacija nije poslana.`
          : op.stepLost
            ? `Slanje je prekinuto, a telefon nije mogao zapisati svaki korak: ne zna se dokle je stiglo (zadnji zapisani korak: ${where}).`
            : `Slanje je prekinuto (${where}). Po zapisu još ništa nije bilo poslano, ali zapis može kasniti za jedan korak.`;
      return { ...base, tone: 'bad', text: `${what} Provjeri u StoreFrontu prije ponovnog slanja; aplikacija neće slati ništa sama.` };
    }
    default:
      return { ...base, tone: 'warn', text: '' };
  }
}

/**
 * Compares a record with what StoreFront shows now (store-task.js opcheck: stock history since shortly before the
 * sending, and the Minus lista). For every line and step: 'seen' (exactly one movement by this user of exactly that
 * quantity on that article after the sending began), 'none', or 'unclear' (more than one, or one also before).
 * The answer only HELPS the employee: same article and quantity is not proof, so nothing is marked done from it.
 * Answer: { lines: [{ num, target, minus, adjust }], all: 'seen' | 'none' | 'mixed' }.
 */
export function evidence(op, chk, slackMs = 2 * 60 * 1000) {
  const since = (op && op.at) || 0;
  const until = ((op && op.end) || since) + 15 * 60 * 1000;
  const hist = (chk && chk.hist) || [];
  const minusNow = (chk && chk.minus) || {};
  const look = (art, q) => {
    const mine = hist.filter((h) => h.art === art && h.q === q && h.mine);
    const after = mine.filter((h) => h.t >= since - slackMs && h.t <= until);
    const before = mine.filter((h) => h.t < since - slackMs);
    if (after.length === 1 && !before.length) return 'seen';
    if (!after.length) return 'none';
    return 'unclear';
  };
  // every movement StoreFront shows for the article in that time, as it is: when (before / during / after the
  // sending), how many, which kind, by whom (this user or someone else), and whether it is exactly the one expected
  const moves = (art, q) => hist.filter((h) => h.art === art).sort((a, b) => a.t - b.t).map((h) => ({
    t: h.t, q: h.q, type: h.type, mine: !!h.mine,
    when: h.t < since - slackMs ? 'prije' : h.t <= until ? 'tokom' : 'poslije',
    exact: h.q === q && !!h.mine && h.t >= since - slackMs && h.t <= until,
  }));
  const lines = ((op && op.items) || []).map((it) => {
    const n = Math.abs(+it.qty);
    let minus = op.kind === 'adjust' ? 'skip' : look(it.num, n);
    // still on the Minus lista with the same minus: the Minus lista step did not go through for this line
    const stillMinus = Object.prototype.hasOwnProperty.call(minusNow, it.num) ? minusNow[it.num] : null;
    if (minus !== 'skip' && stillMinus === +it.qty) minus = 'none';
    return {
      num: it.num, target: it.target, minus, adjust: look(it.target, -n), stillMinus,
      numMoves: op.kind === 'adjust' ? [] : moves(it.num, n), targetMoves: moves(it.target, -n),
    };
  });
  const vals = lines.flatMap((l) => [l.minus, l.adjust]).filter((v) => v !== 'skip');
  const all = vals.length && vals.every((v) => v === 'seen') ? 'seen' : vals.length && vals.every((v) => v === 'none') ? 'none' : 'mixed';
  return { lines, all };
}
