// Reading planograms (PDF) into the app: picking, the import queue, pictures, replacing an older planogram, and
// reading again planograms of an older version or with lost pictures. Moved out of app.js in 1.69 WITHOUT changing a
// line of what it does. The old planogram is never removed before the new one and its list are saved (1.68).

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createImportUi(ctx) {
  const { $, A, S, afterAutoImport, artikala, ask, blobToBase64, closeSheet, core, docs, dropFiles, esc, icon, note, openSheet, pageCache, plural, progress, pruneSuperseded, queue, rebuildIndex, renderHome, renderItem, renderPlans, savePlansList, saveUser, store, toast, top } = ctx;


/** The running import as a bar under the search (tap: the progress sheet again). */
function importBar(title, pct, line) {
  const b = $('#importBar');
  if (!b) return;
  if (!S.importBg || !S.busy) { b.hidden = true; return; }
  b.hidden = false;
  b.innerHTML = `<i class="work-dot"></i><span><b>${esc(title)} · ${pct} %</b><small>${esc(line || '')} · pretraga radi sa postojećim planogramima</small></span>`;
}

function addPlanograms(targetId = null) {
  S.importTarget = targetId;
  A.pickPdfs();
}

window.onPicking = (n) => {
  if (S.busy && !S.refreshing) return; // the running import shows its own progress
  progress(n > 1 ? `Uvozim ${n} ${plural(n, 'fajl', 'fajla', 'fajlova')}` : 'Uvozim fajl', 0, 'Kopiram u aplikaciju…');
};

const newId = () => 'p' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);

function compactPlace(plan, it) {
  return it.oc.map((o) => {
    const p = core.placeOf(plan, o);
    return { module: p.module, shelf: p.shelf, notch: p.notch, segment: p.segment, fixture: p.fixture };
  });
}

function changesOf(oldPlan, newPlan, codes = null) {
  const d = core.diffPlans(oldPlan, newPlan, codes);
  return {
    added: d.added.map((n) => ({ num: n, nm: newPlan.items[n].nm, to: compactPlace(newPlan, newPlan.items[n]) })),
    removed: d.removed.map((n) => ({ num: n, nm: oldPlan.items[n].nm, from: compactPlace(oldPlan, oldPlan.items[n]) })),
    moved: d.moved.map((m) => ({ num: m.num, nm: newPlan.items[m.num].nm, from: compactPlace(oldPlan, oldPlan.items[m.num]), to: compactPlace(newPlan, newPlan.items[m.num]) })),
  };
}

function metaOf(id, f, plan) {
  const count = Object.values(plan.items).filter((it) => it.oc.length || it.rw.length).length;
  return {
    id,
    name: f.name,
    size: f.size,
    imported: Date.now(),
    key: plan.key,
    title: core.planTitle(plan),
    concept: plan.meta.concept || '',
    deadline: plan.meta.deadline || '',
    sections: [...new Map(plan.meta.sections.map((s) => [s.code + s.name, s])).values()],
    pages: plan.meta.pages,
    count,
    pictures: Object.values(plan.items).filter((it) => it.im).length,
  };
}

/** Saves the article pictures of a planogram; onStep(done, total). */
async function savePictures(id, thumbs, onStep) {
  const list = [...thumbs.entries()];
  const encoded = new Map(); // the same photo is shared by several numbers
  // the pictures are turned into text 16 at a time (in the background), then written in order
  const uniq = [...new Set(list.map(([, b]) => b))];
  for (let i = 0; i < uniq.length; i += 16) {
    const part = uniq.slice(i, i + 16);
    const txt = await Promise.all(part.map((b) => blobToBase64(b)));
    part.forEach((b, j) => encoded.set(b, txt[j]));
  }
  let done = 0;
  if (A.writeThumbs) {
    // 1.69: 24 pictures a call, written without waiting for the disk each (MainActivity.writeQuick)
    for (let i = 0; i < list.length; i += 24) {
      const part = {};
      for (const [num, blob] of list.slice(i, i + 24)) part[`${num}.webp`] = encoded.get(blob);
      A.writeThumbs(id, JSON.stringify(part));
      done = Math.min(list.length, i + 24);
      if (onStep) { onStep(done, list.length); await new Promise((r) => setTimeout(r, 0)); }
    }
    return;
  }
  for (const [num, blob] of list) {
    A.writeThumb(id, `${num}.webp`, encoded.get(blob));
    done++;
    if (onStep && done % 10 === 0) { onStep(done, list.length); await new Promise((r) => setTimeout(r, 0)); }
  }
}


window.onPicked = (list) => {
  if (list === null) {
    if (!S.busy) closeSheet();
    toast('Na telefonu nema aplikacije za izbor fajlova.');
    return;
  }
  if (!list || !list.length) { if (!S.busy) closeSheet(); return; }
  queue.push({ list, target: S.importTarget });
  S.importTarget = null;
  if (S.busy) {
    if (S.refreshing) progress('Uvoz čeka', 0, 'Jysk Reloaded završava slike za stari planogram i odmah nastavlja.');
    else toast('PDF čeka na red, Jysk Reloaded ga čita odmah poslije ovog.');
    return;
  }
  drainImports();
};

async function drainImports() {
  if (S.busy || !queue.length) return;
  S.busy = true;
  A.keepScreenOn(true);
  const results = [];
  const afters = [];
  let loud = false;
  try {
    while (queue.length) {
      const { list, target, auto } = queue.shift();
      const from = results.length;
      await importList(list, target, results);
      if (auto) afterAutoImport(auto, results, from);
      // 1.73-test4: a planogram downloaded from an article: no results sheet, the article screen shows what came
      if (auto && auto.after) { const mine = results.slice(from); afters.push(() => auto.after(mine)); }
      if (!(auto && auto.quiet)) loud = true;
    }
  } finally {
    A.clearInbox(); // only now: files of a queued import are in the inbox too
    A.keepScreenOn(false);
    S.busy = false;
    S.importBg = false;
    importBar();
  }
  renderHome();
  if (top().id === 'plans') renderPlans();
  if (loud) showResults(results);
  else closeSheet();
  for (const f of afters) { try { f(); } catch (e) { note('poslije uvoza: ' + String(e && e.message || e).slice(0, 80)); } }
  pageCache.start(); // the new planograms' pages
}

async function importList(list, forced, results) {
  for (let i = 0; i < list.length; i++) {
    const f = list[i];
    const title = list.length > 1 ? `Čitam ${i + 1}. od ${list.length}` : 'Čitam planogram';
    if (f.error || !f.file) { results.push({ kind: 'error', name: f.name }); continue; }
    progress(title, 0, f.name);
    let plan, thumbs;
    const tRead = Date.now();
    try {
      ({ plan, thumbs } = await docs.readPlanogram(`/files/inbox/${f.file}`, (frac, p, n, phase) => progress(title, frac * 0.92,
        phase === 'pictures' ? `Slike artikala, stranica ${p} od ${n}` : `${f.name}, stranica ${p} od ${n}`)));
    } catch (e) {
      console.warn('read', f.name, e);
      results.push({ kind: e.message === 'locked' ? 'locked' : 'bad', name: f.name });
      continue;
    }
    const meta0 = metaOf('', f, plan);
    if (!meta0.count) { results.push({ kind: 'notplan', name: f.name }); continue; }
    let target = forced ? S.plans.find((p) => p.id === forced) : S.plans.find((p) => core.samePlanogram(p.plan, plan));
    if (forced && target && !core.samePlanogram(target.plan, plan)) {
      const ok = await ask('Drugi odjel?',
        `<p><b>${esc(f.name)}</b> je planogram za <b>${esc(meta0.title)}</b>, a mijenjaš <b>${esc(target.title)}</b>.</p>`,
        [{ label: `Zamijeni ${target.title}`, value: 'replace', kind: 'btn-primary' }, { label: 'Dodaj kao novi', value: 'add', kind: 'btn-soft' }, { label: 'Preskoči', value: 'skip', kind: 'btn-quiet' }]);
      if (ok === 'skip' || !ok) { results.push({ kind: 'skipped', name: f.name }); continue; }
      if (ok === 'add') target = null;
    }
    if (target && core.deadlineValue(target.deadline) > core.deadlineValue(plan.meta.deadline) && core.deadlineValue(plan.meta.deadline)) {
      const ok = await ask('Ovaj planogram je stariji',
        `<p><b>${esc(f.name)}</b> ima rok ${esc(core.deadlineLabel(plan.meta.deadline))}, a planogram koji već imaš ima rok ${esc(core.deadlineLabel(target.deadline))}.</p>`,
        [{ label: 'Ipak zamijeni', value: 'replace', kind: 'btn-primary' }, { label: 'Zadrži postojeći', value: 'skip', kind: 'btn-soft' }]);
      if (ok !== 'replace') { results.push({ kind: 'skipped', name: f.name }); continue; }
    }
    // read much thinner than the planogram it replaces: maybe a bad scan, a wrong file or a reading error
    if (target) {
      const was = core.articlesIn(target.plan), now = core.articlesIn(plan);
      if (was >= 10 && now < was * 0.5) {
        const ok = await ask('Novi PDF ima mnogo manje artikala',
          `<p><b>${esc(f.name)}</b>: pročitano ${now} ${plural(now, 'artikal', 'artikla', 'artikala')} s mjestom, a planogram koji mijenja (<b>${esc(target.title)}</b>) ima ${was}.</p><p>Možda PDF nije dobro pročitan ili nije cijeli. Ako zamijeniš, stari se briše.</p>`,
          [{ label: 'Zadrži stari', value: 'skip', kind: 'btn-primary' }, { label: 'Ipak zamijeni', value: 'replace', kind: 'btn-soft' }]);
        if (ok !== 'replace') { results.push({ kind: 'skipped', name: f.name }); continue; }
      }
    }
    // a PDF with only some sections of a planogram takes over just those sections
    const partOf = target ? [] : S.plans
      .map((p) => ({ p, codes: core.sharedSections(p.plan, plan) }))
      .filter((x) => x.codes.size);
    const id = newId();
    const before = S.plans.slice();
    if (!A.keepPdf(f.file, `${id}.pdf`) || !store.write(`plan-${id}.json`, plan)) {
      dropFiles(id);
      results.push({ kind: 'error', name: f.name });
      continue;
    }
    const tPics = Date.now();
    await savePictures(id, thumbs, (d, n) => progress(title, 0.92 + (0.08 * d) / n, `Spremam slike artikala, ${d} od ${n}`));
    note(`uvoz planograma: ${plan.pages.length} str., ${meta0.count} artikala, čitanje ${tPics - tRead} ms, spremanje ${thumbs.size} slika ${Date.now() - tPics} ms${A.writeThumbs ? '' : ' (pojedinačno)'}`);
    const meta = { ...metaOf(id, f, plan), thumbN: thumbs.size }; // thumbN: pictures written, checked at start (1.69)
    if (target) {
      const ch = changesOf(target.plan, plan);
      S.user.changes[id] = { ...ch, from: target.deadline, to: meta.deadline, at: Date.now(), title: meta.title };
      delete S.user.changes[target.id];
      S.plans = S.plans.map((p) => (p.id === target.id ? { ...meta, plan } : p));
      results.push({ kind: 'replaced', name: f.name, meta, old: target, ch });
    } else {
      let ch = null;
      for (const { p, codes } of partOf) {
        const c = changesOf(p.plan, plan, codes);
        ch = ch ? { added: ch.added.concat(c.added), removed: ch.removed.concat(c.removed), moved: ch.moved.concat(c.moved) } : c;
      }
      if (ch) S.user.changes[id] = { ...ch, from: partOf[0].p.deadline, to: meta.deadline, at: Date.now(), title: meta.title };
      S.plans.push({ ...meta, plan });
      results.push({ kind: 'added', name: f.name, meta, partOf, ch });
    }
    rebuildIndex();
    const pruned = pruneSuperseded();
    for (const g of pruned) results.push({ kind: 'pruned', name: g.name, meta: g });
    // the old files go only once the new list is on the disk; if it cannot be written, everything stays as it was
    if (!savePlansList()) {
      S.plans = before;
      rebuildIndex();
      dropFiles(id);
      results.splice(results.length - 1 - pruned.length, 1 + pruned.length, { kind: 'error', name: f.name });
      continue;
    }
    if (target) dropFiles(target.id);
    for (const g of pruned) dropFiles(g.id);
    saveUser();
  }
}

function showResults(results) {
  const line = (r) => {
    switch (r.kind) {
      case 'added': {
        let extra = '';
        if (r.partOf && r.partOf.length) {
          const secs = r.meta.sections.map((x) => `${x.code} ${x.name}`).join(', ');
          const n = r.ch ? r.ch.added.length + r.ch.moved.length + r.ch.removed.length : 0;
          extra = `<p>Za ${esc(secs)} sada vrijedi ovaj PDF umjesto ${esc(r.partOf.map((x) => x.p.title).join(', '))}.</p>${n
            ? `<button class="btn btn-small btn-soft" type="button" data-changes="${r.meta.id}">${icon('list')}Pogledaj promjene (${n})</button>` : ''}`;
        }
        return `<div class="result"><b>Dodan: ${esc(r.meta.title)}</b><p>${artikala(r.meta.count)}, ${r.meta.pictures} sa slikom${r.meta.deadline ? `, rok ${esc(core.deadlineLabel(r.meta.deadline))}` : ''}.</p>${extra}</div>`;
      }
      case 'pruned':
        return `<div class="result"><b>Uklonjen stari: ${esc(r.meta.title)}</b><p>Sve iz njega sada pokrivaju noviji planogrami.</p></div>`;
      case 'replaced': {
        const c = r.ch;
        const parts = [];
        if (c.added.length) parts.push(`${c.added.length} ${plural(c.added.length, 'novi', 'nova', 'novih')}`);
        if (c.moved.length) parts.push(`${c.moved.length} ${plural(c.moved.length, 'premješten', 'premještena', 'premještenih')}`);
        if (c.removed.length) parts.push(`${c.removed.length} ${plural(c.removed.length, 'izbačen', 'izbačena', 'izbačenih')}`);
        const dl = r.old.deadline && r.meta.deadline && r.old.deadline !== r.meta.deadline
          ? ` (${esc(core.deadlineLabel(r.old.deadline))} → ${esc(core.deadlineLabel(r.meta.deadline))})` : '';
        return `<div class="result"><b>Zamijenjen: ${esc(r.meta.title)}${dl}</b><p>${parts.length ? parts.join(', ') + '.' : 'Nema promjena u rasporedu.'}</p>${parts.length
          ? `<button class="btn btn-small btn-soft" type="button" data-changes="${r.meta.id}">${icon('list')}Pogledaj promjene</button>` : ''}</div>`;
      }
      case 'checked':
        return `<div class="result"><b>Provjereno ${r.n} ${plural(r.n, 'planogram', 'planograma', 'planograma')} (${esc(r.side)})</b><p>${r.same ? `${r.same} bez promjene${r.skipped ? ` (${r.skipped} ${r.skipped === 1 ? 'nije preuzet: MYJYSK ga nije mijenjao' : 'nisu preuzeti: MYJYSK ih nije mijenjao'} od zadnjeg preuzimanja)` : ''}. ` : ''}${r.fresh ? `${r.fresh} ${plural(r.fresh, 'novi ili promijenjen', 'nova ili promijenjena', 'novih ili promijenjenih')}.` : 'Nema novih planograma.'}</p></div>`;
      case 'dlerror':
        return `<div class="result"><b>${esc(r.name)}</b><p>Nije preuzet: ${esc(r.why || 'greška')}.</p></div>`;
      case 'notplan':
        return `<div class="result"><b>${esc(r.name)}</b><p>Ne izgleda kao planogram: u njemu nema šifara artikala.</p></div>`;
      case 'locked':
        return `<div class="result"><b>${esc(r.name)}</b><p>PDF je zaključan šifrom.</p></div>`;
      case 'skipped':
        return `<div class="result"><b>${esc(r.name)}</b><p>Preskočen.</p></div>`;
      default:
        return `<div class="result"><b>${esc(r.name)}</b><p>Ovaj PDF se ne može pročitati.</p></div>`;
    }
  };
  const ok = results.filter((r) => r.kind === 'added' || r.kind === 'replaced').length;
  const checked = results.some((r) => r.kind === 'checked');
  const again = results.find((r) => r.kind === 'checked' && r.again);
  openSheet({
    title: checked ? (ok ? 'Novi planogrami su tu' : 'Planogrami su najnoviji') : ok ? (results.length === 1 ? 'Planogram je spreman' : 'Uvoz je gotov') : 'Ništa nije uvezeno',
    body: results.map(line).join(''),
    actions: [{ label: 'U redu', kind: 'btn-primary', onClick: closeSheet },
      ...(again ? [{ label: 'Preuzmi ipak sve ponovo', kind: 'btn-quiet', onClick: () => { closeSheet(); again.again(); } }] : [])],
  });
}

// ----------------------------------------- planograms read by an older version

/** Reads planograms imported by an older version again from their PDFs, to add the article pictures. */
/**
 * The article pictures of a planogram are written without waiting for the disk (writeQuick). Should some be missing
 * (a power cut right after the import), they are cut from the planogram's own PDF again, in the background: the
 * planogram itself is not changed. Checked once at start, for planograms imported since 1.69 (thumbN known).
 */
async function repairPictures() {
  if (!A.thumbCount || S.busy) return;
  const short = S.plans.filter((p) => p.thumbN > 0 && A.thumbCount(p.id) >= 0 && A.thumbCount(p.id) < p.thumbN);
  if (!short.length) return;
  S.busy = true;
  S.refreshing = true;
  const line = $('#workLine');
  const say = (t) => { line.querySelector('span').textContent = t; line.hidden = false; };
  try {
    for (const p of short) {
      if (!S.plans.some((x) => x.id === p.id)) continue;
      const had = A.thumbCount(p.id);
      say(`Obnavljam slike artikala, ${p.title}`);
      try {
        const { thumbs } = await docs.readPlanogram(`/files/plans/${p.id}.pdf`, (frac) => say(`Obnavljam slike artikala, ${p.title}, ${Math.round(frac * 100)}%`));
        if (!S.plans.some((x) => x.id === p.id)) continue;
        await savePictures(p.id, thumbs);
        const now = A.thumbCount(p.id);
        note(`slike planograma obnovljene: bilo ${had} od ${p.thumbN}, sada ${now}`);
        // still short (the phone cannot write them): what is there counts from now on, so the PDF is not read again
        // at every start
        if (now >= 0 && now < p.thumbN) {
          S.plans = S.plans.map((x) => (x.id === p.id ? { ...x, thumbN: now } : x));
          savePlansList();
        }
        if (top().id === 'item') renderItem(); else if (top().id === 'home') renderHome();
      } catch (e) {
        note(`slike planograma nisu obnovljene: ${String(e && e.message || e).slice(0, 80)}`);
      }
    }
  } finally {
    line.hidden = true;
    S.busy = false;
    S.refreshing = false;
  }
  drainImports();
}

async function refreshOld() {
  const old = S.plans.filter((p) => (p.plan.v || 1) < docs.PLAN_VERSION);
  if (!old.length || S.busy) return;
  S.busy = true;
  S.refreshing = true;
  const line = $('#workLine');
  const say = (t) => { line.querySelector('span').textContent = t; line.hidden = false; };
  const still = (id) => S.plans.some((x) => x.id === id); // deleted meanwhile?
  try {
    for (const p of old) {
      if (!still(p.id)) continue;
      say(`Pripremam slike artikala, ${p.title}`);
      try {
        const { plan, thumbs } = await docs.readPlanogram(`/files/plans/${p.id}.pdf`, (frac) => {
          say(`Pripremam slike artikala, ${p.title}, ${Math.round(frac * 100)}%`);
        });
        if (!still(p.id)) continue;
        A.removeThumbs(p.id);
        await savePictures(p.id, thumbs);
        if (!still(p.id)) { A.removeThumbs(p.id); continue; }
        if (!store.write(`plan-${p.id}.json`, plan)) continue;
        const cur = S.plans.find((x) => x.id === p.id);
        const meta = { ...metaOf(p.id, cur, plan), imported: cur.imported, thumbN: thumbs.size };
        S.plans = S.plans.map((x) => (x.id === p.id ? { ...meta, plan } : x));
        savePlansList();
        rebuildIndex();
        const t = top();
        if (t.id === 'home') renderHome();
        else if (t.id === 'item') renderItem();
        else if (t.id === 'plans') renderPlans();
      } catch (e) {
        console.warn('refresh', p.id, e);
      }
    }
  } finally {
    line.hidden = true;
    S.busy = false;
    S.refreshing = false;
  }
  drainImports();
}


  return { addPlanograms, drainImports, importBar, refreshOld, repairPictures, showResults };
}
