// Planogram notes in Bosnian (owner, 14. 11. 2026): JYSK's planogram PDFs carry short English instructions under a
// label ("Display in 4912804 ROY"). The employee should understand them at once. Translated on the phone, when the note
// is SHOWN (the stored planogram keeps the PDF's text, so planograms imported before get it without a new import).
// Only patterns that are certain are translated; every model name, size and code is kept as written; anything else
// stays in English (a wrong instruction is worse than an English one). No business text leaves the phone.

// What the article is, from its name (planogram or StoreFront, English or Bosnian), for "u <locative>"
const KINDS = [
  [/\b(vase|vases|vaza|vaze)\b/i, 'vazi'],
  [/\b(basket|baskets|korpa|korpe|košara|kosara)\b/i, 'korpi'],
  [/\b(bowl|bowls|zdjela|zdjele|činija|cinija)\b/i, 'zdjeli'],
  [/\b(tray|trays|pladanj|poslužavnik|posluzavnik)\b/i, 'pladnju'],
  [/\b(box|boxes|kutija|kutije)\b/i, 'kutiji'],
  [/\b(bucket|kanta)\b/i, 'kanti'],
  [/\b(jar|jars|tegla|staklenka)\b/i, 'tegli'],
  [/\b(flower ?pot|plant ?pot|saksija|tegla za cvijeće)\b/i, 'saksiji'],
  [/\b(lantern|lanterns|fenjer|lampion)\b/i, 'fenjeru'],
  [/\b(crate|gajba)\b/i, 'gajbi'],
];
/** The locative of what the article is ("vazi"), or '' when its name does not say it surely. */
export function kindIn(name) {
  const n = String(name || '');
  for (const [rx, loc] of KINDS) if (rx.test(n)) return loc;
  return '';
}
const kindsIn = (name) => KINDS.filter(([rx]) => rx.test(String(name || ''))).map(([, loc]) => loc);

/** The text as the PDF gave it, tidied: line breaks, typographic quotes, a word split over two lines. */
export function tidy(text) {
  return String(text || '')
    .replace(/[“”„‟«»″]/g, '"')
    .replace(/[‘’‚‛′]/g, "'")
    .replace(/([a-z])-\s*\n\s*([a-z])/g, '$1$2') // "Dis-\nplay"
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^["']+|["']+$/g, '')
    .trim();
}

const CODE = '\\d{7}';
// what the instruction points at: codes (one or more, "/" or "," or "i") and/or a model name with sizes
const REF = `((?:${CODE}(?:\\s*(?:[/,&+]|and|i)\\s*${CODE})*)?)\\s*([A-ZČĆŽŠĐ0-9][A-Za-zČĆŽŠĐčćžšđ0-9 .,x×\\-/()'"]*)?`;
const VERBS = [
  // [English, Bosnian verb, preposition rules]
  [/^(?:display|show)$/i, 'Izložiti'],
  [/^(?:place|put|position)$/i, 'Staviti'],
  [/^hang$/i, 'Objesiti'],
];
const PREPS = [
  [/^(?:in|inside|into)$/i, 'u'],
  [/^(?:on|onto|on top of)$/i, 'na'],
  [/^(?:with|together with)$/i, 'zajedno s'],
  [/^(?:next to|beside|by)$/i, 'pored'],
  [/^(?:under|below|beneath)$/i, 'ispod'],
  [/^(?:above|over)$/i, 'iznad'],
  [/^behind$/i, 'iza'],
  [/^in front of$/i, 'ispred'],
];
const RX = new RegExp(`^(display|show|place|put|position|hang)\\s+(on top of|in front of|together with|next to|inside|into|onto|in|on|with|beside|by|under|below|beneath|above|over|behind)\\s+${REF}$`, 'i');

// whole notes that are only these words
const FIXED = [
  [/^mix(?:ed)? colou?rs?$/i, 'Miješane boje'],
  [/^assorted colou?rs?$/i, 'Različite boje'],
  [/^assorted$/i, 'Razni modeli'],
  [/^(?:display|show) (?:all|every) colou?rs?$/i, 'Izložiti sve boje'],
  [/^(?:display|show) (?:all|every) sizes?$/i, 'Izložiti sve veličine'],
  [/^(?:display|show) folded$/i, 'Izložiti složeno'],
  [/^(?:display|show) hanging$/i, 'Izložiti obješeno'],
  [/^(?:display|show) stacked$/i, 'Izložiti naslagano'],
  [/^(?:display|show) standing$/i, 'Izložiti uspravno'],
  [/^(?:display|show) lying( down)?$/i, 'Izložiti položeno'],
  [/^hang on hooks?$/i, 'Objesiti na kuku'],
  [/^front facing$/i, 'Licem prema kupcu'],
];

/**
 * { text, orig, done }: text is the Bosnian instruction (the original when it is not translated), done says whether
 * it was. name(code) gives an article's name (planogram or StoreFront) to tell what the referred article is.
 */
export function noteBs(raw, name = () => '') {
  const orig = tidy(raw);
  for (const [rx, bs] of FIXED) if (rx.test(orig)) return { text: bs, orig, done: true };
  const m = RX.exec(orig);
  if (!m) return { text: orig, orig, done: false };
  const verb = VERBS.find(([rx]) => rx.test(m[1]));
  const prep = PREPS.find(([rx]) => rx.test(m[2]));
  const codes = (m[3] || '').match(/\d{7}/g) || [];
  const model = (m[4] || '').trim();
  if (!verb || !prep || (!codes.length && !model)) return { text: orig, orig, done: false };
  // a model name must look like one (capitals, as JYSK writes them), not a sentence we cannot read
  if (model && !codes.length && !/^[A-ZČĆŽŠĐ0-9]/.test(model)) return { text: orig, orig, done: false };
  if (model && /\b(the|and|or|of|to|for|if|when|only)\b/.test(model)) return { text: orig, orig, done: false };
  const what = [model, codes.length ? `(${codes.join(', ')})` : ''].filter(Boolean).join(' ');
  let p = prep[1];
  if (p === 'u') {
    const kinds = [...new Set([model, ...codes.map((c) => name(c))].flatMap(kindsIn))];
    // only when every name that says something says the same: "u vazi ROY (4912804)"; else "u: ROY (4912804)"
    p = kinds.length === 1 ? `u ${kinds[0]}` : 'u:';
  }
  return { text: `${verb[1]} ${p} ${what}`.replace(/\s+/g, ' ').trim(), orig, done: true };
}
