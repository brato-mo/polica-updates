// Ostali alati → OOPUS (1.98, owner): online orders the customer picks up in the store ("Naruči online – Preuzmi u
// prodavnici"). The same data and the same handover as StoreFront's own page Orders → OOPUS (GK)
// (/ui/legacy-oopus-orders, read from its code on 14. 11. 2026), through store-task.js oopuslist / oopusfind /
// oopusorder / oopushandout:
//   list    the tab "Aktivan" (Naručeno, U tranzitu, Spremno za preuzimanje) and the counts of the other tabs
//   search  StoreFront's own search (order number = the barcode on the customer's order, name, phone, e-mail, article)
//   order   articles, quantities, CSC's notes and the next step StoreFront allows (the same rules as its order sheet)
//   handover  only READY_FOR_PICKUP: the employee checks (order, ID card, all articles), the customer signs with a
//           finger, the signature goes as StoreFront's own "Potpis kupca" → "Spremi" does (a PNG to handout/...).
//           "Preuzimanje potvrđeno" only after StoreFront said so. Never queued for later, never sent twice: an answer
//           that did not come back means reading the order's real state before anything else.
// Customer data (names, the order's content, the signature) stays in this screen's memory: never saved, never in the
// flow log or the diagnostics (they get the phase, how long it took and the kind of error only).

export function createOopusUi(ctx) {
  const { $, A, S, esc, icon, go, top, back, ageText, toast, plural, whole, stCall, offline } = ctx;
  const flow = ctx.flow || null;
  const scanFor = ctx.scanFor || null;
  // 1.99: the article's picture (app.js thumb: StoreFront's picture from the phone's own store, asked for when the row
  // is on the screen) and its code that opens that very article in StoreFront (app.js sfCode, as in Narudžbe)
  const thumb = ctx.thumb || (() => '');
  const sfCode = ctx.sfCode || ((n) => esc(n));
  const RET_OK = new Set(['NOT_RETURNED', 'PARTIALLY_RETURNED', 'RETURNED']);

  const ST = {
    ORDERED: ['Naručeno', 'Čeka slanje iz skladišta'], IN_TRANSIT: ['U tranzitu', 'Poslano iz skladišta (DC)'],
    READY_FOR_PICKUP: ['Spremno za preuzimanje', 'Kupac je obaviješten'], OVERDUE: ['Zakasnilo', 'Više od 7 dana od isporuke'],
    CANCELLED: ['Otkazano', ''], COMPLETED: ['Završeno', 'Predano kupcu'],
  };
  const stName = (s) => (ST[s] ? ST[s][0] : s ? 'Nepoznat status' : '—');
  const HIST = {
    CORRESPONDENCE_PICKED_READY_FOR_HANDOUT: 'Kupcu javljeno: spremno za preuzimanje', CORRESPONDENCE_REMINDER_SENT: 'Poslan podsjetnik',
    CORRESPONDENCE_CUSTOM_MESSAGE: 'Poruka', CORRESPONDENCE_IN_TRANSIT: 'Kupcu javljeno: u tranzitu',
  };
  const keyOf = (o) => `${o.bk}:${o.dg}`;
  const day = (t) => { const d = new Date(t); return t && Number.isFinite(d.getTime()) ? `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}.` : ''; };
  const hm = (t) => { const d = new Date(t); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const km = (o) => (o.amount == null ? '' : `${o.amount.toFixed(2).replace('.', ',')} ${o.cur === 'BAM' || !o.cur ? 'KM' : esc(o.cur)}`);
  const kom = (n) => `${whole(n)} kom`;

  // memory only: { list: { store, at, orders, totals }, err, busy, filter, q, found, order, hand }
  // 2.12: the signature as sent to StoreFront, at most (see sigPng). StoreFront's own, read from 5 completed orders'
  // history on 18. 11. 2026: 306 × 284 or 458 × 284 px, 6-9 KB, kept as a data URL of 7.5-13 thousand characters.
  const SIG_W = 458, SIG_H = 284, SIG_MAX = 16000, SIG_BIG = 'big';
  const v = { list: null, err: null, busy: false, filter: 'all', q: '', found: null, findBusy: false, findErr: null, cur: null, order: null, orderBusy: false, orderErr: null, hand: null, seq: 0 };
  const sending = new Set(); // order keys whose handover is on its way (double tap, a second screen)

  const call = (arg) => new Promise((ok, no) => {
    const sent = stCall(arg, (r) => {
      if (r.how === 'ok' && r.res) { ok(r.res); return; }
      const e = String(r.err || '');
      no({ how: r.how === 'login' ? 'login' : offline() || /offline/.test(e) ? 'offline' : /^state /.test(e) ? 'state' : e === 'context' ? 'context' : e === 'not found' ? 'missing' : /^http 4/.test(e) ? 'rejected' : 'error', err: e });
    });
    if (!sent) no({ how: 'offline' });
  });
  const why = (e) => (e && e.how === 'login' ? 'Prijava u StoreFront je istekla.' : e && e.how === 'offline' ? 'Nema interneta.' : 'StoreFront nije odgovorio.');
  const openOfficial = () => { try { A.storefrontPage('oopus'); } catch (e) { toast('OOPUS u StoreFrontu se nije otvorio.'); } };
  const sorted = (l) => l.slice().sort((a, b) => (a.st === 'READY_FOR_PICKUP' ? 0 : 1) - (b.st === 'READY_FOR_PICKUP' ? 0 : 1) || (a.expected || 9e15) - (b.expected || 9e15));

  // ------------------------------------------------------------------ the list
  function open() {
    go('oopus');
    load();
  }
  async function load() {
    if (v.busy) return;
    v.busy = true; v.err = null; renderList();
    const t0 = Date.now();
    const f = flow ? flow.start('oopus', 'Čitanje OOPUS') : null;
    try {
      const r = await call({ mode: 'oopuslist', tab: 'LEGACY_UNCOMPLETED', flow: f });
      if (v.list && v.list.store !== r.store) { v.order = null; v.found = null; }
      v.list = { store: r.store, at: Date.now(), orders: r.orders || [], totals: r.totals || null, total: r.total };
      if (f) f.end('ok', { n: v.list.orders.length, ms: Date.now() - t0 });
    } catch (e) {
      v.err = e;
      if (f) f.end({ login: 'login', offline: 'network', rejected: 'rejected' }[e.how] || 'network', { why: e.how, ms: Date.now() - t0 });
    }
    v.busy = false;
    if (top().id === 'oopus') renderList();
    ctx.onChange && ctx.onChange();
  }
  const counts = () => {
    const o = (v.list && v.list.orders) || [];
    const c = { all: o.length, ready: 0, transit: 0, ordered: 0 };
    o.forEach((x) => { if (x.st === 'READY_FOR_PICKUP') c.ready++; else if (x.st === 'IN_TRANSIT') c.transit++; else if (x.st === 'ORDERED') c.ordered++; });
    return c;
  };
  const FILTERS = [['ready', 'Spremno za preuzimanje', (x) => x.st === 'READY_FOR_PICKUP'], ['transit', 'U tranzitu', (x) => x.st === 'IN_TRANSIT'], ['ordered', 'Naručeno', (x) => x.st === 'ORDERED'], ['all', 'Sve aktivne', () => true]];
  /** the loaded list filtered by the search text: order number, name, article number */
  function localMatch(q) {
    const t = q.trim().toLowerCase();
    if (!t) return null;
    return ((v.list && v.list.orders) || []).filter((o) => o.no.includes(t) || o.bk === t || o.who.toLowerCase().includes(t) || o.lines.some((l) => l.num === t));
  }
  function row(o) {
    const late = o.st !== 'READY_FOR_PICKUP' && o.expected && o.expected < Date.now() && o.st !== 'COMPLETED' && o.st !== 'CANCELLED';
    const marks = [
      o.ret === 'RETURNED' ? '<span class="pill pill-warn">Vraćeno (CSC)</span>' : o.ret === 'PARTIALLY_RETURNED' ? '<span class="pill pill-warn">Djelimično vraćeno</span>' : '',
      o.comm ? '<span class="pill pill-order">Komentar CSC-a</span>' : '', o.issue ? '<span class="pill pill-warn">Čeka korisničku službu</span>' : '',
    ].join('');
    return `<button class="item oopus-row is-${esc(o.st.toLowerCase())}" type="button" data-oopus="${esc(keyOf(o))}">
      <span class="oopus-main"><b class="oopus-who">${esc(o.who || 'Kupac bez imena')}</b><span class="oopus-no">${esc(o.no)}</span>
        <span class="oopus-meta"><span class="pill oopus-st st-${esc(o.st.toLowerCase())}">${esc(stName(o.st))}</span>${marks}</span>
        <small>${o.lines.length} ${plural(o.lines.length, 'artikal', 'artikla', 'artikala')} · ${kom(o.qty)}${o.expected ? ` · <span class="${late ? 'is-late' : ''}">očekivano ${esc(day(o.expected))}</span>` : ''}</small></span>${icon('chev', 'chev')}</button>`;
  }
  function stateBox() {
    const e = v.err;
    if (!e) return '';
    const kept = v.list ? ' Prikazana je lista iz zadnjeg čitanja.' : '';
    if (e.how === 'login') return `<div class="oopus-state is-login"><b>Prijava u StoreFront je istekla</b><small>Prijavi se u StoreFrontu pa osvježi.${kept}</small><span class="oopus-state-btns"><button class="btn btn-primary" type="button" data-oopus-sf>Prijavi se u StoreFrontu</button><button class="btn" type="button" data-oopus-reload>Osvježi</button></span></div>`;
    if (e.how === 'offline') return `<div class="oopus-state is-off"><b>Nema interneta</b><small>OOPUS se čita iz StoreFronta.${kept}</small><button class="btn" type="button" data-oopus-reload>Pokušaj ponovo</button></div>`;
    return `<div class="oopus-state is-err"><b>Greška pri čitanju</b><small>StoreFront nije odgovorio.${kept}</small><button class="btn" type="button" data-oopus-reload>Pokušaj ponovo</button></div>`;
  }
  function renderList() {
    const body = $('#oopusBody');
    if (!body) return;
    const c = counts(), L = v.list, tot = L && L.totals;
    let h = `<div class="oopus-search"><input id="oopusQ" type="search" inputmode="search" autocomplete="off" placeholder="Broj narudžbe, ime ili artikal" value="${esc(v.q)}" aria-label="Traži OOPUS narudžbu">
      ${scanFor ? `<button class="round-btn" type="button" data-oopus-scan aria-label="Skeniraj narudžbu">${icon('scan')}</button>` : ''}</div>`;
    h += `<p class="count-line oopus-when">${v.busy ? 'Osvježavam…' : L ? `Osvježeno u ${hm(L.at)} (${esc(ageText(L.at))})` : ''}</p>`;
    h += stateBox();
    if (v.q.trim()) { body.innerHTML = h + searchHtml(); return; }
    if (!L) { body.innerHTML = h + (v.busy ? '<p class="empty">Čitam OOPUS narudžbe iz StoreFronta…</p>' : ''); return; }
    h += `<div class="chips oopus-filters">${FILTERS.map(([id, label]) => `<button class="chip" type="button" role="radio" aria-checked="${v.filter === id}" data-oopus-filter="${id}">${label} <small>${c[id]}</small></button>`).join('')}</div>`;
    if (tot) h += `<p class="oopus-tot">Uskoro stižu: <b>${whole(tot.LEGACY_NOT_YET_ARRIVED || 0)}</b> · Završeno: <b>${whole(tot.LEGACY_COMPLETED || 0)}</b></p>`;
    const pick = FILTERS.find((f) => f[0] === v.filter)[2];
    const rows = sorted(L.orders.filter(pick));
    if (!L.orders.length) h += '<div class="oopus-state is-empty"><b>Nema aktivnih OOPUS narudžbi</b><small>StoreFront nema nijednu narudžbu u kartici „Aktivan“ za ovu prodavnicu.</small></div>';
    else if (!rows.length) h += `<p class="empty">Nema narudžbi sa statusom „${esc(FILTERS.find((f) => f[0] === v.filter)[1])}“.</p>`;
    else h += `<div class="list">${rows.map(row).join('')}</div>`;
    if (L.total > L.orders.length) h += `<p class="oopus-tot">Prikazano ${L.orders.length} od ${L.total}. Ostale traži pretragom.</p>`;
    h += `<button class="btn btn-block oopus-sf" type="button" data-oopus-sf>${icon('link')}Otvori OOPUS u StoreFrontu</button>`;
    body.innerHTML = h;
  }
  function searchHtml() {
    const loc = localMatch(v.q) || [];
    const fs = v.found && v.found.q === v.q.trim() ? v.found : null;
    const seen = new Set(loc.map(keyOf));
    const more = fs ? fs.orders.filter((o) => !seen.has(keyOf(o))) : [];
    let h = '';
    if (loc.length) h += `<div class="list">${sorted(loc).map(row).join('')}</div>`;
    if (more.length) h += `<p class="stk-h">Iz StoreFront pretrage</p><div class="list">${more.map(row).join('')}</div>`;
    if (v.findBusy) h += '<p class="empty">Tražim u StoreFrontu…</p>';
    else if (v.findErr) h += `<p class="ord-trust is-unknown">${esc(why(v.findErr))} <button class="link" type="button" data-oopus-find>Pokušaj ponovo</button></p>`;
    else if (!fs && v.q.trim().length >= 3) h += `<button class="btn btn-block" type="button" data-oopus-find>${icon('search')}Traži „${esc(v.q.trim())}“ u StoreFrontu</button>`;
    else if (fs && !loc.length && !more.length) h += `<p class="empty">Nema narudžbe za „${esc(v.q.trim())}“. StoreFront traži po punom broju narudžbe (10 cifara), imenu, telefonu ili e-mailu.</p>`;
    if (v.q.trim().length < 3 && !loc.length) h += '<p class="empty">Upiši bar 3 znaka ili skeniraj barkod s narudžbe kupca.</p>';
    return h;
  }
  let findSeq = 0;
  async function find(q) {
    q = String(q || '').trim();
    if (q.length < 3 || q !== v.q.trim()) return;
    // 1.99: a scan of B while A is still being searched: B is searched at once (1.98 dropped it while A was busy) and
    // the late answer for A is dropped (it opened A's customer over B)
    const my = ++findSeq;
    v.findBusy = true; v.findErr = null; v.found = null; renderList();
    let r = null, err = null;
    try { r = await call({ mode: 'oopusfind', q, flow: flow ? flow.start('oopus', 'Pretraga OOPUS') : null }); } catch (e) { err = e; }
    if (my !== findSeq) return; // an older search: nothing of it is shown, the newer one is still on its way
    v.findBusy = false;
    if (v.q.trim() !== q) { if (top().id === 'oopus') renderList(); return; } // the field says something else now
    if (err) v.findErr = err; else v.found = { q, orders: r.orders || [] };
    if (top().id === 'oopus') { renderList(); const one = v.found && v.found.q === q && !localMatch(q).length && v.found.orders.length === 1 ? v.found.orders[0] : null; if (one) openOrder(one); }
  }
  let typing = 0;
  function onInput(q) {
    v.q = q;
    clearTimeout(typing);
    renderListKeepFocus();
    // a whole order number (the barcode, 10 digits) that is not in the list: StoreFront's search at once
    if (/^\d{10}$/.test(q.trim()) && !(localMatch(q) || []).length) typing = setTimeout(() => find(q), 250);
  }
  function renderListKeepFocus() {
    const a = $('#oopusQ'), pos = a ? a.selectionStart : null;
    renderList();
    const b = $('#oopusQ');
    if (b && a) { b.focus(); try { b.setSelectionRange(pos, pos); } catch (e) { /* type=search */ } }
  }
  function fromScan(code) {
    const c = String(code || '').replace(/\D/g, '');
    if (!c) { renderList(); return; }
    clearTimeout(typing);
    v.q = c;
    const loc = localMatch(c) || [];
    if (loc.length === 1) { renderList(); openOrder(loc[0]); return; }
    renderList();
    if (!loc.length) find(c);
  }

  // ------------------------------------------------------------------ one order
  function findKey(k) {
    const all = [...((v.list && v.list.orders) || []), ...((v.found && v.found.orders) || [])];
    return all.find((o) => keyOf(o) === k) || (v.order && keyOf(v.order) === k ? v.order : null);
  }
  function openOrder(o) {
    if (!o) return;
    v.cur = keyOf(o);
    if (!v.order || keyOf(v.order) !== v.cur) v.order = { ...o, hist: undefined };
    if (!v.hand || v.hand.key !== v.cur) { leaveOrder(); v.hand = null; }
    go('oopusOrder');
    loadOrder();
  }
  async function loadOrder(after) {
    const o = v.order;
    if (!o) return null;
    const seq = ++v.seq, k = keyOf(o);
    v.orderBusy = true; v.orderErr = null; renderOrder();
    let got = null;
    try {
      const r = await call({ mode: 'oopusorder', bk: o.bk, dg: o.dg, src: o.src, flow: after || null });
      got = r.order;
      if (v.list && r.store && v.list.store !== r.store) got = null; // another store signed in: this order is not ours
      if (got && seq === v.seq && v.order && keyOf(v.order) === k) {
        v.order = { ...got, store: r.store };
        if (v.list) v.list.orders = v.list.orders.map((x) => (keyOf(x) === k ? { ...got } : x)).filter((x) => x.st !== 'COMPLETED' && x.st !== 'CANCELLED');
      }
    } catch (e) { if (seq === v.seq) v.orderErr = e; got = got || { err: e }; }
    if (seq === v.seq) v.orderBusy = false;
    if (top().id === 'oopusOrder' && seq === v.seq) renderOrder();
    return got;
  }
  /** What StoreFront's order sheet lets the employee do next (the same rules as its buttons). */
  function next(o) {
    if (o.st === 'READY_FOR_PICKUP' && !RET_OK.has(o.ret)) return { kind: 'sf', text: 'StoreFront nije dao status povrata (vraćeno ili ne), pa predaja iz aplikacije nije sigurna. Provjeri narudžbu u StoreFrontu.' };
    if (o.st === 'READY_FOR_PICKUP' && o.ret === 'NOT_RETURNED') return { kind: 'hand', text: 'Kupac je tu? Provjeri i predaj narudžbu.' };
    if (o.st === 'READY_FOR_PICKUP' && o.ret === 'PARTIALLY_RETURNED') return { kind: 'hand', partial: true, text: 'Djelimično vraćeno: prije predaje provjeri komentare CSC-a.' };
    if (o.ret === 'RETURNED' && o.st !== 'COMPLETED' && o.st !== 'CANCELLED') return { kind: 'sf', text: 'Vraćeno od CSC-a: ne predaje se. U StoreFrontu „Označi kao obrađeno“, artikle vrati na zalihu.' };
    if (o.st === 'IN_TRANSIT') return { kind: 'sf', text: 'Kad paket stigne: provjeri da su svi artikli tu i neoštećeni, odštampaj narudžbenicu pa u StoreFrontu „Označi kao spremno za preuzimanje“ (kupac dobije SMS i e-mail).' };
    if (o.st === 'ORDERED') return { kind: 'none', text: 'Čeka slanje iz skladišta. Nema radnje u prodavnici.' };
    if (o.st === 'COMPLETED') return { kind: 'none', text: 'Završeno: narudžba je predana kupcu.' };
    if (o.st === 'CANCELLED') return { kind: 'none', text: 'Otkazano: ne predaje se.' };
    return { kind: 'sf', text: 'Status koji aplikacija ne poznaje: otvori narudžbu u StoreFrontu.' };
  }
  function handBox(o, n) {
    const H = v.hand && v.hand.key === keyOf(o) ? v.hand : null;
    if (H && H.phase === 'done' && H.sigLost) return `<div class="oopus-next is-unknown" role="status"><b>Predano, ali bez potpisa</b><small>${esc(H.note)}</small></div>`;
    if (H && H.phase === 'done') return `<div class="oopus-done" role="status"><b>Preuzimanje potvrđeno</b><small>StoreFront je potvrdio predaju narudžbe ${esc(o.no)} u ${hm(H.at)}.${H.note ? ' ' + esc(H.note) : ''}</small></div>`;
    if (H && H.phase === 'sending') return '<div class="oopus-next is-busy"><b>Šaljem potpis u StoreFront…</b><small>Ne zatvaraj aplikaciju.</small></div>';
    if (H && H.phase === 'checking') return '<div class="oopus-next is-busy"><b>Provjeravam status u StoreFrontu…</b><small>Odgovor na predaju nije stigao.</small></div>';
    if (H && H.phase === 'unknown') return `<div class="oopus-next is-unknown"><b>Ishod predaje nepoznat</b><small>Potpis je možda stigao u StoreFront. Ne potpisuj ponovo dok ne provjeriš status.</small><button class="btn btn-primary btn-block" type="button" data-oopus-recheck>Provjeri status</button></div>`;
    let h = '';
    if (H && H.phase === 'failed') h += `<p class="ord-trust is-unknown">${esc(H.msg)}</p>`;
    if (n.kind === 'hand') {
      if (H && H.phase === 'check') {
        const items = [['order', `Kupac je pokazao narudžbu <b>${esc(o.no)}</b> (štampanu ili na mobitelu)`], ['id', `Lična karta odgovara kupcu${o.who ? ` <b>${esc(o.who)}</b>` : ''}`], ['items', `Svi artikli su tu i neoštećeni (${o.lines.length} ${plural(o.lines.length, 'artikal', 'artikla', 'artikala')}, ${kom(o.qty)})`]];
        if (n.partial) items.push(['csc', 'Pročitao sam komentar CSC-a (djelimično vraćeno)']);
        const all = items.every(([id]) => H.ok[id]);
        h += `<div class="oopus-next oopus-check"><b>Prije potpisa</b>${items.map(([id, t]) => `<label class="oopus-tick"><input type="checkbox" data-oopus-tick="${id}"${H.ok[id] ? ' checked' : ''}><span>${t}</span></label>`).join('')}
          ${offline() ? '<p class="ord-trust is-unknown">Za predaju treba internet. Ništa se ne šalje kasnije.</p>' : ''}
          <span class="oopus-state-btns"><button class="btn" type="button" data-oopus-cancel>Odustani</button><button class="btn btn-primary" type="button" data-oopus-sign${all && !offline() ? '' : ' disabled'}>Kupac potpisuje</button></span></div>`;
        return h;
      }
      return h + `<div class="oopus-next"><b>Sljedeće</b><small>${esc(n.text)}</small><button class="btn btn-primary btn-block" type="button" data-oopus-hand>Predaj kupcu</button></div>`;
    }
    return h + `<div class="oopus-next"><b>Sljedeće</b><small>${esc(n.text)}</small>${n.kind === 'sf' ? `<button class="btn btn-block" type="button" data-oopus-sf>${icon('link')}Otvori OOPUS u StoreFrontu</button>` : ''}</div>`;
  }
  function renderOrder() {
    const body = $('#oopusOrderBody');
    const o = v.order;
    if (!body || !o) return;
    const t = $('#oopusOrderTitle');
    if (t) t.textContent = `OOPUS ${o.no}`;
    const n = next(o);
    const tel = String(o.ph || '').replace(/[^\d+]/g, '');
    const phone = tel.length >= 6 ? `<a class="oopus-tel" href="tel:${esc(tel)}" aria-label="Pozovi kupca: otvara birač broja">${icon('link')}${esc(o.ph)}</a>` : '<span class="oopus-tel is-none">Broj telefona nije dostupan</span>';
    let h = `<div class="oopus-head"><b class="oopus-who">${esc(o.who || 'Kupac bez imena')}</b><span class="oopus-no" data-copy="${esc(o.no)}">${esc(o.no)}</span>${phone}
      <span class="oopus-meta"><span class="pill oopus-st st-${esc(o.st.toLowerCase())}">${esc(stName(o.st))}</span>${ST[o.st] && ST[o.st][1] ? `<small>${esc(ST[o.st][1])}</small>` : ''}</span>
      <small>${o.created ? `Naručeno ${esc(day(o.created))}` : ''}${o.expected ? ` · očekivano ${esc(day(o.expected))}` : ''}${o.amount != null ? ` · ${km(o)} plaćeno online` : ''}</small></div>`;
    if (v.orderBusy) h += '<p class="count-line">Osvježavam iz StoreFronta…</p>';
    if (v.orderErr) h += `<p class="ord-trust is-unknown">${esc(v.orderErr.how === 'missing' ? 'StoreFront ne nalazi ovu narudžbu.' : why(v.orderErr))} Prikazano je zadnje očitano. <button class="link" type="button" data-oopus-reorder>Pokušaj ponovo</button></p>`;
    if (o.ret === 'PARTIALLY_RETURNED') h += '<p class="ord-trust is-unknown">Ova narudžba je djelimično vraćena: provjeri komentare CSC-a prije nego što predaš.</p>';
    if (o.issue) h += '<p class="ord-trust is-unknown">Otvoren slučaj kod korisničke službe (CSC).</p>';
    h += handBox(o, n);
    h += `<p class="stk-h">Artikli · ${o.lines.length} ${plural(o.lines.length, 'stavka', 'stavke', 'stavki')}, ${kom(o.qty)}</p><div class="list oopus-lines">${o.lines.map((l) => `<div class="item item-static oopus-line" data-line="${esc(l.num)}">${/^\d{7}$/.test(l.num) ? thumb(l.num, 'oopus-thumb', true) : '<span class="thumb oopus-thumb"></span>'}<span class="oopus-line-txt"><b>${esc(l.name || l.num)}</b><small>${/^\d{7}$/.test(l.num) ? sfCode(l.num) : esc(l.num)}${l.state && l.state !== 'OPEN' ? ` · ${esc(l.state === 'RETURNED' ? 'vraćeno' : l.state.toLowerCase())}` : ''}</small></span><span class="oopus-qty">${whole(l.qty)}×</span></div>`).join('')}</div>`;
    if (Array.isArray(o.hist) && o.hist.length) {
      h += `<p class="stk-h">Historija</p><div class="list oopus-hist">${o.hist.map((x) => `<div class="item item-static"><span><b>${esc(HIST[x.type] || (x.csc ? 'Korisnička služba' : 'Događaj'))}</b><small>${esc(day(x.t))} ${x.t ? hm(x.t) : ''}</small>${x.text ? `<small class="oopus-note${x.comm || x.csc ? ' is-csc' : ''}">${esc(x.text)}</small>` : ''}</span></div>`).join('')}</div>`;
    }
    h += `<button class="btn btn-block oopus-sf" type="button" data-oopus-sf>${icon('link')}Otvori OOPUS u StoreFrontu</button>`;
    body.innerHTML = h;
  }

  // ------------------------------------------------------------------ the signature (finger), the handover
  const pad = { strokes: 0, ctx: null, last: null, dpr: 1 };
  function renderSign() {
    const o = v.order, H = v.hand;
    const body = $('#oopusSignBody');
    if (!body || !o || !H) return;
    body.innerHTML = `<p class="oopus-sign-for">Narudžba <b>${esc(o.no)}</b> · ${o.lines.length} ${plural(o.lines.length, 'artikal', 'artikla', 'artikala')}, ${kom(o.qty)}</p>
      <div class="oopus-pad"><canvas id="oopusCanvas" aria-label="Potpis kupca: potpiši prstom"></canvas><span class="oopus-pad-hint" id="oopusHint">Potpiši se prstom ovdje</span></div>
      <div class="oopus-sign-btns"><button class="btn" type="button" data-oopus-clear>Obriši</button><button class="btn" type="button" data-oopus-signoff>Odustani</button><button class="btn btn-primary" type="button" data-oopus-save disabled>Spremi</button></div>`;
    requestAnimationFrame(setupPad); // measured once the screen is shown
  }
  function setupPad() {
    const c = $('#oopusCanvas');
    if (!c) return;
    const r = c.getBoundingClientRect();
    pad.dpr = Math.max(1, window.devicePixelRatio || 1);
    c.width = Math.max(10, Math.round(r.width * pad.dpr)); c.height = Math.max(10, Math.round(r.height * pad.dpr));
    const g = c.getContext('2d');
    pad.ctx = g; pad.strokes = 0; pad.last = null; pad.box = null;
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); // as StoreFront's pad: black on white
    g.strokeStyle = '#000'; g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = 2.6 * pad.dpr;
    const at = (ev) => { const b = c.getBoundingClientRect(); return [(ev.clientX - b.left) * pad.dpr, (ev.clientY - b.top) * pad.dpr]; };
    c.onpointerdown = (ev) => {
      if (busyHand()) return;
      ev.preventDefault(); try { c.setPointerCapture(ev.pointerId); } catch (e) { /* old WebView */ }
      pad.last = at(ev); ink(pad.last); g.beginPath(); g.arc(pad.last[0], pad.last[1], g.lineWidth / 2, 0, Math.PI * 2); g.fillStyle = '#000'; g.fill();
    };
    c.onpointermove = (ev) => {
      if (!pad.last) return;
      ev.preventDefault();
      const p = at(ev); ink(p); g.beginPath(); g.moveTo(pad.last[0], pad.last[1]); g.lineTo(p[0], p[1]); g.stroke(); pad.last = p;
    };
    const up = () => { if (!pad.last) return; pad.last = null; pad.strokes++; const s = $('[data-oopus-save]'); if (s) s.disabled = busyHand(); const hn = $('#oopusHint'); if (hn) hn.hidden = true; };
    c.onpointerup = up; c.onpointercancel = up; c.onpointerleave = up;
    // no page scroll, no pull-to-refresh while the finger signs
    c.addEventListener('touchmove', (ev) => ev.preventDefault(), { passive: false });
    c.addEventListener('touchstart', (ev) => ev.preventDefault(), { passive: false });
  }
  // 2.12 (owner, 18. 11. 2026): the first real handover through the app finished the order in StoreFront, but StoreFront
  // answered 500 and the signature is not in the order's history (its own signatures are there as an image). The app sent
  // the whole full-screen pad (about 1080 × 1900 px); StoreFront's own pad is a small box in a dialog. Now only the part
  // with ink (plus a margin) goes, scaled to at most 600 × 300 px, still black on white, as StoreFront's own.
  function ink(p) {
    const b = pad.box || (pad.box = { x0: p[0], y0: p[1], x1: p[0], y1: p[1] });
    b.x0 = Math.min(b.x0, p[0]); b.y0 = Math.min(b.y0, p[1]); b.x1 = Math.max(b.x1, p[0]); b.y1 = Math.max(b.y1, p[1]);
  }
  function sigPng(c) {
    const b = pad.box;
    if (!b) return '';
    const m = 24 * pad.dpr, x0 = Math.max(0, b.x0 - m), y0 = Math.max(0, b.y0 - m);
    const w = Math.min(c.width, b.x1 + m) - x0, h = Math.min(c.height, b.y1 + m) - y0;
    // StoreFront's pad is wider than tall: the signature keeps its shape, centred on a sheet of StoreFront's proportions
    const W0 = Math.max(w, h * SIG_W / SIG_H), H0 = Math.max(h, W0 * SIG_H / SIG_W);
    let k = Math.min(1, SIG_W / W0, SIG_H / H0), url = '';
    for (let i = 0; i < 4; i++, k *= 0.75) { // a very busy signature: smaller until it is as small as StoreFront's own
      const out = document.createElement('canvas');
      out.width = Math.max(10, Math.round(W0 * k)); out.height = Math.max(10, Math.round(H0 * k));
      const g = out.getContext('2d');
      g.fillStyle = '#fff'; g.fillRect(0, 0, out.width, out.height);
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
      g.drawImage(c, x0, y0, w, h, Math.round((W0 - w) / 2 * k), Math.round((H0 - h) / 2 * k), Math.round(w * k), Math.round(h * k));
      url = out.toDataURL('image/png');
      if (url.length <= SIG_MAX) return url;
    }
    // #24 (21. 11. 2026): still bigger than StoreFront's own after the smallest size: never sent (it was sent anyway)
    url = '';
    return SIG_BIG;
  }
  const busyHand = () => !!(v.hand && (v.hand.phase === 'sending' || v.hand.phase === 'checking'));
  function clearPad() { setupPad(); const s = $('[data-oopus-save]'); if (s) s.disabled = true; const hn = $('#oopusHint'); if (hn) hn.hidden = false; }

  async function save() {
    const o = v.order, H = v.hand;
    if (!o || !H || H.key !== keyOf(o) || H.phase !== 'sign' || !pad.strokes) return;
    const k = keyOf(o);
    if (sending.has(k)) return; // a double tap
    if (offline()) { toast('Za predaju treba internet. Ništa nije poslano.'); return; }
    const c = $('#oopusCanvas');
    let sig = '';
    try { sig = sigPng(c); } catch (e) { sig = ''; }
    if (sig === SIG_BIG) { toast('Potpis je pregust za StoreFront. Obriši ga i potpiši se ponovo, jednostavnije. Ništa nije poslano.', 5200); return; }
    if (!/^data:image\/png;base64,/.test(sig)) { toast('Potpis se nije mogao pripremiti. Pokušaj ponovo.'); return; }
    sending.add(k);
    H.phase = 'sending'; H.at = Date.now();
    document.querySelectorAll('#oopusSign button').forEach((b) => { b.disabled = true; });
    const f = H.flow;
    if (f) f.step('potpis', 'ok');
    const t0 = Date.now();
    let res = null, err = null;
    try {
      res = await call({ mode: 'oopushandout', bk: o.bk, dg: o.dg, src: o.src, no: o.no, store: o.store || (v.list && v.list.store) || '', partialOk: o.ret === 'PARTIALLY_RETURNED' && !!H.ok.csc, sig, flow: f });
    } catch (e) { err = e; }
    sig = '';
    try { const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); } catch (e) { /* gone */ }
    if (res && res.ok && (res.state === 'COMPLETED' || res.dry)) done(H, f, t0, '');
    else if (res && res.ok && !res.state) done(H, f, t0, '');
    else if (err && (err.how === 'state' || err.how === 'context')) {
      // checked before anything was sent: nothing was sent
      H.phase = 'failed';
      H.msg = err.how === 'context' ? 'Nije poslano: u StoreFrontu je prijavljena druga prodavnica ili se narudžba promijenila.'
        : /^state READY_FOR_PICKUP (NONE|[A-Z_]+)$/.test(err.err || '') && !/ (NOT_RETURNED|PARTIALLY_RETURNED|RETURNED)$/.test(err.err || '') ? 'Nije poslano: StoreFront pri zadnjoj provjeri nije dao status povrata (vraćeno ili ne). Potpis nije poslan. Provjeri narudžbu u StoreFrontu.'
        : 'Nije poslano: narudžba više nije „Spremno za preuzimanje“. Pogledaj novi status.';
      if (f) f.end('rejected', { why: err.how, ms: Date.now() - t0 });
      sending.delete(k);
      leaveSign();
      loadOrder();
    } else {
      // the answer was lost, came as an error or said something else: read the real state before anything else
      await recheck(H, f, t0);
    }
  }
  function done(H, f, t0, note) {
    H.phase = 'done'; H.at = Date.now(); H.note = note;
    if (f) f.end('ok', { ms: Date.now() - t0 });
    sending.delete(H.key);
    if (v.order && keyOf(v.order) === H.key) v.order = { ...v.order, st: 'COMPLETED' };
    if (v.list) v.list.orders = v.list.orders.filter((x) => keyOf(x) !== H.key);
    if (v.list && v.list.totals) v.list.totals = { ...v.list.totals, LEGACY_UNCOMPLETED: Math.max(0, (v.list.totals.LEGACY_UNCOMPLETED || 1) - 1), LEGACY_COMPLETED: (v.list.totals.LEGACY_COMPLETED || 0) + 1 };
    leaveSign();
    ctx.onChange && ctx.onChange();
    loadOrder(); // StoreFront's own state, shown when it comes
  }
  async function recheck(H, f, t0) {
    H.phase = 'checking';
    leaveSign();
    renderOrder();
    const got = await loadOrder(f);
    if (got && got.st === 'COMPLETED') {
      // 2.12 (18. 11. 2026): StoreFront can finish the order and still fail to keep the signature (answer 500). Its own
      // signatures are a CORRESPONDENCE_CUSTOM_MESSAGE in the order's history: none since the sending = not kept.
      const sigKept = Array.isArray(got.hist) ? got.hist.some((x) => x.type === 'CORRESPONDENCE_CUSTOM_MESSAGE' && x.t >= t0 - 10 * 60000) : null;
      H.sigLost = sigKept === false;
      done(H, f, t0, sigKept === false ? 'Narudžba je u StoreFrontu „Završeno“, ali StoreFront NIJE sačuvao potpis (u historiji narudžbe ga nema). Javi šefu ako potpis treba.' : 'Odgovor na slanje se izgubio; StoreFront pokazuje „Završeno“.');
      return;
    }
    sending.delete(H.key);
    if (got && got.st) {
      H.phase = 'failed';
      H.msg = got.st === 'READY_FOR_PICKUP' ? 'Predaja nije završena: StoreFront i dalje pokazuje „Spremno za preuzimanje“. Možeš pokušati ponovo s novim potpisom.' : `Predaja nije potvrđena. Status u StoreFrontu: ${stName(got.st)}.`;
      if (f) f.end('rejected', { why: 'nije završeno', ms: Date.now() - t0 });
    } else {
      H.phase = 'unknown';
      if (f) f.end('unsure', { why: got && got.err ? got.err.how : 'nema odgovora', ms: Date.now() - t0 });
    }
    if (top().id === 'oopusOrder') renderOrder();
  }
  function leaveSign() {
    if (top().id === 'oopusSign') back();
    else if (top().id === 'oopusOrder') renderOrder();
  }

  function onClick(t) {
    if (t.id === 'oopusBar') { open(); return true; }
    if ('oopusReload' in t.dataset) { load(); return true; }
    if ('oopusSf' in t.dataset) { openOfficial(); return true; }
    if (t.dataset.oopusFilter) { v.filter = t.dataset.oopusFilter; renderList(); return true; }
    if ('oopusFind' in t.dataset) { find(v.q); return true; }
    if ('oopusScan' in t.dataset) { if (scanFor) scanFor((code) => fromScan(code)); return true; }
    if (t.dataset.oopus) { openOrder(findKey(t.dataset.oopus)); return true; }
    if ('oopusReorder' in t.dataset) { loadOrder(); return true; }
    if ('oopusHand' in t.dataset) {
      const o = v.order;
      if (!o || sending.has(keyOf(o))) return true;
      v.hand = { key: keyOf(o), phase: 'check', ok: {}, flow: flow ? flow.start('oopus', 'Predaja narudžbe', { step: 'provjera' }) : null };
      renderOrder();
      return true;
    }
    if ('oopusCancel' in t.dataset) { if (v.hand && v.hand.flow) v.hand.flow.end('cancelled', { step: 'provjera' }); v.hand = null; renderOrder(); return true; }
    if ('oopusSign' in t.dataset) {
      const H = v.hand;
      if (!H || H.phase !== 'check' || t.disabled) return true;
      if (offline()) { toast('Za predaju treba internet.'); renderOrder(); return true; }
      H.phase = 'sign';
      if (H.flow) H.flow.step('provjera', 'ok');
      go('oopusSign');
      renderSign();
      return true;
    }
    if ('oopusClear' in t.dataset) { if (!busyHand()) clearPad(); return true; }
    if ('oopusSignoff' in t.dataset) { if (!busyHand()) back(); return true; }
    if ('oopusSave' in t.dataset) { save(); return true; }
    if ('oopusRecheck' in t.dataset) { if (v.hand && v.hand.phase === 'unknown') recheck(v.hand, v.hand.flow && v.hand.flow.open ? v.hand.flow : null, Date.now()); return true; }
    return false;
  }
  function onChangeInput(t) {
    if (t.id === 'oopusQ') { onInput(t.value); return true; }
    if (t.dataset && t.dataset.oopusTick && v.hand) { v.hand.ok[t.dataset.oopusTick] = t.checked; renderOrder(); return true; }
    return false;
  }
  /**
   * Leaving the order (Natrag, another order) during the checks or the signature: nothing was sent, so the handover
   * flow ends as cancelled. Up to 1.99 it stayed open and the next start showed it as "prekinuto (aplikacija
   * zatvorena)" (owner, 15. 11. 2026: tapped "Predaj kupcu" at home, went back, nothing was handed over).
   * Sending, checking or an unknown outcome stays open on purpose: that one must be checked.
   */
  function leaveOrder() {
    const H = v.hand;
    if (!H || (H.phase !== 'check' && H.phase !== 'sign')) return;
    if (H.flow && H.flow.open) H.flow.end('cancelled', { step: H.phase === 'sign' ? 'potpis' : 'provjera' });
    v.hand = null;
  }
  /** Leaving the signature screen without saving (Odustani, Natrag): back to the checks, nothing sent. */
  function onLeaveSign() {
    const H = v.hand;
    if (H && H.phase === 'sign') { H.phase = 'check'; if (H.flow) H.flow.step('potpis', 'cancelled'); }
  }
  function bar() {
    const c = counts();
    return v.list ? `${c.ready} spremno za preuzimanje · ${esc(ageText(v.list.at))}` : 'Online narudžbe za preuzimanje u prodavnici';
  }
  return { open, renderList, renderOrder, renderSign, onClick, onChangeInput, onLeaveSign, leaveOrder, bar, _v: v };
}
