// Predictable, bounded DOM work for long StoreFront lists.
// The complete result remains in memory; only rendered rows are paged.
export function createListWindow(chunk = 48) {
  if (!Number.isSafeInteger(chunk) || chunk < 1) throw new RangeError('chunk');
  let key = null, count = chunk;
  function resetIfChanged(nextKey) {
    if (key !== nextKey) { key = nextKey; count = chunk; }
  }
  return {
    visible(nextKey, total) {
      resetIfChanged(nextKey);
      return Math.min(count, Math.max(0, total));
    },
    more(nextKey, total) {
      resetIfChanged(nextKey);
      const before = Math.min(count, Math.max(0, total));
      count = Math.min(Math.max(0, total), count + chunk);
      return { from: before, to: count };
    }
  };
}
