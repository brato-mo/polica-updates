// Minus lista and Regulacija zalihe: the screen, its bar on the start screen and the sending record's card.
// Moved out of app.js in 1.69 WITHOUT changing a line of what it does (tests/e2e/minus.e2e.mjs and corrupt.e2e.mjs
// guard it). The rules of sending live in Java (OpLog, MinusApply) and in minusop.js; this is only the screen.
// Everything it uses from the app comes in through createMinusUi(ctx); what the app uses from it comes back.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
import * as orderWaiting from './order-waiting.js';

export function createMinusUi(ctx) {
  const { $, A, S, SIMS, ageText, ask, esc, go, icon, itemRow, minusop, nameOf, openItem, ordersOf, plural, renderHome, sandboxOn, saveUser, sfThumb, simNow, stCall, toast, top } = ctx;
  const flow = ctx.flow || null, ordersBlock = ctx.ordersBlock || null, openSheet = ctx.openSheet || null, closeSheet = ctx.closeSheet || null;
  // 2.15: js/auto-sync.js (what changed since the last reading, and why the data is not newer)
  const onMinusRead = ctx.onMinusRead || null, minusMark = ctx.minusMark || (() => ''), autoNote = ctx.autoNote || (() => '');

/**
 * 1.97 (owner): who waits for the goods under the replacement number, for the decision while counting. Only what the
 * loaded orders say: "2 narudžbe · čeka 5 kom"; a waiting quantity StoreFront did not give is left out; an old reading
 * says its age. Nothing here changes a Regulacija or a reservation.
 */
function custLine(num) {
  const o = S.user.orders;
  if (!o || !ordersOf(num).length) return '';
  const all = orderWaiting.articles(o.list, { onlyWaiting: false }).find((e) => e.num === num);
  const wait = orderWaiting.articles(o.list, { onlyWaiting: true }).find((e) => e.num === num);
  const n = all ? all.n : ordersOf(num).length;
  const old = Date.now() - (o.at || 0) > 3600000 ? ` · stanje ${ageText(o.at)}` : '';
  const q = wait && !wait.unsure ? ` · čeka ${wait.qty} kom` : wait ? ` · čeka (količina nepotpuna)` : ' · ništa ne čeka';
  return `<button class="link mp-cust" type="button" data-mp-orders="${esc(num)}">naručio kupac: ${n} ${plural(n, 'narudžba', 'narudžbe', 'narudžbi')}${q}${old}</button>`;
}
function openCustomers(num) {
  if (!openSheet || !ordersBlock) return;
  openSheet({ title: `Kupci za ${num}`, body: `${ordersBlock(num)}${ordersBlock(num, { after: true })}<p class="hint">Samo za odluku pri brojanju: količina za Regulaciju i rezervacije se ne mijenjaju.</p>`,
    actions: [{ label: 'Nazad na Minus listu', kind: 'btn-primary', onClick: closeSheet }] });
}


function renderMinusBar() {
  const b = $('#minusBar');
  if (!b) return;
  const has = S.plans.length > 0 && S.mode !== 'news'; // 2.23: automatic refresh, not under Vijesti
  b.hidden = !has;
  if (!has) return;
  const m = S.user.minus;
  const ic = icon('info');
  if (!m || !m.items) {
    b.innerHTML = `${ic}<span><b>Minus lista</b><small>Artikli u minusu, iz StoreFronta</small></span><span class="go">Učitaj</span>`;
    return;
  }
  const map = minusTargets(m.items);
  const ready = m.items.filter((x) => (map.get(x.num) || {}).target).length;
  const pend = (S.user.minusPending || []).length;
  const open = minusop.locks(S.minusOp) ? ' · <b>ishod nepoznat, provjeri</b>' : '';
  b.innerHTML = `${ic}<span><b>Minus lista: ${m.items.length}</b><small>${ready} spremno za ispravku${pend ? ` · ${pend} čeka Regulaciju` : ''}${open} · ${esc(ageText(Math.max(m.at || 0, m.seen || 0)))}</small></span><span class="go">Otvori</span>`; // 2.15: the last check (emulator 19. 11.: the bar said "prije 19 h" a minute after an automatic look)
}

/** The record of the last sending, kept by the phone (survives closing the app and restarts). */
function minusOpNow() {
  try { const t = A.minusOp && A.minusOp(); S.minusOp = t ? JSON.parse(t) : null; } catch (e) { /* older shell: no record */ }
  return S.minusOp || null;
}

/** The status card of the last sending, with the read-only check and the employee's own decision for an unknown one. */
function minusOpCard() {
  const op = S.minusOp;
  const d = minusop.describe(op);
  if (!d) return '';
  // an old finished sending is not worth a card; an open one always is
  if (!d.lock && op.state !== 'unknown' && Date.now() - (op.end || op.at || 0) > 12 * 3600000) return '';
  const when = op.at ? new Date(op.at).toLocaleString('bs-BA', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
  let more = '';
  if (op.state === 'corrupt') {
    more = `<div class="mp-head"><button class="text-btn" type="button" data-sf-page="minus">Otvori Minus listu</button><button class="text-btn" type="button" data-sf-page="adjust">Otvori Regulaciju</button></div>
      <button class="btn btn-block" type="button" data-op-resolve="checked">Provjerio sam u StoreFrontu: očisti zapis…</button>`;
  }
  if (op.state === 'unknown' && !op.resolved) {
    const ev = S.minusCheck && S.minusCheck.id === op.id ? S.minusCheck : null;
    const tm = (t) => (t ? new Date(t).toLocaleString('bs-BA', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '–');
    const STEPS = { start: 'čitanje Minus liste', check: 'provjera liste', user: 'provjera korisnika', minus: 'Minus lista', adjust: 'Regulacija zalihe' };
    const http = op.http || {};
    const httpTxt = (k) => (http[k] ? `HTTP ${http[k]}` : 'bez odgovora');
    // what the phone itself knows about this sending, before anything is read from StoreFront
    const facts = `<div class="op-facts">
      <div><span>Počelo</span><b>${esc(tm(op.at))}</b></div>
      <div><span>Završeno / prekinuto</span><b>${esc(tm(op.end))}</b></div>
      <div><span>Stiglo do koraka</span><b>${esc(STEPS[op.step] || op.step || '–')}</b></div>
      ${op.kind === 'adjust' ? '' : `<div><span>StoreFront za Minus listu</span><b>${esc(http.minus ? httpTxt('minus') : op.minusOk || op.step === 'adjust' ? 'prihvaćeno' : op.step === 'minus' ? 'bez odgovora' : 'nije poslano')}</b></div>`}
      <div><span>StoreFront za Regulaciju</span><b>${esc(op.step === 'adjust' || op.kind === 'adjust' ? httpTxt('adjust') : 'nije poslano')}</b></div>
      <div><span>Razlog</span><b>${esc({ mreza: 'veza prekinuta', timeout: 'isteklo vrijeme', prekinuto: 'aplikacija zatvorena ili prekinuta' }[op.why] || op.why || '–')}</b></div>
    </div>`;
    const MV = { '911': 'smanjenje (911)', '912': 'povećanje (912)', '921': '921', '922': '922', '251': 'prodaja', '252': 'povrat', '101': 'prijem' };
    const moveList = (list, want) => (list.length ? `<ul class="op-moves">${list.map((m) => `<li class="${m.exact ? 'is-exact' : ''}">${esc(tm(m.t))} · <b>${m.q > 0 ? '+' : ''}${esc(mq(m.q))}</b> · ${esc(MV[m.type] || m.type || '?')} · ${m.mine ? 'tvojim korisnikom' : 'drugi korisnik'} · ${esc(m.when)} slanja${m.exact ? ' · <b>tačno očekivano</b>' : ''}</li>`).join('')}</ul>`
      : `<p class="op-none">Nema kretanja od 6 sati prije slanja (očekivano ${esc(want)}).</p>`);
    const W = { seen: 'tačno jedno očekivano kretanje', none: 'očekivano kretanje se ne vidi', unclear: 'nejasno: više mogućih ili isto i prije slanja', skip: '' };
    const rows = (op.items || []).map((it) => {
      const n = Math.abs(it.qty);
      const l = ev && ev.res && ev.res.lines.find((x) => x.num === it.num);
      const what = op.kind === 'adjust' ? `<b>${esc(it.target)}</b> ukloni ${mq(n)} · kod 53`
        : `<b>${esc(it.num)}</b> ${mq(it.qty)} → 0 · <b>${esc(it.target)}</b> ukloni ${mq(n)}`;
      if (!l) return `<div class="mp-row"><div class="mp-txt"><span>${what}</span></div></div>`;
      const minusPart = op.kind === 'adjust' ? '' : `<div class="op-ev"><b>Minus lista ${esc(it.num)}</b> (očekivano +${esc(mq(n))}): ${esc(W[l.minus])}
          <small>Sada na Minus listi: ${l.stillMinus == null ? 'nije na listi' : esc(mq(l.stillMinus))}</small>${moveList(l.numMoves, '+' + mq(n))}</div>`;
      return `<div class="mp-row"><div class="mp-txt"><span>${what}</span>${minusPart}
        <div class="op-ev"><b>Regulacija ${esc(it.target)}</b> (očekivano -${esc(mq(n))}): ${esc(W[l.adjust])}${moveList(l.targetMoves, '-' + mq(n))}</div></div></div>`;
    }).join('');
    const evText = ev ? (ev.busy ? '<p class="count-line"><i class="mj-busy"></i> Čitam historiju zalihe iz StoreFronta…</p>'
      : ev.err ? `<p class="att-from">Provjera nije uspjela (${esc(ev.err)}). Pogledaj u StoreFrontu.</p>`
        : `<p class="att-from op-warnline">Ovo nije dokaz. StoreFront ne daje broj operacije, a historija zalihe nema ni komentar ni razlog (53/103). Isto kretanje je mogao napraviti neko drugi ili ti ručno. Uporedi u StoreFrontu, pa odluči. Pročitano ${esc(tm(ev.at))}.</p>`) : '';
    more = `${facts}${rows}${evText}
      <button class="btn btn-block" type="button" data-op-check ${ev && ev.busy ? 'disabled' : ''}>Provjeri u StoreFrontu (samo čitanje)</button>
      <div class="mp-head"><button class="text-btn" type="button" data-sf-page="minus">Otvori Minus listu</button><button class="text-btn" type="button" data-sf-page="adjust">Otvori Regulaciju</button></div>
      <p class="att-from">Kad provjeriš u StoreFrontu, reci šta si našao. Tek tada se može slati ponovo.</p>
      ${op.kind !== 'adjust' && op.step === 'minus'
    ? `<button class="btn btn-block" type="button" data-op-resolve="done">Provjerio sam: Minus lista je prošla</button>
      <button class="btn btn-block" type="button" data-op-resolve="notdone">Provjerio sam: Minus lista nije prošla</button>`
    : `<button class="btn btn-block" type="button" data-op-resolve="done">Provjerio sam: prošlo je</button>
      <button class="btn btn-block" type="button" data-op-resolve="notdone">Provjerio sam: nije prošlo</button>`}`;
  }
  const sim = sandboxOn() ? '<p class="att-from op-warnline">TEST verzija: ovo je odigrano, ništa nije poslano u StoreFront.</p>' : '';
  return `<section class="mj-sec mp op-card op-${d.tone}" aria-live="polite"><div class="sec-head"><h2>${esc(d.label)}${sandboxOn() ? ' (TEST)' : ''}</h2><small>${esc(when)}</small></div>
    <p class="att-from">${esc(d.text)}</p>${sim}${more}</section>`;
}

function minusOpCheck() {
  const op = S.minusOp;
  if (!op || op.state !== 'unknown') return;
  S.minusCheck = { id: op.id, busy: true };
  const ok = stCall({ mode: 'opcheck', items: (op.items || []).map((x) => ({ num: x.num, target: x.target })), since: op.at }, (r) => {
    S.minusCheck = r.how === 'ok' ? { id: op.id, at: Date.now(), res: minusop.evidence(op, r.res) } : { id: op.id, err: r.how === 'login' ? 'traži prijavu' : 'greška' };
    if (top().id === 'minus') renderMinus();
  });
  if (!ok) S.minusCheck = { id: op.id, err: 'ova verzija to ne zna' };
  renderMinus();
}

/** Read only: the stock history of the replacement numbers of the lines 1.57 left waiting for Regulacija. */
function legacyCheck() {
  const items = (S.user.minusPending || []).filter((p) => p && p.legacy && p.target);
  if (!items.length) return;
  const since = Date.now() - 14 * 86400000;
  S.legacyCheck = { busy: true };
  const ok = stCall({ mode: 'opcheck', items: items.map((x) => ({ num: x.num, target: x.target })), since: since + 6 * 3600000 }, (r) => {
    S.legacyCheck = r.how === 'ok' ? { at: Date.now(), res: minusop.evidence({ kind: 'adjust', at: since, end: Date.now(), items }, r.res) } : { err: r.how === 'login' ? 'traži prijavu' : 'greška' };
    if (top().id === 'minus') renderMinus();
  });
  if (!ok) S.legacyCheck = { err: 'ova verzija to ne zna' };
  renderMinus();
}

/** A yes/no question on the Minus lista screen; answer true for yes. */
function minusAsk(title, body, yes) {
  return ask(title, body, [{ label: yes, kind: 'btn-primary', value: true }, { label: 'Odustani', value: false }]).then((v) => v === true);
}

/** The employee's own decision on an unknown sending, after he checked it in StoreFront. */
function minusOpResolve(how) {
  const op = S.minusOp;
  if (op && op.state === 'corrupt' && how === 'checked' && A.minusOpResolve) {
    // What clearing can and cannot unlock:
    //  - Minus lista + Regulacija together: safe, the sending reads the Minus lista again and sends only lines that
    //    are still on it unchanged (a line whose Minus lista went through is not on it any more);
    //  - "Čeka Regulaciju" lines (Regulacija alone): these could be sent twice. They are locked again and each needs
    //    the read-only stock history check before it can be sent (legacy flow).
    const waiting = (S.user.minusPending || []).filter((p) => p && p.target);
    minusAsk('Očistiti nečitljiv zapis?', `<p>Prije toga u StoreFrontu pogledaj Minus listu i Regulaciju zalihe za zadnja 24 sata.</p>
      <p>Novo slanje Minus liste je i dalje zaštićeno: aplikacija prije slanja ponovo čita Minus listu i šalje samo redove koji su ostali isti.</p>
      ${waiting.length ? `<p><b>${waiting.length} ${plural(waiting.length, 'red čeka', 'reda čekaju', 'redova čeka')} Regulaciju.</b> Ostaju zaključani dok aplikacija ne pročita historiju zalihe u StoreFrontu i ne vidi da te Regulacije nema.</p>` : ''}`, 'Očisti zapis').then((yes) => {
      if (!yes) return;
      let ok = false;
      try { ok = !!A.minusOpResolve('corrupt', 'checked'); } catch (e) { ok = false; }
      if (ok) { for (const p of waiting) p.legacy = 'zapis'; S.legacyCheck = null; saveUser(); }
      toast(ok ? `Zapis je očišćen (nečitljiva kopija sačuvana).${waiting.length ? ' Redovi za Regulaciju čekaju provjeru.' : ''}` : 'Nije očišćeno. Pokušaj ponovo.');
      minusOpNow();
      renderMinus();
      renderMinusBar();
    });
    return;
  }
  if (!op || op.state !== 'unknown' || !A.minusOpResolve) return;
  if (how === 'notdone' && !S.opNotdoneOk) {
    // "it did not go through" lets the same lines be sent again: only after StoreFront was read, and never where it
    // shows the expected movement
    const ev = S.minusCheck && S.minusCheck.id === op.id && S.minusCheck.res;
    if (!ev) { toast('Prvo tapni „Provjeri u StoreFrontu (samo čitanje)“.'); return; }
    const steps = op.kind === 'adjust' || op.step === 'adjust' ? ['adjust'] : op.step === 'minus' ? ['minus'] : ['minus', 'adjust'];
    const seen = ev.lines.filter((l) => steps.some((k) => l[k] === 'seen'));
    const unclear = ev.lines.filter((l) => steps.some((k) => l[k] === 'unclear'));
    if (seen.length) { toast(`Ne može: StoreFront pokazuje očekivano kretanje za ${seen.map((l) => l.num).join(', ')}. Ako je to tvoje slanje, odaberi „prošlo je“.`, 6000); return; }
    if (unclear.length) {
      minusAsk('Nejasno', `<p>Za ${esc(unclear.map((l) => l.num).join(', '))} historija zalihe nije jasna (više mogućih kretanja ili isto i prije slanja).</p><p>Označi „nije prošlo“ samo ako si u StoreFrontu sigurno vidio da te korekcije nema.</p>`, 'Sigurno nije prošlo').then((yes) => {
        if (!yes) return;
        S.opNotdoneOk = true;
        try { minusOpResolve('notdone'); } finally { S.opNotdoneOk = false; }
      });
      return;
    }
  }
  let rec = null;
  try { const t = A.minusOpResolve(op.id, how); rec = t ? JSON.parse(t) : null; } catch (e) { rec = null; }
  if (!rec) { toast('Nije zapisano. Pokušaj ponovo.'); return; }
  S.minusOp = rec;
  const items = rec.items || [];
  const minusOnly = rec.kind !== 'adjust' && rec.step === 'minus';
  if (how === 'done' && minusOnly) {
    // it stopped at Minus lista: that went through, Regulacija zalihe was never sent and still has to be done
    const d = S.user.minusDone || (S.user.minusDone = {});
    for (const x of items) d[`${x.num}|${x.qty}|1`] = Date.now();
    const have = new Set((S.user.minusPending || []).map((p) => p.num));
    S.user.minusPending = [...(S.user.minusPending || []), ...items.filter((x) => x.target && !have.has(x.num))];
  } else if (how === 'done') {
    const d = S.user.minusDone || (S.user.minusDone = {});
    for (const x of items) {
      if (rec.kind !== 'adjust') d[`${x.num}|${x.qty}|1`] = Date.now();
      d[`${x.num}|${x.qty}|2`] = Date.now();
    }
    if (rec.kind === 'adjust') {
      const nums = new Set(items.map((x) => x.num));
      S.user.minusPending = (S.user.minusPending || []).filter((p) => !nums.has(p.num));
    }
  } else if (rec.kind !== 'adjust' && rec.step === 'adjust') {
    // Minus lista was accepted, Regulacija did not go through: only Regulacija is left, sent when the employee taps it
    const have = new Set((S.user.minusPending || []).map((p) => p.num));
    S.user.minusPending = [...(S.user.minusPending || []), ...items.filter((x) => !have.has(x.num))];
  }
  saveUser();
  toast(how === 'done' ? (minusOnly ? 'Zapisano: Minus lista je prošla. Regulacija zalihe čeka u „Čeka Regulaciju“.' : 'Zapisano: prošlo je.') : 'Zapisano: nije prošlo. Slanje je ponovo moguće.');
  S.minusCheck = null;
  renderMinus();
  setTimeout(loadMinus, 500);
}

function loadMinus() {
  if (S.minusBusy) return;
  S.minusBusy = true;
  try { A.minus(); } catch (e) { S.minusBusy = false; toast('Ova verzija aplikacije ne zna čitati Minus listu.'); }
  if (top().id === 'minus') renderMinus();
}

function openMinus() {
  renderMinus();
  go('minus');
  if (!S.user.minus || Date.now() - (S.user.minus.at || 0) > 10 * 60 * 1000) loadMinus();
}

window.onMinus = (r) => {
  S.minusBusy = false;
  if (!r) return;
  if (r.how === 'ok') {
    const prevMinus = S.user.minus;
    S.user.minus = { at: r.at || Date.now(), items: r.items || [], total: r.meta && r.meta.total || 0, other: (r.meta && r.meta.other) || [] };
    if (onMinusRead) onMinusRead(prevMinus, S.user.minus);
    const live = new Set((r.items || []).map((x) => `${x.num}|${x.qty}|`));
    const d = S.user.minusDone || {};
    for (const k of Object.keys(d)) if (!live.has(k.replace(/[12]$/, ''))) delete d[k];
    const nums = new Set((r.items || []).map((x) => x.num));
    const pk = S.user.minusPick || {};
    for (const k of Object.keys(pk)) if (!nums.has(k)) delete pk[k];
    saveUser();
  } else {
    toast(r.how === 'login' ? 'StoreFront traži prijavu. Prijavi se (Narudžbe → Osvježi) pa pokušaj ponovo.' : 'Minus lista se nije mogla učitati. Pokušaj ponovo.');
  }
  if (top().id === 'minus') renderMinus();
  if (top().id === 'home') renderHome();
};

/** The substitution chain with the store's stock of each number ({num, st, stock}); an older read kept only future
 * replacement numbers, which are not where the goods are: those are left out until the next read. */
const chainOf = (x) => (x.subs || []).filter((c) => c && typeof c === 'object');
// 2.15 audit: an unknown quantity is "?", never "null" or 0
const mq = (n) => (typeof n !== 'number' || !Number.isFinite(n) ? '?' : Number.isInteger(n) ? String(n) : String(n).replace('.', ','));

/**
 * Where each article in minus gets its goods back from: the replacement number with stock. Numbers the employee picked
 * (S.user.minusPick) count first; a replacement shared by several articles is given out only as far as its stock goes.
 * Answer: Map num -> {target: {num, st, stock}, left} or {why, pos} when it needs the employee.
 */
function minusTargets(items) {
  const picks = S.user.minusPick || {};
  const used = {};
  // goods already promised to a Regulacija that is still waiting: that stock is not free for a new line
  for (const p of S.user.minusPending || []) if (p && p.target) used[p.target] = (used[p.target] || 0) + Math.abs(+p.qty || 0);
  const out = new Map();
  const order = items.slice().sort((a, b) => (picks[b.num] ? 1 : 0) - (picks[a.num] ? 1 : 0) || a.qty - b.qty);
  for (const x of order) {
    if (!(x.qty < 0)) continue;
    const ch = chainOf(x);
    if (!ch.length) continue;
    const pos = ch.filter((c) => typeof c.stock === 'number' && c.stock > 0);
    const need = Math.abs(x.qty);
    let t = null;
    if (picks[x.num]) t = pos.find((c) => c.num === picks[x.num]) || null;
    else if (pos.length === 1) t = pos[0];
    if (!t) {
      out.set(x.num, { why: !pos.length ? 'none' : picks[x.num] ? 'gone' : 'many', pos });
      continue;
    }
    const free = t.stock - (used[t.num] || 0);
    if (free < need) { out.set(x.num, { why: 'short', pos, t, free }); continue; }
    used[t.num] = (used[t.num] || 0) + need;
    out.set(x.num, { target: t, left: free - need });
  }
  return out;
}
/** The number the goods really are under (for one article). */
function minusTarget(x) {
  const r = S.minusMap && S.minusMap.get(x.num);
  return r && r.target ? r.target : null;
}

/** The comments StoreFront takes (at most 50 characters): Minus lista, then Regulacija zalihe. */
const minusComments = (x, t) => [`Zamjena: ${x.num} na 0, roba pod ${t.num}`, `Zamjena: prodano pod ${x.num}`];

function minusRow(x) {
  const qty = `${mq(x.qty)} ${esc(x.unit || 'KOM')}`;
  const ch = chainOf(x);
  const t = minusTarget(x);
  const sub = ch.length
    ? `<span class="pills">${t ? `<span class="pill pill-order">Roba pod šifrom ${esc(t.num)} (${esc(mq(t.stock))} kom)</span>` : ''}</span>
       <span class="store-line">Zaliha zamjenskih: ${ch.map((c) => `${esc(c.num)}${c.st ? ` (${esc(c.st)})` : ''}${typeof c.stock === 'number' ? ` ${esc(mq(c.stock))}` : ''}`).join(' · ')}</span>`
    : x.subsErr ? '<span class="pills"><span class="pill pill-muted">Zamjene nisu pročitane</span></span>' : '<span class="pills"><span class="pill pill-muted">Nema zamjene</span></span>';
  const line = `<span class="store-line minus-qty">${minusMark(x.num)}${qty}${x.st ? ` · status ${esc(x.st)}` : ''}${x.blocked ? ` · blokirano ${esc(mq(x.blocked))}` : ''}</span>`;
  if (S.index.byNum.has(x.num)) return itemRow(x.num, { sub: `${sub}${line}` });
  return `<div class="item item-static">${sfThumb(x.num)}<span class="item-main">
    <span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.name) || 'Bez naziva'}</span>
    ${sub}<span class="pills"><span class="pill pill-muted">Nije u tvojim planogramima</span>${ordersOf(x.num).length ? '<span class="pill pill-order">Naručio kupac</span>' : ''}</span>${line}</span></div>`;
}

/** An article with replacements that the plan can not decide: why, and (when several have stock) a pick. */
function minusDecideRow(x) {
  const r = S.minusMap.get(x.num) || {};
  const pos = r.pos || [];
  const why = r.why === 'none' ? 'Nijedna zamjenska šifra nema zalihu: provjeri uzrok (dostava, blagajna, popis) i prebroji.'
    : r.why === 'short' ? `Šifra ${esc(r.t.num)} ima samo ${esc(mq(r.free))} kom za ovaj artikal, a minus je ${esc(mq(x.qty))}. Prebroji i odluči sam.`
    : r.why === 'gone' ? 'Šifra koju si izabrao više nema zalihu. Izaberi ponovo.'
    : 'Više zamjenskih šifri ima zalihu. Izaberi pod kojom je roba prodana:';
  const picks = r.why === 'many' || r.why === 'gone'
    ? `<div class="chips mp-picks">${pos.map((c) => `<button class="chip" type="button" data-mp-pick="${esc(x.num)}|${esc(c.num)}">${esc(c.num)} · ${esc(mq(c.stock))} kom</button>`).join('')}</div>` : '';
  return `<div class="mp-row mp-decide"><div class="mp-txt"><span><b>${esc(x.num)}</b> ${esc(x.name)} · <b class="minus-qty">${esc(mq(x.qty))}</b></span><small>${why}</small>${picks}
    <small>Zaliha zamjenskih: ${chainOf(x).map((c) => `${esc(c.num)} ${typeof c.stock === 'number' ? esc(mq(c.stock)) : '?'}`).join(' · ')}</small></div></div>`;
}

/** The shift plan: Minus lista back to 0 on the number in minus, Regulacija zalihe minus the same on the number with stock. */
function minusPlan(list) {
  const one = list.filter((x) => minusTarget(x));
  const pending = (S.user.minusPending || []).filter((p) => p && p.target);
  if (!one.length && !pending.length) return '';
  const done = S.user.minusDone || {};
  const key = (x, step) => `${x.num}|${x.qty}|${step}`;
  const row = (x, step) => {
    const k = key(x, step);
    const n = Math.abs(x.qty);
    const t = minusTarget(x);
    const r = S.minusMap.get(x.num);
    const ord = ordersOf(t.num).length ? ` · ${custLine(t.num)}` : '';
    const what = step === 1
      ? `<b>${esc(x.num)}</b> ${esc(x.name)}<br>upiši brojano: <b>0</b> (sad ${mq(x.qty)})`
      : `<b>${esc(t.num)}</b> ${esc(nameOf(t.num) || '')}<br>ukloni <b>${mq(n)}</b> · kod <b>53</b> · poslije ostaje <b>${mq(r.left)}</b> kom${ord}`;
    const com = minusComments(x, t)[step - 1];
    return `<div class="mp-row${done[k] ? ' is-done' : ''}">
      <button class="mp-check" type="button" role="checkbox" aria-checked="${!!done[k]}" aria-label="Urađeno" data-mp-done="${esc(k)}"></button>
      <div class="mp-txt"><span>${what}</span><small>${esc(com)}</small></div>
      <button class="text-btn" type="button" data-mp-copy="${esc(com)}">Kopiraj</button></div>`;
  };
  const left = (step) => one.filter((x) => !done[key(x, step)]).length;
  const busy = S.minusApplying || minusop.locks(S.minusOp) ? 'disabled' : '';
  const legacy = pending.filter((p) => p.legacy);
  const lc = S.legacyCheck;
  const MVL = { '911': 'smanjenje (911)', '912': 'povećanje (912)' };
  const tm = (t) => new Date(t).toLocaleString('bs-BA', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' });
  const legacyRow = (p) => {
    const l = lc && lc.res && lc.res.lines.find((x) => x.num === p.num);
    const moves = l ? (l.targetMoves.length ? `<ul class="op-moves">${l.targetMoves.map((m) => `<li class="${m.q === -Math.abs(p.qty) && m.mine ? 'is-exact' : ''}">${esc(tm(m.t))} · <b>${m.q > 0 ? '+' : ''}${esc(mq(m.q))}</b> · ${esc(MVL[m.type] || m.type || '?')} · ${m.mine ? 'tvojim korisnikom' : 'drugi korisnik'}${m.q === -Math.abs(p.qty) && m.mine ? ' · <b>ista količina</b>' : ''}</li>`).join('')}</ul>` : '<p class="op-none">U zadnje 2 sedmice nema kretanja zalihe za ovu šifru.</p>') : '';
    const evl = l ? { seen: ' · <b>StoreFront pokazuje tu Regulaciju</b>', unclear: ' · <b>nejasno, provjeri ručno</b>', none: ' · nije vidljiva u StoreFrontu' }[l.adjust] || '' : '';
    return `<div class="mp-row"><div class="mp-txt"><span><b>${esc(p.target)}</b> ukloni <b>${mq(Math.abs(p.qty))}</b> · kod 53${p.legacy ? ` · <b>${p.legacy === 'zapis' ? 'zapis bio nečitljiv' : p.legacy === 'vraceno' ? 'iz vraćene kopije' : 'iz 1.57'}, provjeri</b>${evl}` : ''}</span><small>${esc(p.c2)}</small>${moves}</div></div>`;
  };
  const legacyBox = legacy.length ? `<p class="att-from op-warnline">${legacy.some((p) => p.legacy === 'vraceno')
    ? `${legacy.length} ${plural(legacy.length, 'red čeka', 'reda čekaju', 'redova čeka')} provjeru: vraćena je kopija podataka, a sadašnji zapis slanja nije bio čitljiv, pa se ne zna je li neka od ovih Regulacija poslana poslije kopije.`
    : legacy.some((p) => p.legacy === 'zapis')
    ? `${legacy.length} ${plural(legacy.length, 'red čeka', 'reda čekaju', 'redova čeka')} provjeru: zapis slanja je bio nečitljiv, pa se ne zna je li neka od ovih Regulacija u međuvremenu poslana.`
    : `${legacy.length} ${plural(legacy.length, 'red je', 'reda su', 'redova je')} ovdje stavila verzija 1.57, koja je i prekinutu vezu brojala kao „nije prošlo“. Neki su možda ipak prošli.`} Otključava se samo red za koji pročitana historija zalihe ne pokazuje tu Regulaciju.</p>
      ${lc && lc.busy ? '<p class="count-line"><i class="mj-busy"></i> Čitam historiju zalihe…</p>' : lc && lc.err ? `<p class="att-from">Provjera nije uspjela (${esc(lc.err)}).</p>` : lc && lc.res ? '<p class="att-from">Kretanja zadnje 2 sedmice za šifre ispod. Ovo nije dokaz: StoreFront ne pokazuje komentar ni razlog.</p>' : ''}
      <button class="btn btn-block" type="button" data-legacy-check ${lc && lc.busy ? 'disabled' : ''}>Provjeri u StoreFrontu (samo čitanje)</button>
      <button class="btn btn-block" type="button" data-legacy-ok="notdone">Provjerio sam: Regulacija nije prošla</button>
      <button class="btn btn-block" type="button" data-legacy-ok="done">Provjerio sam: prošla je, ukloni</button>` : '';
  const pend = pending.length ? `<div class="mp-step mp-pending"><div class="mp-head"><b>Čeka Regulaciju</b><small>${pending.length}</small></div>
      <p class="att-from">Ovi artikli su na Minus listi već vraćeni na 0, ali Regulacija zalihe nije prošla:</p>
      ${pending.map(legacyRow).join('')}
      ${legacyBox}
      <button class="btn btn-primary btn-block mp-apply" type="button" data-mp-apply-adjust ${busy || legacy.length ? 'disabled' : ''}>${S.minusApplying ? 'Šaljem…' : 'Pošalji samo Regulaciju'}</button>
      <button class="text-btn" type="button" data-mp-pending-clear>Uradio sam to u StoreFrontu, ukloni</button></div>` : '';
  if (!one.length) return `<section class="mj-sec mp"><div class="sec-head"><h2>Plan za smjenu</h2></div>${pend}</section>`;
  return `<section class="mj-sec mp"><div class="sec-head"><h2>Plan za smjenu</h2><small>${one.length} ${plural(one.length, 'zamjena', 'zamjene', 'zamjena')}</small></div>
    ${pend}
    <p class="att-from">Prije potvrde provjeri na polici da je pod zamjenskom šifrom stvarno ostalo koliko piše „poslije ostaje“.</p>
    ${(() => { const go = minusApplyItems().length, held = one.length - go; return `${held ? `<p class="att-from op-warnline">${held} ${plural(held, 'red je', 'reda su', 'redova je')} već ${plural(held, 'poslan', 'poslana', 'poslano')} ili označen${held === 1 ? '' : 'i'} kao urađen${held === 1 ? '' : 'i'} u zadnjih 12 sati: ne šalje se ponovo, čak i ako ga StoreFront još pokazuje.</p>` : ''}
    <button class="btn btn-primary btn-block mp-apply" type="button" data-mp-apply ${busy || !go ? 'disabled' : ''}>${S.minusApplying ? 'Šaljem u StoreFront…' : go ? `Potvrdi ${go} ${plural(go, 'zamjenu', 'zamjene', 'zamjena')} u aplikaciji` : 'Nema ništa novo za slanje'}</button>`; })()}
    <p class="att-from">Potvrda šalje oba koraka odjednom, s komentarima, pod tvojim SAP HR brojem, s lozinkom iz postavki (Postavke → Prijava), pa ništa ne kucaš; „Upiši ručno“ ako želiš drugu. Ili ručno u StoreFrontu: prvo svi na Minus listi pa jedna potvrda, zatim svi na Regulaciji zalihe pa jedna potvrda.</p>
    <div class="mp-step"><div class="mp-head"><b>1. Minus lista</b><small>${left(1)} preostalo</small><button class="text-btn" type="button" data-sf-page="minus">Otvori Minus listu</button></div>
      ${one.map((x) => row(x, 1)).join('')}</div>
    <div class="mp-step"><div class="mp-head"><b>2. Regulacija zalihe</b><small>${left(2)} preostalo</small><button class="text-btn" type="button" data-sf-page="adjust">Otvori Regulaciju</button></div>
      ${one.map((x) => row(x, 2)).join('')}</div>
  </section>`;
}

/** The lines the shift plan would send: number in minus, its replacement with stock, the two comments. */
/**
 * A line already done in the last 12 hours (StoreFront confirmed both steps, or the employee ticked both as done),
 * or one waiting for Regulacija alone: it is not sent again even if StoreFront's Minus lista still shows it (the
 * list may be read before StoreFront updated it; the Minus lista correction adds, so twice would be wrong).
 */
function minusSentRecently(x) {
  const d = S.user.minusDone || {};
  const t = d[`${x.num}|${x.qty}|2`] || 0;
  if (Date.now() - t < 12 * 3600000) return true;
  return (S.user.minusPending || []).some((p) => p && p.num === x.num);
}

function minusApplyItems() {
  const m = S.user.minus;
  if (!m || !m.items) return [];
  return m.items.filter((x) => minusTarget(x) && !minusSentRecently(x)).map((x) => {
    const t = minusTarget(x);
    const [c1, c2] = minusComments(x, t);
    return { num: x.num, qty: x.qty, target: t.num, c1, c2 };
  });
}

window.onMinusApplying = () => { S.minusApplying = true; minusOpNow(); if (top().id === 'minus') renderMinus(); };
window.onMinusApplied = (r) => {
  S.minusApplying = false;
  // 1.97: the outcome in the flow log, step by step ("Minus potvrđen, Regulacija čeka provjeru")
  try {
    if (flow) {
      const adj = !!S.minusSendingAdjust, n = (S.minusSending || []).length;
      const act = adj ? 'Slanje Regulacije' : 'Slanje Minus liste i Regulacije';
      const st = r && r.state, step = r && r.step;
      const o = !r ? ['app_error', 'nema odgovora']
        : st === 'ok' ? ['ok', adj ? 'Regulacija potvrđena' : 'Minus potvrđen, Regulacija potvrđena']
        : st === 'locked' ? ['held', 'prethodno slanje ima nepoznat ishod: zaključano']
        : st === 'unknown' ? ['unsure', step === 'minus' ? 'Minus poslan, potvrda nije stigla: provjeri' : adj ? 'Regulacija poslana, potvrda nije stigla: provjeri' : 'Minus potvrđen, Regulacija čeka provjeru']
        : (/^adjust/.test(r.why || '') || step === 'adjust') && !adj ? ['rejected', 'Minus potvrđen, Regulacija odbijena: čeka ponovno slanje']
        : r.why === 'login' ? ['login', 'ništa nije poslano'] : ['rejected', 'ništa nije poslano'];
      flow.one(adj ? 'reg' : 'minus', act, o[1], o[0], { n, ...(r && r.why ? { why: String(r.why).slice(0, 20) } : {}) });
    }
  } catch (e) { /* ignore */ }
  if (r && r.op) S.minusOp = r.op; else minusOpNow();
  const W = { empty: 'Upiši SAP HR broj i lozinku.', auth: 'StoreFront nije prihvatio SAP HR broj ili lozinku. Ništa nije poslano.', nonstore: 'StoreFront kaže da korisnik nije iz prodavnice. Ništa nije poslano: uradi to u StoreFrontu.', wrongstore: 'StoreFront kaže da korisnik nije iz ove prodavnice. Ništa nije poslano: uradi to u StoreFrontu.', login: 'StoreFront traži prijavu. Ništa nije poslano.', nouser: 'StoreFront nije dao tvoj SAP HR broj. Ništa nije poslano: tapni „Upiši ručno“.' };
  if (r && r.kept && r.why === 'auth') W.auth = 'StoreFront nije prihvatio lozinku iz postavki za potvrdu. Ništa nije poslano. Sljedeći put je upiši ručno, ili je promijeni u Postavke → Prijava.';
  const sentItems = S.minusSending || [];
  const adjustOnly = !!S.minusSendingAdjust;
  S.minusSending = null;
  S.minusSendingAdjust = false;
  if (r && r.state === 'locked') {
    toast(r.why === 'busy' ? 'Slanje je već u toku.' : r.why === 'record' ? 'Zapis slanja se nije mogao spremiti (pun prostor?). Ništa nije poslano.'
      : r.why === 'corrupt' ? 'Zapis posljednjeg slanja je nečitljiv. Provjeri u StoreFrontu i očisti ga na Minus listi. Ništa nije poslano.'
        : 'Prethodno slanje ima nepoznat ishod. Prvo ga provjeri, pa tek onda šalji ponovo.');
  } else if (r && r.state === 'unknown') {
    // a step was sent and its answer never came: nothing is marked done, nothing is kept for sending again
    toast('Ishod nepoznat – potrebna provjera. Ništa se neće slati dok ne provjeriš.');
  } else if (!r || r.state !== 'ok') {
    const why = r && r.why || '';
    let msg = W[why] || (r && r.step === 'minus' ? 'StoreFront je odbio Minus listu. Ništa nije promijenjeno.' : 'Slanje nije uspjelo. Ništa nije poslano.');
    if (!adjustOnly && (/^adjust/.test(why) || r && r.step === 'adjust')) {
      // Minus lista went through (StoreFront accepted it), Regulacija was refused: keep those lines to send again
      // on their own, when the employee taps it
      const sent = new Set(r && r.sent ? r.sent : sentItems.map((i) => i.num));
      const have = new Set((S.user.minusPending || []).map((p) => p.num));
      S.user.minusPending = [...(S.user.minusPending || []), ...sentItems.filter((i) => sent.has(i.num) && !have.has(i.num))];
      saveUser();
      msg = 'Minus lista je ispravljena, ali StoreFront je odbio Regulaciju zalihe. Tapni „Pošalji samo Regulaciju“ ili je uradi u StoreFrontu.';
    }
    toast(msg);
  } else {
    const n = (r.sent || []).length, k = (r.skipped || []).length;
    if (r.unsaved) toast('StoreFront je potvrdio, ali telefon nije mogao zapisati ishod (pun prostor?). Slanje ostaje zaključano dok ne provjeriš.', 6000);
    else toast(`${sandboxOn() ? 'TEST, odigrano (ništa nije poslano): ' : ''}${n ? `Potvrđeno u StoreFrontu: ${n} ${plural(n, adjustOnly ? 'regulacija' : 'zamjena', adjustOnly ? 'regulacije' : 'zamjene', adjustOnly ? 'regulacija' : 'zamjena')}.` : 'Ništa nije poslano.'}${k ? ` Preskočeno ${k} (promijenilo se u međuvremenu).` : ''}`);
    if (adjustOnly) {
      const sent = new Set(r.sent || []);
      S.user.minusPending = (S.user.minusPending || []).filter((p) => !sent.has(p.num));
    } else {
      const d = S.user.minusDone || (S.user.minusDone = {});
      const m = S.user.minus;
      for (const num of r.sent || []) {
        const x = m && m.items.find((i) => i.num === num);
        if (x) { d[`${x.num}|${x.qty}|1`] = Date.now(); d[`${x.num}|${x.qty}|2`] = Date.now(); }
      }
    }
    saveUser();
    setTimeout(loadMinus, 2500);
  }
  // StoreFront answered, but the phone could not write the outcome down: the record reads as unknown from now on
  if (r && r.unsaved && r.state !== 'locked' && r.state !== 'ok') setTimeout(() => toast('Telefon nije mogao zapisati ishod slanja (pun prostor?). Slanje ostaje zaključano dok ne provjeriš u StoreFrontu.', 6000), 3200);
  if (r && r.unsaved) minusOpNow();
  if (top().id === 'minus') renderMinus();
  renderMinusBar();
};

function onMinusClick(ev) {
  const t = ev.target.closest('[data-num],[data-mp-done],[data-mp-copy],[data-sf-page],[data-mp-apply],[data-mp-apply-adjust],[data-mp-pick],[data-mp-pending-clear],[data-op-check],[data-op-resolve],[data-legacy-check],[data-legacy-ok],[data-mp-orders]');
  if (!t) return;
  if (t.dataset.mpOrders) { openCustomers(t.dataset.mpOrders); return; }
  if ('opCheck' in t.dataset) { minusOpCheck(); return; }
  if ('legacyCheck' in t.dataset) { legacyCheck(); return; }
  if (t.dataset.legacyOk) {
    const legacy = (S.user.minusPending || []).filter((p) => p && p.legacy);
    if (t.dataset.legacyOk === 'done') {
      S.user.minusPending = (S.user.minusPending || []).filter((p) => !(p && p.legacy));
      saveUser();
      S.legacyCheck = null;
      toast(`Uklonjeno ${legacy.length}: Regulacija je već bila prošla.`);
    } else {
      // "not done" lets Regulacija be sent again: only after StoreFront's stock history was actually read, and never
      // for a line where it shows the expected movement (or something that could be it)
      const lc = S.legacyCheck;
      if (!lc || !lc.res || Date.now() - (lc.at || 0) > 30 * 60000) { toast('Prvo tapni „Provjeri u StoreFrontu“: bez pročitane historije zalihe ne može se otključati.'); return; }
      const ev = new Map(lc.res.lines.map((l) => [l.num, l.adjust]));
      const free = legacy.filter((p) => ev.get(p.num) === 'none');
      const hold = legacy.filter((p) => ev.get(p.num) !== 'none');
      for (const p of free) { delete p.legacy; p.checkedAt = Date.now(); }
      saveUser();
      toast(hold.length
        ? `Otključano ${free.length}. ${hold.length} ostaje zaključano (${hold.map((p) => p.target).join(', ')}): StoreFront pokazuje kretanje koje može biti ta Regulacija. Provjeri ručno; ako je prošla, ukloni.`
        : `Otključano ${free.length}: StoreFront ne pokazuje tu Regulaciju. Sada se može poslati.`);
    }
    renderMinus();
    renderMinusBar();
    return;
  }
  if (t.dataset.opResolve) { minusOpResolve(t.dataset.opResolve); return; }
  if (('mpApply' in t.dataset || 'mpApplyAdjust' in t.dataset) && minusop.locks(minusOpNow())) {
    toast('Prethodno slanje ima nepoznat ishod. Prvo ga provjeri.');
    renderMinus();
    return;
  }
  if ('mpApply' in t.dataset) {
    if (S.minusApplying) return;
    if (!S.user.minus || Date.now() - (S.user.minus.at || 0) > 15 * 60 * 1000) { toast('Lista je starija od 15 minuta. Osvježi je pa potvrdi.'); loadMinus(); return; }
    const items = minusApplyItems();
    if (!items.length) return;
    S.minusSending = items;
    try { A.minusApply(JSON.stringify(items)); } catch (e) { S.minusSending = null; toast('Ova verzija aplikacije to ne zna.'); }
    return;
  }
  if ('mpApplyAdjust' in t.dataset) {
    if (S.minusApplying) return;
    const items = (S.user.minusPending || []).filter((p) => p && p.target);
    if (!items.length) return;
    if (items.some((p) => p.legacy)) { toast('Prvo provjeri zaključane redove (Provjeri u StoreFrontu).'); return; }
    if (!A.minusApplyAdjust) { toast('Ova verzija aplikacije to ne zna. Uradi Regulaciju u StoreFrontu.'); return; }
    S.minusSending = items;
    S.minusSendingAdjust = true;
    try { A.minusApplyAdjust(JSON.stringify(items)); } catch (e) { S.minusSending = null; S.minusSendingAdjust = false; toast('Ova verzija aplikacije to ne zna.'); }
    return;
  }
  if ('mpPendingClear' in t.dataset) { S.user.minusPending = []; saveUser(); renderMinus(); return; }
  if (t.dataset.mpPick) {
    const [num, target] = t.dataset.mpPick.split('|');
    const p = S.user.minusPick || (S.user.minusPick = {});
    p[num] = target;
    saveUser();
    renderMinus();
    return;
  }
  if (t.dataset.sfPage) { try { A.storefrontPage(t.dataset.sfPage); } catch (e) { toast('Ova verzija aplikacije to ne zna.'); } return; }
  if (t.dataset.mpCopy) {
    try { A.copyText(t.dataset.mpCopy); toast('Komentar kopiran'); } catch (e) { toast('Kopiranje ne radi u ovoj verziji.'); }
    return;
  }
  if (t.dataset.mpDone) {
    const d = S.user.minusDone || (S.user.minusDone = {});
    if (d[t.dataset.mpDone]) delete d[t.dataset.mpDone]; else d[t.dataset.mpDone] = Date.now();
    saveUser();
    renderMinus();
    return;
  }
  if (t.dataset.num) openItem(t.dataset.num, { via: 'minus' });
}

function renderMinus() {
  const box = $('#minusBody');
  if (!box) return;
  const m = S.user.minus;
  const busy = S.minusBusy ? '<p class="count-line"><i class="mj-busy"></i> Čitam Minus listu iz StoreFronta…</p>' : '';
  if (!m || !m.items) { minusOpNow(); box.innerHTML = (busy || '<p class="empty">Minus lista još nije učitana. Tapni osvježi gore desno.</p>') + minusOpCard(); return; }
  const items = m.items.slice().sort((a, b) => a.qty - b.qty);
  S.minusMap = minusTargets(items);
  minusOpNow();
  const ready = items.filter((x) => minusTarget(x));
  const decide = items.filter((x) => chainOf(x).length && !minusTarget(x));
  const unread = items.filter((x) => !chainOf(x).length && x.subsErr);
  const noSub = items.filter((x) => !chainOf(x).length && !x.subsErr);
  const hidden = (m.other || []).length;
  const cut = m.total > 300 ? m.total - 300 : 0;
  box.innerHTML = `${busy}<p class="count-line">${items.length} ${plural(items.length, 'artikal', 'artikla', 'artikala')} u minusu · stanje <span class="min-age">${esc(ageText(Math.max(m.at || 0, m.seen || 0)))}</span><span class="auto-note">${esc(autoNote())}</span></p>
    ${sandboxOn() ? `<p class="sandbox-note">TEST verzija: slanje se samo odigra (${esc((SIMS.find((x) => x[0] === simNow()) || SIMS[0])[1])}). Ništa ne ide u StoreFront. Promjena: Postavke → TEST.</p>` : ''}
    ${cut ? `<p class="att-from op-warnline">StoreFront ima ${m.total} redova na Minus listi, ovdje je prvih 300. Ostale pogledaj u StoreFrontu.</p>` : ''}
    ${hidden ? `<p class="att-from">Nije prikazano ${hidden} (šifre koje nisu od 7 cifara, npr. setovi): ${esc(m.other.join(', '))}. Njih uradi u StoreFrontu.</p>` : ''}
    ${minusOpCard()}
    ${minusPlan(items)}
    ${unread.length ? `<section class="mj-sec"><div class="sec-head"><h2>Zamjene nisu pročitane</h2><small>${unread.length}</small></div>
      <p class="att-from op-warnline">StoreFront nije odgovorio za zamjenske šifre ovih artikala. To ne znači da zamjene nema. Osvježi listu.</p>
      <div class="list">${unread.map(minusRow).join('')}</div></section>` : ''}
    ${decide.length ? `<section class="mj-sec"><div class="sec-head"><h2>Treba tvoja odluka</h2><small>${decide.length}</small></div>
      <div class="mp-step">${decide.map(minusDecideRow).join('')}</div></section>` : ''}
    ${ready.length ? `<section class="mj-sec"><div class="sec-head"><h2>Spremno za ispravku</h2><small>${ready.length}</small></div>
      <div class="list">${ready.map(minusRow).join('')}</div></section>` : ''}
    <section class="mj-sec"><div class="sec-head"><h2>Bez zamjene</h2><small>${noSub.length}</small></div>
      <p class="att-from">Pravilo 6.02: provjeri neprihvaćene dostave, pronađi uzrok, prebroji i u komentar upiši šta je provjereno.</p>
      ${noSub.length ? `<div class="list">${noSub.map(minusRow).join('')}</div>` : '<p class="empty">Nema.</p>'}</section>`;
}

  return { loadMinus, minusOpNow, onMinusClick, openMinus, renderMinus, renderMinusBar };
}
