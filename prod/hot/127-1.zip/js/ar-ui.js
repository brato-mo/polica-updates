// AR artikli: the weekly rating of the department in MYJYSK (the screen; the form is in ar.js).
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createArUi(ctx) {
  const { $, A, S, ar, cfg, esc, go, icon, mjOn, note, refreshMyjysk, renderNews, saveUser, toast, top } = ctx;

//
// The employee rates his department 1-5 per question; everything starts at 5. Under 5 MYJYSK wants a comment: he
// picks a ready-made sentence or writes his own. One button then makes the visit in MYJYSK, fills in his answers
// and completes it (assets/myjysk-ar.js, with his own sign-in).

const arKept = () => S.user.ar || (S.user.ar = { form: null, last: null, used: {} });
// own comments per question and score (older versions kept one list per question: those count as 4s)
const arUsed = (k, id) => { const u = k.used[id]; return Array.isArray(u) ? { 4: u } : { ...(u || {}) }; };
const arFormName = () => cfg().arForm || ar.DEFAULT_FORM;
const AR_STEP = { create: 'pravljenje posjete', start: 'otvaranje posjete', answers: 'upisivanje odgovora', complete: 'završavanje posjete' };

function arBar() {
  if (!mjOn()) return '';
  const k = arKept();
  const done = ar.doneThisWeek(k.last, Date.now());
  const sub = done ? `Urađeno ove sedmice${k.last.score ? `, rezultat ${Math.round(k.last.score)}%` : ''}` : 'Nije urađeno ove sedmice';
  return `<button class="orders-bar ar-bar${done ? ' is-done' : ''}" type="button" data-mj="ar">${icon('list')}<span><b>AR artikli</b><small>${esc(sub)}</small></span><span class="go">${done ? 'Otvori' : 'Ocijeni'}</span></button>`;
}

function openAr() {
  S.ar.err = null;
  S.ar.done = null;
  if (!S.ar.busy) { S.ar.scores = {}; S.ar.notes = {}; }
  go('ar');
  renderAr();
  if (!S.ar.busy) arLoad();
}

function arCall(arg) {
  try { A.myjyskAr(JSON.stringify(arg)); return true; } catch (e) { return false; }
}

function arLoad() {
  if (!arCall({ mode: 'form', form: arFormName() })) { S.ar.err = { kind: 'old' }; renderAr(); return; }
  S.ar.busy = 'form';
  renderAr();
}

function arSend() {
  const k = arKept();
  const qs = ar.questions(k.form);
  const miss = ar.missing(qs, S.ar.scores, S.ar.notes);
  if (miss.length) {
    toast('Za ocjenu ispod 5 treba komentar.');
    const el = document.querySelector(`[data-ar-note="${miss[0].id}"]`);
    if (el) { el.scrollIntoView({ block: 'center' }); el.focus(); }
    return;
  }
  let answers;
  try { answers = ar.answers(qs, S.ar.scores, S.ar.notes); } catch (e) { toast('Obrazac se promijenio. Osvježi ga pa pokušaj ponovo.'); return; }
  if (!navigator.onLine) { toast('Nema internet veze.'); return; }
  if (!arCall({ mode: 'send', guid: k.form.guid, answers })) { toast('Ova verzija aplikacije to ne može. Ažuriraj je.'); return; }
  S.ar.busy = 'send';
  S.ar.sent = { scores: { ...S.ar.scores }, notes: { ...S.ar.notes } };
  renderAr();
}

window.onMjAr = (r) => {
  if (r && r.res && r.res.dry) setTimeout(() => toast('TEST verzija: ništa nije poslano u MYJYSK (samo odigrano).'), 1800);
  const was = S.ar.busy;
  S.ar.busy = '';
  const k = arKept();
  if (r && r.how === 'ok' && was === 'form') {
    const res = r.res || {};
    k.forms = res.forms || k.forms || [];
    if (res.form) { k.form = res.form; S.ar.err = null; } else S.ar.err = { kind: 'noform' };
    saveUser();
  } else if (r && r.how === 'ok' && was === 'send') {
    const res = r.res || {};
    const qs = ar.questions(k.form);
    for (const q of qs) {
      const n = String((S.ar.sent.notes || {})[q.id] || '').trim();
      const sc = +((S.ar.sent.scores || {})[q.id] || 5);
      if (n && sc < 5) { const u = arUsed(k, q.id); u[sc] = [n, ...(u[sc] || []).filter((x) => x !== n)].slice(0, 3); k.used[q.id] = u; }
    }
    const mine = ar.score(qs, S.ar.sent.scores || {});
    k.last = { at: Date.now(), id: res.id || 0, score: res.score ? res.score : mine, form: k.form.name, status: res.status || '' };
    saveUser();
    S.ar.done = k.last;
    S.ar.err = null;
  } else {
    S.ar.err = { kind: r && r.how === 'login' ? 'login' : 'error', was, step: r && r.step, id: r && r.id, err: r && r.err };
  }
  if (top().id === 'ar') renderAr();
  if (S.mode === 'news') renderNews();
};

function arQuestion(q, i) {
  const sc = +(S.ar.scores[q.id] || 5);
  const k = arKept();
  const note = String(S.ar.notes[q.id] || '');
  const sugg = sc < 5 && q.note ? ar.suggestions(q, sc, arUsed(k, q.id)) : [];
  return `<div class="ar-q${sc < 5 ? ' is-low' : ''}">
    <p class="ar-name"><span>${i + 1}.</span> ${esc(q.name)}</p>
    <div class="ar-scores" role="radiogroup" aria-label="Ocjena">${[1, 2, 3, 4, 5].map((n) => `<button class="ar-sc" type="button" role="radio" aria-checked="${sc === n}" data-ar-sc="${q.id}:${n}" ${S.ar.busy ? 'disabled' : ''}>${n}</button>`).join('')}</div>
    ${sc < 5 && q.note ? `<div class="ar-sugg">${sugg.map((t) => `<button class="chip" type="button" aria-pressed="${note === t}" data-ar-pick="${q.id}" data-text="${esc(t)}">${esc(t)}</button>`).join('')}</div>
    <textarea class="ar-note" rows="2" maxlength="1000" placeholder="Zašto ${sc}? Izaberi gore ili napiši svoje." data-ar-note="${q.id}" ${S.ar.busy ? 'disabled' : ''}>${esc(note)}</textarea>` : ''}
  </div>`;
}

function renderAr() {
  const box = $('#arBody');
  if (!box) return;
  const k = arKept();
  const qs = ar.questions(k.form);
  const e = S.ar.err;
  let msg = '';
  if (S.ar.busy === 'form' && !qs.length) msg = '<div class="mj-state"><span><i class="mj-busy"></i>Učitavam obrazac iz MYJYSK…</span></div>';
  else if (S.ar.busy === 'form') msg = '<div class="mj-state"><span><i class="mj-busy"></i>Provjeravam obrazac u MYJYSK…</span></div>';
  if (e && e.kind === 'login') msg = `<button class="orders-bar" type="button" data-ar="login">${icon('info')}<span><b>Prijavi se ponovo u MYJYSK</b><small>Prijava je istekla.${e.was === 'send' ? ' Ništa nije poslano.' : ''}</small></span><span class="go">Prijava</span></button>`;
  else if (e && e.kind === 'noform') msg = `<p class="ar-err">U MYJYSK nema obrasca „${esc(arFormName())}". Izaberi svoj obrazac dolje.</p>`;
  else if (e && e.kind === 'old') msg = '<p class="ar-err">Ova verzija aplikacije to ne može. Ažuriraj je.</p>';
  else if (e && e.was === 'send') {
    msg = e.id
      ? `<div class="ar-err"><b>Nije završeno do kraja</b> (zapelo kod: ${esc(AR_STEP[e.step] || e.step || 'nepoznato')}). Posjeta je napravljena u MYJYSK, otvori je i završi tamo, da ne bude dvije.<br><button class="text-btn" type="button" data-mj-open="/ui/store-visits/${+e.id}">Otvori u MYJYSK</button></div>`
      : `<div class="ar-err"><b>Nije poslano.</b> ${e.err === 'lost' || e.err === 'timeout' ? 'MYJYSK nije odgovorio na vrijeme. Prije ponovnog slanja pogledaj u MYJYSK (Store Visit) da li je posjeta ipak napravljena.' : 'MYJYSK je vratio grešku. Pokušaj ponovo za koji minut.'}</div>`;
  } else if (e) msg = '<p class="ar-err">MYJYSK nije odgovorio. Prikazan je zadnji učitani obrazac.</p>';
  const d = S.ar.done;
  if (d) {
    box.innerHTML = `<div class="mj-intro ar-ok"><h3>AR artikli završeni ✓</h3>
      <p>Posjeta „${esc(d.form)}" je napravljena i završena u MYJYSK${d.score ? `, rezultat ${Math.round(d.score)}%` : ''}.</p>
      ${d.id ? `<button class="btn btn-quiet btn-block" type="button" data-mj-open="/ui/store-visits/${+d.id}">Pogledaj u MYJYSK</button>` : ''}</div>`;
    return;
  }
  const last = k.last && ar.doneThisWeek(k.last, Date.now()) ? `<p class="ar-note-top">Ove sedmice je već urađeno (${new Date(k.last.at).getDate()}.${new Date(k.last.at).getMonth() + 1}.). Ponovno slanje pravi novu posjetu.</p>` : '';
  const forms = (k.forms || []).length ? `<label class="ar-form">Obrazac <select data-ar="form" ${S.ar.busy ? 'disabled' : ''}>${k.forms.map((f) => `<option ${f.name === arFormName() ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>` : '';
  if (!qs.length) {
    box.innerHTML = `${msg}${forms}${S.ar.busy ? '' : '<button class="btn btn-quiet btn-block" type="button" data-ar="reload">Učitaj ponovo</button>'}`;
    return;
  }
  const low = qs.filter((q) => +(S.ar.scores[q.id] || 5) < 5).length;
  box.innerHTML = `${msg}${last}${forms}
    <p class="ar-hint">Sve je na 5. Promijeni samo ono što nije za 5 i izaberi zašto.</p>
    ${qs.map(arQuestion).join('')}
    <button class="btn btn-primary btn-block ar-send" type="button" data-ar="send" ${S.ar.busy ? 'disabled' : ''}>${S.ar.busy === 'send' ? '<i class="mj-busy"></i>Šaljem u MYJYSK…' : `Završi AR artikle${low ? ` (${low} ispod 5)` : ''}`}</button>`;
}

function onArClick(t) {
  if (t.dataset.arSc) {
    const [id, n] = t.dataset.arSc.split(':');
    const q = ar.questions(arKept().form).find((x) => String(x.id) === id);
    const was = +(S.ar.scores[id] || 5);
    // a ready-made sentence picked for the old score does not fit the new one
    if (q && was < 5 && ar.suggestions(q, was, arUsed(arKept(), q.id)).includes(S.ar.notes[id])) delete S.ar.notes[id];
    S.ar.scores[id] = +n;
    renderAr();
    if (+n < 5) { const el = document.querySelector(`[data-ar-note="${id}"]`); if (el && !el.value) el.closest('.ar-q').scrollIntoView({ block: 'nearest' }); }
    return;
  }
  if (t.dataset.arPick) {
    S.ar.notes[t.dataset.arPick] = t.dataset.text;
    renderAr();
    return;
  }
  const a = t.dataset.ar;
  if (a === 'send') arSend();
  else if (a === 'reload') arLoad();
  else if (a === 'login') { S.ar.err = null; S.ar.after = true; refreshMyjysk(true); }
}


  return { arBar, arKept, arLoad, onArClick, openAr, renderAr };
}
