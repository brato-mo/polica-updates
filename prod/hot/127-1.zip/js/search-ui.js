// The start screen and the article search: what the search box finds (number, barcode, name) and the start screen's
// bars. Moved out of app.js in 1.69 WITHOUT changing a line of what it does (tests/ui-smoke.mjs guards it).

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createSearchUi(ctx) {
  const cfg = ctx.cfg || (() => ({})), setCfg = ctx.setCfg || (() => {});
  const chev = ctx.chev || '', stCall = ctx.stCall, offline = ctx.offline || (() => false), thumb = ctx.thumb || (() => ''), ST_SHORT = ctx.ST_SHORT || {}, money = ctx.money || ((x) => String(x));
  const { $, $$, S, artikala, core, esc, itemRow, itemSummaryRow, placeHomeBars, mjOn, newsWaiting, ordersBlock, plural, renderClearBar, renderMinusBar, renderNews, renderOrdersBar, renderStoreBars, runOrdersSearch } = ctx;


function renderHome() {
  const has = S.plans.length > 0;
  $('#planCount').textContent = String(S.plans.length);
  $('#planCount').hidden = !has;
  const count = S.index.names.length;
  // 2.08: an order in two StoreFront tabs counts once (as in Narudžbe)
  const ol = S.user.orders && S.user.orders.list && [...new Set(S.user.orders.list.map((x) => x && x.no))];
  $('#homeStats').textContent = S.mode === 'sf' ? 'Pretraga cijelog StoreFronta, i van tvojih planograma' : S.mode === 'orders'
    ? (ol ? `${ol.length} ${plural(ol.length, 'narudžba', 'narudžbe', 'narudžbi')} kupaca` : 'Narudžbe još nisu učitane')
    : has
      ? `${artikala(count)} u ${S.plans.length} ${plural(S.plans.length, 'planogramu', 'planograma', 'planograma')}`
      : 'Tvoji planogrami, uvijek pri ruci';
  const nw = S.mode === 'news' && mjOn();
  $('#newsTab').hidden = !mjOn();
  $('#newsDot').hidden = nw || !newsWaiting();
  $('#newsWrap').hidden = !nw;
  if (nw) {
    $('#homeStats').textContent = 'Zadaci i vijesti iz MYJYSK';
    document.body.dataset.homeMode = 'news';
    for (const id of ['#sfSt', '#welcome', '#searchForm', '#homeDock', '#results', '#recentWrap', '#ordersBar', '#clearBar', '#minusBar', '#tipsBar', '#topBar', '#smBar', '#soonBar', '#moreTools']) $(id).hidden = true;
    for (const b of $$('#modeSeg [data-mode]')) b.setAttribute('aria-selected', String(b.dataset.mode === S.mode));
    renderNews();
    return;
  }
  const ord = S.mode === 'orders' || S.mode === 'sf'; // 2.17: the StoreFront search works without planograms too
  $('#welcome').hidden = has || ord;
  $('#searchForm').hidden = !(has || ord);
  $('#homeDock').hidden = !(has || ord);
  const q = $('#q').value.trim();
  $('#results').hidden = !(has || ord) || !q;
  $('#recentWrap').hidden = !(has || ord) || !!q;
  const favs = (S.user.favs || []).filter((n) => S.index.byNum.has(n));
  const recent = S.user.recent.filter((r) => S.index.byNum.has(r.num) && !favs.includes(r.num));
  $('#favWrap').hidden = !favs.length;
  // audit 13. 11. 2026: the short row (stock, status, "Na planogramu"); the first RECENT_SHOWN, the rest on a tap
  const RECENT_SHOWN = 5;
  const shownRecent = S.recentAll ? recent : recent.slice(0, RECENT_SHOWN);
  $('#favs').innerHTML = favs.length ? `<div class="list">${favs.map((n) => itemSummaryRow(n)).join('')}</div>` : '';
  $('#recent').innerHTML = recent.length ? `<div class="list">${shownRecent.map((r) => itemSummaryRow(r.num)).join('')}</div>`
    + (recent.length > RECENT_SHOWN ? `<button class="text-btn recent-more" type="button" data-recent-all>${S.recentAll ? 'Prikaži manje' : `Prikaži sve (${recent.length})`}</button>` : '') : '';
  renderOrdersBar();
  renderClearBar();
  renderMinusBar();
  renderStoreBars();
  $('#recentHead').hidden = recent.length === 0;
  for (const b of $$('#modeSeg [data-mode]')) b.setAttribute('aria-selected', String(b.dataset.mode === S.mode));
  $('#q').placeholder = S.mode === 'orders' ? 'Ime, artikal, broj narudžbe…' : S.mode === 'sf' ? 'Šifra ili naziv u StoreFrontu' : 'Šifra ili naziv artikla';
  paintScope();
  if (S.mode === 'orders') { runOrdersSearch(); return; }
  placeHomeBars(false);
  if (q) runSearch();
}

function runSearch() {
  if (S.mode === 'orders') { runOrdersSearch(); return; }
  placeHomeBars(false);
  const q = $('#q').value.trim();
  $('#clearQ').hidden = !q;
  const box = $('#results');
  paintScope();
  if (!q || (!S.plans.length && !sfScope())) {
    box.hidden = true;
    $('#recentWrap').hidden = !S.plans.length;
    return;
  }
  box.hidden = false;
  $('#recentWrap').hidden = true;
  if (sfScope()) { box.innerHTML = `<div class="sfs" id="sfsBox">${sfsHtml(q)}</div>`; sfsAsk(q); return; }
  const nums = core.search(S.index, q, 60);
  if (!nums.length) {
    const d = q.replace(/\s/g, '');
    box.innerHTML = `<p class="empty">${/^\d+$/.test(d) && d.length < 3
      ? 'Upiši bar tri cifre šifre.'
      : `Nema artikla „${esc(q)}“ u planogramima.`}</p>${/^\d{7}$/.test(d) ? ordersBlock(d, { label: d }) + ordersBlock(d, { after: true }) : ''}`
      + (d.length >= 3 && stCall ? `<button class="btn btn-soft btn-block sfs-go" type="button" data-mode-q="sf">Traži „${esc(q)}“ u StoreFrontu</button>` : '');
    return;
  }
  box.innerHTML = `<p class="count-line">${artikala(nums.length)}${nums.length >= 60 ? ' i više' : ''}</p><div class="list">${nums.map((n) => itemSummaryRow(n)).join('')}</div>`;
}


  // 2.15-pregled (owner, 19. 11. 2026): nothing in the planograms → StoreFront's own search for the same words, shown
  // here (read only). Asked 0.6 s after the typing stops, once per text; a late answer for an older text is dropped.
  const sfs = { q: '', at: 0, timer: 0, cache: new Map(), last: null, store: '', hint: '', seq: 0, storeSeq: 0 };
  // #25 (21. 11. 2026): what is kept belongs to ONE store (the store StoreFront answered for). Another store in an
  // answer, a new store the app learned elsewhere (an article reading) or a sign-out forgets it all; an answer of a
  // store left behind (asked before a newer answer of another store) is dropped, not shown or kept. Kept 10 min at most.
  const KEEP_MS = 10 * 60 * 1000;
  function forget() { clearTimeout(sfs.timer); sfs.cache.clear(); sfs.last = null; sfs.store = ''; sfs.storeSeq = ++sfs.seq; }
  /** true: an answer asked as `seq` for `store` may be shown (and the store it is of is now the one kept). */
  function storeOk(store, seq) {
    const s = String(store || '');
    if (!s) return true; // an answer that does not say its store (an empty one): shown, its stock is never "live"
    if (s === sfs.store) { if (seq > sfs.storeSeq) sfs.storeSeq = seq; return true; }
    if (seq < sfs.storeSeq) return false;
    sfs.cache.clear(); sfs.last = null; sfs.store = s; sfs.storeSeq = seq;
    return true;
  }
  // 2.17 (owner: "jako je sporo"): 0.3 s after the typing stops (was 0.6), the StoreFront page is warmed when the tab
  // opens, Enter asks at once, the last results stay on screen while new ones come, and a text that only narrows a
  // search whose every hit is already here (fewer than 20) is answered from those hits without asking StoreFront.
  const keyOf = (q) => `${q.toLowerCase().replace(/\s+/g, ' ')}|${sfStatuses().join(',')}`;
  const words = (q) => core.fold(q).split(/\s+/).filter(Boolean);
  function narrowed(q) {
    const st = sfStatuses().join(','), ws = words(q);
    let best = null;
    for (const [k, c] of sfs.cache) {
      const [kq, kst] = k.split('|');
      if (kst !== st || !c.list || c.similar || c.seen >= 40 || !kq || !q.toLowerCase().startsWith(kq) || !c.at || Date.now() - c.at > KEEP_MS) continue; // only a complete answer
      if (!best || kq.length > best.kq.length) best = { kq, c };
    }
    if (!best) return null;
    return { list: best.c.list.filter((x) => { const f = core.fold(`${x.name} ${x.num}`); return ws.every((w) => f.includes(w)); }), total: 0, seen: 0, local: true, stockBusy: best.c.stockBusy, at: best.c.at, store: best.c.store };
  }
  function sfsAsk(q, now = false) {
    const key = keyOf(q);
    clearTimeout(sfs.timer);
    sfs.q = key;
    if (q.replace(/\s/g, '').length < 3 || offline()) return;
    const hs = String((S.user && S.user.sfHint && S.user.sfHint.store) || '');
    if (hs !== sfs.hint) { sfs.hint = hs; if (hs && sfs.store && hs !== sfs.store) forget(); } // the app saw another store
    let have = sfs.cache.get(key);
    if (have && have.at && Date.now() - have.at > KEEP_MS) { sfs.cache.delete(key); have = null; }
    if (have && !have.err) return;
    const local = narrowed(q);
    if (local && local.list.length) { local.total = local.list.length; sfs.cache.set(key, local); paintSfs(q); return; }
    const go = () => {
      if (sfs.q !== key) return;
      sfs.cache.set(key, { busy: true, t0: Date.now() });
      paintSfs(q);
      retry();
    };
    function retry() {
      const seq = ++sfs.seq;
      stCall({ mode: 'sfsearch', q, st: sfStatuses().length === ST_ALL.length ? [] : sfStatuses() }, (r) => { // [] = all statuses
        if (r && r.how === 'ok' && r.res && !storeOk(r.res.store, seq)) { // #25: a store left behind
          if ((sfs.cache.get(key) || {}).busy) sfs.cache.delete(key);
          if (sfs.q === key) { paintSfs(q); if (!sfs.cache.has(key)) sfsAsk(q, true); }
          return;
        }
        // 2.19: one StoreFront hiccup (the owner's phone 19. 11. 14:05: http 500) is asked again once, by itself
        if (!(r && r.how === 'ok') && !(r && r.how === 'login') && !(sfs.cache.get(key) || {}).again) {
          sfs.cache.set(key, { busy: true, again: true, t0: Date.now() });
          setTimeout(() => { if (sfs.q === key) { sfs.cache.delete(key); sfs.cache.set(key, { busy: true, again: true, t0: Date.now() }); retry(); } }, 800);
          return;
        }
        const v = r && r.how === 'ok' && r.res ? split(q, r.res.list || [], r.res.total || 0) : { err: r && r.how === 'login' ? 'login' : 'error' };
        v.ms = Date.now() - ((sfs.cache.get(key) || {}).t0 || Date.now());
        if (v.list) { v.at = Date.now(); v.store = String(r.res.store || ''); }
        sfs.cache.set(key, v);
        if (v.list) { sfs.last = { q, ...v }; if (sfs.q === key) liveStock(q, key, v); } // 2.20: only for the text still in the box (log 20. 11.: 3 searches → 3 stock jobs)
        if (sfs.q === key) paintSfs(q);
      });
    }
    if (now) go(); else sfs.timer = setTimeout(go, 300);
  }
  function rowsHtml(c) {
    const stockPill = (x) => (Number.isFinite(x.stock) && x.live
      ? `<span class="pill ${x.stock <= 0 ? 'pill-zero' : 'pill-stock'}">Zaliha <b>${x.stock}</b> kom${Number.isFinite(x.free) && x.free !== x.stock ? ` · za prodaju <b>${x.free}</b>` : ''}</span>`
      : c.stockBusy ? '<span class="pill pill-muted">Zaliha: čitam…</span>'
        : Number.isFinite(x.stock0) ? `<span class="pill pill-muted">Zaliha okvirno ${x.stock0}</span>` : '<span class="pill pill-muted">Zaliha: nepoznato</span>');
    return `<p class="count-line">${c.similar ? `Nijedan naziv nema „${esc(c.q || '')}“ · slično u StoreFrontu:` : `${artikala(c.list.length)}${c.total > c.list.length ? ` · u StoreFrontu ih ima više, upiši tačnije` : ''}`}</p>
      <div class="list${c.stale ? ' is-stale' : ''}">${c.list.map((x) => `<div class="item item-sum is-sf">
        <button class="item-open" type="button" ${S.index && S.index.byNum.has(x.num) ? `data-num="${esc(x.num)}"` : `data-miss="${esc(x.num)}"`}>
          ${thumb(x.num)}
          <span class="item-main"><span class="item-name">${esc(x.name || x.num)}</span><span class="code">${esc(x.num)}</span>
            <span class="pills">${S.index && S.index.byNum.has(x.num) ? '<span class="pill pill-plan">Na planogramu</span>' : ''}${stockPill(x)}${x.st ? `<span class="pill ${x.st === '21' || x.st === '81' ? 'pill-warn' : 'pill-muted'}">Status ${esc(x.st)}${ST_SHORT[x.st] ? ` ${esc(ST_SHORT[x.st])}` : ''}</span>` : ''}${x.price != null ? `<span class="pill pill-muted">${esc(money(x.price))}</span>` : ''}</span>
          </span>
          ${chev}
        </button></div>`).join('')}</div>`;

  }
  /**
   * 2.19 (owner, 19. 11.: "dani" must give the DANI lamps, not GEDVED): StoreFront's search is loose (it also finds
   * words that only look alike), so a row whose name or number has every typed word is a hit; the rest is "similar" and
   * shown only when there is no hit at all.
   */
  function split(q, rows, total) {
    const ws = words(q);
    const hit = (x) => { const f = core.fold(`${x.name} ${x.num}`); return ws.every((w) => f.includes(w)); };
    const list = rows.filter(hit), like = rows.filter((x) => !hit(x));
    return { list: list.length ? list : like.slice(0, 20), similar: !list.length && like.length > 0, total: list.length ? (rows.length < 40 ? list.length : total) : 0, seen: rows.length };
  }
  /** The stock of the shown rows, live (the fast search's own number is not), in one batch, painted when it comes. */
  function liveStock(q, key, v) {
    const nums = v.list.slice(0, 20).map((x) => x.num).filter((n) => /^\d{7}$/.test(n));
    if (!nums.length) return;
    v.stockBusy = true;
    stCall({ mode: 'stockbatch', nums, par: 8 }, (r) => {
      // #25: the stock of another store than the one the rows are of (or of an unknown store) is not their live stock
      const same = !!v.store && String((r && r.res && r.res.store) || '') === v.store;
      const got = new Map(((same && r && r.how === 'ok' && r.res && r.res.list) || []).map((x) => [x.num, x]));
      for (const x of v.list) { const g = got.get(x.num); if (g) { x.stock = g.stock; if (Number.isFinite(g.free)) x.free = g.free; x.live = true; } }
      v.stockBusy = false;
      v.stockErr = !got.size;
      if (sfs.q === key) paintSfs(q);
    });
  }
  function sfsNow(q) { sfsAsk(q, true); }
  function paintSfs(q) {
    const b = $('#sfsBox');
    if (b && $('#q').value.trim().toLowerCase() === q.toLowerCase()) b.innerHTML = sfsHtml(q);
  }
  function sfsHtml(q) {
    let c = sfs.cache.get(keyOf(q));
    const head = '<div class="sfs-head"><span class="sfs-badge">StoreFront</span><b>Pronađeno u StoreFrontu</b></div>';
    if (offline()) return `${head}<p class="sfs-note">Nema interneta: StoreFront se ne može pretražiti.</p>`;
    if (q.replace(/\s/g, '').length < 3) return `${head}<p class="sfs-note">Upiši bar tri slova ili cifre.</p>`;
    const wait = `<p class="sfs-note"><span class="spin"></span> Tražim „${esc(q)}“ u StoreFrontu…</p>`;
    if (!c || c.busy) {
      if (!sfs.last || !sfs.last.list.length) return head + wait;
      c = { ...sfs.last, stale: true, stockBusy: false }; // the last results stay while the new ones come
      return head + wait + rowsHtml(c);
    }
    const real = `<button class="btn btn-soft btn-block" type="button" data-store="${esc(q)}">Otvori u pravom StoreFrontu</button>`;
    if (c.err) return `${head}<p class="sfs-note">${c.err === 'login' ? 'Prijava u StoreFront je istekla.' : 'StoreFront se nije javio aplikaciji.'} <button class="link" type="button" data-sfs-retry="1">Pokušaj ponovo</button></p>${real}`;
    if (!c.list.length) return `${head}<p class="sfs-note">StoreFront ne nalazi „${esc(q)}“ u aplikaciji.</p>${real}`;
    return head + rowsHtml({ ...c, q });
  }
  const sfScope = () => S.mode === 'sf' && !!stCall;
  // 2.17 (owner, 19. 11. 2026): the article statuses StoreFront's search looks in (StoreFront's own statusCode filter)
  const ST_ALL = ['11', '12', '21', '81', '31', '32', '41', '42', '51', '01', '02'];
  const sfStatuses = () => { const v = cfg().sfSt; return Array.isArray(v) && v.length ? ST_ALL.filter((x) => v.includes(x)) : ST_ALL.slice(); };
  function paintScope() {
    document.body.dataset.homeMode = S.mode; // 2.17: every search has its own colour (app.css [data-home-mode])
    const bar = $('#sfSt');
    if (!bar) return;
    bar.hidden = !sfScope();
    if (bar.hidden) return;
    const on = sfStatuses(), all = on.length === ST_ALL.length;
    const keepX = bar.scrollLeft; // the row stays where the finger left it
    bar.innerHTML = `<span class="sf-st-l">Statusi:</span><button type="button" data-sf-st="all" aria-pressed="${all}">Svi</button>`
      + ST_ALL.map((x) => `<button type="button" data-sf-st="${x}" aria-pressed="${!all && on.includes(x)}">${x}${ST_SHORT[x] ? ` <small>${esc(ST_SHORT[x])}</small>` : ''}</button>`).join('');
    bar.scrollLeft = keepX;
  }
  /** A status tapped: "Svi", or one status more / less (the first tap on a status picks only that one). */
  function toggleSt(x) {
    const on = sfStatuses(), all = on.length === ST_ALL.length;
    let next;
    if (x === 'all') next = [];
    else if (all) next = [x];
    else next = on.includes(x) ? on.filter((y) => y !== x) : [...on, x];
    setCfg({ sfSt: next.length === ST_ALL.length ? [] : next });
    runSearch();
  }
  /** Enter in the StoreFront scope: a number opens its article in the app (from StoreFront), one hit opens itself. */
  function sfEnter(v) {
    const d = v.replace(/\s/g, '');
    if (/^\d{4,7}$/.test(d)) return d;
    const c = sfs.cache.get(keyOf(v));
    return c && c.list && c.list.length === 1 ? c.list[0].num : null;
  }
  function sfsRetry() { const q = $('#q').value.trim(); sfs.cache.delete(keyOf(q)); paintSfs(q); sfsAsk(q); }

  return { renderHome, runSearch, sfsRetry, toggleSt, sfScope, sfEnter, sfsNow, sfsForget: forget };
}
