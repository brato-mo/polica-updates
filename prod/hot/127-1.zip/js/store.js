// The app keeps its data as small JSON files inside the app (through the Android bridge):
//   plans.json        list of planograms
//   plan-<id>.json    one read planogram
//   user.json         recent articles, barcodes linked by hand, last changes
const A = window.Android;

/** Files that exist but could not be read this session (kept beside as <name>.bad-<time>.json). */
export const damaged = [];

export function read(name, fallback) {
  let s = null;
  try {
    s = A.readText(name);
  } catch (e) {
    console.warn('read ' + name, e);
    return fallback;
  }
  if (!s) return fallback;
  try {
    return JSON.parse(s);
  } catch (e) {
    // the file is there but broken: keep it as it is before the app writes over it (nothing is silently lost)
    console.warn('broken ' + name, e);
    if (!damaged.some((d) => d.name === name)) {
      const copy = `${name.replace(/\.json$/, '')}.bad-${Date.now()}.json`;
      let kept = false;
      try { kept = A.writeText(copy, s) !== false; } catch (e2) { kept = false; }
      damaged.push({ name, copy: kept ? copy : '' });
    }
    return fallback;
  }
}

export function write(name, value) {
  try {
    return A.writeText(name, JSON.stringify(value)) !== false;
  } catch (e) {
    console.warn('write ' + name, e);
    return false;
  }
}

export function remove(name) {
  try {
    A.deleteText(name);
  } catch (e) {
    console.warn('delete ' + name, e);
  }
}
