// Everything that touches pdf.js: reading a planogram at import, keeping documents open,
// and drawing a part of a page (with the product photos recorded for the highlight).
import * as pdfjs from '../vendor/pdfjs/pdf.min.mjs';
import { readPages, pageGraphics, photoImage, mul } from './extract.js';
import { analyzePage, placeLabels, buildPlan, productBlock, labelPicture, rowPhoto } from './core.js';

/** Version of what the reader stores; older planograms are read again after an update. */
export const PLAN_VERSION = 4; // 3: product boxes take every facing (gaps, partly hidden ones); 4 (1.77, #18): neighbouring numbers kept apart, each number has its own box

// 1.77 (found in the IMAGE LAB experiment): pdf.js reads a page's text with `for await` over a ReadableStream, which WebView only has from
// Chrome 124 on. An older WebView (the API 34 emulator has 113) could read no planogram at all ("e is not async
// iterable"). The same, done by hand, for those WebViews; newer ones keep their own.
if (typeof ReadableStream !== 'undefined' && !ReadableStream.prototype[Symbol.asyncIterator]) {
  ReadableStream.prototype[Symbol.asyncIterator] = async function* iterate() {
    const reader = this.getReader();
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) return;
        yield value;
      }
    } finally {
      reader.releaseLock();
    }
  };
}

const VENDOR = new URL('../vendor/pdfjs/', import.meta.url).href;
pdfjs.GlobalWorkerOptions.workerSrc = VENDOR + 'pdf.worker.min.mjs';

function load(data) {
  return pdfjs.getDocument({
    data,
    standardFontDataUrl: VENDOR + 'standard_fonts/',
    wasmUrl: VENDOR + 'wasm/',
    iccUrl: VENDOR + 'iccs/',
    useWorkerFetch: false,
    enableXfa: false,
    verbosity: 0,
  });
}

async function bytes(url) {
  const r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error('missing');
  return new Uint8Array(await r.arrayBuffer());
}

// ------------------------------------------------------------------ pictures

const THUMB = 240; // longest side of an article picture, in pixels

function dataCanvas(img) {
  const { width: w, height: h, kind, data } = img;
  if (!data || (kind !== 2 && kind !== 3)) return null;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  const id = ctx.createImageData(w, h);
  const o = id.data;
  if (kind === 3) {
    o.set(data.subarray(0, o.length));
  } else {
    for (let i = 0, j = 0, k = 0; i < w * h; i++, j += 3, k += 4) {
      o[k] = data[j]; o[k + 1] = data[j + 1]; o[k + 2] = data[j + 2]; o[k + 3] = 255;
    }
  }
  ctx.putImageData(id, 0, 0);
  return c;
}

/** A clip path from pageGraphics as a Path2D (pdf.js drawing format), or null if unknown. */
function pathOf(data) {
  if (data instanceof Path2D) return data;
  if (!data || typeof data.length !== 'number') return null;
  const p = new Path2D();
  for (let i = 0; i < data.length;) {
    switch (data[i++]) {
      case 0: p.moveTo(data[i++], data[i++]); break;
      case 1: p.lineTo(data[i++], data[i++]); break;
      case 2: p.bezierCurveTo(data[i++], data[i++], data[i++], data[i++], data[i++], data[i++]); break;
      case 3: p.quadraticCurveTo(data[i++], data[i++], data[i++], data[i++]); break;
      case 4: p.closePath(); break;
      default: return null; // a wrong cut-out is worse than none
    }
  }
  return p;
}

/**
 * An article's picture as a small WebP: its photos (usually one) drawn the way they stand
 * on the page, each cut out by its own clip paths.
 */
async function thumbOf(page, parts) {
  const loaded = [];
  for (const photo of parts) {
    const img = await photoImage(page, photo);
    if (!img || !img.width || !img.height) continue;
    const src = img.bitmap || dataCanvas(img);
    if (src) loaded.push({ photo, img, src });
  }
  if (!loaded.length) return null;
  const b = loaded.slice(1).reduce((u, { photo: { b: p } }) => [Math.min(u[0], p[0]), Math.min(u[1], p[1]), Math.max(u[2], p[2]), Math.max(u[3], p[3])], loaded[0].photo.b);
  const k = THUMB / Math.max(b[2] - b[0], b[3] - b[1]);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round((b[2] - b[0]) * k));
  c.height = Math.max(1, Math.round((b[3] - b[1]) * k));
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  const toPic = [k, 0, 0, k, -k * b[0], -k * b[1]];
  for (const { photo, img, src } of loaded) {
    ctx.save();
    // the photo's own cut-out: clip paths, from their space to the picture
    for (const clip of photo.clips || []) {
      const p = pathOf(clip.path);
      if (!p) continue;
      const M = mul(toPic, clip.m);
      ctx.setTransform(M[0], M[1], M[2], M[3], M[4], M[5]);
      ctx.clip(p, clip.rule);
    }
    // image pixels -> page (the unit square under the photo's transform) -> picture
    const [m0, m1, m2, m3, m4, m5] = photo.m;
    const w = img.width, h = img.height;
    const M = mul(toPic, [m0 / w, m1 / w, -m2 / h, -m3 / h, m2 + m4, m3 + m5]);
    ctx.setTransform(M[0], M[1], M[2], M[3], M[4], M[5]);
    ctx.drawImage(src, 0, 0, w, h);
    ctx.restore();
  }
  // not awaited by the caller: the encoding runs while the next pictures are cut out
  return { encoding: new Promise((resolve) => c.toBlob((blob) => resolve(blob), 'image/webp', 0.82)) };
}

/**
 * Reads a planogram PDF. onStep(fraction 0..1, pageNo, pages, phase) reports progress.
 * With pictures: true, also returns a small photo of every article (Map number -> Blob).
 * Throws Error('locked') for password protected files and Error('bad') for broken ones.
 */
export async function readPlanogram(url, onStep, { pictures = true } = {}) {
  const task = load(await bytes(url));
  let doc;
  try {
    doc = await task.promise;
  } catch (e) {
    await task.destroy();
    throw new Error(e && e.name === 'PasswordException' ? 'locked' : 'bad');
  }
  try {
    const n = doc.numPages;
    const raw = await readPages(doc, (i) => onStep && onStep((0.3 * i) / n, i, n, 'text'));
    const ctx = {};
    const pages = raw.map((r) => analyzePage(r, ctx));
    const thumbs = new Map();
    const work = pages.map((p, i) => (p.kind === 'drawing' || p.kind === 'table' ? i : -1)).filter((i) => i >= 0);
    // pdf.js reads a page's drawing (and decodes its photos) in its worker while this thread cuts out the pictures of
    // the page before: the next page is always asked for ahead. Same result, the two halves overlap instead of taking
    // turns.
    const ahead = (k) => (k < work.length ? doc.getPage(work[k] + 1).then((pg) => { pg.getOperatorList().catch(() => {}); return pg; }) : null);
    let next = ahead(0);
    const pending = []; // pictures still being encoded: waited for once, at the end
    for (let k = 0; k < work.length; k++) {
      const i = work[k];
      const pg = pages[i];
      const page = await next;
      next = ahead(k + 1);
      try {
        const gfx = await pageGraphics(page, pdfjs.OPS);
        if (pg.kind === 'drawing') placeLabels(pg, gfx);
        if (pictures && gfx.photos.length) {
          const made = new Map(); // one picture per photo, even when facings repeat it
          const want = [];
          if (pg.kind === 'drawing') {
            for (const lab of pg.labels) want.push({ nums: lab.nums, parts: labelPicture(pg, lab, gfx.photos) });
          } else {
            for (const row of pg.rows) { const ph = rowPhoto(row, gfx.photos); want.push({ nums: [row.num, ...row.variants], parts: ph ? [ph] : [] }); }
          }
          for (const { nums, parts } of want) {
            if (!parts.length || nums.every((x) => thumbs.has(x))) continue;
            const key = parts.map((ph) => ph.id || ph.b.join(',')).join('|');
            // the picture is cut out now (it needs this page), its WebP encoding finishes in the background
            if (!made.has(key)) {
              const t = await thumbOf(page, parts).catch(() => null);
              made.set(key, t ? t.encoding.catch(() => null) : null);
            }
            const blob = made.get(key); // a promise of the picture while it is being encoded
            if (blob) for (const x of nums) if (!thumbs.has(x)) thumbs.set(x, blob);
          }
        }
      } catch (e) {
        console.warn('page ' + (i + 1), e);
      }
      page.cleanup();
      if (onStep) onStep(0.3 + (0.7 * (k + 1)) / work.length, i + 1, n, 'pictures');
    }
    // the encodings, in the order they were started; a picture that failed is left out as before
    for (const [num, b] of [...thumbs.entries()]) {
      const blob = await b;
      if (blob) thumbs.set(num, blob); else thumbs.delete(num);
    }
    const plan = buildPlan(pages);
    rescueLabels(plan, raw);
    plan.v = PLAN_VERSION;
    for (const num of thumbs.keys()) if (plan.items[num]) plan.items[num].im = 1;
    return { plan, thumbs };
  } finally {
    await task.destroy();
  }
}

/**
 * Articles that came out "only on the list" although their number is written on a drawing (a label the reading of
 * the drawing missed): placed on that drawing after all, on the shelf under the number. The list's own shelf
 * ("Segment 1/3") decides when it is on that page; the drawings before the list come first, as each department's
 * product list follows its own drawings.
 */
function rescueLabels(plan, raw) {
  const drawn = plan.pages.map((pg, i) => i).filter((i) => plan.pages[i].segs && plan.pages[i].segs.length);
  for (const [num, it] of Object.entries(plan.items)) {
    if (it.oc.length || !it.rw.length) continue;
    const row = it.rw[0];
    const fx = /Segment\s+([0-9]+(?:-[0-9]+)?)\s*\/\s*([0-9]+)/i.exec(row.fx || '');
    const order = [...drawn.filter((i) => i < row.p).reverse(), ...drawn.filter((i) => i > row.p)];
    for (const pi of order) {
      const pg = plan.pages[pi];
      let lab = null;
      for (const t of raw[pi].items) {
        const str = t.str.replace(/\s+/g, ' ');
        const at = str.search(new RegExp(`(^|[^0-9])${num}([^0-9]|$)`));
        if (at < 0 || /Segment|Notch/i.test(str)) continue;
        const m = t.t;
        const h = Math.hypot(m[2], m[3]) || 8;
        const k = (t.w || h * 0.55 * str.length) / Math.max(1, str.length);
        const off = at + (str[at] === num[0] ? 0 : 1);
        const b = [m[4] + k * off, m[5] - h, m[4] + k * (off + num.length), m[5] + h * 0.2];
        if (!lab || h > lab.h) lab = { b, h };
      }
      if (!lab) continue;
      // the shelf under the number: the nearest segment line below it that the number stands over
      const cxl = (lab.b[0] + lab.b[2]) / 2;
      let g = -1, best = Infinity;
      pg.segs.forEach((sg, si) => {
        const dy = sg.b[1] - lab.b[3];
        if (dy < -lab.h) return;
        const col = sg.col >= 0 && pg.cols && pg.cols[sg.col] ? pg.cols[sg.col] : null;
        const x0 = col ? Math.min(col.x0, sg.b[0]) : sg.b[0] - 200, x1 = col ? Math.max(col.x1, sg.b[2]) : sg.b[2] + 200;
        if (cxl < x0 || cxl > x1) return;
        if (dy < best) { best = dy; g = si; }
      });
      if (g < 0) continue; // not standing over any shelf: a mention in a note, not a label
      // the list says which shelf: a number found on another shelf of the page is someone else's mention
      if (fx && g >= 0 && `${pg.segs[g].s}/${pg.segs[g].sh}` !== `${fx[1]}/${fx[2]}`) continue;
      const r1 = (v) => Math.round(v * 10) / 10;
      it.oc.push({ p: pi, b: lab.b.map(r1), g });
      break;
    }
  }
}

// ------------------------------------------------------------- open documents

const open = new Map(); // plan id -> { task, promise }

export function openPlan(id) {
  if (open.has(id)) {
    const hit = open.get(id);
    open.delete(id);
    open.set(id, hit); // most recent last
    return hit.promise;
  }
  const entry = {};
  entry.promise = bytes(`/files/plans/${id}.pdf`).then((data) => {
    entry.task = load(data);
    return entry.task.promise;
  });
  entry.promise.catch(() => open.delete(id));
  open.set(id, entry);
  while (open.size > 2) {
    const [oldId, old] = open.entries().next().value;
    open.delete(oldId);
    if (old.task) old.task.destroy();
  }
  return entry.promise;
}

/**
 * A page that is not on screen any more lets go of what pdf.js keeps for it (its parsed drawing, decoded pictures):
 * a long PDF browsed page by page does not pile them up in a phone's memory. Drawn again from the PDF when needed;
 * a page still being drawn is cleaned up by pdf.js after it.
 */
export function release(id, pageNo) {
  const e = open.get(id);
  if (!e || !e.promise) return;
  e.promise.then((doc) => doc.getPage(pageNo)).then((p) => { try { p.cleanup(); } catch (err) { /* nothing kept */ } }).catch(() => {});
}

export function forget(id) {
  const e = open.get(id);
  if (!e) return;
  open.delete(id);
  if (e.task) e.task.destroy();
}

// ------------------------------------------------------------------ drawing

const drawStat = { n: 0, ms: 0, max: 0 };
/** 1.75: PDF drawing since the last call, as one diagnostics line ('' when nothing was drawn). */
export function drawSummary() {
  if (!drawStat.n) return '';
  const line = `PDF: ${drawStat.n} crtanja, prosjek ${Math.round(drawStat.ms / drawStat.n)} ms, najduže ${Math.round(drawStat.max)} ms`;
  drawStat.n = 0; drawStat.ms = 0; drawStat.max = 0;
  return line;
}

/**
 * Draws region [x0, y0, x1, y1] (page units, scale 1, y down) of a page into canvas,
 * filling cssW x cssH CSS pixels. Records where photos were drawn, in page units.
 */
export async function renderRegion(doc, pageNo, region, canvas, cssW, cssH, opts = {}) {
  const page = await doc.getPage(pageNo);
  const dpr = Math.min(window.devicePixelRatio || 1, opts.maxDpr || 3);
  const pw = Math.max(1, Math.round(cssW * dpr));
  const ph = Math.max(1, Math.round(cssH * dpr));
  const s = pw / (region[2] - region[0]);
  const viewport = page.getViewport({ scale: s, offsetX: -region[0] * s, offsetY: -region[1] * s });
  canvas.width = pw;
  canvas.height = ph;
  const ctx = canvas.getContext('2d', { alpha: !!opts.transparent });
  if (!opts.transparent) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, pw, ph);
  }
  const photos = [];
  const orig = ctx.drawImage;
  ctx.drawImage = function (img, ...a) {
    try {
      let dx, dy, dw, dh;
      if (a.length >= 8) [, , , , dx, dy, dw, dh] = a;
      else if (a.length >= 4) [dx, dy, dw, dh] = a;
      else { [dx, dy] = a; dw = img.width; dh = img.height; }
      const m = this.getTransform();
      const xs = [], ys = [];
      for (const [x, y] of [[dx, dy], [dx + dw, dy], [dx, dy + dh], [dx + dw, dy + dh]]) {
        xs.push((m.a * x + m.c * y + m.e) / s + region[0]);
        ys.push((m.b * x + m.d * y + m.f) / s + region[1]);
      }
      photos.push({ b: [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)] });
    } catch (e) {
      // recording is best effort
    }
    return orig.call(this, img, ...a);
  };
  const task = page.render({
    canvasContext: ctx,
    viewport,
    background: opts.transparent ? 'rgba(0,0,0,0)' : '#ffffff',
  });
  if (opts.onTask) opts.onTask(task);
  const t0 = performance.now();
  try {
    await task.promise;
    // 1.75 diagnostics: how long drawing a page (or a part of it) takes on this phone
    const ms = performance.now() - t0;
    drawStat.n++; drawStat.ms += ms; if (ms > drawStat.max) drawStat.max = ms;
  } finally {
    ctx.drawImage = orig;
  }
  return { scale: s, photos, page };
}

/**
 * Where an article number is written on a page (its label), in page space: [x0, y0, x1, y1], or null. For articles
 * whose label the reading of the planogram missed: the number is on the drawing all the same.
 */
// near (1.96): the place's own box (a list-only article on several shelves): the label in or nearest to it wins,
// before the biggest one of the page (which gave every place the same label)
export async function findNumber(doc, pageNo, num, near = null) {
  const page = await doc.getPage(pageNo);
  const vp = page.getViewport({ scale: 1 });
  const tc = await page.getTextContent();
  let best = null;
  for (const it of tc.items) {
    if (typeof it.str !== 'string') continue;
    const str = it.str.replace(/\s+/g, ' ');
    const at = str.search(new RegExp(`(^|[^0-9])${num}([^0-9]|$)`));
    if (at < 0 || /Segment|Notch/i.test(str)) continue;
    const m = mul(vp.transform, it.transform);
    const h = Math.hypot(m[2], m[3]) || Math.abs(m[3]) || 8;
    const w = it.width || h * 0.55 * str.length;
    // the part of the line that is the number (a label line may say "4912333 Plant pot ...")
    const k = w / Math.max(1, str.length);
    const off = at + (str[at] === num[0] ? 0 : 1);
    const b = [m[4] + k * off, m[5] - h, m[4] + k * (off + num.length), m[5] + h * 0.2];
    const d = near ? Math.max(0, near[0] - b[2], b[0] - near[2]) + Math.max(0, near[1] - b[3], b[1] - near[3]) : 0;
    // nearest to the place first; then the big label under the photo rather than a mention in a note
    if (!best || d < best.d - 1 || (Math.abs(d - best.d) <= 1 && h > best.h)) best = { b, h, d };
  }
  return best ? best.b : null;
}

/** Photos on a page without drawing it (when the drawing could not record them). */
export async function photosOf(doc, pageNo) {
  const page = await doc.getPage(pageNo);
  return (await pageGraphics(page, pdfjs.OPS)).photos;
}

/**
 * The product's box on the page: stored at import, or found from the photos now.
 * plan: stored planogram, oc: the occurrence, photos: from renderRegion/photosOf.
 */
export function blockFor(plan, oc, photos, extra) {
  if (oc.k && !extra) return oc.k;
  if (!photos || !photos.length) return null;
  const pg = plan.pages[oc.p];
  const seen = new Set();
  const labels = [];
  for (const [num, it] of Object.entries(plan.items)) {
    for (const o of it.oc) {
      if (o.p !== oc.p) continue;
      const key = o.b.join(',');
      if (seen.has(key)) continue;
      seen.add(key);
      labels.push({ b: o.b, nums: [num] });
    }
  }
  if (extra) labels.push(extra); // a label found on the page now: { b, nums }
  const lab = extra || labels.find((l) => l.b.join(',') === oc.b.join(','));
  if (!lab) return null;
  return productBlock({ w: pg.w, h: pg.h, labels }, lab, photos);
}
