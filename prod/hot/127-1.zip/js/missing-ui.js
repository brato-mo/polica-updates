// A barcode or number in no planogram: the screen that looks it up in StoreFront and lets it be linked.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createMissingUi(ctx) {
  const { $, A, S, cfg, core, planServerBtn, debounce, esc, go, icon, itemRow, money, openItem, ordersBlock, ordersOf, saveUser, sfThumb, stCall, stPill, stockHtml, stockLoad, toast, top, whole } = ctx;
  const note = ctx.note || (() => {});
  const offline = ctx.offline || (() => false);
  // 1.96: why StoreFront gave nothing, said as it is (a barcode that was read is never "not found" because of a network)
  const failWhy = (r) => (r && r.how === 'login' ? 'Prijava u StoreFront je istekla. Prijavi se, pa pokušaj ponovo.'
    : (r && r.err === 'offline') || offline() ? 'Nema interneta. Barkod je očitan, ali StoreFront sada nije dostupan.'
      : 'StoreFront nije odgovorio. Provjeri vezu i pokušaj ponovo.');
  const planGet = ctx.planGet || null; // 1.73-test4: the department's planogram next to an article in no planogram


function renderMissing(code) {
  // a code that is itself an article number is simply not in the planograms on the phone
  if (/^\d{4,7}$/.test(code)) {
    // 1.96 (owner, VIDAR): the article of a linked barcode opens here too when it is in no planogram on the phone:
    // StoreFront's picture, name, stock, price and status, and "Promijeni vezu"
    const via = S.missLinked && S.missLinked.num === code ? S.missLinked.code : '';
    const sd = S.stock.get(code);
    const nm = (sd && sd.d && sd.d.md && sd.d.md.name) || '';
    $('#missing .top-title').textContent = via ? 'Artikal' : 'Nije pronađeno';
    $('#missingBody').innerHTML = `<div class="missing">
      ${via ? `<p class="notice">${icon('link')}<span>Barkod ${esc(via)} je povezan s ovim artiklom. <button class="link" type="button" data-unlink="${esc(via)}">Promijeni vezu</button></span></p>` : ''}
      <div class="item item-static">${sfThumb(code)}<span class="item-main"><span class="code">${esc(code)}</span><span class="item-name" id="missName">${esc(nm)}</span></span></div>
      ${/* 2.06 (owner): a customer's order first, right under the article: no scrolling to see it */ ''}${ordersBlock(code)}
      ${A.storeTask && /^\d{7}$/.test(code) ? `<div class="stock-box" data-stock="${esc(code)}">${stockHtml(code)}</div>` : ''}
      <h2>Artikal nije u planogramima</h2>
      <p>Šifre ${esc(code)} nema ni u jednom planogramu na telefonu. Možda je u planogramu koji još nisi dodao.</p>
      ${planGet ? planGet.slot(code) : ''}
      ${ordersBlock(code, { after: true })}
      <button class="btn btn-soft btn-block" type="button" data-store="${esc(code)}">${icon('link')}Otvori u pravom StoreFrontu</button>
      <button class="btn btn-soft btn-block" type="button" data-add>${icon('plus')}Dodaj planograme</button>
    </div>`;
    $('#missingBody').onclick = null;
    if (planGet) planGet.fill($('#missingBody'));
    if (A.storeTask && /^\d{7}$/.test(code)) stockLoad(code);
    return;
  }
  $('#missing .top-title').textContent = 'Novi barkod';
  $('#missingBody').innerHTML = `<div class="missing">
    <div class="missing-ico">${icon('link')}</div>
    <h2>Poveži ovaj barkod</h2>
    <p>Barkod na proizvodu ne sadrži šifru artikla. Poveži ga jednom i od tada ga Jysk Reloaded odmah prepozna.</p>
    <span class="code-big">${esc(code)}</span>
  </div>
  <section class="block">
    <button class="btn btn-primary btn-block" type="button" id="storeGo">${icon('search')}Nađi u StoreFrontu</button>
    <p class="hint store-hint">StoreFront zna ovaj barkod. Prvi put se prijaviš na njihovoj stranici, poslije ide samo.</p>
    <div id="storeBox"></div>
  </section>
  <section class="block">
    <div class="sec-head"><h3>Ili upiši šifru s naljepnice</h3></div>
    <p class="empty" style="margin-bottom:10px">Na naljepnici je to „Product no.“ (npr. 4912611). Prije povezivanja vidiš naziv i sliku iz StoreFronta.</p>
    <form class="link-form" id="linkForm" autocomplete="off">
      <input id="linkNum" inputmode="numeric" pattern="[0-9]*" maxlength="9" placeholder="4912611" aria-label="Šifra artikla">
      <button class="btn btn-primary" type="submit">Poveži</button>
    </form>
    <p class="form-msg" id="linkMsg" role="alert"></p>
    <div id="linkPreview"></div>
  </section>
  <section class="block">
    <div class="sec-head"><h3>Ili ga nađi po nazivu</h3></div>
    <form class="search" id="linkSearch" role="search" autocomplete="off">
      ${icon('search', 'search-ico')}
      <input id="linkQ" type="search" enterkeyhint="search" placeholder="Npr. ingar, okvir, korpa" aria-label="Naziv artikla" spellcheck="false" autocapitalize="off" autocorrect="off">
    </form>
    <div id="linkResults"></div>
  </section>`;
  // 2.05: the link goes to the shared list too, when the employee chose to share (Java also needs the diagnostics consent): "sf" when StoreFront's
  // exact barcode search gave this one article, otherwise "manual" (shared only after a second phone sends it)
  const share = (num) => {
    if (S.user.noShared) delete S.user.noShared[code];
    if (!/^\d{8,14}$/.test(code) || !A.shareBarcode) return;
    const sf = S.sfExact && S.sfExact.code === code && S.sfExact.num === num;
    S.user.linkKind = { ...(S.user.linkKind || {}), [code]: sf ? 'sf' : 'manual' }; // 2.21: kept, for shareLearned
    const send = (yes) => { if (yes) try { A.shareBarcode(code, num, sf ? 'sf' : 'manual'); } catch (e) { /* older shell */ } };
    // 2.08: no question here any more; the choice is made in Postavke → Dijagnostika and Java checks it again (#22)
    send(S.user.shareCodes === 'yes');
  };
  const link = (num) => {
    S.user.learned[code] = num;
    share(num);
    saveUser();
    openItem(num, { via: 'learned', code }, { replace: true });
    toast('Zapamćeno. Sljedeći put ovaj barkod radi odmah.');
  };
  // 1.96 (owner, VIDAR 6120901): an article in no planogram on the phone can be linked too, after StoreFront showed it
  // (name, picture, status, stock) and the employee confirmed it; the link is kept and the article opens on the next scan
  const linkSf = (num) => {
    S.user.learned[code] = num;
    share(num);
    S.missLinked = { num, code };
    saveUser();
    openMissing(num, { replace: true });
    toast('Zapamćeno. Sljedeći put ovaj barkod odmah otvara ovaj artikal.');
  };
  let lookSeq = 0;
  const sfCard = (x) => `<div class="item item-static">${sfThumb(x.num)}<span class="item-main"><span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.name) || 'Bez naziva'}</span>${x.st ? `<span class="pills">${stPill(x.st)}</span>` : ''}${Number.isFinite(x.stock) ? `<span class="store-line">Zaliha u prodavnici: ${esc(whole(x.stock))}${Number.isFinite(x.price) ? ` · ${money(x.price)} KM` : ''}</span>` : ''}</span></div>
    <button class="btn btn-primary btn-block" type="button" data-link-sf="${esc(x.num)}">${icon('link')}Poveži barkod s ovim artiklom</button>`;
  const lookNow = () => {
    const n = $('#linkNum').value.replace(/\D/g, '');
    const seq = ++lookSeq;
    const res = n.length >= 4 ? core.resolveCode(S.index, n, {}) : null;
    $('#linkMsg').textContent = '';
    if (res && res.via !== 'inside' && res.num === n) { $('#linkPreview').innerHTML = `<div class="list">${itemRow(res.num, { attr: 'data-link' })}</div>`; return; }
    $('#linkPreview').innerHTML = '';
    if (n.length < 4 || n.length > 9) return;
    if (!A.storeTask) { $('#linkMsg').textContent = `Šifra ${n} nije u planogramima.`; return; }
    $('#linkMsg').textContent = `Tražim šifru ${n} u StoreFrontu…`;
    const sent = stCall({ mode: 'lookup', num: n }, (r) => {
      if (seq !== lookSeq || top().id !== 'missing' || top().state !== code) return;
      if (r.how !== 'ok' || !r.res) { $('#linkMsg').textContent = failWhy(r); return; }
      if (!r.res.found) { $('#linkMsg').textContent = `StoreFront ne nalazi šifru ${n}. Provjeri broj na etiketi.`; return; }
      $('#linkMsg').textContent = '';
      $('#linkPreview').innerHTML = sfCard(r.res.a);
    });
    if (!sent) $('#linkMsg').textContent = failWhy({ err: 'offline' });
  };
  const preview = debounce(lookNow, 350);
  $('#linkNum').addEventListener('input', preview);
  $('#linkForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const n = $('#linkNum').value.replace(/\D/g, '');
    const res = n.length >= 4 ? core.resolveCode(S.index, n, {}) : null;
    if (res && res.via !== 'inside' && res.num === n) { link(res.num); return; }
    // never linked blind: the StoreFront card has to be there and is confirmed with its own button
    const b = $('#linkPreview [data-link-sf]');
    if (b && b.dataset.linkSf === n) { linkSf(n); return; }
    if (n.length < 4 || n.length > 9) { $('#linkMsg').textContent = 'Upiši šifru artikla s etikete (4 do 9 cifara).'; return; }
    lookNow();
  });
  $('#linkSearch').addEventListener('submit', (ev) => { ev.preventDefault(); $('#linkQ').blur(); });
  $('#linkQ').addEventListener('input', debounce(() => {
    const q = $('#linkQ').value.trim();
    const nums = q ? core.search(S.index, q, 30) : [];
    $('#linkResults').innerHTML = nums.length
      ? `<div class="list">${nums.map((n) => itemRow(n, { attr: 'data-link' })).join('')}</div>`
      : q ? `<p class="empty">Nema artikla „${esc(q)}“.</p>` : '';
  }, 90));
  $('#missingBody').onclick = (ev) => {
    const t = ev.target.closest('[data-link],[data-link-sf]');
    if (t && t.dataset.link) link(t.dataset.link);
    else if (t && t.dataset.linkSf) linkSf(t.dataset.linkSf);
  };

  // StoreFront: the same barcode, asked where the store system itself knows it
  const box = $('#storeBox');
  const say = (t, cls = '') => { box.innerHTML = `<p class="store-msg ${cls}">${t}</p>`; };
  const storeLine = (x) => {
    const bits = [x.stock ? `Zaliha u prodavnici: ${esc(x.stock)}` : '', x.price ? esc(x.price) : ''].filter(Boolean);
    return `${x.st ? `<span class="pills">${stPill(x.st)}</span>` : ''}${bits.length ? `<span class="store-line">${bits.join(' · ')}</span>` : ''}`;
  };
  S.storeCb = (r) => {
    S.storeLast = r; // shown again when a planogram came from here (the article may be in it now)
    // 2.04: StoreFront's answer can arrive after the employee left this screen (log 16.11.: TypeError at this line, 4x)
    const hint = $('.store-hint');
    if (!hint || !box.isConnected) return;
    hint.hidden = r.how === 'ok' && (r.results || []).length > 0;
    if (r.how === 'cancelled' || r.how === 'bad') { box.innerHTML = ''; return; }
    if (r.how === 'timeout') { say('StoreFront nije odgovorio na vrijeme. Provjeri vezu i pokušaj ponovo.', 'is-bad'); return; }
    const res = (r.results || []).slice(0, 3);
    // 1.96 (owner): a barcode that was read but has no confirmed article says exactly that (the 2-year rule of
    // StoreFront 6.9.0 is not something we can see from here)
    if (!res.length) { say('Barkod je očitan. Veza s artiklom nije pronađena. Upiši šifru s etikete.', 'is-bad'); return; }
    // StoreFront's master data has exactly this barcode on one article: link it and open it, also when it is in no
    // planogram on the phone (1.96, VIDAR)
    if (res.length === 1 && top().id === 'missing' && r.via === 'task') { if (S.index.byNum.has(res[0].num)) link(res[0].num); else linkSf(res[0].num); return; }
    if (res.length === 1 && S.index.byNum.has(res[0].num) && top().id === 'missing') { link(res[0].num); return; }
    S.user.store = { ok: true };
    saveUser();
    const rows = res.map((x, i) => {
      const lead = i === 0 && res.length > 1 ? '<span class="pill">Najbolji pogodak</span>' : '';
      if (S.index.byNum.has(x.num)) return itemRow(x.num, { attr: 'data-link', sub: `${lead ? `<span class="pills">${lead}</span>` : ''}${storeLine(x)}` });
      return `<div class="item item-static">${sfThumb(x.num)}<span class="item-main"><span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.name) || 'Bez naziva'}</span><span class="pills"><span class="pill pill-muted">Nije u tvojim planogramima</span>${ordersOf(x.num).length ? '<span class="pill pill-order">Naručio kupac</span>' : ''}</span>${storeLine(x)}${planServerBtn ? planServerBtn(x.num) : ''}${planGet ? planGet.slot(x.num) : ''}<button class="link" type="button" data-link-sf="${esc(x.num)}">Poveži s ovim artiklom</button></span></div>`;
    });
    const ord = res.map((x, i) => (ordersOf(x.num).length
      ? ordersBlock(x.num, { label: `${x.num} ${x.name || ''}`.trim() })
      : i === 0 ? ordersBlock(x.num, { after: true }) : '')).join('');
    box.innerHTML = `${ord}<p class="store-msg">Dodirni pravi artikal i barkod ${esc(code)} se povezuje s njim.</p><div class="list">${rows.join('')}</div>`;
    if (planGet) planGet.fill(box);
    if (r.via === 'task') {
      box.insertAdjacentHTML('beforeend', `<div class="stock-box" data-stock="${esc(res[0].num)}">${stockHtml(res[0].num)}</div>`);
      stockLoad(res[0].num);
    }
  };
  // asked in the background with every status code (StoreFront's own search page leaves 81 out); its page only
  // when it wants a sign-in, or on an older version of the app
  const askStore = () => {
    say('Tražim u StoreFrontu…');
    const ok = stCall({ mode: 'find', code }, (r) => {
      const t = top();
      if (t.id !== 'missing' || t.state !== code) return;
      if (r.how === 'login') { say(failWhy(r), 'is-bad'); A.storefront(code, 'lookup'); return; }
      if (r.how !== 'ok') { say(failWhy(r), 'is-bad'); return; }
      const list = (r.res && r.res.list) || [];
      // 2.05: StoreFront's exact barcode search found exactly this one article: a link made from it is shared as "sf"
      S.sfExact = r.res && r.res.via === 1 && list.length === 1 ? { code, num: list[0].num } : null;
      // 2.04: what StoreFront gave, to tell "StoreFront does not know this barcode" from "the app missed it"
      { const q = r.res || {}; note(`barkod: StoreFront tačno po barkodu ${q.exact != null ? +q.exact : '–'}${q.via === 1 ? '' : `, labava pretraga ${+q.rows || 0} redova (ukupno ${+q.total || 0}), provjereno ${+q.checked || 0}`}, s ovim barkodom ${list.length}${q.via ? ` (pretraga ${q.via})` : ''}`); }
      S.storeCb({ how: 'ok', via: 'task', results: list.map((x) => ({ num: x.num, name: x.name, st: x.st, stock: `${whole(x.stock)} ${(x.unit || '').toLowerCase()}`.trim(), price: Number.isFinite(x.price) ? `${money(x.price)} KM` : '' })) });
    });
    if (!ok) A.storefront(code, 'lookup');
  };
  $('#storeGo').addEventListener("click", askStore);
  // after the first successful answer every unknown barcode is asked there without a tap
  if (cfg().auto && ((S.user.store && S.user.store.ok) || A.storeTask) && !S.tried.has(code)) { S.tried.add(code); askStore(); }
}

function openMissing(code, opts = {}) {
  renderMissing(code);
  go('missing', code, opts);
}


  return { openMissing, renderMissing };
}
