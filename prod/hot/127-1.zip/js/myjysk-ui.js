// MYJYSK: reading tasks and news (the 8:00 job of the phone too), who the employee is, what is new.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createMyjyskUi(ctx) {
  const { $, A, MJ_FILE, S, arLoad, ask, back, cfg, closeSheet, esc, icon, impItems, mjOn, news, openSheet, plural, renderHome, renderNews, renderSettings, saveUser, setMode, startPlanDownload, store, toast, top } = ctx;

const mjMe = () => {
  const c = cfg().mjMe;
  if (c != null) return c;
  try { return (A.myjyskMe && A.myjyskMe()) || ''; } catch (e) { return ''; }
};
const syncMyjysk = (ask) => { try { if (mjOn() && A.myjyskDaily) A.myjyskDaily(!!cfg().mj, !!ask); } catch (e) { /* older shell */ } };

/** Something new for the employee since he last looked at Vijesti (a red dot on the tab). */
function newsWaiting() {
  const st = S.user.mj;
  if (!st || !st.at) return false;
  return news.myTasks(st, mjMe()).some((t) => news.isNew(st, t.id)) || st.news.some((a) => news.isNew(st, a.id)) || impItems(st).some((x) => x.fresh);
}

function seenNews() {
  if (!S.user.mj) return;
  S.user.mj.viewedAt = Date.now();
  saveUser();
}

function takeMyjysk(r) {
  if (!r || r.how !== 'ok' || !r.data) return false;
  const at = +r.at || Date.now();
  if (S.user.mj && S.user.mj.at >= at) return false;
  S.user.mj = news.merge(S.user.mj, r.data, at);
  saveUser();
  return true;
}

/** What the 8:00 job read while the app was closed. */
function pickupMyjysk() {
  if (!mjOn()) return;
  const r = store.read(MJ_FILE, null);
  if (!r) return;
  if (r.how === 'login' && (!S.user.mj || !S.user.mj.at || r.at > S.user.mj.at)) {
    if (S.user.mj) { S.user.mj.login = true; saveUser(); }
    else S.user.mj = { at: 0, my: [], loc: [], news: [], sys: [], seen: {}, login: true };
  }
  takeMyjysk(r);
}

/** Reads again when the kept data is from before this morning's 8:00. */
function freshenMyjysk() {
  const st = S.user.mj;
  if (!st || !st.at || st.at < news.lastMorning(Date.now())) refreshMyjysk(false);
}

function refreshMyjysk(visible) {
  if (!mjOn()) return false;
  if (S.mj.busy && !visible) return true; // caller will receive existing onMyjysk response
  // Android WebView can report navigator.onLine=false even when StoreFront works.
  // Let the real MYJYSK request determine connectivity, rather than blocking it.
  S.mj.err = '';
  S.mj.busy = !visible;
  try { A.myjysk(!!visible); }
  catch (e) {
    S.mj.busy = false;
    toast('Ova verzija aplikacije ne zna čitati MYJYSK.');
    return false;
  }
  if (S.mode === 'news') renderNews();
  return true;
}

window.onMyjysk = (r) => {
  S.mj.busy = false;
  const after = S.mj.after;
  if (after === 'plans' && r && r.how !== 'login') S.mj.after = null;
  S.mj.err = r && r.how === 'error' ? (navigator.onLine ? 'error' : 'offline') : r && r.how === 'login' ? 'login' : '';
  if (r && r.how === 'ok') {
    takeMyjysk(r);
    store.write(MJ_FILE, { how: 'ok', at: +r.at || Date.now(), data: r.data });
  } else if (r && r.how === 'login') {
    if (!S.user.mj) S.user.mj = { at: 0, my: [], loc: [], news: [], sys: [], seen: {} };
    S.user.mj.login = true;
    saveUser();
  } else if (r && r.how === 'error') {
    toast(navigator.onLine ? 'MYJYSK nije odgovorio (greška na njihovoj strani). Ranije učitano ostaje.' : 'Nema internet veze. Ranije učitano ostaje.');
  }
  renderHome();
  if ($('#settings').classList.contains('is-active')) renderSettings();
  if (S.ar.after && r && r.how !== 'cancelled') { S.ar.after = false; if (r.how === 'ok' && top().id === 'ar') arLoad(); }
  if (after === 'plans') {
    if (r && r.how === 'ok') startPlanDownload();
    else if (r && r.how === 'login') {
      openSheet({ title: 'Prijavi se u MYJYSK', body: '<p>Za provjeru planograma treba prijava u MYJYSK. Poslije prijave provjera ide dalje sama.</p>',
        actions: [{ label: 'Prijavi se', kind: 'btn-primary', onClick: () => { closeSheet(); refreshMyjysk(true); } }, { label: 'Odustani', kind: 'btn-quiet', onClick: () => { S.mj.after = null; closeSheet(); } }] });
    } else { closeSheet(); if (!r || r.how !== 'cancelled') toast('MYJYSK nije odgovorio, provjera planograma nije urađena.'); }
  }
};

window.openNews = () => {
  while (S.stack.length > 1) back();
  setMode('news');
};


function taskRow(st, t, { role = false } = {}) {
  const d = news.due(t.end, Date.now());
  const meta = [d.date ? `rok ${d.date}${t.time && t.time !== '00:00' ? ` u ${t.time}` : ''}` : '', role && t.role ? t.role : '', t.eff ? `${t.eff} min` : ''].filter(Boolean).join(' · ');
  return `<button class="mj-row" type="button" ${t.path ? `data-mj-open="${esc(t.path)}"` : 'disabled'}>
    <span class="mj-main"><span class="mj-title">${news.isNew(st, t.id) ? '<span class="mj-new">NOVO</span>' : ''}${esc(t.title)}</span>${meta ? `<span class="mj-meta">${esc(meta)}</span>` : ''}</span>
    ${d.left ? `<span class="mj-due ${d.cls}">${esc(d.left)}</span>` : ''}${t.path ? icon('chev', 'chev') : ''}
  </button>`;
}

function newsRow(st, a) {
  const open = S.mj.open.has(a.id);
  const meta = [a.kb, a.by, news.dayText(a.at), a.att ? `${a.att} ${plural(a.att, 'prilog', 'priloga', 'priloga')}` : ''].filter(Boolean).join(' · ');
  return `<div class="mj-news"><button class="mj-row" type="button" data-mj-x="${esc(a.id)}" aria-expanded="${open}">
    <span class="mj-main"><span class="mj-title">${news.isNew(st, a.id) ? '<span class="mj-new">NOVO</span>' : ''}${esc(a.title)}</span><span class="mj-meta">${esc(meta)}</span></span>
  </button>${open ? `<div class="mj-text">${esc(a.text) || 'Bez teksta u pregledu.'}${a.path ? `<br><button class="text-btn" type="button" data-mj-open="${esc(a.path)}">Otvori vijest</button>` : ''}</div>` : ''}</div>`;
}


  return { freshenMyjysk, mjMe, newsRow, newsWaiting, pickupMyjysk, refreshMyjysk, seenNews, syncMyjysk, taskRow };
}
