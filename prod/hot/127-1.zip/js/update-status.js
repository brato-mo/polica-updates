/**
 * Error summaries for the update settings view.
 * Never render free-form exceptions: network errors may embed corporate URLs
 * or query parameters. The native log stays on the device.
 */
export function updateErrorText(msg) {
  const reason = String(msg || '');
  // 1.74: the channel's version.json is meant for the other app (TEST vs the real one): refused before any download
  if (/drugi paket|drugi kanal/i.test(reason)) return 'Kanal ažuriranja nudi drugu aplikaciju (TEST ili pravu). Ništa nije preuzeto.';
  if (/drugi potpisni ključ/i.test(reason)) return 'Kanal ažuriranja nudi verziju potpisanu drugim ključem. Ništa nije preuzeto.';
  if (/nema dovoljno prostora/i.test(reason)) return 'Na telefonu nema dovoljno slobodnog prostora za ažuriranje. Oslobodi prostor pa pokušaj ponovo.';
  if (/potpis instalirane aplikacije/i.test(reason)) return 'Potpis instalirane aplikacije nije pročitan, pa ažuriranje nije provjereno. Ništa nije preuzeto.';
  if (/neispravan version\.json/i.test(reason)) return 'Opis nove verzije na serveru nije ispravan. Ništa nije preuzeto.';
  if (/HTTP\s*(401|403|404)\b/i.test(reason)) return 'Server ažuriranja nije dostupan ili još nema verzije za ovaj kanal. Pokušaj kasnije.';
  if (/HTTP\s*5\d{2}\b/i.test(reason)) return 'Server ažuriranja trenutno ne odgovara. Pokušaj ponovo kasnije.';
  if (/kontrolna suma|potpisana istim ključem|veličina ne odgovara|veći od očekivanog|nije https/i.test(reason)) return 'Preuzeti APK nije prošao sigurnosnu provjeru. Neće biti instaliran.';
  if (/timeout|timed out|connection|network|host|internet|reset|refused|unreachable/i.test(reason)) return 'Ne mogu pristupiti serveru za ažuriranje. Provjeri internetsku vezu.';
  return 'Provjera nije uspjela. Pokušaj ponovo iz Postavki.';
}

/** 1.75: why Android did not install the downloaded update (UpdateReceiver.why), in words. */
export function installResultText(why) {
  switch (String(why || '')) {
    case 'aborted': return 'Instalacija je otkazana. Verzija je preuzeta, možeš je instalirati kasnije.';
    case 'storage': return 'Nema dovoljno slobodnog prostora za instalaciju. Oslobodi prostor pa tapni „Instaliraj“.';
    case 'blocked': return 'Telefon je blokirao instalaciju (pravila uređaja ili zaštita). Aplikacija nije promijenjena.';
    case 'conflict': return 'Android je odbio instalaciju: verzija se ne slaže s instaliranom aplikacijom. Aplikacija nije promijenjena.';
    case 'incompatible': return 'Ova verzija nije za ovaj telefon. Aplikacija nije promijenjena.';
    case 'invalid': return 'Android je odbio preuzetu datoteku kao neispravnu. Aplikacija nije promijenjena.';
    default: return 'Instalacija nije izvršena. Aplikacija nije promijenjena.';
  }
}
