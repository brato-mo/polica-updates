// 1.73-test4 (from the store: "kad otvorim artikal i piše Nije u tvojim planogramima, da mogu preuzeti taj planogram"):
// an article that is in no planogram on the phone gets, next to it, its department's planogram from MYJYSK. StoreFront
// says the article's group (50113 is 5|01|13: department 05 Homeware), MYJYSK's list for the store's side says which
// planograms are that department's; a tap downloads the ones not on the phone with a blue progress in the button
// (percent), reads them at once and the article screen shows where the article is. Nothing is downloaded on its own.

/**
 * StoreFront's group of an article -> its department ("05"). The departments are StoreFront's top groups 1..11 and
 * every level below has two digits: 50113 is 5|01|13 (05), 405 is 4|05 (04), 100113 is 10|01|13 (10).
 */
export function deptOfGroup(g) {
  const s = String(g == null ? '' : g).trim();
  if (!/^\d{1,8}$/.test(s)) return '';
  const d = +s.slice(0, s.length % 2 ? 1 : 2);
  return d > 0 ? String(d).padStart(2, '0') : '';
}

/**
 * 1.75: the department of a group according to StoreFront's own list of departments and their groups (S.user.hier,
 * read from StoreFront): the one department whose own id is the group or one of whose groups is the group or its
 * beginning. null: no list on the phone (cannot say); '': the list does not place the group in exactly one department.
 */
export function deptInHier(g, hier) {
  const s = String(g == null ? '' : g).trim();
  const roots = hier && Array.isArray(hier.groups) ? hier.groups : null;
  if (!roots || !roots.length) return null;
  if (!/^\d{1,8}$/.test(s)) return '';
  const hit = roots.filter((r) => String(r.id) === s
    || (r.subs || []).some((x) => String(x.id) === s || (String(x.id).length > String(r.id).length && s.startsWith(String(x.id)))));
  if (hit.length !== 1) return '';
  const d = +hit[0].id;
  return d > 0 && d < 100 ? String(d).padStart(2, '0') : '';
}

/**
 * The department a planogram may be offered for: only when StoreFront's list and the shape of the group number say
 * the same. { dept, sure: true } | { dept: '', sure: false, why: 'nolist' | 'unplaced' }.
 */
export function confirmedDept(g, hier) {
  const byList = deptInHier(g, hier), byShape = deptOfGroup(g);
  if (byList === null) return { dept: '', sure: false, why: 'nolist' };
  if (byList && byList === byShape) return { dept: byList, sure: true };
  return { dept: '', sure: false, why: 'unplaced' };
}

export function createPlanGet({ S, esc, stCall, news, planList, planOnPhone, startPlanDownload, cancel, busy, refreshList, loadDepts, toast, onReady }) {
  const groupOf = new Map(); // article -> its StoreFront group ('' StoreFront did not say, null no answer: asked again)
  let running = null; // { num, dept, keys, frac, line, reading }
  let listWait = 0; // MYJYSK's list being read after a tap on "Učitaj spisak planograma"
  let deptsWait = false, deptsTried = false; // StoreFront's list of departments being read (once by itself, then on a tap)
  function readDepts() {
    if (deptsWait) return;
    deptsWait = true;
    const ok = loadDepts(() => { deptsWait = false; redraw(); });
    if (!ok) deptsWait = false;
    redraw();
  }

  /** The placeholder in an article row; filled by fill() when the department is known. */
  const slot = (num) => `<div class="pl-get" data-plget="${esc(num)}"></div>`;

  const links = (dept) => planList().filter((p) => news.deptNo(p.dept) === dept);
  const msg = (t) => `<span class="pl-get-msg">${t}</span>`;

  function render(box) {
    const num = box.dataset.plget;
    const g = groupOf.get(num);
    if (g === undefined) { box.innerHTML = msg('<i class="mj-busy"></i> Tražim planogram odjela…'); return; }
    if (g === null) { box.innerHTML = msg('StoreFront nije odgovorio, pa ne znam odjel ovog artikla.'); return; }
    if (!g) { box.innerHTML = msg('StoreFront nije rekao odjel ovog artikla.'); return; }
    // 1.75: a planogram is offered only for a department StoreFront's own list of departments confirms
    const c = confirmedDept(g, S.user && S.user.hier);
    if (!c.sure) {
      if (c.why === 'nolist' && deptsWait) { box.innerHTML = msg('<i class="mj-busy"></i> Čitam odjele iz StoreFronta…'); return; }
      box.innerHTML = c.why === 'nolist'
        ? `${msg('Odjel ovog artikla nije potvrđen: spisak odjela iz StoreFronta nije na telefonu.')}<button class="pl-get-x" type="button" data-plget-depts="1">Učitaj odjele</button>`
        : msg(`Odjel ovog artikla nije potvrđen (StoreFront grupa ${esc(g)}), pa ne nudim planogram.`);
      return;
    }
    const dept = c.dept;
    const name = news.deptName(dept) || dept; // "05 Kućanstvo"
    if (running && running.dept === dept) {
      const pct = Math.max(1, Math.min(100, Math.round((running.frac || 0) * 100)));
      box.innerHTML = `<button class="pl-get-btn is-busy" type="button" disabled style="--p:${pct}%"><span>${running.reading ? 'Čitam planogram…' : `Preuzimam ${pct} %`}</span><i class="bar"></i></button>
        ${running.reading ? '' : `${msg(esc(running.line || ''))}<button class="pl-get-x" type="button" data-plget-cancel="1">Prekini</button>`}`;
      return;
    }
    if (!planList().length) {
      if (listWait) { box.innerHTML = msg('<i class="mj-busy"></i> Čitam spisak planograma iz MYJYSK-a…'); return; }
      box.innerHTML = `<button class="pl-get-btn" type="button" data-plget-list="1"><span>Učitaj spisak planograma</span></button>
        ${msg('Spisak planograma iz MYJYSK-a još nije na telefonu.')}`;
      return;
    }
    const l = links(dept);
    if (!l.length) { box.innerHTML = msg(`MYJYSK nema planogram odjela ${esc(name)} za tvoju stranu trgovine.`); return; }
    const need = l.filter((p) => !planOnPhone(p));
    if (!need.length) {
      box.innerHTML = msg(l.length === 1 ? `Nije ni na planogramu odjela ${esc(name)} (on je na telefonu).` : `Nije ni na planogramima odjela ${esc(name)} (svi su na telefonu).`);
      return;
    }
    box.innerHTML = `<button class="pl-get-btn" type="button" data-plget-go="${esc(dept)}" data-plget-num="${esc(num)}"><span>${need.length === 1 ? `Preuzmi planogram ${esc(name)}` : `Preuzmi planograme ${esc(name)} (${need.length})`}</span><i class="bar"></i></button>`;
  }
  function redraw() { for (const b of document.querySelectorAll('[data-plget]')) render(b); }
  function fill(root) {
    for (const box of root.querySelectorAll('[data-plget]')) {
      const num = box.dataset.plget;
      render(box);
      if ((groupOf.has(num) && groupOf.get(num) !== null) || box.dataset.asked) continue;
      box.dataset.asked = '1';
      groupOf.delete(num);
      render(box);
      // the article's group comes with its stock (master data, read only, one request)
      const ok = stCall({ mode: 'stockbatch', nums: [num], bg: true }, (r) => {
        const x = r && r.how === 'ok' && r.res && (r.res.list || []).find((y) => String(y.num) === num);
        groupOf.set(num, x ? String(x.group || '') : r && r.how === 'ok' ? '' : null);
        // no list of departments on the phone yet: read once by itself (one read-only request), later only on a tap
        if (x && x.group && !(S.user && S.user.hier && (S.user.hier.groups || []).length) && !deptsTried) { deptsTried = true; readDepts(); }
        for (const b of document.querySelectorAll(`[data-plget="${num}"]`)) render(b);
      });
      if (!ok) { groupOf.set(num, null); render(box); }
    }
  }

  function go(dept, num) {
    const keys = links(dept).filter((p) => !planOnPhone(p)).map((p) => p.key);
    if (!keys.length) { redraw(); return; }
    running = { num, dept, keys, frac: 0.01, line: '', reading: false };
    redraw();
    const end = () => { running = null; redraw(); };
    const started = startPlanDownload({
      only: keys, force: true, quiet: true,
      // frac null: the server has said nothing for a while (the line says so); the bar stays where it was
      onProgress: (frac, line) => { if (!running) return; if (frac != null) running.frac = frac; running.line = line || ''; redraw(); },
      done: (r) => {
        if (r.importing) { if (running) { running.frac = 1; running.reading = true; } redraw(); return; }
        end();
        if (r.cancelled) { /* "Provjera planograma prekinuta." comes from the cancel itself */ }
        else if (r.login) { /* the sign-in sheet says what to do; after it the same download goes on */ }
        else if (r.error || r.errors) toast('Planogram nije preuzet. Pokušaj ponovo.');
        else if (r.none) toast('MYJYSK nema taj planogram za tvoju stranu trgovine.');
        else onReady(num); // the same file as on the phone: show the article as it is
      },
      after: () => { end(); onReady(num); },
    });
    if (!started) end();
  }

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-plget-cancel]')) { cancel(); return; }
    if (e.target.closest('[data-plget-depts]')) { readDepts(); return; }
    if (e.target.closest('[data-plget-list]')) {
      if (!refreshList()) { toast('MYJYSK je isključen u postavkama, pa ne znam planograme odjela.'); return; }
      listWait = Date.now();
      redraw();
      const tick = () => {
        if (S.mj && S.mj.busy && Date.now() - listWait < 90000) { setTimeout(tick, 1000); return; }
        listWait = 0;
        if (!planList().length) toast('Spisak planograma nije učitan. Provjeri prijavu u MYJYSK (Vijesti).');
        redraw();
      };
      setTimeout(tick, 1000);
      return;
    }
    const t = e.target.closest('[data-plget-go]');
    if (!t) return;
    if (busy() || running) { toast('Planogrami se već preuzimaju.'); return; }
    go(t.dataset.plgetGo, t.dataset.plgetNum);
  });
  return { slot, fill, redraw };
}
