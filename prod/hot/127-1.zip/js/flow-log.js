// 1.97 (owner, 14. 11. 2026): Postavke → Privatnost i dijagnostika → Pregledaj dijagnostiku says, for what the
// employee started: which action, where it stopped, whether StoreFront already made the change, what to do next.
// One action = one flow with a short local mark (#a3f); each step: time, module, action, step, wait in the queue,
// request time, tries, outcome (closed list), a technical reason (closed words or Error class @ file:line).
// Stays on the phone (flow-log.json). Repeats are grouped (first, last, count). A flow that never ended when the app
// was closed comes back as "prekinuto". The text to share has no names, phones, receipt numbers, messages, list
// names, keys, tokens or raw answers: only these fields.

export const MOD = { scan: 'Skener', plan: 'Planogram', stock: 'Zalihe', refill: 'Punjenje', minus: 'Minus lista', reg: 'Regulacija',
  smdm: 'SM/DM', orders: 'Narudžbe', oopus: 'OOPUS', sync: 'Sinhronizacija', app: 'Aplikacija', sf: 'StoreFront' };
export const OUT = {
  ok: 'uspjelo', started: 'započeto', sent: 'zahtjev poslan', waiting: 'čeka', network: 'veza prekinuta', login: 'prijava istekla',
  timeout: 'isteklo vrijeme', rejected: 'upis odbijen', bad_response: 'neispravan odgovor', incomplete: 'nepotpuni podaci',
  colleague: 'kolega je promijenio', app_error: 'greška aplikacije', cancelled: 'otkazao korisnik', unsure: 'ishod nejasan',
  not_found: 'nije pronađeno', not_read: 'kamera nije pročitala barkod', interrupted: 'prekinuto (aplikacija zatvorena)', held: 'zadržano',
};
const BAD = new Set(['network', 'login', 'timeout', 'rejected', 'bad_response', 'incomplete', 'colleague', 'app_error', 'unsure', 'interrupted', 'held']);
export const isBad = (out) => BAD.has(out);

/** A technical reason safe to keep and share: closed words, or "TypeError @ app.js:1234". Never content. */
export function cleanWhy(v) {
  let t = String(v == null ? '' : v);
  t = t.replace(/https?:\/\/[^\s)]+\/([A-Za-z0-9_.-]+\.(?:js|java|mjs))/g, '$1') // a location keeps only the file name
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '…') // e-mail
    .replace(/\+?\d[\d\s/-]{8,}\d/g, '…') // phone-like, receipt-like long numbers
    .replace(/\b\d{6,}\b/g, '…') // article, order, list and other long numbers
    .replace(/(token|key|k|pass|password|auth|cookie)=\S+/gi, '$1=…')
    .replace(/[^A-Za-z0-9ČĆŽŠĐčćžšđ _.:@/()+,=·…—„“-]/g, ' ').replace(/\s+/g, ' ').trim();
  return t.slice(0, 90);
}
/** An Error -> "TypeError: x is undefined @ refill-ui.js:212" (class, short message, file:line). */
export function errWhy(e, where = '') {
  if (!e) return cleanWhy(where);
  const cls = (e && e.name) || (typeof e === 'string' ? 'Error' : typeof e);
  const msg = e && e.message ? e.message : typeof e === 'string' ? e : '';
  const loc = where || ((e && e.stack ? String(e.stack).split('\n').find((l) => /\.(m?js|java):\d+/.test(l)) : '') || '');
  const m = /([A-Za-z0-9_.-]+\.(?:m?js|java)):(\d+)/.exec(loc);
  return cleanWhy(`${cls}: ${msg}`.slice(0, 60) + (m ? ` @ ${m[1]}:${m[2]}` : ''));
}

export function createFlowLog({ read, write, version = () => '', now = () => Date.now(), max = 400 } = {}) {
  let d;
  try { d = JSON.parse(read() || 'null'); } catch (e) { d = null; }
  if (!d || d.v !== 1 || !Array.isArray(d.e)) d = { v: 1, e: [], open: {}, done: null, broken: null };
  let seq = Math.floor(Math.random() * 46656);
  let timer = 0;
  const flush = () => { clearTimeout(timer); timer = 0; try { write(JSON.stringify(d)); } catch (e) { /* the log never breaks the app */ } };
  const later = () => { if (!timer) timer = setTimeout(flush, 800); };
  // flows that were open when the app went away: interrupted (shown, kept as the last interrupted flow)
  for (const [id, f] of Object.entries(d.open || {})) {
    push({ id, mod: f.mod, act: f.act, step: f.last || 'u toku', out: 'interrupted', why: f.lastOk ? `zadnje potvrđeno: ${f.lastOk}` : 'ništa potvrđeno' });
    d.broken = { id, mod: f.mod, act: f.act, at: now(), last: f.last || '', lastOk: f.lastOk || '' };
  }
  d.open = {};
  flush();

  function push(x) {
    const t = now();
    const e = { t, id: x.id || '', mod: x.mod || 'app', act: cleanWhy(x.act).slice(0, 40), step: cleanWhy(x.step).slice(0, 50), out: OUT[x.out] ? x.out : 'app_error',
      ...(Number.isFinite(x.q) && x.q >= 0 ? { q: Math.round(x.q) } : {}), ...(Number.isFinite(x.ms) && x.ms >= 0 ? { ms: Math.round(x.ms) } : {}),
      ...(Number.isFinite(x.tries) && x.tries > 1 ? { tries: x.tries } : {}), ...(x.why ? { why: cleanWhy(x.why) } : {}),
      ...(Number.isFinite(x.n) ? { n: x.n } : {}),
      // 21. 11. 2026: a StoreFront reading's time, split: a new page's start (pg) and StoreFront's requests (net)
      ...(Number.isFinite(x.pg) && x.pg >= 0 ? { pg: Math.round(x.pg) } : {}), ...(Number.isFinite(x.net) && x.net >= 0 ? { net: Math.round(x.net) } : {}),
      v: version() };
    // the same thing again within 10 minutes (a camera frame, a retried reading): one row, first/last/count
    const last = d.e[d.e.length - 1];
    if (last && last.mod === e.mod && last.act === e.act && last.step === e.step && last.out === e.out && (last.why || '') === (e.why || '') && t - (last.t2 || last.t) < 600000) {
      last.c = (last.c || 1) + 1; last.t2 = t;
      if (e.ms != null) last.ms = e.ms; if (e.q != null) last.q = e.q;
    } else {
      d.e.push(e);
      if (d.e.length > max) d.e.splice(0, d.e.length - max);
    }
    later();
    return e;
  }
  const mark = () => (++seq % 46656).toString(36).padStart(3, '0');
  /** A user's action: returns { id, step(step, out, extra), end(out, extra), done } */
  function start(mod, act, extra = {}) {
    const id = mark();
    d.open[id] = { mod, act, at: now(), last: '', lastOk: '' };
    push({ id, mod, act, step: extra.step || 'započeto', out: 'started', ...extra });
    const f = {
      id,
      step(step, out = 'ok', x = {}) {
        // the last step that is CONFIRMED (out ok), said when the action stops before its end
        if (d.open[id]) { d.open[id].last = step; if (out === 'ok') d.open[id].lastOk = step; }
        return push({ id, mod, act, step, out, ...x });
      },
      end(out = 'ok', x = {}) {
        const e = push({ id, mod, act, step: x.step || 'kraj', out, ...x });
        const o = d.open[id];
        delete d.open[id];
        if (isBad(out)) d.broken = { id, mod, act, at: now(), last: x.step || (o && o.last) || '', lastOk: o ? o.lastOk : '', out };
        else d.done = { id, mod, act, at: now(), out };
        later();
        return e;
      },
      // a flow that waits for something outside (the network, a sign-in): stays open, survives a restart as interrupted
      get open() { return !!d.open[id]; },
    };
    return f;
  }
  /** One step that is its own flow (a background reading, an error). */
  function one(mod, act, step, out, x = {}) {
    const id = mark();
    const e = push({ id, mod, act, step, out, ...x });
    if (isBad(out)) d.broken = { id, mod, act, at: now(), last: step, lastOk: '', out };
    else if (out === 'ok') d.done = { id, mod, act, at: now(), out };
    return e;
  }

  const two = (n) => String(n).padStart(2, '0');
  const hm = (t) => { const z = new Date(t); return `${two(z.getDate())}.${two(z.getMonth() + 1)}. ${two(z.getHours())}:${two(z.getMinutes())}:${two(z.getSeconds())}`; };
  /** One readable line: "17:34:35 · Punjenje · Brisanje liste · Zahtjev poslan · veza prekinuta · 512 ms · #a3f" */
  function line(e) {
    const bits = [hm(e.t), MOD[e.mod] || e.mod, e.act, e.step, OUT[e.out] || e.out];
    if (e.q != null && e.q >= 200) bits.push(`u redu ${e.q} ms`);
    if (e.ms != null) bits.push(`${e.ms} ms`);
    if (e.pg != null && e.pg >= 200) bits.push(`nova stranica ${e.pg} ms`);
    if (e.net != null) bits.push(`StoreFront ${e.net} ms`);
    if (e.tries) bits.push(`${e.tries}. pokušaj`);
    if (e.n != null) bits.push(`${e.n} kom`);
    if (e.why) bits.push(e.why);
    if (e.c > 1) bits.push(`${e.c}× (zadnji ${hm(e.t2)})`);
    return `${bits.filter(Boolean).join(' · ')}${e.id ? ` · #${e.id}` : ''}`;
  }
  function list(onlyErrors = false) { return d.e.filter((e) => !onlyErrors || isBad(e.out)).slice().reverse(); }
  /** The short text to send for analysis: version, last finished and last interrupted flow, errors grouped. */
  function summary() {
    const errs = new Map();
    for (const e of d.e) if (isBad(e.out)) {
      const k = `${e.mod}|${e.act}|${e.step}|${e.out}|${e.why || ''}`;
      const g = errs.get(k) || { e, n: 0, first: e.t, last: e.t2 || e.t };
      g.n += e.c || 1; g.last = Math.max(g.last, e.t2 || e.t); errs.set(k, g);
    }
    const out = [`JYSK Reloaded ${version()} · dijagnostika · ${hm(now())}`];
    if (d.done) out.push(`Zadnji dovršen tok: ${MOD[d.done.mod] || d.done.mod} · ${d.done.act} · ${OUT[d.done.out] || d.done.out} · ${hm(d.done.at)} · #${d.done.id}`);
    if (d.broken) out.push(`Zadnji prekinut tok: ${MOD[d.broken.mod] || d.broken.mod} · ${d.broken.act} · stalo na: ${d.broken.last || '?'} · zadnje potvrđeno: ${d.broken.lastOk || 'ništa'} · ${hm(d.broken.at)} · #${d.broken.id}`);
    const open = Object.entries(d.open);
    if (open.length) out.push(`U toku: ${open.map(([id, f]) => `${MOD[f.mod] || f.mod} · ${f.act} · ${f.last || 'započeto'} · #${id}`).join('; ')}`);
    if (errs.size) {
      out.push(`Greške (${errs.size} vrsta):`);
      for (const g of [...errs.values()].sort((a, b) => b.last - a.last).slice(0, 25)) {
        out.push(`- ${MOD[g.e.mod] || g.e.mod} · ${g.e.act} · ${g.e.step} · ${OUT[g.e.out]}${g.e.why ? ` · ${g.e.why}` : ''} · ${g.n}× · prvo ${hm(g.first)}, zadnje ${hm(g.last)}`);
      }
    } else out.push('Greške: nema zabilježenih.');
    return out.join('\n');
  }
  return { start, one, push, line, list, summary, flush, get data() { return d; } };
}
