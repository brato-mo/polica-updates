// Drawn parts of planograms kept as pictures (ImageBitmap), newest last, at most `keep`: a place shown again is drawn
// from here at once instead of from the PDF. A picture pushed out or forgotten is closed (its memory freed at once).
// 1.69. Nothing here knows about the screen: app.js decides the key and what is kept with the picture.

export function createCropCache(keep = 6) {
  const map = new Map(); // key -> { bmp, ...whatever the caller keeps }
  const free = (v) => { try { if (v && v.bmp && v.bmp.close) v.bmp.close(); } catch (e) { /* closed already */ } };
  return {
    get(key) {
      const hit = map.get(key);
      if (!hit) return null;
      map.delete(key);
      map.set(key, hit); // most recent last
      return hit;
    },
    has: (key) => map.has(key),
    put(key, entry) {
      const old = map.get(key);
      if (old && old !== entry) free(old);
      map.delete(key);
      map.set(key, entry);
      while (map.size > keep) {
        const [k, v] = map.entries().next().value;
        map.delete(k);
        free(v);
      }
    },
    clear() { for (const v of map.values()) free(v); map.clear(); },
    get size() { return map.size; },
  };
}
