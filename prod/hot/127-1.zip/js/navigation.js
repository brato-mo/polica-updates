// The screens of the app as a stack: [{ id, state, scroll }]. go() opens one on top, back() returns to the one below
// where the list was left. Taken out of app.js in 1.69 without changing what it does; what a screen does when it is
// shown again (draw itself anew) is the app's: onReturn(top) and onLeave(left).

export function createNav({ stack, $, $$, onLeave = () => {}, onReturn = () => {}, raf = (f) => requestAnimationFrame(f) }) {
  function show(id, how = 'enter') {
    for (const s of $$('.screen')) {
      const on = s.id === id;
      s.classList.toggle('is-active', on);
      s.classList.remove('enter', 'enter-back');
      if (on && how) { void s.offsetWidth; s.classList.add(how); }
    }
  }

  function top() { return stack[stack.length - 1]; }

  function go(id, state = null, { replace = false } = {}) {
    const t = top();
    // the list stays where it was: coming back, the screen below opens at the same place
    const below = $(`#${t.id} .scroll`);
    if (below) t.scroll = below.scrollTop;
    if (replace && t.id !== 'home') stack[stack.length - 1] = { id, state };
    else stack.push({ id, state });
    show(id, replace ? 'enter-back' : 'enter');
    const sc = $(`#${id} .scroll`);
    if (sc) sc.scrollTop = 0;
  }

  function back() {
    if (stack.length <= 1) return false;
    const left = stack.pop();
    onLeave(left);
    const t = top();
    show(t.id, 'enter-back');
    onReturn(t);
    const sc = $(`#${t.id} .scroll`);
    if (sc && t.scroll) { const y = t.scroll; sc.scrollTop = y; raf(() => { sc.scrollTop = y; }); }
    return true;
  }

  return { show, top, go, back };
}
