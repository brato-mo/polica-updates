// Najprodavanije (the department's best sellers) and Uskoro 21 (articles StoreFront says will be discontinued).
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.
// Uskoro 21 writes SM/DM through smJob (smdm-ui.js): StoreFront compares before every line.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createTopSoonUi(ctx) {
  const { $, A, S, ageText, ask, cfg, note, deptArg, deptChips, deptGroups, deptKey, deptName, deptNums, deptSig, dm, esc, go, icon, itemRow, money, plural, saveUser, sfThumb, smJob, stCall, toast, top, whole, withDept } = ctx;

// 1.77: Najprodavanije for any department of StoreFront's own product groups (or the whole store), for 7, 30 or 365
// days. 30 days: StoreFront's own count (quantitySoldInPeriod, one search, every article sold, pages of 100). 7 and
// 365 days: each article's stock history (net sales: 251 sold minus 252 returned; transfers, receipts, stocktaking
// and write-offs are not sales), read in small background jobs (30 articles, 4 requests at once) that a planogram
// page never waits behind for long, kept per store and article (7 days: 3 h, 365: 24 h). 7 days: every article sold
// in 30 days is a candidate (whatever sold in 7 days also sold in 30), so the ranking is exact, not only the 30-day
// top. 365 days: every article of the groups is a candidate; how far StoreFront's history really goes is measured
// (its oldest movement) and said; nothing is extrapolated. No turnover in KM: StoreFront has no past prices.
const TOPV = 'top-v2.json', SALES = 'sales-cache.json';
const T = { days: 7, scope: { kind: 'dept', id: '', title: '' }, sort: 'most', st: 'all', q: '', busy: '', prog: '', cancel: false, pick: false };
let topData = null, salesMap = null;
const topStore = () => (topData || (topData = (ctx.store && ctx.store.read(TOPV, null)) || { v: 1, sets: {} }));
const sales = () => {
  if (salesMap) return salesMap;
  salesMap = new Map();
  const d = ctx.store && ctx.store.read(SALES, null);
  if (d && d.v === 1) for (const [n, x] of Object.entries(d.s || {})) if (/^\d{7}$/.test(n) && x && Number.isFinite(x.at)) salesMap.set(n, x);
  salesMap.w = (d && d.w) || '';
  return salesMap;
};
let salesTimer = 0;
function saveSales() {
  clearTimeout(salesTimer);
  salesTimer = setTimeout(() => {
    const m = sales(), keep = [...m.entries()].filter(([, x]) => Date.now() - x.at < 3 * 86400000).sort((a, b) => b[1].at - a[1].at).slice(0, 6000);
    if (ctx.store) ctx.store.write(SALES, { v: 1, w: m.w || '', s: Object.fromEntries(keep) });
  }, 1500);
}
// Prijedlozi danas (tips-ui.js) reads the department's best sellers as before 1.77 (S.user.top)
function legacyTop(set) {
  if (!set || set.scope.kind !== 'dept') return;
  const l = set.list.filter((x) => x.sold30 > 0).sort((a, b) => b.sold30 - a.sold30).slice(0, 80);
  S.user.top = { dept: deptSig(), at: set.at, list: l.map((x) => ({ num: x.num, name: x.name, st: x.st, unit: x.unit, stock: x.stock, sold30: x.sold30, ...(typeof x.s7 === 'number' ? { sold7: x.s7 } : {}) })) };
  saveUser();
}
function saveTop() {
  const d = topStore();
  const keys = Object.keys(d.sets).sort((a, b) => d.sets[b].at - d.sets[a].at);
  for (const k of keys.slice(8)) delete d.sets[k];
  if (ctx.store) ctx.store.write(TOPV, d);
}
const scopeKey = () => `${T.scope.kind}:${T.scope.kind === 'dept' ? deptSig() : T.scope.id}`;
const setKey = () => `${scopeKey()}|${T.days}`;
const scopeTitle = () => (T.scope.kind === 'dept' ? `Moj odjel (${deptName()})` : T.scope.kind === 'store' ? 'Cijela poslovnica' : T.scope.title);
const dmy = (t) => { const d = new Date(t); return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}.`; };
const FRESH = { 7: 3 * 3600000, 365: 24 * 3600000 };
const soldOf = (x, days) => (days === 30 ? x.sold30 : days === 7 ? x.s7 : x.s365);

function renderTopBar() {
  const b = $('#topBar');
  if (!b) return;
  b.hidden = !S.plans.length || !A.storeTask;
  if (b.hidden) return;
  const last = Object.values(topStore().sets).sort((x, y) => y.at - x.at)[0];
  b.innerHTML = `${icon('chart')}<span><b>Najprodavanije</b><small>${last ? `${esc(last.title)} · ${last.days} dana · ${esc(ageText(last.at))}` : 'Bilo koji odjel · 7, 30 ili 365 dana, iz StoreFronta'}</small></span><span class="go">${last ? 'Otvori' : 'Učitaj'}</span>`;
}

function openTop() {
  go('top');
  renderTop();
  const set = topStore().sets[setKey()];
  if (!set || Date.now() - set.at > (T.days === 365 ? 24 : 6) * 3600000) loadTop();
  else if (set.phase && !set.complete) loadTop(true); // 1.78: an interrupted reading carries on (what was read stays)
}

function loadTop(resume = false) {
  if (T.busy) return;
  T.busy = 'cand';
  if (T.scope.kind === 'dept') withDept(() => loadTop2(resume)); else loadTop2(resume);
  renderTop();
}

function scopeArg() {
  if (T.scope.kind === 'dept') return { cat: cfg().group || '5', ...deptArg() };
  if (T.scope.kind === 'store') {
    const g = ((S.user.hier || {}).groups || []).map((x) => x.id).filter((x) => /^\d{1,8}$/.test(x));
    return { cat: g[0] || '5', cats: g.slice(0, 80) };
  }
  return { cat: T.scope.id, cats: [T.scope.id] };
}

// 1.78: the reading is a loop of small StoreFront jobs, one page (50 articles) or one history batch (30 articles) at a
// time; after every job the list is saved and shown, so a slow StoreFront never loses what was read (1.77 lost it all
// at the 2 min time-out of one big job), Prekini stops between two jobs and Nastavi carries on where it stopped.
//  - candidates: StoreFront's search sorted by sold in 30 days ('sold' pages), for 365 days then every other article
//    of the scope ('any' pages)
//  - 30 days: StoreFront's order is the ranking: the first TOP30 sold articles are read, then it stops
//  - 7 days: the 7-day sales of an article are at most its 30-day sales; candidates come in falling 30-day order, so
//    once K articles sold at least as much in 7 days as the next candidate sold in 30, no later one can enter the
//    first K: the reading stops with an exact ranking of the first K
//  - 365 days: no such bound; the articles that sell now are read first (a useful ranking early), then the rest;
//    the ranking says it is not final until every article of the scope is read
// A page that times out is asked again once at half the size (down to 25), then the reading stops (partial, Nastavi).
const PAGE = 50, MINPAGE = 25, TOP30 = 200, EXACT = 50;
// StoreFront pages by offset; many articles have the same sales, and an order that changes between two requests could
// push an article over a page edge unseen. Each page therefore starts OVERLAP rows before the end of the last one
// (repeats are dropped), and a 365-day reading is final only when it has every article StoreFront counts.
const OVERLAP = 5;
function freshFor(days) { return FRESH[days] || FRESH[7]; }
function needHist(set) {
  if (set.days === 30) return [];
  const m = sales(), fresh = freshFor(set.days), bad = new Set(set.bad || []);
  return set.list.filter((x) => { const h = m.get(x.num); return (!h || Date.now() - h.at >= fresh) && !bad.has(x.num); }).map((x) => x.num);
}
function applySales(set) {
  if (set.days === 30) { set.done = set.list.length; return; }
  const m = sales(), fresh = freshFor(set.days);
  let done = 0;
  for (const x of set.list) {
    const h = m.get(x.num);
    if (h && Date.now() - h.at < fresh) { x.s7 = h.s7; x.s365 = h.s365; x.oldest = h.oldest; done++; }
  }
  set.done = done;
  const olds = set.list.map((x) => x.oldest).filter((t) => t > 0);
  set.cov = olds.length ? Math.min(...olds) : 0;
}
/** 7 days: the first EXACT can no longer change (see above). */
function exact7(set) {
  if (set.days !== 7 || needHist(set).length) return false;
  const s7 = set.list.map((x) => x.s7 || 0).filter((v) => v > 0).sort((a, b) => b - a);
  return s7.length >= EXACT && s7[EXACT - 1] >= (set.bound || 0);
}
function newSet() {
  return { at: Date.now(), days: T.days, title: scopeTitle(), scope: { ...T.scope }, store: '', list: [], phase: 'sold', next: 0, size: PAGE,
    total: 0, totalAny: 0, bound: Infinity, done: 0, failed: 0, complete: false, final: false, pages: 0, ms: 0 };
}

function loadTop2(resume = false) {
  const key = setKey();
  let set = topStore().sets[key];
  if (!resume || !set || !set.phase || set.complete) { set = newSet(); topStore().sets[key] = set; }
  T.cancel = false;
  T.busy = 'cand';
  set.err = '';
  const t0 = Date.now();
  readLoop(set, key, t0);
}

function readLoop(set, key, t0) {
  const m = sales();
  const finish = (msg) => {
    T.busy = '';
    T.cancel = false;
    applySales(set);
    saveTop();
    legacyTop(set);
    if (msg && !T.after) toast(msg, 5000);
    if (T.after) { T.after = false; setTimeout(() => loadTop(true), 0); }
    note(`najprodavanije ${set.title} ${set.days} d: ${set.complete ? 'gotovo' : 'djelimično'}${set.final ? ' (poredak konačan)' : ''}, ${set.list.length} artikala, ${set.pages} stranica (${set.ms} ms StoreFront), historija ${set.done}, ${Date.now() - t0} ms${set.err ? ', ' + set.err : ''}`);
    renderTopBar();
    if (top().id === 'top') renderTop();
  };
  const step = () => {
    if (T.cancel || topStore().sets[key] !== set) { finish(''); return; }
    // a planogram on screen goes first: wait while it is open
    if (top().id === 'viewer') { setTimeout(step, 2000); return; }
    applySales(set);
    T.prog = set.days === 30 ? `${set.list.length}` : `${set.done}/${set.list.length}`;
    T.busy = 'cand';
    if (top().id === 'top') renderTop();
    saveTop();
    if (set.days === 7 && exact7(set)) { set.complete = true; set.final = true; finish(''); return; }
    if (set.days === 30 && set.list.length >= TOP30) { set.complete = true; set.final = true; finish(''); return; }
    const hist = needHist(set).slice(0, 30);
    if (hist.length) {
      T.busy = 'hist';
      const ok = stCall({ mode: 'sales', nums: hist, bg: true }, (r) => {
        if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
          if (r.res.store && m.w && m.w !== r.res.store) m.clear();
          if (r.res.store) m.w = r.res.store;
          const now = Date.now();
          for (const x of r.res.list) if (/^\d{7}$/.test(x.num)) m.set(x.num, { at: now, s7: +x.s7 || 0, s30: +x.s30 || 0, s365: +x.s365 || 0, oldest: +x.oldest || 0 });
          set.bad = [...(set.bad || []), ...(r.res.failed || []).map(String)];
          set.failed = set.bad.length;
          saveSales();
          setTimeout(step, 30);
        } else {
          set.err = r.how === 'login' ? 'prijava' : r.err || 'greška';
          finish(r.how === 'login' ? 'StoreFront traži prijavu: čitanje je zaustavljeno.' : 'Čitanje prodaje je prekinuto (mreža ili spor StoreFront). Prikazano je pročitano; Nastavi čita dalje.');
        }
      });
      if (!ok) finish('');
      return;
    }
    if (set.phase === 'done') { set.complete = true; set.final = !set.missing; finish(''); return; }
    const any = set.phase === 'any';
    const from = set.next > 0 ? Math.max(0, set.next - OVERLAP) : 0;
    const ok = stCall({ mode: 'top', ...scopeArg(), page: { start: from, max: set.size }, ...(any ? { any: true } : {}), bg: true }, (r) => {
      if (topStore().sets[key] !== set) return;
      if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
        if (r.res.store && m.w !== r.res.store) { m.clear(); m.w = r.res.store; }
        set.store = r.res.store || set.store;
        set.pages++;
        set.ms += +r.res.ms || 0;
        const seen = new Set(set.list.map((x) => x.num));
        for (const x of r.res.list) {
          if (!/^\d{7}$/.test(x.num) || seen.has(x.num)) continue;
          seen.add(x.num);
          set.list.push({ num: x.num, name: String(x.name || ''), st: String(x.st || ''), unit: String(x.unit || ''),
            stock: Number.isFinite(+x.stock) ? +x.stock : null, price: x.price != null && Number.isFinite(+x.price) ? +x.price : null, sold30: +x.sold30 || 0 });
        }
        const n = +r.res.n || 0;
        set.next = from + n;
        if (any) set.totalAny = +r.res.total || set.totalAny; else { set.total = +r.res.total || set.total; set.bound = +r.res.last || 0; }
        const end = n < set.size || set.next >= (+r.res.total || 0) || (!any && !(+r.res.last > 0));
        if (end) {
          if (!any && set.days === 365) { set.phase = 'any'; set.next = 0; set.bound = 0; set.anyPass = 1; }
          else if (any && set.list.length < set.totalAny && (set.anyPass || 1) < 2) { set.next = 0; set.anyPass = 2; } // a second pass for what slipped by
          else {
            set.phase = 'done';
            if (any && set.list.length < set.totalAny) set.missing = set.totalAny - set.list.length;
          }
        }
        if (!any && !(+r.res.last > 0)) set.bound = 0;
        setTimeout(step, 30);
      } else if (r.how !== 'login' && set.size > MINPAGE) {
        // a slow page: once more at half the size (StoreFront answers a smaller page sooner)
        set.size = Math.max(MINPAGE, Math.floor(set.size / 2));
        note(`najprodavanije: stranica od ${set.next} nije stigla (${r.err || r.how}), ponovo po ${set.size}`);
        setTimeout(step, 300);
      } else {
        set.err = r.how === 'login' ? 'prijava' : r.err || 'greška';
        finish(r.how === 'login' ? 'StoreFront traži prijavu. Prijavi se pa Nastavi.' : r.err === 'offline' ? 'Nema interneta: prikazano je pročitano; Nastavi čita dalje.' : 'StoreFront ne odgovara na vrijeme: prikazano je pročitano; Nastavi čita dalje.');
      }
    });
    if (!ok) finish('Ova verzija aplikacije to ne zna.');
  };
  step();
}

/** The list as shown: period, filters, sort, search. */
function topRows(set) {
  const d = set.days;
  let l = set.list.map((x) => ({ ...x, sold: soldOf(x, d) })).filter((x) => typeof x.sold === 'number');
  if (T.st === 'active') l = l.filter((x) => x.st !== '21' && x.st !== '81');
  if (T.st === 'out') l = l.filter((x) => x.st === '21' || x.st === '81');
  const q = T.q.trim().toLowerCase();
  if (q) l = l.filter((x) => x.num.includes(q) || x.name.toLowerCase().includes(q));
  const low = (x) => x.sold > 0 && x.stock != null && x.stock < (x.sold / d) * 14; // stock for less than two weeks of sales
  if (T.sort === 'least') l = l.filter((x) => x.sold > 0).sort((a, b) => a.sold - b.sold);
  else if (T.sort === 'low') l = l.filter(low).sort((a, b) => (a.stock + 1) / a.sold - (b.stock + 1) / b.sold);
  else if (T.sort === 'zero') l = l.filter((x) => x.sold > 0 && x.stock != null && x.stock <= 0).sort((a, b) => b.sold - a.sold);
  else l = l.filter((x) => x.sold > 0).sort((a, b) => b.sold - a.sold);
  return { rows: l, low };
}

function renderTop() {
  const box = $('#topBody');
  if (!box) return;
  const set = topStore().sets[setKey()];
  const per = `<div class="seg" role="tablist">${[7, 30, 365].map((n) => `<button class="seg-btn" type="button" role="tab" aria-selected="${T.days === n}" data-top-days="${n}">${n} dana</button>`).join('')}</div>`;
  const scopes = `<div class="chips top-scope">
    <button class="chip" type="button" data-top="scope-dept" aria-pressed="${T.scope.kind === 'dept'}">Moj odjel</button>
    <button class="chip" type="button" data-top="scope-pick" aria-pressed="${T.scope.kind === 'grp' || T.pick}">${T.scope.kind === 'grp' ? esc(T.scope.title) : 'Drugi odjel…'}</button>
    <button class="chip" type="button" data-top="scope-store" aria-pressed="${T.scope.kind === 'store'}">Cijela poslovnica</button></div>`;
  const picker = T.pick ? `<div class="top-pick">${ctx.pickerHtml(S.user.hier, esc, 'top', T.scope.kind === 'grp' ? T.scope.id : '')}</div>` : '';
  const cont = !T.busy && set && set.phase && !set.complete ? `<button class="text-btn" type="button" data-top="resume">${icon('arrow')}Nastavi</button>` : '';
  const head = `<div class="top-head">${per}${cont}<button class="text-btn" type="button" data-top="${T.busy ? 'cancel' : 'refresh'}">${icon(T.busy ? 'x' : 'refresh')}${T.busy ? 'Prekini' : 'Osvježi'}</button></div>${scopes}${picker}`;
  const busy = S.deptBusy ? '<p class="count-line"><i class="mj-busy"></i> Prvi put: tražim grupe proizvoda tvog odjela…</p>'
    : T.busy === 'cand' ? `<p class="count-line"><i class="mj-busy"></i> Čitam artikle iz StoreFronta${T.prog ? `: ${esc(T.prog)}` : '…'} (stranicu po stranicu; rezultati ispod se dopunjuju)</p>`
    : T.busy === 'hist' ? `<p class="count-line"><i class="mj-busy"></i> Čitam historiju prodaje: ${esc(T.prog)} artikala (u pozadini; planogram ima prednost)</p>` : '';
  if (!set) { box.innerHTML = `${head}${busy}${T.busy ? '' : '<p class="empty">Još nije učitano. Dodirni Osvježi.</p>'}`; return; }
  const { rows, low } = topRows(set);
  const all = set.list.map((x) => ({ ...x, sold: soldOf(x, set.days) })).filter((x) => typeof x.sold === 'number' && x.sold > 0);
  const now = set.at;
  // how far StoreFront's history goes (365): never more than it has
  const covDays = set.cov ? Math.floor((now - set.cov) / 86400000) : 0;
  const shortHist = set.days === 365 && set.done > 0 && covDays < 358;
  const from = shortHist ? set.cov : now - set.days * 86400000;
  const notes = [];
  // 1.78: final or not, said plainly
  if (set.phase && set.complete && set.missing) notes.push(`StoreFront je od ${set.totalAny} artikala odabira vratio ${set.totalAny - set.missing}: ${set.missing} nije pročitano, poredak zato nije potpun. Osvježi pokušava ponovo.`);
  if (set.phase && !set.complete) {
    const read = set.days === 365 && set.phase === 'any' ? `${set.next} od ${set.totalAny || '?'} artikala odabira` : `${set.list.length} artikala`;
    notes.push(`Djelimično: pročitano ${read}${set.days !== 30 ? `, prodaja za ${set.done}` : ''}${set.failed ? ` (${set.failed} bez odgovora)` : ''}. Poredak nije konačan${T.busy ? '' : ' – Nastavi čita dalje'}.`);
  } else if (set.phase && set.days === 7) notes.push(`Poredak prvih ${Math.min(EXACT, all.length)} je konačan: nijedan nepročitani artikal ne može ih prestići (prodaja za 7 dana nije veća od prodaje za 30).`);
  else if (set.phase && set.days === 30 && set.list.length >= TOP30) notes.push(`Prikazano prvih ${TOP30} najprodavanijih po StoreFrontu; sažetak se odnosi na njih.`);
  if (!set.phase && set.days !== 30 && set.done < set.list.length) notes.push(`Djelimično: prodaja pročitana za ${set.done} od ${set.list.length} artikala. Poredak nije konačan.`);
  if (set.limited) notes.push(`StoreFront je vratio ${set.cand} od ${set.total} artikala: lista ne pokriva cijeli izbor.`);
  if (shortHist) notes.push(`StoreFront historija ovdje seže samo do ${dmy(set.cov)} (${covDays} dana): prikazana je prodaja za taj period, ne za punih 365 dana.`);
  const src = set.days === 30 ? 'StoreFront: prodano u zadnjih 30 dana' : 'iz historije zaliha: prodano minus vraćeno od kupaca (bez transfera, inventure i otpisa)';
  const best = all.slice().sort((a, b) => b.sold - a.sold)[0];
  const sum = all.reduce((a, x) => a + x.sold, 0);
  const summary = `<div class="top-sum">
    <p><b>${esc(set.title)}</b> · ${set.days} dana: ${dmy(from)} – ${dmy(now)}</p>
    <p>${best ? `Najprodavaniji: <b>${esc(best.name || best.num)}</b> (${whole(best.sold)})` : 'Ništa prodano u tom periodu.'}</p>
    <p>${whole(sum)} prodanih komada · ${all.length} artikala s prodajom od ${set.list.length} analiziranih · ${all.filter(low).length} s niskom zalihom</p>
    <p class="top-src">${esc(src)} · osvježeno ${esc(ageText(now))}. Promet u KM se ne prikazuje: StoreFront nema historijske cijene.</p>
    ${notes.map((n) => `<p class="top-warn">${esc(n)}</p>`).join('')}</div>`;
  const tools = `<div class="top-tools"><input class="set-input" type="search" data-top-q placeholder="Traži u rezultatima" value="${esc(T.q)}" aria-label="Traži u rezultatima">
    <div class="chips">${[['most', 'Najviše'], ['least', 'Najmanje'], ['low', 'Prodaje se, malo zalihe'], ['zero', 'Nema na stanju']].map(([k, l]) => `<button class="chip" type="button" data-top-sort="${k}" aria-pressed="${T.sort === k}">${l}</button>`).join('')}</div>
    <div class="chips">${[['all', 'Svi statusi'], ['active', 'Aktivni'], ['out', 'Status 21/81']].map(([k, l]) => `<button class="chip" type="button" data-top-st="${k}" aria-pressed="${T.st === k}">${l}</button>`).join('')}</div></div>`;
  const list = rows.slice(0, 200).map((x, i) => {
    const sub = `<span class="top-sold"><b>${whole(x.sold)}</b> prodano · na stanju ${x.stock == null ? '?' : whole(x.stock)}${x.price != null ? ` · ${money(x.price)}` : ''}${x.st && x.st !== '11' ? ` · status ${esc(x.st)}` : ''}</span>`;
    const rank = `<span class="top-rank">${i + 1}</span>`;
    if (S.index.byNum.has(x.num)) return `<div class="top-row">${rank}${itemRow(x.num, { sub })}</div>`;
    return `<div class="top-row">${rank}<button class="item" type="button" data-top-sf="${esc(x.num)}">${sfThumb(x.num)}<span class="item-main"><span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.name)}</span><span class="pills"><span class="pill pill-muted">Nije u tvojim planogramima</span></span>${sub}</span></button></div>`;
  });
  box.innerHTML = `${head}${busy}${summary}${tools}${list.length ? `<div class="list">${list.join('')}</div>` : '<p class="empty">Nema artikala za ovaj izbor.</p>'}${rows.length > 200 ? `<p class="count-line">Prikazano prvih 200 od ${rows.length}.</p>` : ''}`;
  const qi = box.querySelector('[data-top-q]');
  if (qi) qi.addEventListener('input', () => { T.q = qi.value; const pos = qi.selectionStart; renderTop(); const n = $('#topBody [data-top-q]'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* type */ } } });
}

/** Clicks on the Najprodavanije screen (app.js passes them on). */
function onTopClick(t) {
  // another period or scope: what runs stops (what it read stays) and this one starts or carries on
  const fresh = () => {
    const s0 = topStore().sets[setKey()];
    if (s0 && (s0.complete || !s0.phase)) return;
    if (T.busy) { T.cancel = true; T.after = true; } else loadTop(true);
  };
  if (t.dataset.topDays) { T.days = +t.dataset.topDays; renderTop(); fresh(); return true; }
  if (t.dataset.topSort) { T.sort = t.dataset.topSort; renderTop(); return true; }
  if (t.dataset.topSt) { T.st = t.dataset.topSt; renderTop(); return true; }
  if (t.dataset.topSf) { ctx.openMissing(t.dataset.topSf); return true; }
  if (t.dataset.topPick) {
    const g = ctx.validGroup(S.user.hier, t.dataset.topPick);
    if (!g) return true;
    T.scope = { kind: 'grp', id: g.id, title: g.title };
    T.pick = false;
    renderTop();
    fresh();
    return true;
  }
  if (t.dataset.topHier) { ctx.loadHierarchy({ S, stCall, saveUser, toast, done: () => { if (top().id === 'top') renderTop(); } }); return true; }
  const a = t.dataset.top;
  if (!a) return false;
  if (a === 'refresh') { loadTop(); }
  else if (a === 'resume') { loadTop(true); }
  else if (a === 'cancel') { T.cancel = true; renderTop(); }
  else if (a === 'scope-dept') { T.scope = { kind: 'dept', id: '', title: '' }; T.pick = false; renderTop(); fresh(); }
  else if (a === 'scope-store') {
    T.pick = false;
    const go2 = () => { T.scope = { kind: 'store', id: 'all', title: 'Cijela poslovnica' }; renderTop(); fresh(); };
    if (!S.user.hier) ctx.loadHierarchy({ S, stCall, saveUser, toast, done: () => { if (S.user.hier) go2(); else renderTop(); } });
    else go2();
  } else if (a === 'scope-pick') {
    T.pick = !T.pick;
    renderTop();
  }
  return true;
}

// ------------------------------------------------ Uskoro 21: articles StoreFront already says will be discontinued

// StoreFront keeps the coming status of an article and the date it is valid from (futurestatusCode). This screen
// reads it: first for the employee's own planogram (his department, the priority), or for any other product group
// he picks (e.g. Namještaj > Kancelarija). Sorted by the date, the soonest first, so the SM can go to 0 in time.
S.soon = { scope: 'pick', grp: '', grpTitle: '', busy: '', onlySm: false, pick: false, future: 'all' };
const soonToday = () => Date.parse(`${new Date().toISOString().slice(0, 10)}T00:00:00Z`);
const soonDays = (iso) => Math.round((Date.parse(`${iso}T00:00:00Z`) - soonToday()) / 86400000);
const soonDmy = (iso) => { const [y, m, d] = String(iso).split('-'); return `${d}.${m}.${y}`; };
const soonHas = (x) => x.sm > 0 || x.dm > 0;
/** The read that is shown: the department's or the chosen group's. */
function soonSrc() {
  const u = S.user.soon || {};
  return S.soon.scope === 'dept' ? u.dept : (u.grp || {})[S.soon.grp];
}

function renderSoonBar() {
  const b = $('#soonBar');
  if (!b) return;
  b.hidden = !S.plans.length || !A.storeTask;
  if (b.hidden) return;
  const d = (S.user.soon || {}).dept;
  let small = 'Šta StoreFront najavljuje za status 21, po datumu';
  if (d && d.list) {
    const near = d.list.filter((x) => soonDays(x.from) <= 60);
    const sm = near.filter(soonHas).length;
    small = d.list.length ? `${near.length} u narednih 60 dana${sm ? ` · ${sm} još ima SM/DM` : ''} · ${esc(ageText(d.at))}` : `Ništa najavljeno · ${esc(ageText(d.at))}`;
  }
  b.innerHTML = `${icon('info')}<span><b>Uskoro status 21</b><small>${small}</small></span><span class="go">${d && d.list ? 'Otvori' : 'Učitaj'}</span>`;
}

function openSoon() {
  S.soon.scope = 'pick';
  go('soon');
  renderSoon();
  // No automatic queries on opening this screen; user chooses the group.
}

function loadHier() {
  if (S.soon.busy) return;
  S.soon.busy = 'hier';
  renderSoon();
  const ok = stCall({ mode: 'hier' }, (r) => {
    S.soon.busy = '';
    if (r.how === 'ok' && r.res && Array.isArray(r.res.groups)) {
      S.user.hier = { at: Date.now(), groups: r.res.groups.slice(0, 40).map((g) => ({ id: String(g.id), title: String(g.title || ''), subs: (g.subs || []).slice(0, 60).map((x) => ({ id: String(x.id), title: String(x.title || '') })) })) };
      saveUser();
    } else toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Grupe se nisu mogle učitati. Pokušaj ponovo.');
    if (top().id === 'soon') renderSoon();
  });
  if (!ok) { S.soon.busy = ''; toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); renderSoon(); }
}

function loadSoon() {
  if (S.soon.busy || S.soon.scope === 'pick') return;
  const dept = S.soon.scope === 'dept';
  const nums = dept ? deptNums() : [];
  if (dept && !nums.length) { toast('Prvo dodaj planogram svog odjela.'); return; }
  if (!dept && !S.soon.grp) return;
  const grp = S.soon.grp, title = S.soon.grpTitle;
  S.soon.busy = 'load';
  renderSoon();
  const ok = stCall(dept ? { mode: 'soon', nums } : { mode: 'soon', cats: [grp] }, (r) => {
    S.soon.busy = '';
    if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
      const list = r.res.list.slice(0, 1500).filter((x) => /^\d{7}$/.test(x.num) && /^\d{4}-\d{2}-\d{2}$/.test(x.from)).map((x) => ({
        num: x.num, name: String(x.name || ''), st: String(x.st || ''), fut: String(x.fut || ''), from: x.from, sm: +x.sm || 0, dm: +x.dm || 0,
        stock: +x.stock || 0, sold30: +x.sold30 || 0, cap: +x.cap || 0, price: +x.price || 0, unit: String(x.unit || 'KOM'), groupName: String(x.groupName || ''),
      }));
      const rec = { at: Date.now(), asked: +r.res.asked || 0, list };
      const u = S.user.soon || {};
      S.user.soon = dept ? { ...u, dept: { ...rec, key: deptKey() } } : { ...u, grp: { ...(u.grp || {}), [grp]: { ...rec, title } } };
      saveUser();
    } else {
      toast(r.how === 'login' ? 'StoreFront traži prijavu.' : r.err === 'timeout' ? 'StoreFront je predugo odgovarao. Izaberi manju grupu ili pokušaj ponovo.' : 'Lista se nije mogla učitati. Pokušaj ponovo.');
    }
    renderSoonBar();
    if (top().id === 'soon') renderSoon();
  });
  if (!ok) { S.soon.busy = ''; toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); renderSoon(); }
}

/** Puts SM (and, if asked, DM) to 0 for these articles, after the employee confirmed. */
async function soonZero(nums, prefer = 'sm') {
  const s = soonSrc();
  const xs = ((s && s.list) || []).filter((x) => nums.includes(x.num) && soonHas(x));
  if (!xs.length || S.soon.busy) return;
  const one = xs.length === 1 ? xs[0] : null;
  const sm = xs.filter((x) => x.sm > 0).length, dm = xs.filter((x) => x.dm > 0).length;
  const how = await ask(one ? `${one.num}: SM na 0?` : `${xs.length} artikala: SM na 0?`,
    `${one ? `<p>${esc(one.name)}</p><p>Prelazi u status ${esc(one.fut)} ${soonDmy(one.from)}. Sada SM ${whole(one.sm)}, DM ${whole(one.dm)}.</p>` : `<p>SM ima ${sm}, DM ima ${dm} ${plural(dm, 'artikal', 'artikla', 'artikala')}.</p>`}
     <p>SM na 0: SAO ih više ne naručuje za dodatno izlaganje. DM ostavi dok su izloženi; skini ga kad uklonješ izložene komade (vraćaju se u online zalihu).</p><p>Sprema se odmah u StoreFront pod tvojom prijavom.</p>`,
    prefer === 'both' && dm
      ? [{ label: 'SM i DM na 0', kind: 'btn-primary', value: 'both' }, ...(sm ? [{ label: 'Samo SM na 0', value: 'sm' }] : []), { label: 'Odustani', value: '' }]
      : [{ label: 'SM na 0', kind: 'btn-primary', value: 'sm' }, ...(dm ? [{ label: 'SM i DM na 0', value: 'both' }] : []), { label: 'Odustani', value: '' }]);
  if (!how) return;
  const all = xs.filter((x) => x.sm > 0 || how === 'both').map((x) => ({ num: x.num, sm: 0, dm: how === 'both' ? 0 : x.dm, was: { sm: x.sm, dm: x.dm } }));
  if (!all.length) { toast('Ovi artikli nemaju SM.'); return; }
  // StoreFront takes at most 300 in one job: the rest goes in the next one, one after the other
  let saved = 0, bad = 0;
  const send = (i) => {
    const items = all.slice(i, i + 300);
    const ok = smJob(items, (r) => {
      if (r.how === 'ok' && r.res) {
        const done = new Set(r.res.done || []);
        for (const x of s.list) if (done.has(x.num)) { const it = items.find((y) => y.num === x.num); x.sm = 0; x.dm = it.dm; }
        saveUser();
        saved += done.size;
        bad += (r.res.failed || []).length;
        if (i + 300 < all.length) { send(i + 300); return; }
        toast(`Spremljeno: ${saved} ${plural(saved, 'artikal', 'artikla', 'artikala')}${bad ? `, nije prošlo ${bad}` : ''}.`);
      } else toast(`${saved ? `Spremljeno ${saved}, za ostale ishod nepoznat. ` : ''}${r.how === 'login' ? 'StoreFront traži prijavu.' : 'StoreFront nije odgovorio do kraja.'} Osvježi listu da vidiš šta je stvarno spremljeno.`);
      S.soon.busy = '';
      renderSoonBar();
      if (top().id === 'soon') renderSoon();
    });
    if (!ok) { S.soon.busy = ''; toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); renderSoon(); return; }
    S.soon.busy = 'send';
    renderSoon();
  };
  send(0);
}

function soonPicker() {
  const h = S.user.hier;
  if (!h || !h.groups) {
    return S.soon.busy === 'hier' ? '<p class="count-line"><i class="mj-busy"></i> Čitam grupe proizvoda iz StoreFronta…</p>'
      : `<p class="empty">Izaberi odjel iz grupa proizvoda StoreFronta (npr. Namještaj › Kancelarija).</p><button class="btn btn-primary btn-block" type="button" data-soon="hier">${icon('list')}Učitaj grupe</button>`;
  }
  const done = (S.user.soon || {}).grp || {};
  const chip = (id, title, label) => `<button class="chip${done[id] ? ' is-read' : ''}" type="button" data-soon-grp="${esc(id)}" data-soon-title="${esc(title)}">${esc(label)}</button>`;
  return `<p class="count-line">Izaberi grupu. Manja grupa se čita brže (velika, kao cijeli Namještaj, i do 5 minuta).</p>
    ${h.groups.map((g) => `<details class="soon-grp"${String(S.soon.grp).startsWith(g.id) ? ' open' : ''}><summary>${esc(g.title)}</summary>
      <div class="chips">${chip(g.id, g.title, `Sve: ${g.title}`)}${g.subs.map((x) => chip(x.id, `${g.title} › ${x.title}`, x.title)).join('')}</div></details>`).join('')}`;
}

function soonRow(x, other) {
  const days = soonDays(x.from);
  const has = soonHas(x);
  const dis = S.soon.busy ? 'disabled' : '';
  return `<div class="soon-row${has && days <= 60 ? ' is-due' : ''}">
    <button class="soon-main" type="button" data-store="${esc(x.num)}">
      <span class="code">${esc(x.num)}<span class="pill pill-muted">Status ${esc(x.st)} → ${esc(x.fut)}</span>${x.sm > 0 ? `<span class="pill pill-warn">SM ${whole(x.sm)}</span>` : ''}${x.dm > 0 ? `<span class="pill pill-warn">DM ${whole(x.dm)}</span>` : ''}</span>
      <span class="item-name">${esc(x.name) || 'Bez naziva'}</span>
      <span class="sm-facts">Na stanju ${whole(x.stock)} · prodano 30 dana ${whole(x.sold30)}${x.price ? ` · ${money(x.price)} KM` : ''}${other && x.groupName ? ` · ${esc(x.groupName)}` : ''}</span>
    </button>
    ${has ? `<button class="chip soon-zero" type="button" data-soon-zero="${esc(x.num)}" ${dis} aria-label="${x.sm > 0 ? 'SM' : 'DM'} na 0">${x.sm > 0 ? 'SM' : 'DM'} 0</button>` : ''}
  </div>`;
}

function renderSoon() {
  const box = $('#soonBody');
  if (!box) return;
  const dept = S.soon.scope === 'dept';
  const dis = S.soon.busy ? 'disabled' : '';
  const seg = `<div class="seg" role="tablist">${[['pick','Odjeli'], ['dept', 'Moj odjel'], ['grp', 'Drugi odjel']].map(([v, t]) => `<button class="seg-btn" type="button" role="tab" aria-selected="${S.soon.scope === v}" data-soon-scope="${v}" ${dis}>${t}</button>`).join('')}</div>`;
  const intro = `<details class="sm-intro"><summary>Odakle je ovo?</summary>
    <p>StoreFront za svaki artikal unaprijed čuva budući status i datum od kada vrijedi. Ovdje su artikli kojima je najavljen status <b>21</b> (ukinut) ili <b>81</b>, poredani po datumu.</p>
    <p>SAO naručuje samo statuse 11, 12 i 41, pa nakon prelaska u 21 artikal više ne stiže. Prije toga SAO i dalje dopunjava policu i SM: spusti SM na 0 nekoliko sedmica prije datuma da ne ostane višak za rasprodaju. Smjernica: kad artikal pređe u 21, ukloni SM i DM.</p></details>`;
  if (S.soon.scope === 'pick') {
    box.innerHTML = `<div class="pick-dept"><h3>Uskoro status 21 / 81</h3>
      <p class="hint">Izaberi odjel. Nema automatskog učitavanja.</p>
      <button class="pick-dept-item" type="button" data-soon-scope="dept">Moj odjel <span>›</span></button>
      <button class="pick-dept-item" type="button" data-soon-scope="grp">Drugi odjel / podgrupa <span>›</span></button>
    </div>`;
    return;
  }
  if (!dept && (S.soon.pick || !S.soon.grp)) {
    box.innerHTML = `${seg}${intro}${soonPicker()}`;
    return;
  }
  const s = soonSrc();
  const busy = S.soon.busy === 'load' ? `<p class="count-line"><i class="mj-busy"></i> Čitam iz StoreFronta budući status svakog artikla… ${dept ? '(oko minutu)' : '(veća grupa i do 5 minuta)'}</p>`
    : S.soon.busy === 'send' ? '<p class="count-line"><i class="mj-busy"></i> Spremam u StoreFront…</p>' : '';
  const which = dept ? `${esc(deptName())} · artikli iz tvog planograma` : `<button class="text-btn" type="button" data-soon="pick" ${dis}>${esc(S.soon.grpTitle)} · Promijeni</button>`;
  if (!s || !s.list) {
    box.innerHTML = `${seg}${intro}<p class="count-line">${which}</p>${busy || `<button class="btn btn-primary btn-block" type="button" data-soon="load">${icon('refresh')}Učitaj iz StoreFronta</button>`}`;
    return;
  }
  const all = s.list.filter((x) => soonDays(x.from) >= -1 &&
    (S.soon.future === 'all' || x.fut === S.soon.future));
  const list = S.soon.onlySm ? all.filter(soonHas) : all;
  const withSm = all.filter(soonHas);
  const near = withSm.filter((x) => soonDays(x.from) <= 60);
  const days = [];
  for (const x of list) { const d = days[days.length - 1]; if (d && d.from === x.from) d.xs.push(x); else days.push({ from: x.from, xs: [x] }); }
  const when = (n) => (n <= 0 ? 'danas' : n === 1 ? 'sutra' : `za ${n} ${plural(n, 'dan', 'dana', 'dana')}`);
  box.innerHTML = `${seg}${intro}
    <div class="top-head"><p class="count-line">${which}</p><button class="text-btn" type="button" data-soon="load" ${dis}>${icon('refresh')}Osvježi</button></div>
    ${busy}
    <p class="count-line">${all.length ? `${all.length} ${plural(all.length, 'artikal najavljen', 'artikla najavljena', 'artikala najavljeno')} · ${withSm.length} sa SM/DM` : 'Nijedan artikal nema najavljen status 21 ni 81.'} · pregledano ${whole(s.asked)} · ${esc(ageText(s.at))}</p>
    <div class="chips soon-filter" role="group" aria-label="Budući status">
      ${[['all','Svi 21 / 81'],['21','Status 21'],['81','Status 81']].map(([id, label]) =>
        `<button class="chip" type="button" data-soon="future" data-future="${id}" aria-pressed="${S.soon.future === id}" ${dis}>${label}</button>`).join('')}
    </div>
    ${all.length ? `<div class="chips soon-filter"><button class="chip" type="button" data-soon="only" aria-pressed="${S.soon.onlySm}" ${dis}>Samo sa SM/DM</button></div>` : ''}
    ${withSm.length ? `<button class="btn btn-primary btn-block" type="button" data-soon="zero-all" ${dis}>SM i DM na 0 · svi najavljeni (${withSm.length})</button>` : ''}
    ${near.length && near.length < withSm.length ? `<button class="btn btn-soft btn-block soon-near" type="button" data-soon="zero-near" ${dis}>Samo narednih 60 dana (${near.length})</button>` : ''}
    ${days.map((d) => { const n = soonDays(d.from); return `<h3 class="soon-date${n <= 60 ? ' is-near' : ''}">${soonDmy(d.from)} <small>${when(n)} · ${d.xs.length}</small></h3><div class="soon-list">${d.xs.map((x) => soonRow(x, !dept)).join('')}</div>`; }).join('')}`;
}

function onSoonClick(t) {
  if (t.dataset.soonScope) { if (S.soon.busy) return; S.soon.scope = ['grp','dept','pick'].includes(t.dataset.soonScope) ? t.dataset.soonScope : 'pick'; S.soon.pick = S.soon.scope === 'grp' && !S.soon.grp; renderSoon(); return; }
  if (t.dataset.soonGrp) {
    if (S.soon.busy) return;
    S.soon.grp = t.dataset.soonGrp; S.soon.grpTitle = t.dataset.soonTitle || t.dataset.soonGrp; S.soon.pick = false;
    renderSoon();
    // Only the explicit Učitaj or Osvježi button queries StoreFront.
    return;
  }
  if (t.dataset.soonZero) { soonZero([t.dataset.soonZero]); return; }
  const a = t.dataset.soon;
  if (a === 'hier') loadHier();
  else if (a === 'pick') { S.soon.pick = true; renderSoon(); }
  else if (a === 'load') loadSoon();
  else if (a === 'future') { S.soon.future = ['all','21','81'].includes(t.dataset.future) ? t.dataset.future : 'all'; renderSoon(); }
  else if (a === 'only') { S.soon.onlySm = !S.soon.onlySm; renderSoon(); }
  else if (a === 'zero-all') { const s = soonSrc(); soonZero(((s && s.list) || []).filter((x) => soonHas(x) && soonDays(x.from) >= -1 && (S.soon.future === 'all' || x.fut === S.soon.future)).map((x) => x.num), 'both'); }
  else if (a === 'zero-near') { const s = soonSrc(); soonZero(((s && s.list) || []).filter((x) => soonHas(x) && soonDays(x.from) <= 60 && soonDays(x.from) >= -1 && (S.soon.future === 'all' || x.fut === S.soon.future)).map((x) => x.num)); }
}


  return { loadTop, onSoonClick, onTopClick, openSoon, openTop, renderSoon, renderSoonBar, renderTop, renderTopBar };
}
