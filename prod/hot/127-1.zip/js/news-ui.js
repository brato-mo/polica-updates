// Vijesti: MYJYSK tasks and news on screen, and an Excel attachment of a news article as a list of articles.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createNewsUi(ctx) {
  const { $, A, NEWS_SHOWN, S, ageText, arBar, cfg, debounce, esc, go, icon, itemRow, mjMe, mjOn, news, newsRow, openAr, openItem, ordersOf, refreshMyjysk, sfThumb, taskRow, toast } = ctx;


const ATT_SHOWN = 150;

/** Which columns hold what: the article number (7 digits in most rows), its name, the store, quantity, reason. */
function prepAttachment(a) {
  const rows = a.rows.filter((r) => Array.isArray(r)).map((r) => r.map((c) => String(c == null ? '' : c)));
  const isNum = (c) => /^-?\d+([.,]\d+)?(E-?\d+)?$/i.test(c);
  let h = 0;
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    if (rows[i].filter((c) => c && !isNum(c)).length >= 2) { h = i; break; }
  }
  const head = rows[h] || [];
  const data = rows.slice(h + 1);
  const width = Math.max(head.length, ...data.slice(0, 50).map((r) => r.length), 0);
  const find = (re, not = []) => head.findIndex((c, i) => re.test(c) && !not.includes(i));
  let art = -1, best = 0;
  for (let c = 0; c < width; c++) {
    const n = data.filter((r) => /^\d{7}$/.test((r[c] || '').trim())).length;
    const bonus = /artic|artik|material/i.test(head[c] || '') ? 0.5 : 0;
    if (n + bonus > best) { best = n + bonus; art = c; }
  }
  if (best < Math.max(1, data.length * 0.3)) art = -1;
  let name = find(/short text|naziv|opis|descr|^text|^name|article name|artikal naziv/i, [art]);
  if (name < 0 && art >= 0) name = head.findIndex((c, i) => i > art && data.slice(0, 30).filter((r) => r[i] && !isNum(r[i])).length > 15);
  const site = find(/^(site|store|prodavnica|prodavaonica|trgovina|plant|lokacija)$/i);
  const qty = find(/quant|količ|kolic|^qty|pcs|^kom/i);
  const why = find(/reason|razlog/i);
  // the employee's own store: from the customer orders (their numbers start with it: #7X704…)
  const o = S.user.orders && S.user.orders.list && S.user.orders.list[0];
  const m = o && /^#?\d([A-Z]\d{3})/.exec(o.no || '');
  const sites = site >= 0 ? new Set(data.map((r) => (r[site] || '').trim())) : new Set();
  const mine = m && sites.has(m[1]) ? m[1] : '';
  return { ...a, head, data, art, name, site, qty, why, mine };
}

window.onAttachment = () => {
  let a = null;
  try { a = JSON.parse(A.readText('attachment.json') || 'null'); } catch (e) { a = null; }
  if (!a || !Array.isArray(a.rows) || !a.rows.length) { toast('Prilog se ne može prikazati.'); return; }
  S.att = prepAttachment(a);
  S.attF = { site: S.att.mine ? 'mine' : 'all', kind: 'all', q: '', table: false, more: false };
  renderAttach();
  go('attach');
};

function attRows() {
  const A2 = S.att, f = S.attF;
  const q = f.q.trim().toLowerCase();
  return A2.data.filter((r) => {
    if (f.site === 'mine' && A2.site >= 0 && (r[A2.site] || '').trim() !== A2.mine) return false;
    const num = A2.art >= 0 ? (r[A2.art] || '').trim() : '';
    if (f.kind === 'ord' && !(num && ordersOf(num).length)) return false;
    if (f.kind === 'plan' && !(num && S.index.byNum.has(num))) return false;
    return !q || r.some((c) => String(c).toLowerCase().includes(q));
  });
}

function attRow(r) {
  const A2 = S.att;
  const num = A2.art >= 0 ? (r[A2.art] || '').trim() : '';
  const bits = [
    A2.qty >= 0 && r[A2.qty] ? `${esc(A2.head[A2.qty] || 'Količina')}: ${esc(r[A2.qty])}` : '',
    A2.site >= 0 && S.attF.site === 'all' && r[A2.site] ? esc(r[A2.site]) : '',
    A2.why >= 0 && r[A2.why] ? esc(r[A2.why]) : '',
  ].filter(Boolean).join(' · ');
  const line = bits ? `<span class="store-line">${bits}</span>` : '';
  if (/^\d{7}$/.test(num) && S.index.byNum.has(num)) return itemRow(num, { sub: line });
  const nm = A2.name >= 0 ? r[A2.name] : '';
  return `<div class="item item-static">${num ? sfThumb(num) : `<span class="thumb">${icon('box')}</span>`}<span class="item-main">
    <span class="code">${esc(num || r.filter(Boolean).slice(0, 1).join(''))}</span><span class="item-name">${esc(nm) || 'Bez naziva'}</span>
    <span class="pills">${num ? '<span class="pill pill-muted">Nije u tvojim planogramima</span>' : ''}${num && ordersOf(num).length ? '<span class="pill pill-order">Naručio kupac</span>' : ''}</span>${line}</span></div>`;
}

function renderAttach() {
  const A2 = S.att, f = S.attF;
  if (!A2) return;
  $('#attachTitle').textContent = A2.name || 'Prilog';
  const list = attRows();
  const inSite = (r) => !(f.site === 'mine' && A2.site >= 0 && (r[A2.site] || '').trim() !== A2.mine);
  const base = A2.data.filter(inSite);
  const numOf = (r) => (A2.art >= 0 ? (r[A2.art] || '').trim() : '');
  const nOrd = base.filter((r) => numOf(r) && ordersOf(numOf(r)).length).length;
  const nPlan = base.filter((r) => numOf(r) && S.index.byNum.has(numOf(r))).length;
  const siteChips = A2.site >= 0 && A2.mine
    ? `<div class="chips">${[['mine', `Moja prodavnica (${esc(A2.mine)})`], ['all', `Sve prodavnice (${A2.data.length})`]].map(([k, t]) => `<button class="chip" type="button" aria-pressed="${f.site === k}" data-att-site="${k}">${t}</button>`).join('')}</div>` : '';
  const kindChips = A2.art >= 0
    ? `<div class="chips">${[['all', `Sve linije ${base.length}`], ['ord', `Naručio kupac ${nOrd}`], ['plan', `U mojim planogramima ${nPlan}`]].map(([k, t]) => `<button class="chip" type="button" aria-pressed="${f.kind === k}" data-att-kind="${k}">${t}</button>`).join('')}</div>` : '';
  const shown = f.more ? list : list.slice(0, ATT_SHOWN);
  const body = f.table || A2.art < 0
    ? `<div class="att-table"><table><thead><tr>${A2.head.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${shown.map((r) => `<tr>${A2.head.map((_, i) => `<td>${esc(r[i] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
    : `<div class="list">${shown.map(attRow).join('')}</div>`;
  $('#attachBody').innerHTML = `
    ${A2.title ? `<p class="att-from">Iz vijesti: <b>${esc(A2.title)}</b></p>` : ''}
    <div class="att-tools">
      <input class="set-input" id="attQ" type="search" value="${esc(f.q)}" placeholder="Traži broj ili naziv" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="Traži u prilogu">
      ${siteChips}${kindChips}
      ${A2.art >= 0 ? `<button class="text-btn" type="button" data-att-table>${f.table ? 'Prikaži kao listu' : 'Prikaži kao tabelu'}</button>` : ''}
    </div>
    ${list.length ? body : '<p class="empty">Nema linija za ovaj izbor.</p>'}
    ${list.length > ATT_SHOWN ? `<button class="mj-more" type="button" data-att-more>${f.more ? 'Prikaži manje' : `Prikaži još ${list.length - ATT_SHOWN}`}</button>` : ''}`;
  const q = $('#attQ');
  q.addEventListener('input', debounce(() => { S.attF.q = q.value; S.attF.more = false; renderAttach(); const n = $('#attQ'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }, 200));
}

function onAttachClick(ev) {
  const t = ev.target.closest('button, [data-num]');
  if (!t) return;
  if (t.dataset.attSite) { S.attF.site = t.dataset.attSite; S.attF.more = false; renderAttach(); return; }
  if (t.dataset.attKind) { S.attF.kind = t.dataset.attKind; S.attF.more = false; renderAttach(); return; }
  if ('attTable' in t.dataset) { S.attF.table = !S.attF.table; renderAttach(); return; }
  if ('attMore' in t.dataset) { S.attF.more = !S.attF.more; renderAttach(); return; }
  if (t.dataset.num) openItem(t.dataset.num, { via: 'attachment' });
}

function renderNews() {
  const box = $('#newsWrap');
  const st = S.user.mj;
  const busy = S.mj.busy;
  // what the screen shows is always the last good read; the line says how old it is and what is going on now
  const ERR = { offline: 'Nema internet veze', error: 'MYJYSK nije odgovorio', login: 'Sesija je istekla' };
  const err = !busy && S.mj.err && ERR[S.mj.err] ? `<b class="mj-err">${ERR[S.mj.err]}</b> · ` : '';
  const when = st && st.at ? `${busy ? 'Prikazano' : 'Zadnje osvježeno'} ${esc(ageText(st.at))}` : '';
  const stateLine = `<div class="mj-state"><span>${busy ? `<i class="mj-busy"></i>Osvježavam iz MYJYSK…${when ? ` <small>${when}</small>` : ''}` : `${err}${when}${when && cfg().mj && !err ? ' · samo se osvježi u 8:00' : ''}`}</span>${busy ? '' : '<button class="text-btn" type="button" data-mj="refresh">Osvježi</button>'}</div>`;
  const login = st && st.login
    ? `<button class="orders-bar" type="button" data-mj="login">${icon('info')}<span><b>Prijavi se ponovo u MYJYSK</b><small>Prijava je istekla, pa se zadaci i vijesti ne mogu osvježiti.</small></span><span class="go">Prijava</span></button>`
    : '';
  if (!st || !st.at) {
    box.innerHTML = `${stateLine}${login}<div class="mj-intro"><h3>Zadaci i vijesti iz MYJYSK</h3>
      <p>Tvoji zadaci, zadaci prodavnice, vijesti i status sistema na jednom mjestu. Učitavaju se s tvojom prijavom u MYJYSK, svako jutro u 8:00 same od sebe.</p>
      <button class="btn btn-primary btn-block" type="button" data-mj="login">Prijavi se i učitaj</button></div>`;
    return;
  }
  const now = Date.now();
  const mine = news.myTasks(st, mjMe());
  const overMine = mine.filter((t) => t.over).length;
  const loc = st.loc.filter((t) => !t.done);
  const locOpen = loc.filter((t) => !t.over), locOver = loc.filter((t) => t.over);
  const locShown = (S.mj.loc === 'over' ? locOver : S.mj.loc === 'all' ? loc : locOpen).slice().sort(news.byDue);
  const newsShown = S.mj.more ? st.news : st.news.slice(0, NEWS_SHOWN);
  box.innerHTML = `${stateLine}${login}
  ${arBar()}
  ${impSection(st)}
  <section class="mj-sec"><div class="sec-head"><h2>Za mene</h2><small>${mine.length}${overMine ? ` · ${overMine} isteklo` : ''}</small></div>
    ${mine.length ? `<div class="list">${mine.map((t) => taskRow(st, t, { role: true })).join('')}</div>` : '<p class="empty">Nema otvorenih zadataka za tebe.</p>'}</section>
  <section class="mj-sec"><div class="sec-head"><h2>Vijesti</h2><small>${st.newsTotal > st.news.length ? `zadnjih ${st.news.length} od ${st.newsTotal}` : st.news.length}</small></div>
    ${st.news.length ? `<div class="list">${newsShown.map((a) => newsRow(st, a)).join('')}${st.news.length > NEWS_SHOWN ? `<button class="mj-more" type="button" data-mj="more">${S.mj.more ? 'Prikaži manje' : `Prikaži još ${st.news.length - NEWS_SHOWN}`}</button>` : ''}</div>` : '<p class="empty">Nema vijesti.</p>'}</section>
  <section class="mj-sec"><div class="sec-head"><h2>Zadaci lokacije</h2><small>${loc.length}</small></div>
    <div class="chips">${[['open', `Otvoreni ${locOpen.length}`], ['over', `Istekli ${locOver.length}`], ['all', 'Svi']].map(([k, t]) => `<button class="chip" type="button" aria-pressed="${S.mj.loc === k}" data-mj="loc-${k}">${t}</button>`).join('')}</div>
    ${locShown.length ? `<div class="list">${locShown.map((t) => taskRow(st, t, { role: true })).join('')}</div>` : '<p class="empty">Nema zadataka ovdje.</p>'}</section>`;
}

const IMP_SHOWN = 6;
const KIND = { plan: 'Planogram', upd: 'Ažuriranje koncepta', concept: 'Koncept', sys: 'Status sistema' };
const MY_DEPT = '05';

function impItems(st) {
  const log = (S.user.planLog || []).map((x) => ({ ...x, fresh: (x.at || 0) > (st.viewedAt || 0) }));
  const imp = (st.imp || []).map((x) => ({ ...x, fresh: news.isNew(st, x.id) }));
  return [...log, ...imp].sort((a, b) => String(b.date).localeCompare(String(a.date)) || (b.fresh - a.fresh));
}

function impRow(x) {
  const open = S.mj.open.has(x.id);
  const mine = news.deptNo(x.dept) === MY_DEPT;
  const meta = [KIND[x.kind] || '', x.kind === 'plan' ? '' : news.deptName(x.dept), news.dayText(x.date)].filter(Boolean).join(' · ');
  const go = x.kind === 'plan' && x.planId && S.plans.some((p) => p.id === x.planId)
    ? `<button class="text-btn" type="button" data-open-plan="${esc(x.planId)}" data-page="0">Otvori planogram</button>${S.user.changes[x.planId] ? ` · <button class="text-btn" type="button" data-changes="${esc(x.planId)}">Šta se promijenilo</button>` : ''}`
    : x.path ? `<button class="text-btn" type="button" data-mj-open="${esc(x.path)}">Otvori u MYJYSK</button>` : '';
  return `<div class="mj-news${x.kind === 'sys' ? ' is-sys' : ''}"><button class="mj-row" type="button" data-mj-x="${esc(x.id)}" aria-expanded="${open}">
    <span class="mj-main"><span class="mj-title">${x.fresh ? '<span class="mj-new">NOVO</span>' : ''}${esc(x.title)}</span><span class="mj-meta">${esc(meta)}${mine ? ' · <b class="mj-mine">tvoj odjel</b>' : ''}</span></span>
  </button>${open ? `<div class="mj-text">${esc(x.text) || esc(impHint(x))}${go ? `<br>${go}` : ''}</div>` : ''}</div>`;
}

/** What to say when an entry has no text of its own. */
function impHint(x) {
  if (x.kind === 'concept') return `Koncept je ažuriran ${news.dayText(x.date)}. Šta je tačno novo, piše u članku.`;
  if (x.kind === 'plan') return 'Planogram je preuzet i zamijenio stari.';
  return 'Više detalja je u članku.';
}

function impSection(st) {
  const all = impItems(st);
  if (!all.length) return '';
  const shown = S.mj.impMore ? all : all.slice(0, IMP_SHOWN);
  const fresh = all.filter((x) => x.fresh).length;
  return `<section class="mj-sec"><div class="sec-head"><h2>Važno</h2><small>${fresh ? `${fresh} novo` : 'koncept, planogrami, sistem'}</small></div>
    <div class="list">${shown.map(impRow).join('')}${all.length > IMP_SHOWN ? `<button class="mj-more" type="button" data-mj="imp-more">${S.mj.impMore ? 'Prikaži manje' : `Prikaži još ${all.length - IMP_SHOWN}`}</button>` : ''}</div>
    ${mjOn() ? '<button class="text-btn" type="button" data-plcheck>Provjeri nove planograme</button>' : ''}</section>`;
}

function onNewsClick(t) {
  if (t.dataset.mjOpen) { try { A.myjyskOpen(t.dataset.mjOpen); } catch (e) { /* older shell */ } return; }
  if (t.dataset.mjX) {
    const id = t.dataset.mjX;
    if (!S.mj.open.delete(id)) S.mj.open.add(id);
    renderNews();
    return;
  }
  const a = t.dataset.mj;
  if (a === 'ar') { openAr(); return; }
  if (a === 'refresh') refreshMyjysk(false);
  else if (a === 'login') refreshMyjysk(true);
  else if (a === 'more') { S.mj.more = !S.mj.more; renderNews(); }
  else if (a === 'imp-more') { S.mj.impMore = !S.mj.impMore; renderNews(); }
  else if (a.startsWith('loc-')) { S.mj.loc = a.slice(4); renderNews(); }
}



  return { impItems, onAttachClick, onNewsClick, renderAttach, renderNews };
}
