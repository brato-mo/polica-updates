// Prijedlozi danas: what is worth doing today (the screen; the rules are in tips.js).
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createTipsUi(ctx) {
  const { $, A, S, ar, arKept, deptName, esc, go, icon, loadAudit, loadClr2, loadTop, mjMe, mjOn, news, openAr, openAudit, openClearance, openTop, setMode, smcheck, tips, top } = ctx;


S.tips = { busy: false, timer: 0 };

/** Everything the tips are made from, as the app has it now. */
function tipsSrc() {
  const a = S.user.audit;
  const c = S.user.clr2 || {};
  const st = S.user.mj;
  let tasks = [];
  if (st && st.at) {
    const now = Date.now();
    tasks = news.myTasks(st, mjMe()).map((t) => {
      const d = news.due(t.end, now);
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(t.end || '');
      const days = m ? Math.round((new Date(+m[1], +m[2] - 1, +m[3]) - new Date(new Date(now).setHours(0, 0, 0, 0))) / 86400000) : null;
      return { title: t.title, days, left: d.left };
    });
  }
  return {
    audit: a && a.list ? { at: a.at, groups: smcheck.check(a.list, a.top, (n) => S.index.byNum.has(n)) } : null,
    top: S.user.top && S.user.top.list ? S.user.top : null,
    home: c.home || null,
    furn: c.furn || null,
    ar: { enabled: mjOn(), done: ar.doneThisWeek(arKept().last, Date.now()) },
    tasks,
  };
}

function renderTipsBar() {
  const b = $('#tipsBar');
  if (!b) return;
  b.hidden = !S.plans.length || !A.storeTask;
  if (b.hidden) return;
  const t = tips.build(tipsSrc());
  const now1 = t.filter((x) => x.level === 1).length;
  b.innerHTML = `${icon('star')}<span><b>Prijedlozi danas${t.length ? `: ${t.length}` : ''}</b><small>${t.length ? `${now1 ? `${now1} hitno · ` : ''}${esc(t[0].title)}` : 'Šta se isplati uraditi danas u odjelu'}</small></span><span class="go">Otvori</span>`;
}

function openTips() {
  go('tips');
  renderTips();
  if (tips.stale(tipsSrc()).length) tipsRefresh();
}

/** Reads again what is old or missing (best sellers, SM/DM check, lists to sell out), the screen follows. */
function tipsRefresh(all = false) {
  const src = tipsSrc();
  const want = all ? ['audit', 'top', 'home', 'furn'] : tips.stale(src);
  if (want.includes('audit') && !S.au.busy) loadAudit();
  if (want.includes('top') && !S.topBusy) loadTop();
  const home = want.includes('home'), furn = want.includes('furn');
  if (home) loadClr2('home');
  S.tips.busy = true;
  clearInterval(S.tips.timer);
  let furnDone = !furn;
  S.tips.timer = setInterval(() => {
    // the two lists to sell out are read one after the other (one list at a time)
    if (!furnDone && !S.clr.busy) { furnDone = true; loadClr2('furn'); }
    const busy = S.au.busy || S.topBusy || S.clr.busy || S.deptBusy || !furnDone;
    if (top().id === 'tips') renderTips();
    renderTipsBar();
    if (!busy) { clearInterval(S.tips.timer); S.tips.busy = false; if (top().id === 'tips') renderTips(); }
  }, 1200);
  renderTips();
}

function renderTips() {
  const box = $('#tipsBody');
  if (!box) return;
  const t = tips.build(tipsSrc());
  const lv = { 1: 'Hitno', 2: 'Danas', 3: 'Kad stigneš' };
  const busy = S.tips.busy ? `<p class="count-line"><i class="mj-busy"></i> Čitam iz StoreFronta: ${[S.au.busy && 'SM/DM provjera', S.topBusy && 'najprodavanije', S.clr.busy && 'lista za rasprodaju', S.deptBusy && 'grupe odjela'].filter(Boolean).join(', ') || 'još malo'}…</p>` : '';
  const cards = t.map((x) => `<section class="tipc tip-l${x.level}">
    <div class="tip-head"><span class="tip-lv">${lv[x.level]}</span><b>${esc(x.title)}</b></div>
    <p>${esc(x.text)}</p>
    ${x.items.length ? `<ul class="tip-items">${x.items.map((i) => `<li>${i.num ? `<span class="code">${esc(i.num)}</span> ` : ''}${esc(i.name)}${i.sub ? ` <small>· ${esc(i.sub)}</small>` : ''}</li>`).join('')}</ul>` : ''}
    <button class="btn btn-soft btn-small" type="button" data-tip-go="${esc(x.go)}">Otvori i riješi</button>
  </section>`).join('');
  box.innerHTML = `<div class="top-head"><p class="count-line">${esc(deptName())} · iz StoreFronta i MYJYSK</p>
      <button class="text-btn" type="button" data-tip="refresh" ${S.tips.busy ? 'disabled' : ''}>${icon('refresh')}Osvježi sve</button></div>
    ${busy}
    ${cards || (S.tips.busy ? '' : '<div class="mj-intro"><h3>Nema ništa hitno ✓</h3><p>Ukinuti artikli nemaju SM/DM, namještaj na izlogu je u redu, najprodavaniji imaju zalihe. Osvježi sutra.</p></div>')}`;
}

function onTipClick(t) {
  if (t.dataset.tip === 'refresh') { tipsRefresh(true); return; }
  const g = t.dataset.tipGo;
  if (g === 'audit') openAudit();
  else if (g === 'top') openTop();
  else if (g === 'ar') openAr();
  else if (g === 'news') { go('home'); setMode('news'); }
  else if (g === 'clear-home' || g === 'clear-furn') { S.clr.dept = g === 'clear-furn' ? 'furn' : 'home'; S.clr.st = 'all'; openClearance(); }
}


  return { onTipClick, openTips, renderTips, renderTipsBar };
}
