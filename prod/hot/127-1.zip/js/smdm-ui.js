import { pickerHtml, validGroup, loadHierarchy } from './other-depts.js';
// SM i DM: the department's (21, 81) and the garden's SM/DM values, the batches record and Master provjera.
// Moved out of app.js in 1.69 WITHOUT changing a line of what it does (tests/e2e/smdm.e2e.mjs guards it). Writing to
// StoreFront compares before every line (store-task.js smset: 'was', fresh read); this is only the screen.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createSmdmUi(ctx) {
  const { $, A, S, SMLOG, ageText, ask, cfg, deptArg, deptChips, deptGroups, deptName, deptSig, esc, go, icon, plural, saveUser, smcheck, stCall, stPill, stText, store, toast, top, whole, withDept } = ctx;
  const flow = ctx.flow || null;
  // 1.99 (owner): a tap on a code: look at the article (StoreFront, or its place on the planogram) and come back to the
  // same list, filter, place and unsaved values. Saving stays on "Spremi".
  const { openSheet, closeSheet, planSpots, onPlanTap } = ctx;
  const codeBtn = (num) => `<button class="code-link sm-code" type="button" data-sm-code="${esc(num)}" aria-label="Šifra ${esc(num)}: otvori u StoreFrontu ili na planogramu">${esc(num)}</button>`;
  function codeSheet(num) {
    const spots = planSpots ? planSpots(num) : [];
    const name = ((smData() && smData().list) || []).concat(((smData() && smData().list) || []).map((x) => x.succ).filter(Boolean)).find((x) => x.num === num);
    openSheet({
      title: `Šifra ${num}`,
      body: `<p>${esc((name && name.name) || '')}</p><p class="hint">Samo pregled. Nespremljene SM/DM promjene ostaju na listi; spremaju se tek na „Spremi“.</p>${spots.length ? '' : '<p class="hint">Lokacija na planogramu nije poznata na ovom telefonu.</p>'}`,
      actions: [
        { label: 'Otvori u StoreFrontu', kind: 'btn-primary', onClick: () => { closeSheet(); try { A.storefront(num, 'view'); } catch (e) { toast('StoreFront se nije otvorio.'); } } },
        ...(spots.length ? [{ label: spots.length > 1 ? `Prikaži na planogramu (${spots.length} mjesta)` : 'Prikaži na planogramu', onClick: () => { const b = $('#smBody'); S.sm.top = b ? b.scrollTop : null; closeSheet(); onPlanTap(num); } }] : []),
        { label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet },
      ],
    });
  }
  // 1.97 (owner): after a partly successful saving, the row itself says it (which row to read again): not saved, or a
  // move whose old number went through and the replacement did not (or the other way round)
  const failTag = (res, x) => {
    if (!res || !res.failed || !res.failed.length) return '';
    const bad = new Set(res.failed.map((f) => f.num));
    const ok = new Set(res.doneNums || []);
    if (x.succ && (bad.has(x.num) !== bad.has(x.succ.num)) && (ok.has(x.num) || ok.has(x.succ.num))) {
      const good = bad.has(x.num) ? x.succ.num : x.num, no = bad.has(x.num) ? x.num : x.succ.num;
      return `<span class="pill pill-warn">Prenos djelimičan: ${esc(good)} spremljeno, ${esc(no)} nije · učitaj ponovo</span>`;
    }
    return bad.has(x.num) ? '<span class="pill pill-warn">Nije spremljeno · učitaj ponovo</span>' : '';
  };


S.sm = { busy: '', edit: {}, move: {}, st: ['21', '81', '42'], scope: 'pick', otherId: '', pick: false, filter: 'all' };
// 1.98 (owner, MYJYSK 5127 "Smjernice za vrijednosti SM/DM"): "Kada artikal pređe na statusni kod 21 (ukinut), uklonite
// SM/DM vrijednosti"; daily: "filtrirajte ukinute (discontinued) SM/DM vrijednosti … uklonite sve vrijednosti sa starih
// artikala prije završetka ažuriranja prostora". StoreFront's own SM & DM filters "Discontinued articles with SM value"
// and "… with DM value" (its sm-dm page code, 14. 11. 2026) are statuses 21, 81 and 42, each value on its own.
// Garden: "Kada završi sezona vrtova … ukloniti sve DM vrijednosti - u suprotnom, DC će naručiti artikle … kad se
// promijeni u kod 42" (DM only; the article says nothing about the garden's SM).
const DISC = new Set(['21', '81', '42']);
const known = (v) => typeof v === 'number' && Number.isFinite(v);
const smTxt = (v) => (known(v) ? whole(v) : 'nije očitano');
const ST_WHY = {
  '21': 'Status 21 (ukinut): smjernica kaže „uklonite SM/DM vrijednosti“.',
  '81': 'Status 81 (označen za brisanje): StoreFront ga ubraja u ukinute (filter „ukinuti sa SM/DM“); ukloni prije kraja ažuriranja prostora.',
  '42': 'Status 42: StoreFront ga ubraja u ukinute; s DM vrijednošću DC ponovo naručuje robu (smjernica, vrt).',
};
/** The guideline's proposal for one row: { sm, dm } targets (null = leave as it is), a short text and the reason. */
function smPlan(x) {
  const out = { sm: null, dm: null, text: '', why: '', unk: [] };
  if (!known(x.sm)) out.unk.push('SM');
  if (!known(x.dm)) out.unk.push('DM');
  const why = [];
  if (DISC.has(x.st)) {
    if (known(x.sm) && x.sm > 0) out.sm = 0;
    if (known(x.dm) && x.dm > 0) out.dm = 0;
    why.push(ST_WHY[x.st]);
  } else if (smGarden()) {
    if (known(x.dm) && x.dm > 0) { out.dm = 0; why.push('Vrt, kraj sezone: smjernica kaže ukloniti sve DM vrijednosti (inače DC naruči robu kad artikal pređe u 42).'); }
    if (known(x.sm) && x.sm > 0) why.push('SM u vrtu: smjernica ne traži uklanjanje; odluči sam.');
  } else if (known(x.sm) && x.sm > 0 || known(x.dm) && x.dm > 0) why.push(`Status ${x.st || '?'}: smjernica ne traži uklanjanje.`);
  if (out.dm === 0 && Number.isFinite(+x.stock) && +x.stock > 0) why.push(`Na stanju ${whole(+x.stock)}: izloženi komadi se vraćaju u online zalihu.`);
  const parts = [];
  if (out.sm === 0 && out.dm === 0) parts.push(`ukloni SM i DM (SM ${whole(x.sm)} → 0, DM ${whole(x.dm)} → 0)`);
  else if (out.sm === 0) parts.push(`ukloni samo SM (${whole(x.sm)} → 0)${known(x.dm) ? `, DM ${whole(x.dm)} ostaje` : ''}`);
  else if (out.dm === 0) parts.push(`ukloni samo DM (${whole(x.dm)} → 0)${known(x.sm) ? `, SM ${whole(x.sm)} ostaje` : ''}`);
  out.text = parts.length ? parts[0][0].toUpperCase() + parts[0].slice(1) : '';
  out.why = why.join(' ');
  return out;
}
const hasPlan = (p) => p.sm !== null || p.dm !== null;
/** The row as the proposal leaves it (what "Prihvati" puts into the fields). */
const planEdit = (x, p) => ({ sm: p.sm !== null ? p.sm : x.sm, dm: p.dm !== null ? p.dm : x.dm });
let smHierBusy = false;
const smOther = () => S.sm.scope === 'other';
const smOtherGroup = () => validGroup(S.user.hier, S.sm.otherId);
function loadSmHierarchy() {
  if (smHierBusy || S.sm.busy) return;
  smHierBusy = true; renderSm();
  const ok = loadHierarchy({ S, stCall, saveUser, toast, done() {
    smHierBusy = false;
    if (top().id === 'smdm') renderSm();
  } });
  if (!ok) { smHierBusy = false; toast('StoreFront trenutno nije dostupan.'); renderSm(); }
}
// "Vrt": the whole garden assortment of StoreFront (category 9: garden furniture, garden cushions, parasols, ...),
// every status, every article with an SM or a DM value; for putting the season's values to 0 at once
const GARDEN_CAT = '9';
const GARDEN_ST = ['01', '02', '11', '12', '21', '31', '32', '41', '42', '51', '81'];
const smGarden = () => S.sm.scope === 'garden';
/** The list the SM screen works on: the department's 21/81 or the garden's. */
const smData = () => (smGarden() ? S.user.smGarden :
  smOther() ? (S.user.smOther || {})[S.sm.otherId] : S.user.smdm);
function setSmData(v) {
  if (smGarden()) S.user.smGarden = v;
  else if (smOther()) S.user.smOther = { ...(S.user.smOther || {}), [S.sm.otherId]: v };
  else S.user.smdm = v;
}

// ------------------------------------------- SM/DM batches: a small record on the phone
// smset-log.json = { id, at, n, nums, state: sending | done | failed | interrupted, end, done, failed }. Written
// before a batch goes to StoreFront and again with the answer. Found "sending" at the next start = the app died
// meanwhile: the screens say so. SM/DM values are set, not added (store-task.js smset), so sending the rest again
// is safe; the current value is read before every write.
// One batch at a time in the whole app (SM screen, Vrt, Master provjera, Rasprodaja, Uskoro 21): two batches over
// the same articles at once could leave either value. A second one waits for the first to answer.
let smChain = Promise.resolve();
// 1.72-test7: a saving that failed for the network says so (the change is still there, waiting for Spremi)
const NET_SAVE = 'Nema interneta: promjena vjerovatno nije spremljena i i dalje čeka. Kad se veza vrati, pritisni Spremi (vrijednosti se postavljaju, ne dodaju, pa je ponovno slanje sigurno).';
const netDown = (r) => r && (r.err === 'offline' || /Failed to fetch|NetworkError|ERR_INTERNET|ERR_NAME/.test(String(r.err || '')) || S.net === false || navigator.onLine === false);

function smJob(items, cb) {
  if (!A.storeTask) return false;
  smChain = smChain.then(() => new Promise((next) => {
    const rec = { id: Date.now(), at: Date.now(), n: items.length, nums: items.map((x) => x.num).slice(0, 300), state: 'sending' };
    if (!store.write(SMLOG, rec)) console.warn('smset-log not written');
    const ok = stCall({ mode: 'smset', items }, (r) => {
      // In TEST, never claim these were saved or update local SM/DM values.
      if (r.res && r.res.dry) r = { ...r, res: { done: [], same: [], dry: true, failed: [], tested: items.length } };
      const res = r.res || {};
      store.write(SMLOG, { ...rec, state: r.how === 'ok' ? 'done' : 'failed', how: r.how, end: Date.now(), done: (res.done || []).length, failed: (res.failed || []).length, same: (res.same || []).length });
      try { cb(r); } finally { next(); }
    });
    if (!ok) { store.write(SMLOG, { ...rec, state: 'notsent' }); try { cb({ how: 'error' }); } finally { next(); } }
  }));
  return true;
}
/** The last batch was cut off by the app closing: a line for the SM screens, else ''. */
function smLogLine() {
  const l = S.smLog;
  if (!l || l.state !== 'interrupted' || Date.now() - l.at > 3 * 86400000) return '';
  const t = new Date(l.at).toLocaleString('bs-BA', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' });
  return `<p class="ar-err">Serija SM/DM od ${esc(t)} (${l.n} ${plural(l.n, 'artikal', 'artikla', 'artikala')}) prekinuta je prije odgovora StoreFronta: dio je možda spremljen. Vrijednosti se postavljaju, ne dodaju, pa je ponovno slanje sigurno: učitaj listu ponovo i pošalji ono što je ostalo.</p>`;
}

/** What moving an old number's SM/DM to its replacement sends: the old one to 0, the new one at least as much. */
function smMoveItems(x) {
  return [{ num: x.num, sm: 0, dm: 0, was: { sm: x.sm, dm: x.dm } }, { num: x.succ.num, sm: Math.max(x.succ.sm, x.sm), dm: Math.max(x.succ.dm, x.dm), was: { sm: x.succ.sm, dm: x.succ.dm } }];
}
/** A replacement that would be left without the old number's SM/DM. */
const smNeedsMove = (x) => !!x.succ && (x.succ.sm < x.sm || x.succ.dm < x.dm);

function renderSmBar() {
  const b = $('#smBar');
  if (!b) return;
  b.hidden = !S.plans.length || !A.storeTask;
  if (b.hidden) return;
  const m = S.user.smdm;
  b.innerHTML = `${icon('list')}<span><b>SM i DM · odjel (21, 81, 42) i vrt</b><small>${m && m.list ? `${m.list.length} ${plural(m.list.length, 'artikal', 'artikla', 'artikala')} još ima SM ili DM · ${esc(ageText(m.at))}` : 'Ukinuti sa SM ili DM: prijedlog i razlog po artiklu'}</small></span><span class="go">${m && m.list ? 'Otvori' : 'Učitaj'}</span>`;
}

function openSm() {
  S.sm.scope = 'pick';
  S.sm.edit = {};
  S.sm.move = {};
  S.sm.result = null;
  go('smdm');
  renderSm();
  // No StoreFront reads until the user explicitly presses Učitaj.
}

function smLoadIfOld() {
  const m = smData();
  if (smGarden()) { if (!m || !m.list || Date.now() - m.at > 10 * 60000) loadSm(); return; }
  if (smOther()) {
    if (!smOtherGroup()) { S.sm.pick = true; renderSm(); return; }
    if (!m || !m.list || Date.now() - m.at > 10 * 60000) loadSm();
    return;
  }
  if (!m || !m.list || m.dept !== deptSig() || !deptGroups() || Date.now() - m.at > 10 * 60000) loadSm(); // the last read is shown at once
}

function loadSm() {
  if (S.sm.busy || S.sm.scope === 'pick' || (smOther() && !smOtherGroup())) return;
  S.sm.busy = 'load';
  renderSm();
  if (smGarden() || smOther()) loadSm2(); else withDept(() => loadSm2());
}

function loadSm2() {
  const scope = S.sm.scope, garden = scope === 'garden', other = scope === 'other';
  const group = other ? smOtherGroup() : null;
  if (other && !group) { S.sm.busy = ''; S.sm.pick = true; renderSm(); return; }
  const arg = garden ? { mode: 'smdm', cat: GARDEN_CAT, cats: [GARDEN_CAT], st: GARDEN_ST, nosucc: true } :
    other ? { mode: 'smdm', cat: group.id, cats: [group.id], st: S.sm.st, nosucc: true } :
    { mode: 'smdm', cat: cfg().group || '5', st: S.sm.st, ...deptArg() };
  const ok = stCall(arg, (r) => {
    S.sm.busy = '';
    if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
      const d = { v: 4, dept: garden ? 'vrt' : other ? 'other:' + group.id : deptSig(), at: Date.now(), limited: !!r.res.limited, list: r.res.list.map((x) => ({ num: x.num, name: x.name, st: x.st, unit: x.unit, stock: x.stock, ...(Number.isFinite(x.free) ? { free: x.free } : {}), sm: known(x.sm) ? x.sm : null, dm: known(x.dm) ? x.dm : null, cap: x.cap, sold30: x.sold30, succ: x.succ && /^\d{7}$/.test(x.succ.num) ? { num: x.succ.num, st: String(x.succ.st || ''), sm: +x.succ.sm || 0, dm: +x.succ.dm || 0, stock: +x.succ.stock || 0 } : null })) };
      if (garden) S.user.smGarden = d;
      else if (other) S.user.smOther = { ...(S.user.smOther || {}), [group.id]: d };
      else S.user.smdm = d;
      saveUser();
    } else {
      toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'SM vrijednosti se nisu mogle učitati. Pokušaj ponovo.');
    }
    renderSmBar();
    if (top().id === 'smdm') renderSm();
  });
  if (!ok) { S.sm.busy = ''; toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); renderSm(); }
}

function smSend(items) {
  if (!items.length || S.sm.busy || items.length > 300) return;
  const garden = smGarden(), other = smOther(), selectedId = S.sm.otherId;
  const ok = smJob(items, (r) => {
    S.sm.busy = '';
    const m = garden ? S.user.smGarden : other ? (S.user.smOther || {})[selectedId] : S.user.smdm;
    const want = new Map(items.map((x) => [x.num, x]));
    if (r.how === 'ok' && r.res) {
      const done = new Set(r.res.done || []);
      // 1.98: a row a colleague changed (or StoreFront did not take) shows StoreFront's value now; the edit stays,
      // so the next Spremi compares with what is really there
      const cur = new Map((r.res.failed || []).filter((f) => f.cur && known(f.cur.sm) && known(f.cur.dm)).map((f) => [f.num, f.cur]));
      if (m && m.list) {
        m.list = m.list.map((x) => (done.has(x.num) ? { ...x, sm: want.get(x.num).sm, dm: want.get(x.num).dm } : cur.has(x.num) ? { ...x, sm: cur.get(x.num).sm, dm: cur.get(x.num).dm } : x)).filter((x) => !(known(x.sm) && known(x.dm)) || x.sm > 0 || x.dm > 0);
        m.at = Date.now();
      }
      for (const n of done) { delete S.sm.edit[n]; delete S.sm.move[n]; }
      S.sm.result = { done: done.size, dry: !!r.res.dry, failed: r.res.failed || [], doneNums: [...done] };
      saveUser();
      try { if (flow) flow.one('smdm', 'Spremanje SM/DM', (r.res.failed || []).length ? `spremljeno ${done.size}, nije ${(r.res.failed || []).length}` : `spremljeno ${done.size}`, (r.res.failed || []).length ? (done.size ? 'incomplete' : 'rejected') : 'ok', { n: items.length }); } catch (e) { /* ignore */ }
    } else {
      try { if (flow) flow.one('smdm', 'Spremanje SM/DM', 'odgovor nije stigao do kraja: učitaj listu ponovo', r.how === 'login' ? 'login' : netDown(r) ? 'network' : 'unsure', { n: items.length }); } catch (e) { /* ignore */ }
      S.sm.result = { done: 0, failed: [], err: r.how === 'bad' ? 'Ova verzija aplikacije ne zna spremiti te artikle. Ažuriraj je.' : r.how === 'login' ? 'StoreFront traži prijavu. Ništa nije promijenjeno ili samo dio; učitaj listu ponovo.' : netDown(r) ? NET_SAVE : 'StoreFront nije odgovorio do kraja. Učitaj listu ponovo da vidiš šta je promijenjeno.' };
      // 1.98 (owner): the answer was lost after the sending: read the current values of these rows before any retry
      if (r.how !== 'bad' && r.how !== 'login') smReadRows(items.map((x) => x.num), want);
    }
    renderSmBar();
    if (top().id === 'smdm') renderSm();
  });
  if (!ok) { toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); return; }
  S.sm.busy = 'send';
  renderSm();
}

/**
 * 1.98: read these rows' SM and DM again (store-task.js smread, read only) and show StoreFront's values. want (the
 * values a lost saving asked for): a row that has them now counts as saved; the others keep the employee's edit.
 */
function smReadRows(nums, want = null) {
  const garden = smGarden(), other = smOther(), selectedId = S.sm.otherId;
  nums = [...new Set(nums)].slice(0, 300);
  if (!nums.length) return;
  S.sm.reading = new Set(nums);
  if (top().id === 'smdm') renderSm();
  const ok = stCall({ mode: 'smread', nums }, (r) => {
    S.sm.reading = null;
    const m = garden ? S.user.smGarden : other ? (S.user.smOther || {})[selectedId] : S.user.smdm;
    if (r.how === 'ok' && r.res && Array.isArray(r.res.list) && m && m.list) {
      const got = new Map(r.res.list.filter((x) => !x.err).map((x) => [x.num, x]));
      let saved = 0;
      const open = []; // 1.99: every sent code that is not confirmed now: read with another value, or not read at all
      m.list = m.list.map((x) => {
        const g = got.get(x.num);
        const w = want && want.get(x.num);
        if (!g) { if (w) open.push({ num: x.num, why: 'nije se moglo očitati: ne zna se da li je spremljeno' }); return x; }
        const y = { ...x, sm: known(g.sm) ? g.sm : null, dm: known(g.dm) ? g.dm : null, ...(g.st ? { st: g.st } : {}) };
        if (w && known(y.sm) && known(y.dm) && y.sm === w.sm && y.dm === w.dm) { saved++; delete S.sm.edit[x.num]; } else if (w) open.push({ num: x.num, why: known(y.sm) && known(y.dm) ? `StoreFront sada ima SM ${y.sm}, DM ${y.dm}: nije spremljeno` : 'vrijednost nije očitana: ne zna se da li je spremljeno', cur: known(y.sm) && known(y.dm) ? { sm: y.sm, dm: y.dm } : null });
        return y;
      }).filter((x) => !(known(x.sm) && known(x.dm)) || x.sm > 0 || x.dm > 0 || open.some((o) => o.num === x.num));
      // a sent code that was not even in the list any more is still counted
      if (want) for (const n of want.keys()) if (!m.list.some((x) => x.num === n) && !got.has(n) && !open.some((o) => o.num === n)) open.push({ num: n, why: 'nije se moglo očitati: ne zna se da li je spremljeno' });
      m.at = Date.now();
      saveUser();
      if (want) {
        const msg = `Veza je pukla poslije slanja. Ponovo očitano iz StoreFronta: ${saved} ${plural(saved, 'potvrđena', 'potvrđene', 'potvrđenih')}, ${open.length} ${plural(open.length, 'nepotvrđena', 'nepotvrđene', 'nepotvrđenih')}.`;
        S.sm.result = open.length ? { done: saved, failed: open, reread: true, head: msg } : { done: saved, failed: [], reread: true, note: msg };
      } else if (S.sm.result && S.sm.result.failed) {
        // a row read again on its own: off the list of unsolved ones when it is now what was wanted or simply read
        S.sm.result = { ...S.sm.result, failed: S.sm.result.failed.filter((f) => !got.has(f.num)) };
      }
    } else if (!want) toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Vrijednosti se nisu mogle očitati. Pokušaj ponovo.');
    if (top().id === 'smdm') renderSm();
  });
  if (!ok) { S.sm.reading = null; if (top().id === 'smdm') renderSm(); }
}

function renderSm() {
  const box = $('#smBody');
  if (!box) return;
  // 1.98: after a saving or a re-read the employee stays where he was; 1.99: also back from the planogram (the hidden
  // screen may lose its scroll position)
  const keepTop = S.sm.top != null ? S.sm.top : box.scrollTop;
  S.sm.top = null;
  const m = smData();
  const garden = smGarden();
  const allList = (m && m.list) || [];
  const list = allList.filter(x => S.sm.filter === 'all' || x.st === S.sm.filter);
  const busy = S.deptBusy ? '<p class="count-line"><i class="mj-busy"></i> Prvi put: tražim u StoreFrontu grupe proizvoda tvog odjela (iz planograma)…</p>' : S.sm.busy === 'load' ? '<p class="count-line"><i class="mj-busy"></i> Čitam SM vrijednosti iz StoreFronta…</p>'
    : S.sm.busy === 'send' ? '<p class="count-line"><i class="mj-busy"></i> Spremam u StoreFront…</p>' : '';
  const res = S.sm.result;
  const whatNow = (f) => (f.changed ? 'kolega je promijenio: u redu je sada vrijednost iz StoreFronta, provjeri pa spremi ponovo' : f.cur ? 'u redu je vrijednost iz StoreFronta, spremi ponovo' : 'očitaj ponovo pa spremi');
  const resLine = res ? (res.err ? `<p class="ar-err">${esc(res.err)}</p>`
    : res.dry ? '<p class="sm-ok">TEST: promjene su simulirane, ništa nije poslano u StoreFront.</p>' : res.note ? `<p class="sm-ok">${esc(res.note)}</p>` : res.head ? `<p class="ar-err">${esc(res.head)}</p>${res.failed.length ? `<div class="ar-err sm-unsolved">${res.failed.slice(0, 15).map((f) => `<div class="sm-unsolved-row"><span><b>${esc(f.num)}</b> · ${esc(f.why || '')}<br><small>Šta sada: ${f.cur ? 'u redu je vrijednost iz StoreFronta, spremi ponovo' : 'očitaj ponovo pa odluči'}</small></span><button class="text-btn" type="button" data-sm-read="${esc(f.num)}" ${S.sm.busy ? 'disabled' : ''}>Očitaj ponovo</button></div>`).join('')}</div>` : ''}` : `<p class="sm-ok">Spremljeno u StoreFront: ${res.done} ${plural(res.done, 'artikal', 'artikla', 'artikala')}.</p>${res.failed.length ? `<div class="ar-err sm-unsolved"><b>Nije riješeno (${res.failed.length}):</b>${res.failed.slice(0, 15).map((f) => `<div class="sm-unsolved-row"><span><b>${esc(f.num)}</b> · ${esc(f.why || 'greška')}<br><small>Šta sada: ${esc(whatNow(f))}</small></span>${f.cur ? '' : `<button class="text-btn" type="button" data-sm-read="${esc(f.num)}" ${S.sm.busy ? 'disabled' : ''}>Očitaj ponovo</button>`}</div>`).join('')}${res.failed.length > 15 ? '<p>…</p>' : ''}</div>` : ''}`) : '';
  const intro = `<details class="sm-intro"><summary>Šta su SM i DM i šta kaže smjernica?</summary>
    <p><b>SM</b> (Sales Machine): artikli izloženi dugoročno izvan planograma (Powerline, endframe i slično). SM ulazi u SAO prijedlog narudžbe, da ta ekspozicija bude puna.</p>
    <p><b>DM</b> (Display Model): koliko komada je izloženo. Izloženi komadi se skidaju sa online zalihe trgovine (na JYSK.ba piše „Pogledajte proizvod u prodavnici“).</p>
    <p>Smjernica „Smjernice za vrijednosti SM/DM“ (MYJYSK 5127): <b>kad artikal pređe na status 21 (ukinut), uklonite SM/DM vrijednosti</b>. Svaki dan u StoreFrontu filtrirajte ukinute artikle sa SM/DM i uklonite vrijednosti starih artikala prije kraja ažuriranja prostora. StoreFrontov filter „ukinuti“ obuhvata statuse <b>21, 81 i 42</b>, SM i DM svaki za sebe: ukloni onu oznaku koja je postavljena. Vrt: kad završi sezona, ukloni sve DM vrijednosti. Vrijednosti unesene prije 22:00 ulaze u prijedlog narudžbe sljedećeg dana.</p>
    <p>Zamjena (novi broj artikla): SM/DM se uklanja sa stare šifre i dodjeljuje novoj (MYJYSK 134270 „Smjernice za zamjenu“).</p></details>`;
  const edits = [...Object.entries(S.sm.edit).filter(([n, e]) => { const x = list.find((y) => y.num === n); return x && known(x.sm) && known(x.dm) && !S.sm.move[n] && ((e.sm ?? x.sm) !== x.sm || (e.dm ?? x.dm) !== x.dm); }), ...Object.keys(S.sm.move).filter((n) => list.some((y) => y.num === n && y.succ))];
  const dis = S.sm.busy ? 'disabled' : '';
  const rows = list.map((x) => {
    const mv = !!(S.sm.move[x.num] && x.succ);
    const e = mv ? { sm: 0, dm: 0 } : S.sm.edit[x.num] || {};
    const v = e.sm ?? x.sm, w = e.dm ?? x.dm;
    const both = known(x.sm) && known(x.dm);
    const changed = mv || (both && (+v !== x.sm || +w !== x.dm));
    const p = smPlan(x);
    const reading = S.sm.reading && S.sm.reading.has(x.num);
    const taken = both && hasPlan(p) && +v === planEdit(x, p).sm && +w === planEdit(x, p).dm;
    const plan = p.unk.length
      ? `<div class="sm-plan is-unknown"><span><b>${p.unk.join(' i ')}: nije očitano</b><small>StoreFront nije vratio vrijednost. Bez nje nema prijedloga ni spremanja za ovaj red.</small></span><button class="text-btn" type="button" data-sm-read="${esc(x.num)}" ${S.sm.busy || reading ? 'disabled' : ''}>${reading ? 'Očitavam…' : 'Očitaj ponovo'}</button></div>`
      : hasPlan(p) ? `<div class="sm-plan${taken ? ' is-taken' : ''}"><span><b>Prijedlog: ${esc(p.text)}</b><small>${esc(p.why)}</small></span>${taken ? '<span class="sm-plan-ok">Prihvaćeno · čeka Spremi</span>' : `<button class="text-btn" type="button" data-sm-plan="${esc(x.num)}" ${dis}>Prihvati</button>`}</div>`
      : p.why ? `<div class="sm-plan is-none"><small>${esc(p.why)}</small></div>` : '';
    const to = mv ? smMoveItems(x)[1] : null;
    const succ = x.succ ? `<div class="sm-succ"><span>Zamjena: ${codeBtn(x.succ.num)} (status ${esc(x.succ.st)}${stText(x.succ.st) ? `, ${esc(stText(x.succ.st))}` : ''}) · SM ${whole(x.succ.sm)} · DM ${whole(x.succ.dm)} · na stanju ${whole(x.succ.stock)}</span>
        ${mv ? `<span class="sm-move-on">Prebacuje se: zamjena dobija SM ${whole(to.sm)}, DM ${whole(to.dm)}; stari broj na 0</span>` : ''}
        ${smNeedsMove(x) || mv ? `<button class="text-btn" type="button" data-sm-move="${esc(x.num)}" ${S.sm.busy ? 'disabled' : ''}>${mv ? 'Ne prebacuj' : 'Prebaci SM/DM na zamjenu'}</button>` : ''}</div>` : '';
    return `<div class="sm-row${changed ? ' is-changed' : ''}">
      <div class="sm-main">${codeBtn(x.num)}<span class="item-name">${esc(x.name)}</span>
        <span class="pills">${stPill(x.st)}${S.index.byNum.has(x.num) ? '<span class="pill">U planogramu</span>' : ''}${failTag(S.sm.result, x)}</span>
        <span class="sm-now">Sada u StoreFrontu: SM <b>${esc(smTxt(x.sm))}</b> · DM <b>${esc(smTxt(x.dm))}</b></span>
        <span class="sm-facts">Na stanju ${whole(x.stock)}${forSale(x)} · prodano 30 dana ${whole(x.sold30)}</span></div>
      ${plan}
      <label class="sm-edit"><span>SM</span><input type="number" inputmode="numeric" min="0" max="9999" value="${esc(v ?? '')}" placeholder="?" data-sm-in="${esc(x.num)}" data-k="sm" ${dis || (!both ? 'disabled' : '')}></label>
      <label class="sm-edit"><span>DM</span><input type="number" inputmode="numeric" min="0" max="9999" value="${esc(w ?? '')}" placeholder="?" data-sm-in="${esc(x.num)}" data-k="dm" ${dis || (!both ? 'disabled' : '')}></label>
      <button class="chip" type="button" data-sm-zero="${esc(x.num)}" ${dis || (!both ? 'disabled' : '')} aria-label="SM i DM na 0">0</button>
      ${succ}
    </div>`;
  }).join('');
  if (S.sm.scope === 'pick') {
    box.innerHTML = `<div class="pick-dept"><h3>SM i DM vrijednosti</h3>
      <p class="hint">Izaberi odjel koji želiš pregledati. Podaci se ne učitavaju automatski.</p>
      <button class="pick-dept-item" type="button" data-sm="scope" data-scope="dept">Moj odjel <span>›</span></button>
      <button class="pick-dept-item" type="button" data-sm="scope" data-scope="garden">Vrt · svi statusi <span>›</span></button>
      <button class="pick-dept-item" type="button" data-sm="scope" data-scope="other">Drugi odjel / podgrupa <span>›</span></button>
    </div>`;
    return;
  }
  const filterButtons = m && m.list ? `<div class="chips sm-scope" role="group" aria-label="Filter statusa">
    ${[['all','Svi'],['21','Status 21'],['81','Status 81'],['42','Status 42']].map(([id, label]) =>
      `<button class="chip" type="button" data-sm="filter" data-status="${id}" aria-pressed="${S.sm.filter === id}">${label}</button>`).join('')}
    </div>` : '';
  const eligible = list.filter(x => x.sm > 0 || x.dm > 0);
  const plans = list.filter((x) => !S.sm.move[x.num] && known(x.sm) && known(x.dm) && hasPlan(smPlan(x)));
  const unk = list.filter((x) => !known(x.sm) || !known(x.dm)).length;
  const bulkActions = m && m.list && eligible.length ? `<div class="sm-bulk">
    ${plans.length ? `<button class="btn btn-primary btn-block" type="button" data-sm="plans" ${S.sm.busy ? 'disabled' : ''}>Prihvati prijedloge (${plans.length})</button><p class="hint">Samo upisuje prijedloge u redove; ništa se ne šalje dok ne pritisneš Spremi.</p>` : ''}
    <p class="hint">Grupne opcije za ${eligible.length} artikala u izabranom filteru. Prvo se pokaže potvrda sa sažetkom.${unk ? ` ${unk} ${plural(unk, 'red nije očitan', 'reda nisu očitana', 'redova nije očitano')} i ne ulazi u grupnu izmjenu.` : ''}</p>
    <div class="sm-bulk-row">
      <button class="btn btn-soft" type="button" data-sm="bulk" data-zero="sm" ${S.sm.busy ? 'disabled' : ''}>SM → 0</button>
      <button class="btn btn-soft" type="button" data-sm="bulk" data-zero="dm" ${S.sm.busy ? 'disabled' : ''}>DM → 0</button>
      <button class="btn btn-soft" type="button" data-sm="bulk" data-zero="both" ${S.sm.busy ? 'disabled' : ''}>SM i DM → 0</button>
    </div>
  </div>` : '';
  const tabs = `<div class="chips sm-scope"><button class="chip" type="button" data-sm="scope" data-scope="pick" aria-pressed="false">Odjeli</button><button class="chip" type="button" data-sm="scope" data-scope="dept" aria-pressed="${S.sm.scope === 'dept'}" ${S.sm.busy ? 'disabled' : ''}>Moj odjel · 21, 81, 42</button><button class="chip" type="button" data-sm="scope" data-scope="garden" aria-pressed="${garden}" ${S.sm.busy ? 'disabled' : ''}>Vrt · sve</button><button class="chip" type="button" data-sm="scope" data-scope="other" aria-pressed="${smOther()}" ${S.sm.busy ? 'disabled' : ''}>Drugi odjel</button></div>`;
  const choice = smOther() ? `<div class="other-dept-box">
    <div class="top-head"><p class="count-line">${esc((smOtherGroup() || {}).title || 'Izaberi drugi odjel')}</p>
      ${smOtherGroup() ? '<button class="text-btn" type="button" data-sm="pick-more">Promijeni</button>' : ''}</div>
    ${S.sm.pick || !smOtherGroup() ? smHierBusy ? '<p class="count-line">Čitam odjele iz StoreFronta…</p>' :
      pickerHtml(S.user.hier, esc, 'sm', S.sm.otherId) : ''}</div>` : '';
  const readOnly = smOther() ? '<p class="hint">Drugi odjel: SM i DM možeš pojedinačno ili grupno pripremiti za 0. TEST ništa ne šalje.</p>' : '';
  const partial = m && m.limited ? '<p class="ar-err">Previše artikala za jedan pregled. Dio rezultata možda nedostaje — izaberi užu grupu.</p>' : '';
  const head = garden ? `${tabs}${busy}${resLine}` : smOther()
    ? `${tabs}${choice}${readOnly}${busy}${resLine}`
    : `<button class="orders-bar au-master" type="button" data-au-master>${icon('chart')}<span><b>Master provjera</b><small>Sve SM i DM vrijednosti odjela: ukinuti sa SM/DM i zamjene, SM bez prodaje, najprodavaniji bez SM</small></span><span class="go">Pokreni</span></button>${tabs}${intro}${deptChips('smdm')}${busy}${resLine}`;
  const what = garden ? `Vrt (vrtni namještaj, vrtni jastuci, suncobrani…) · svi statusi` : `${smOther() ? esc((smOtherGroup() || {}).title || 'Drugi odjel') : esc(deptName())} · status ${S.sm.st.join(' i ')}`;
  const none = garden ? '<p class="empty">Nijedan vrtni artikal nema SM ni DM.</p>' : '<p class="empty">Nijedan artikal sa statusom 21, 81 ili 42 nema SM ni DM. Sve je po smjernici.</p>';
  if (smOther() && (S.sm.pick || !smOtherGroup())) { box.innerHTML = head; return; }
  if (!m) { // chosen, nothing read yet: one clear button, as in Uskoro and Za rasprodaju (nothing is read on its own)
    box.innerHTML = `${head}${smLogLine()}<p class="count-line">${what}</p>${S.sm.busy ? '' : `<button class="btn btn-primary btn-block" type="button" data-sm="reload">${icon('refresh')}Učitaj iz StoreFronta</button>`}`;
    return;
  }
  box.innerHTML = `${head}${partial}${smLogLine()}
    <div class="top-head"><p class="count-line">${what} · ${list.length} sa SM ili DM · ${esc(ageText(m.at))}</p>
      <button class="text-btn" type="button" data-sm="reload" ${S.sm.busy ? 'disabled' : ''}>${icon('refresh')}Osvježi</button></div>
    ${filterButtons}${bulkActions}${!list.length && m && !S.sm.busy ? (allList.length ? '<p class="empty">Nema artikala za odabrani filter statusa.</p>' : none) : ''}
    ${rows ? `<div class="sm-list">${rows}</div>` : ''}
    ${edits.length ? `<div class="sm-save"><button class="btn btn-primary btn-block" type="button" data-sm="save" ${dis}>Spremi promjene (${edits.length})</button></div>` : ''}`;
  box.scrollTop = keepTop;
}

async function onSmClick(t) {
  // Every department can be previewed and edited in TEST, with a confirmation before a batch.
  if (t.dataset.smZero) { S.sm.edit[t.dataset.smZero] = { sm: 0, dm: 0 }; delete S.sm.move[t.dataset.smZero]; S.sm.result = null; renderSm(); return; }
  if (t.dataset.smPlan) {
    const x = ((smData() && smData().list) || []).find((y) => y.num === t.dataset.smPlan);
    if (x && known(x.sm) && known(x.dm)) { S.sm.edit[x.num] = planEdit(x, smPlan(x)); delete S.sm.move[x.num]; }
    renderSm(); return;
  }
  if (t.dataset.smRead) { if (!S.sm.busy) smReadRows([t.dataset.smRead]); return; }
  if (t.dataset.smCode) { codeSheet(t.dataset.smCode); return; }
  if (t.dataset.smMove) { const n = t.dataset.smMove; if (S.sm.move[n]) delete S.sm.move[n]; else { S.sm.move[n] = true; delete S.sm.edit[n]; } S.sm.result = null; renderSm(); return; }
  const a = t.dataset.sm;
  const list = (smData() && smData().list) || [];
  if (a === 'scope') {
    if (S.sm.busy || smHierBusy) return;
    S.sm.scope = ['dept','garden','other','pick'].includes(t.dataset.scope) ? t.dataset.scope : 'pick';
    S.sm.pick = smOther() && !smOtherGroup();
    S.sm.edit = {}; S.sm.move = {}; S.sm.result = null; S.sm.filter = 'all'; renderSm(); return;
  }
  if (a === 'hier' || 'smHier' in t.dataset) { loadSmHierarchy(); return; }
  if (a === 'pick-more') { S.sm.pick = true; renderSm(); return; }
  if (t.dataset.smPick) {
    if (S.sm.busy || smHierBusy) return;
    const g = validGroup(S.user.hier, t.dataset.smPick);
    if (!g) { toast('Nepoznata grupa u StoreFrontu. Osvježi spisak.'); return; }
    S.sm.scope = 'other'; S.sm.otherId = g.id; S.sm.pick = false;
    S.sm.edit = {}; S.sm.move = {}; S.sm.result = null;
    renderSm(); return;
  }
  if (a === 'reload') { S.sm.result = null; loadSm(); return; }
  if (a === 'plans') {
    for (const x of list) if ((S.sm.filter === 'all' || x.st === S.sm.filter) && !S.sm.move[x.num] && known(x.sm) && known(x.dm) && hasPlan(smPlan(x))) S.sm.edit[x.num] = planEdit(x, smPlan(x));
    renderSm(); return;
  }
  if (a === 'filter') {
    S.sm.filter = ['all','21','81','42'].includes(t.dataset.status) ? t.dataset.status : 'all';
    renderSm(); return;
  }
  if (a === 'bulk') {
    const selected = smData();
    if (!selected || !selected.list || S.sm.busy) return;
    if (selected.limited) {
      toast('Lista nije potpuna. Izaberi užu grupu i osvježi je prije grupne izmjene.');
      return;
    }
    const field = ['sm','dm','both'].includes(t.dataset.zero) ? t.dataset.zero : '';
    if (!field) return;
    // 1.98: a row with a value StoreFront did not give is never part of a batch (no "was" to compare with)
    const source = selected.list.filter(x =>
      (S.sm.filter === 'all' || x.st === S.sm.filter) && known(x.sm) && known(x.dm) &&
      (field === 'sm' ? x.sm > 0 : field === 'dm' ? x.dm > 0 : x.sm > 0 || x.dm > 0));
    if (!source.length) { toast('Nema artikala za ovu promjenu.'); return; }
    if (source.length > 300) {
      toast('Previše artikala odjednom. Izaberi manju grupu ili status (najviše 300).');
      return;
    }
    const items = source.map(x => ({
      num: x.num, sm: field === 'dm' ? x.sm : 0, dm: field === 'sm' ? x.dm : 0,
      was: { sm: x.sm, dm: x.dm }
    }));
    const scopeTitle = smOther() ? (smOtherGroup() || {}).title : smGarden() ? 'Vrt' : deptName();
    const title = field === 'both' ? 'SM i DM' : field.toUpperCase();
    const bare = source.filter(smNeedsMove);
    const bareLine = bare.length ? `<p class="ar-err">${bare.length} ${plural(bare.length, 'artikal ima', 'artikla imaju', 'artikala ima')} zamjenu bez SM/DM (${bare.slice(0, 4).map((x) => `${esc(x.num)} → ${esc(x.succ.num)}`).join(', ')}${bare.length > 4 ? ', …' : ''}). Grupna izmjena ih ne prebacuje: ako zamjena treba dobiti ekspoziciju, prvo u redu tapni „Prebaci SM/DM na zamjenu“ i spremi.</p>` : '';
    const yes = await ask(`Postaviti ${title} na 0 za ${source.length} artikala?`,
      `<p><b>Odjel:</b> ${esc(scopeTitle || '')}</p><p><b>Status:</b> ${esc(S.sm.filter === 'all' ? 'svi prikazani' : S.sm.filter)}</p>
      <p>Promjena samo odabranih polja. Statusi i zamjenske šifre se NE mijenjaju automatski.</p>
      <p>Provjeri da li artikal ima zamjenu prije uklanjanja SM/DM. TEST aplikacija neće slati izmjene.</p>${bareLine}
      <p>${source.slice(0, 12).map(x => esc(x.num) + ': SM ' + x.sm + ', DM ' + x.dm).join('<br>')}${source.length > 12 ? '<br>…' : ''}</p>`,
      [{ label: 'Potvrdi odabrane promjene', kind: 'btn-primary', value: true },
       { label: 'Odustani', value: false }]);
    if (yes && top().id === 'smdm' && !S.sm.busy) smSend(items);
    return;
  }
  // A TEST build never writes to StoreFront; production writes still use smJob's compare-before-set.
  let items = [];
  let moves = 0;
  if (a === 'all0') {
    const need = list.filter(smNeedsMove);
    let how = 'zero';
    if (need.length) {
      how = await ask(`${need.length} ${plural(need.length, 'artikal ima', 'artikla imaju', 'artikala ima')} zamjenu bez SM/DM`,
        `<p>Stari broj (21/81) ima SM ili DM, a njegov novi broj (zamjena, npr. status 11 ili 12) nema. Ako samo ukloniš sa starog, ekspozicija novog broja se više neće dopunjavati.</p><p>Prebacivanje: novi broj dobija SM/DM starog (ako već ima više, ostaje njegov), stari ide na 0.</p>`,
        [{ label: `Prebaci na zamjene (${need.length}) i ukloni sa starih`, kind: 'btn-primary', value: 'move' }, { label: 'Samo ukloni sa starih', value: 'zero' }, { label: 'Odustani', value: '' }]);
      if (!how) return;
    }
    for (const x of list) {
      if (!known(x.sm) || !known(x.dm)) continue;
      if (how === 'move' && smNeedsMove(x)) { items.push(...smMoveItems(x)); moves++; } else items.push({ num: x.num, sm: 0, dm: 0, was: { sm: x.sm, dm: x.dm } });
    }
  }
  if (a === 'save') {
    for (const x of list) {
      if (S.sm.move[x.num] && x.succ) { items.push(...smMoveItems(x)); moves++; continue; }
      const e = S.sm.edit[x.num];
      if (e && known(x.sm) && known(x.dm) && ((e.sm ?? x.sm) !== x.sm || (e.dm ?? x.dm) !== x.dm)) items.push({ num: x.num, sm: e.sm ?? x.sm, dm: e.dm ?? x.dm, was: { sm: x.sm, dm: x.dm } });
    }
  }
  if (!items.length) return;
  const olds = items.length - moves;
  const zero = items.filter((x) => x.sm === 0 && x.dm === 0).length;
  const go2 = a === 'all0' && list.some(smNeedsMove) ? true : await ask(`Promijeniti SM/DM za ${olds} ${plural(olds, 'artikal', 'artikla', 'artikala')}?`,
    `<p>Promjena se odmah sprema u StoreFront pod tvojom prijavom.${zero ? smGarden() ? ` Za ${zero} vrtnih artikala SM i DM idu na 0: više ne ulaze u prijedlog narudžbe, a izloženi komadi se vraćaju u online zalihu.` : ` Za ${zero} ${plural(zero, 'artikal', 'artikla', 'artikala')} SM i DM su poslije spremanja 0 (smjernica: ukinuti 21, a StoreFront u ukinute ubraja i 81 i 42): više ne ulaze u prijedlog narudžbe, a izloženi komadi se vraćaju u online zalihu.` : ''}${moves ? ` ${moves} ${plural(moves, 'zamjena dobija', 'zamjene dobijaju', 'zamjena dobija')} SM/DM starog broja.` : ''}</p>`,
    [{ label: 'Spremi u StoreFront', kind: 'btn-primary', value: true }, { label: 'Odustani', value: false }]);
  if (go2) smSend(items);
}

// ------------------------------------------------ Master provjera: every SM/DM value of the department checked

S.au = { busy: '', edit: {}, move: {}, result: null, open: new Set(['out']) };

function openAudit() {
  S.au.edit = {};
  S.au.move = {};
  S.au.result = null;
  go('audit');
  renderAudit();
  const a = S.user.audit;
  if (!a || !a.list || a.dept !== deptSig() || !deptGroups() || Date.now() - a.at > 30 * 60000) loadAudit();
}

/** StoreFront 6.9.0 "Prodajna zaliha": said only when it differs from the stock (reserved for customers). */
const forSale = (x) => (Number.isFinite(x.free) && x.free !== x.stock ? ` (za prodaju ${whole(x.free)})` : '');
const auKeep = (x) => ({ num: x.num, name: x.name, st: x.st, unit: x.unit, stock: +x.stock || 0, ...(Number.isFinite(x.free) ? { free: x.free } : {}), sm: +x.sm || 0, dm: +x.dm || 0, cap: +x.cap || 0, sold30: +x.sold30 || 0,
  succ: x.succ && /^\d{7}$/.test(x.succ.num) ? { num: x.succ.num, st: String(x.succ.st || ''), sm: +x.succ.sm || 0, dm: +x.succ.dm || 0, stock: +x.succ.stock || 0 } : null });

function loadAudit() {
  if (S.au.busy) return;
  S.au.busy = 'load';
  renderAudit();
  withDept(() => loadAudit2());
}

function loadAudit2() {
  const ok = stCall({ mode: 'audit', cat: cfg().group || '5', ...deptArg() }, (r) => {
    S.au.busy = '';
    if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
      S.user.audit = { dept: deptSig(), at: Date.now(), list: r.res.list.slice(0, 800).map(auKeep), top: (r.res.top || []).slice(0, 40).map(auKeep) };
      saveUser();
    } else {
      toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Provjera se nije mogla učitati. Pokušaj ponovo.');
    }
    if (top().id === 'audit') renderAudit();
  });
  if (!ok) { S.au.busy = ''; toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); renderAudit(); }
}

function auGroups() {
  const a = S.user.audit;
  return a && a.list ? smcheck.check(a.list, a.top, (n) => S.index.byNum.has(n)) : null;
}

function auRow(x, gid) {
  const dis = S.au.busy ? 'disabled' : '';
  const mv = !!(S.au.move[x.num] && x.succ);
  const e = mv ? { sm: 0, dm: 0 } : S.au.edit[x.num] || {};
  const v = e.sm ?? x.sm, w = e.dm ?? x.dm;
  const changed = mv || +v !== x.sm || +w !== x.dm;
  const to = mv ? smMoveItems(x)[1] : null;
  const facts = [`na stanju ${whole(x.stock)}${forSale(x)}`, `prodano 30 dana ${whole(x.sold30)}`, x.cap ? `kapacitet svih polica ${whole(x.cap)}` : ''].filter(Boolean).join(' · ');
  const succ = gid === 'out' && x.succ ? `<div class="sm-succ"><span>Zamjena: <b>${esc(x.succ.num)}</b> (status ${esc(x.succ.st)}) · SM ${whole(x.succ.sm)} · DM ${whole(x.succ.dm)}</span>
      ${mv ? `<span class="sm-move-on">Prebacuje se: zamjena dobija SM ${whole(to.sm)}, DM ${whole(to.dm)}; stari broj na 0</span>` : ''}
      ${smNeedsMove(x) || mv ? `<button class="text-btn" type="button" data-au-move="${esc(x.num)}" ${dis}>${mv ? 'Ne prebacuj' : 'Prebaci SM/DM na zamjenu'}</button>` : ''}</div>` : '';
  return `<div class="sm-row${changed ? ' is-changed' : ''}">
    <div class="sm-main"><span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.name)}</span>
      <span class="pills">${stPill(x.st)}${S.index.byNum.has(x.num) ? '<span class="pill">U planogramu</span>' : ''}</span>
      <span class="sm-facts">${facts}</span></div>
    <label class="sm-edit"><span>SM</span><input type="number" inputmode="numeric" min="0" max="9999" value="${esc(v)}" data-au-in="${esc(x.num)}" data-k="sm" ${dis}></label>
    <label class="sm-edit"><span>DM</span><input type="number" inputmode="numeric" min="0" max="9999" value="${esc(w)}" data-au-in="${esc(x.num)}" data-k="dm" ${dis}></label>
    <button class="chip" type="button" data-au-zero="${esc(x.num)}" ${dis} aria-label="SM i DM na 0">0</button>
    ${succ}
  </div>`;
}

/** Everything changed on the screen, as StoreFront takes it. */
function auItems() {
  const a = S.user.audit;
  if (!a) return [];
  const by = new Map([...a.list, ...(a.top || [])].map((x) => [x.num, x]));
  const items = [];
  for (const [n, x] of by) {
    if (S.au.move[n] && x.succ) { items.push(...smMoveItems(x)); continue; }
    const e = S.au.edit[n];
    if (e && ((e.sm ?? x.sm) !== x.sm || (e.dm ?? x.dm) !== x.dm)) items.push({ num: n, sm: e.sm ?? x.sm, dm: e.dm ?? x.dm, was: { sm: x.sm, dm: x.dm } });
  }
  return items;
}

function auSend(items) {
  if (!items.length || S.au.busy) return;
  const ok = smJob(items, (r) => {
    S.au.busy = '';
    if (r.how === 'ok' && r.res) {
      const done = new Set(r.res.done || []);
      const want = new Map(items.map((x) => [x.num, x]));
      const a = S.user.audit;
      if (a) {
        const upd = (x) => {
          let y = done.has(x.num) ? { ...x, sm: want.get(x.num).sm, dm: want.get(x.num).dm } : x;
          if (y.succ && done.has(y.succ.num)) y = { ...y, succ: { ...y.succ, sm: want.get(y.succ.num).sm, dm: want.get(y.succ.num).dm } };
          return y;
        };
        a.list = a.list.map(upd).filter((x) => x.sm > 0 || x.dm > 0);
        a.top = (a.top || []).map(upd);
        saveUser();
      }
      for (const n of done) { delete S.au.edit[n]; delete S.au.move[n]; }
      S.au.result = { done: done.size, failed: r.res.failed || [] };
    } else {
      S.au.result = { done: 0, failed: [], err: r.how === 'login' ? 'StoreFront traži prijavu. Učitaj provjeru ponovo da vidiš šta je promijenjeno.' : netDown(r) ? NET_SAVE : 'StoreFront nije odgovorio do kraja. Učitaj provjeru ponovo.' };
    }
    S.user.smdm = null; // the SM screen reads again
    renderSmBar();
    if (top().id === 'audit') renderAudit();
  });
  if (!ok) { toast('Ova verzija aplikacije to ne zna. Ažuriraj je.'); return; }
  S.au.busy = 'send';
  renderAudit();
}

function renderAudit() {
  const box = $('#auditBody');
  if (!box) return;
  const a = S.user.audit;
  const busy = S.deptBusy ? '<p class="count-line"><i class="mj-busy"></i> Prvi put: tražim u StoreFrontu grupe proizvoda tvog odjela (iz planograma)…</p>' : S.au.busy === 'load' ? '<p class="count-line"><i class="mj-busy"></i> Provjeravam sve SM i DM vrijednosti odjela u StoreFrontu… (do jedne minute)</p>'
    : S.au.busy === 'send' ? '<p class="count-line"><i class="mj-busy"></i> Spremam u StoreFront…</p>' : '';
  const res = S.au.result;
  const resLine = res ? (res.err ? `<p class="ar-err">${esc(res.err)}</p>`
    : `<p class="sm-ok">Spremljeno u StoreFront: ${res.done} ${plural(res.done, 'artikal', 'artikla', 'artikala')}.${res.failed.length ? ` Nije prošlo: ${res.failed.map((f) => esc(f.num)).join(', ')}.` : ''}</p>`) : '';
  const head = `<div class="top-head"><p class="count-line">${a ? `${esc(deptName())} · ${a.list.length} ${plural(a.list.length, 'artikal', 'artikla', 'artikala')} sa SM ili DM · ${esc(ageText(a.at))}` : ''}</p>
    <button class="text-btn" type="button" data-au="reload" ${S.au.busy ? 'disabled' : ''}>${icon('refresh')}Provjeri ponovo</button></div>`;
  const g = auGroups();
  if (!g) { box.innerHTML = `${busy}${resLine}${head}${deptChips('audit')}`; return; }
  const n = smcheck.total(g);
  const sum = n ? `<div class="au-sum">${smcheck.GROUPS.filter((x) => g[x.id].length).map((x) => `<button class="au-chip${x.fix ? ' is-fix' : ''}" type="button" data-au-go="${x.id}"><b>${g[x.id].length}</b>${esc(x.title)}</button>`).join('')}</div>`
    : '<div class="mj-intro"><h3>Sve je u redu ✓</h3><p>Nema ukinutih artikala sa SM/DM, ni drugih sumnjivih vrijednosti u odjelu.</p></div>';
  const groups = smcheck.GROUPS.filter((x) => g[x.id].length).map((x) => {
    const open = S.au.open.has(x.id);
    const fixAll = x.fix ? `<button class="btn btn-primary btn-block btn-small" type="button" data-au="fixout" ${S.au.busy ? 'disabled' : ''}>Riješi sve po smjernici (${g.out.length})</button>` : '';
    return `<section class="au-group" id="au-${x.id}">
      <button class="au-head" type="button" data-au-open="${x.id}" aria-expanded="${open}"><span><b>${esc(x.title)}</b><small>${g[x.id].length} ${plural(g[x.id].length, 'artikal', 'artikla', 'artikala')}</small></span>${icon('chev', 'chev')}</button>
      ${open ? `<p class="au-why">${esc(x.why)}</p>${fixAll}<div class="sm-list">${g[x.id].map((y) => auRow(y, x.id)).join('')}</div>` : ''}
    </section>`;
  }).join('');
  const items = auItems();
  box.innerHTML = `${busy}${resLine}${head}${deptChips('audit')}${sum}${groups}
    ${items.length ? `<div class="sm-save"><button class="btn btn-primary btn-block" type="button" data-au="save" ${S.au.busy ? 'disabled' : ''}>Spremi promjene (${items.length})</button></div>` : ''}`;
}

async function onAuClick(t) {
  const d = t.dataset;
  if (d.auOpen) { if (S.au.open.has(d.auOpen)) S.au.open.delete(d.auOpen); else S.au.open.add(d.auOpen); renderAudit(); return; }
  if (d.auGo) { S.au.open.add(d.auGo); renderAudit(); const el = $(`#au-${d.auGo}`); if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); return; }
  if (d.auZero) { S.au.edit[d.auZero] = { sm: 0, dm: 0 }; delete S.au.move[d.auZero]; S.au.result = null; renderAudit(); return; }
  if (d.auMove) { if (S.au.move[d.auMove]) delete S.au.move[d.auMove]; else { S.au.move[d.auMove] = true; delete S.au.edit[d.auMove]; } S.au.result = null; renderAudit(); return; }
  if (d.au === 'reload') { S.au.result = null; loadAudit(); return; }
  let items = [];
  if (d.au === 'fixout') {
    const g = auGroups();
    for (const x of g.out) items.push(...(smNeedsMove(x) ? smMoveItems(x) : [{ num: x.num, sm: 0, dm: 0, was: { sm: x.sm, dm: x.dm } }]));
    const moves = g.out.filter(smNeedsMove).length;
    const yes = await ask(`Riješiti ${g.out.length} ${plural(g.out.length, 'ukinut artikal', 'ukinuta artikla', 'ukinutih artikala')}?`,
      `<p>Po smjernici: SM i DM idu na 0.${moves ? ` ${moves} ${plural(moves, 'ima zamjenu', 'imaju zamjenu', 'ima zamjenu')} bez SM/DM: ${plural(moves, 'njoj se', 'njima se', 'njima se')} prebacuje SM/DM starog broja.` : ''} Sprema se odmah u StoreFront pod tvojom prijavom.</p>`,
      [{ label: 'Spremi u StoreFront', kind: 'btn-primary', value: true }, { label: 'Odustani', value: false }]);
    if (yes) auSend(items);
    return;
  }
  if (d.au === 'save') {
    items = auItems();
    if (!items.length) return;
    const yes = await ask(`Spremiti promjene za ${items.length} ${plural(items.length, 'artikal', 'artikla', 'artikala')}?`,
      `<p>${items.map((x) => `${esc(x.num)}: SM ${whole(x.sm)}, DM ${whole(x.dm)}`).slice(0, 12).join('<br>')}${items.length > 12 ? '<br>…' : ''}</p><p>Sprema se odmah u StoreFront pod tvojom prijavom.</p>`,
      [{ label: 'Spremi u StoreFront', kind: 'btn-primary', value: true }, { label: 'Odustani', value: false }]);
    if (yes) auSend(items);
  }
}


  return { loadAudit, loadSm, onAuClick, onSmClick, openAudit, openSm, renderAudit, renderSm, renderSmBar, smJob };
}
