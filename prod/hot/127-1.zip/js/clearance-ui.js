import { pickerHtml, validGroup, loadHierarchy } from './other-depts.js';
import { createListWindow } from './list-window.js';
// Za rasprodaju: articles with status 21 / 81 in the department, their stock and SM/DM.
// Moved out of app.js in 1.70 WITHOUT changing a line of what it does.

/* eslint-disable indent */ // the body is app.js's former section as it was (not re-indented: template texts unchanged)
export function createClearanceUi(ctx) {
  const { $, A, CLR_ST, S, ageText, ask, cfg, core, deptUsed, esc, go, icon, norm, plural, renderPlans, saveUser, smJob, stCall, thumb, toast, top, withDept } = ctx;

S.clr = { st: 'all', sort: 'stock', q: '', peek: false, dept: 'pick', otherId: '', pick: false, busy: '' };
let hierarchyBusy = false;
const clrWindow = createListWindow(48);
const selectedGroup = () => validGroup(S.user.hier, S.clr.otherId);
const clearanceKey = (dept = S.clr.dept) => dept === 'other' ? 'other:' + S.clr.otherId : dept;
const clearanceTitle = (dept = S.clr.dept) => dept === 'furn' ? 'Namještaj' :
  dept === 'other' ? (selectedGroup() || {}).title || 'Drugi odjel' : 'Moj odjel';
function clearHierarchy() {
  if (hierarchyBusy || S.clr.busy) return;
  hierarchyBusy = true;
  renderClearance();
  const ok = loadHierarchy({ S, stCall, saveUser, toast, done() {
    hierarchyBusy = false;
    if (top().id === 'clearance') renderClearance();
  } });
  if (!ok) { hierarchyBusy = false; toast('StoreFront trenutno nije dostupan.'); renderClearance(); }
}
function onClearDept(t) {
  if (S.clr.busy || hierarchyBusy) return;
  if ('clrHier' in t.dataset) { clearHierarchy(); return; }
  if ('clrPickMore' in t.dataset) { S.clr.pick = true; renderClearance(); return; }
  if (t.dataset.clrPick) {
    const g = validGroup(S.user.hier, t.dataset.clrPick);
    if (!g) { toast('Nepoznata grupa u StoreFrontu. Osvježi spisak.'); return; }
    S.clr.otherId = g.id;
    S.clr.dept = 'other';
    S.clr.pick = false;
    S.clr.st = 'all'; S.clr.q = '';
    renderClearance();
    return;
  }
  if (t.dataset.clrDept) {
    const next = t.dataset.clrDept;
    if (!['home', 'furn', 'other', 'pick'].includes(next)) return;
    S.clr.dept = next;
    S.clr.pick = next === 'other' && !selectedGroup();
    S.clr.st = 'all'; S.clr.q = '';
    renderClearance();
    // Choosing a scope never starts a potentially large StoreFront query.
    // The user explicitly starts reading with the Učitaj button.
  }
} // peek: show the Christmas / New Year articles for now
// with the background StoreFront jobs the list is read through StoreFront's own search (assets/store-task.js clear):
// the department's own product groups (no cleaning, laundry or storage of other departments), or furniture
const clrNew = () => !!A.storeTask;
/** The list that is shown: { at, st, group, list } of the department (home) or of furniture, or the old read. */
function clrSrc(dept = S.clr.dept) {
  if (!clrNew()) return S.user.clear;
  const id = dept === 'other' ? clearanceKey(dept) : dept;
  if (dept === 'pick') return null;
  const d = (S.user.clr2 || {})[id];
  return d && d.list ? { at: d.at, total: +d.total || d.list.length, limited: !!d.limited, st: CLR_ST, group: dept === 'furn' ? '4' : dept === 'other' ? S.clr.otherId : cfg().group, list: d.list, dept } : null;
}
const clrStatuses = () => CLR_ST.filter((k) => cfg().clr[k]);
const whole = (n) => { try { return Math.round(n).toLocaleString('de-DE'); } catch (e) { return String(Math.round(n)); } };
const money = (n) => { try { return Number(n).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); } catch (e) { return Number(n).toFixed(2); } };
const dmy = (s) => String(s || '').replace(/-/g, '.');

function refreshClearance() {
  if (S.clr.dept === 'pick' || (S.clr.dept === 'other' && !selectedGroup())) { renderClearance(); return; }
  if (clrNew()) { loadClr2(S.clr.dept); return; }
  const st = clrStatuses();
  if (!st.length) { toast('Uključi bar jedan status u postavkama.'); return; }
  if (!A.clearance) { toast('Ova verzija ne zna čitati listu.'); return; }
  A.clearance(JSON.stringify(st), cfg().group);
}

function openClearance() {
  S.clr.dept = 'pick';
  renderClearance();
  go('clearance');
  // A screen opens immediately. StoreFront reads happen only after a selection and Učitaj.
}

/**
 * The stored list as it is shown. What matters is selling the articles off, so an article with nothing in stock never
 * shows (StoreFront is asked for articles in stock, but this does not depend on it). Christmas and New Year articles
 * (a name with one of the words in the settings) are left out too, unless the setting is off or the screen was asked
 * to show them for now (`peek`; the list screen's own switch, other screens pass false). `xmas` counts them, `flag`
 * says which ones they are.
 */
function clrView(peek = S.clr.peek, src = clrSrc()) {
  const c = src;
  // furniture: also what is on display (DM) with nothing in stock; without a replacement number still sold
  const all = (c && c.list ? c.list : []).filter((x) => (c.dept === 'furn' ? (core.inStock(x) || x.dm > 0) && !x.succ : c.dept === 'other' ? core.inStock(x) || x.dm > 0 : core.inStock(x)));
  const words = cfg().noxmas ? core.wordMatcher(cfg().xmas) : null;
  const test = words && c && c.dept === 'home' ? (name, x) => words(name) || (x && String(x.group || '').startsWith('512')) : words && !(c && c.dept) ? words : null;
  if (!test) return { list: all, xs: [], xmas: 0, flag: () => false };
  const xs = all.filter((x) => test(x.name, x));
  const hit = new Set(xs.map((x) => x.num));
  return { list: peek ? all : all.filter((x) => !hit.has(x.num)), xs, xmas: xs.length, flag: (x) => hit.has(x.num) };
}

function renderClearBar() {
  const b = $('#clearBar');
  if (!b) return;
  const has = S.plans.length > 0 && S.mode !== 'news'; // 2.23: not under Vijesti
  b.hidden = !has;
  if (!has) return;
  const c = clrSrc('home');
  const ic = icon('box');
  if (!c || !c.list) {
    b.innerHTML = `${ic}<span><b>Artikli za rasprodaju</b><small>Status ${clrStatuses().join(' i ')} sa zalihom, iz StoreFronta</small></span><span class="go">Učitaj</span>`;
    return;
  }
  const v = clrView(false, c);
  const n = (s) => v.list.filter((x) => x.st === s).length;
  b.innerHTML = `${ic}<span><b>Za rasprodaju: ${v.list.length}</b><small>${c.st.map((k) => `Status ${k}: ${n(k)}`).join(' · ')} · ${esc(ageText(c.at))}</small></span><span class="go">Otvori</span>`;
}

function clrFiltered() {
  const c = clrSrc();
  if (!c || !c.list) return [];
  const toks = norm(S.clr.q).split(/\s+/).filter(Boolean);
  let list = clrView().list.filter((x) => S.clr.st === 'all' || x.st === S.clr.st);
  if (toks.length) {
    list = list.filter((x) => {
      const hay = norm(`${x.num} ${x.name}`);
      return toks.every((t) => hay.includes(t));
    });
  }
  const val = (x) => (x.price || 0) * x.stock;
  const by = S.clr.sort;
  if (by === 'num') return list.sort((a, b) => a.num.localeCompare(b.num));
  list.sort((a, b) => (by === 'value' ? val(b) - val(a) : by === 'new' ? core.dateKey(b.chg) - core.dateKey(a.chg) : b.stock - a.stock) || a.name.localeCompare(b.name, 'bs'));
  // furniture: what stands on display with nothing in stock comes first (customers do not see it)
  if (c.dept === 'furn') list.sort((a, b) => (+(b.dm > 0 && b.stock <= 0)) - (+(a.dm > 0 && a.stock <= 0)));
  return list;
}

/** Reads the list of the department (home: its own product groups, no Christmas) or of furniture. */
function loadClr2(dept) {
  if (S.clr.busy) return;
  S.clr.busy = dept;
  renderClearance();
  const run = () => {
    const used = deptUsed().map((x) => x.id).filter((id) => !id.startsWith('512')); // Christmas is never on this list
    const other = dept === 'other' ? selectedGroup() : null;
    if (dept === 'other' && !other) {
      S.clr.busy = ''; toast('Prvo izaberi odjel iz StoreFronta.'); renderClearance(); return;
    }
    const arg = dept === 'furn' ? { cats: ['4'] } :
      other ? { cats: [other.id] } :
      used.length ? { cats: used } : { cat: cfg().group || '5' };
    const cacheKey = clearanceKey(dept);
    const ok = stCall({ mode: 'clear', ...arg }, (r) => {
      S.clr.busy = '';
      if (r.how === 'ok' && r.res && Array.isArray(r.res.list)) {
        const list = r.res.list.slice(0, 600).filter((x) => /^\d{7}$/.test(x.num)).map((x) => ({
          num: x.num, name: String(x.name || ''), st: String(x.st || ''), unit: String(x.unit || 'KOM'), stock: +x.stock || 0, free: +x.free || 0,
          sm: +x.sm || 0, dm: +x.dm || 0, price: x.price ? +x.price : null, reg: x.reg ? +x.reg : null, chg: String(x.chg || '').slice(0, 10).replace(/\./g, '-'),
          group: String(x.group || ''), groupName: String(x.groupName || ''), succ: x.succ && /^\d{7}$/.test(x.succ.num) ? { num: x.succ.num, st: String(x.succ.st || '') } : null,
        }));
        S.user.clr2 = { ...(S.user.clr2 || {}), [cacheKey]: { at: Date.now(), list, total: +r.res.total || list.length, limited: !!r.res.limited } };
        saveUser();
        const n = clrView(false, S.clr.dept === dept && clearanceKey(dept) === cacheKey ? clrSrc(dept) : { list, dept }).list.length;
        toast(`Učitano: ${n} ${plural(n, 'artikal', 'artikla', 'artikala')}`);
      } else {
        toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Lista se nije mogla učitati. Pokušaj ponovo.');
      }
      if (top().id === 'clearance') renderClearance();
      if (top().id === 'plans') renderPlans();
      renderClearBar();
    });
    if (!ok) { S.clr.busy = ''; renderClearance(); }
  };
  if (dept === 'home') withDept(run); else run();
}

/** A furniture row (or one with a DM): on display with nothing in stock means customers do not see it as in stock. */
function clrRowFurn(x, xm) {
  const shown = x.dm > 0;
  const hidden = shown && x.stock <= 0;
  const cut = x.reg != null && x.price != null && x.reg > x.price;
  const meta = [x.chg ? `Status od ${dmy(x.chg)}` : '', x.groupName].filter(Boolean).join(' · ');
  return `<div class="clr-furn${hidden ? ' is-hidden' : ''}">
    <button class="item clr-item" type="button" data-store="${esc(x.num)}">
      ${thumb(x.num)}
      <span class="item-main">
        <span class="code">${esc(x.num)}<span class="pill pill-st pill-st${esc(x.st)}">Status ${esc(x.st)}</span>${shown ? `<span class="pill pill-dm">Na izlogu · DM ${whole(x.dm)}</span>` : ''}${xm ? '<span class="pill pill-st pill-xmas">Božić</span>' : ''}</span>
        <span class="item-name">${esc(x.name) || 'Bez naziva'}</span>
        <span class="clr-line"><b>${whole(x.stock)} ${esc(x.unit || 'KOM')}</b> na zalihi${x.price != null ? ` · ${money(x.price)} KM` : ''}${cut ? ` <s>${money(x.reg)}</s>` : ''}</span>
        ${meta ? `<span class="clr-sub">${esc(meta)}</span>` : ''}
      </span>
      ${icon('chev', 'chev')}
    </button>
    ${hidden ? `<div class="clr-dm"><span>${x.stock + x.dm > 0
      ? `Zaliha ${whole(x.stock)}, a ${x.dm > 1 ? `${whole(x.dm)} komada stoje` : 'komad stoji'} u DM: kupci ${x.dm > 1 ? 'ih' : 'ga'} ne vide na zalihi. Kad se skine s DM, zaliha pređe sa ${whole(x.stock)} na ${whole(x.stock + x.dm)}.`
      : `Zaliha ${whole(x.stock)} uz DM ${whole(x.dm)}: izloženi komad je vjerovatno prodan, a DM nije skinut. Kad se skine s DM, zaliha bude ${whole(x.stock + x.dm)} (tačno stanje).`}</span>
      ${S.clr.dept === 'other' ? '' : `<button class="btn btn-soft btn-small" type="button" data-clr-dm="${esc(x.num)}" ${S.clr.busy ? 'disabled' : ''}>Skini s DM (DM na 0)</button>`}</div>` : ''}
  </div>`;
}

async function clrDmOff(num) {
  const src = clrSrc();
  const x = src && src.list.find((y) => y.num === num);
  if (!x || S.clr.busy || S.clr.dept === 'other') return;
  const yes = await ask(`Skinuti ${num} s DM?`, `<p>${esc(x.name)}</p><p>DM ${whole(x.dm)} → 0 (SM ostaje ${whole(x.sm)}). Zaliha ${whole(x.stock)} → ${whole(x.stock + x.dm)}${x.stock + x.dm > 0 ? `: kupci ${x.dm > 1 ? 'ih' : 'ga'} vide kao dostupan` : ': izloženi komad je prodan, stanje postaje tačno'}. Sprema se odmah u StoreFront pod tvojom prijavom.</p>`,
    [{ label: 'Skini s DM', kind: 'btn-primary', value: true }, { label: 'Odustani', value: false }]);
  if (!yes) return;
  S.clr.busy = 'dm';
  renderClearList();
  const ok = smJob([{ num, sm: x.sm, dm: 0, was: { sm: x.sm, dm: x.dm } }], (r) => {
    S.clr.busy = '';
    if (r.how === 'ok' && r.res && (r.res.done || []).includes(num)) {
      x.stock += x.dm;
      x.free += x.dm;
      x.dm = 0;
      saveUser();
      toast('Skinuto s DM. Zaliha se u StoreFrontu osvježi za koji trenutak.');
    } else {
      toast(r.how === 'login' ? 'StoreFront traži prijavu.' : 'Nije spremljeno. Pokušaj ponovo.');
    }
    if (top().id === 'clearance') renderClearance();
  });
  if (!ok) { S.clr.busy = ''; renderClearList(); }
}

function clrRow(x, xm) {
  if (x.dm > 0 || (clrSrc() && clrSrc().dept === 'furn')) return clrRowFurn(x, xm);
  const cut = x.reg != null && x.price != null && x.reg > x.price;
  const free = x.free !== x.stock ? ` (slobodno ${whole(x.free)})` : '';
  const meta = [x.chg ? `Status od ${dmy(x.chg)}` : '', x.dd && !x.dd.endsWith('-9998') ? `DD ${dmy(x.dd)}` : ''].filter(Boolean).join(' · ');
  return `<button class="item clr-item" type="button" data-store="${esc(x.num)}">
    ${thumb(x.num)}
    <span class="item-main">
      <span class="code">${esc(x.num)}<span class="pill pill-st pill-st${esc(x.st)}">Status ${esc(x.st)}</span>${xm ? '<span class="pill pill-st pill-xmas">Božić</span>' : ''}</span>
      <span class="item-name">${esc(x.name) || 'Bez naziva'}</span>
      <span class="clr-line"><b>${whole(x.stock)} ${esc(x.unit || 'KOM')}</b> na zalihi${free}${x.price != null ? ` · ${money(x.price)} KM` : ''}${cut ? ` <s>${money(x.reg)}</s>` : ''}</span>
      ${meta ? `<span class="clr-sub">${esc(meta)}</span>` : ''}
    </span>
    ${icon('chev', 'chev')}
  </button>`;
}

function renderClearList(append = false) {
  const c = clrSrc();
  if (!c || !$('#clrList')) return;
  const v = clrView();
  const list = clrFiltered();
  const value = list.reduce((s, x) => s + (x.price || 0) * Math.max(0, x.stock), 0);
  const usual = cfg().xmas === core.XMAS_WORDS; // with the words of the settings changed the name "Christmas" would not be true
  const here = v.xs.filter((x) => S.clr.st === 'all' || x.st === S.clr.st).length; // in the status that is open
  const xm = here || (S.clr.peek && v.xmas) ? `<button class="clr-xmas" type="button" data-clr-xmas="1">${S.clr.peek
    ? `Prikazani su i ${usual ? 'božićni i novogodišnji' : 'sakriveni po riječima iz postavki'}${here ? `: ${here}` : ''} · Sakrij`
    : `Sakriveno ${usual ? 'božićnih i novogodišnjih' : 'po riječima iz postavki'}: ${here} · Prikaži`}</button>` : '';
  const hid = c.dept === 'furn' ? list.filter((x) => x.dm > 0 && x.stock <= 0).length : 0;
  $('#clrSum').innerHTML = `<b>${list.length} ${plural(list.length, 'artikal', 'artikla', 'artikala')}</b><small>Vrijednost zalihe ${whole(value)} KM · ${esc(ageText(c.at))}${c.dept === 'furn' ? ' · bez zamjenske šifre' : ''}</small>${hid ? `<small class="clr-hid">Na izlogu (DM) sa zalihom 0 ili manje: ${hid} (prvi na listi)</small>` : ''}${xm}`;
  // Smart Patch: render only 48 rows initially. The user can append another
  // 48 without replacing the already visible DOM or losing their scroll.
  // Totals, search/filter and safe StoreFront operations still use the FULL list.
  const key = JSON.stringify([clearanceKey(), S.clr.st, S.clr.sort, S.clr.q, S.clr.peek, c.at]);
  const windowRange = append ? clrWindow.more(key, list.length)
    : { from: 0, to: clrWindow.visible(key, list.length) };
  const holder = $('#clrList');
  const html = list.slice(windowRange.from, windowRange.to)
    .map(x => clrRow(x, S.clr.peek && v.flag(x))).join('');
  const existing = holder.querySelector('.list');
  if (append && existing && windowRange.from > 0) {
    existing.insertAdjacentHTML('beforeend', html);
  } else {
    holder.innerHTML = list.length ? '<div class="list">' +
      list.slice(0, windowRange.to).map(x => clrRow(x, S.clr.peek && v.flag(x))).join('') +
      '</div>' : '<p class="empty">Nema artikala za ovaj izbor.</p>';
  }
  const oldMore = holder.querySelector('[data-clr-more]');
  if (oldMore) oldMore.remove();
  if (windowRange.to < list.length) {
    holder.insertAdjacentHTML('beforeend',
      '<button class="btn btn-soft btn-block" type="button" data-clr-more="1">' +
      'Prikaži još (' + (list.length - windowRange.to) + ' preostalih)</button>');
  }
  const lim = (c.limited || []);
  const notes = [];
  if (c.limited || c.total > c.list.length) notes.push(`Prikazano prvih ${c.list.length} od najmanje ${c.total} artikala. Za potpuniju listu izaberi užu grupu.`);
  if (lim.length) notes.push(`StoreFront kaže da za status ${lim.join(' i ')} ima previše rezultata, pa taj dio liste nije učitan.`);
  for (const x of c.short || []) notes.push(`Status ${x.st}: StoreFront javlja ${x.found} artikala, a pročitano ih je ${x.got}.`);
  $('#clrNote').textContent = notes.join(' ');
}

/** What the last reading found, for the box at the bottom of the screen (to be shown to whoever fixes the reader). */
function clrDetails(open) {
  const i = S.user.clrInfo;
  if (!i) return '';
  const L = [];
  for (const p of i.parts || []) {
    L.push(p.limited ? `Status ${p.st}: StoreFront kaže da ima previše rezultata` : `Status ${p.st}: StoreFront javlja ${p.found < 0 ? '?' : p.found}, pročitano ${p.got}`);
    if (p.ex) L.push(`Kartica: ${p.ex}`);
  }
  const d = i.diag;
  if (d) {
    L.push(`Čitanje je stalo kod statusa ${d.st} (${i.how === 'partial' ? 'djelimično' : 'ništa pročitano'}).`);
    if (d.last) L.push(`Stranica javlja: pronađeno ${d.last.f}, kartica ${d.last.r}${d.last.m ? ', previše rezultata' : ''}`);
    if (d.page) {
      L.push(`Redova teksta: ${d.page.lines}, kartica: ${d.page.cards}`);
      if (d.page.head) L.push(`Početak: ${d.page.head}`);
      if (d.page.first) L.push(`Prva kartica: ${d.page.first}`);
      if (d.page.tail) L.push(`Kraj: ${d.page.tail}`);
    }
  }
  if (i.err) L.push(`Greška: ${i.err}`);
  if (!L.length) return '';
  return `<details class="clr-diag"${open ? ' open' : ''}><summary>Detalji čitanja</summary><pre>${esc(L.join('\n').slice(0, 2400))}</pre></details>`;
}

function renderClearance() {
  const body = $('#clearBody');
  const c = clrSrc();
  const seg = clrNew() ? `<div class="seg clr-dept" role="tablist">${[['pick','Odjeli'], ['home', 'Moj odjel'], ['furn', 'Namještaj'], ['other', 'Drugi']].map(([v, t]) => `<button class="seg-btn" type="button" role="tab" aria-selected="${S.clr.dept === v}" data-clr-dept="${v}">${t}</button>`).join('')}</div>` : '';
  if (S.clr.dept === 'pick') {
    body.innerHTML = `<div class="pick-dept"><h3>Izaberi odjel</h3>
      <p class="hint">Nijedan odjel ne učitava se automatski. Odaberi šta želiš pregledati.</p>
      <button class="pick-dept-item" type="button" data-clr-dept="home">Moj odjel <span>›</span></button>
      <button class="pick-dept-item" type="button" data-clr-dept="furn">Namještaj <span>›</span></button>
      <button class="pick-dept-item" type="button" data-clr-dept="other">Ostali odjeli i podgrupe <span>›</span></button>
    </div>`;
    return;
  }
  const otherPick = S.clr.dept === 'other' ? `<div class="other-dept-box">
    <div class="top-head"><p class="count-line">${esc(clearanceTitle())}</p>
    ${selectedGroup() ? '<button class="text-btn" type="button" data-clr-pick-more="1">Promijeni</button>' : ''}</div>
    ${S.clr.pick || !selectedGroup() ?
      (hierarchyBusy ? '<p class="count-line">Učitavam odjele iz StoreFronta…</p>' : pickerHtml(S.user.hier, esc, 'clr', S.clr.otherId)) : ''}</div>` : '';
  if (S.clr.dept === 'other' && (S.clr.pick || !selectedGroup())) {
    body.innerHTML = seg + otherPick; return;
  }
  if (clrNew() && S.clr.busy === S.clr.dept) {
    body.innerHTML = `${seg}${otherPick}<p class="count-line"><i class="mj-busy"></i> ${S.deptBusy ? 'Prvi put: tražim grupe tvog odjela iz planograma…' : `Čitam ${esc(clearanceTitle())} sa statusom 21 i 81 iz StoreFronta…`}</p>`;
    return;
  }
  if (clrNew() && (!c || !c.list)) {
    body.innerHTML = `${seg}${otherPick}<p class="empty">Lista još nije učitana.</p><button class="btn btn-primary btn-block" type="button" data-act="clear-refresh">${icon('refresh')}Učitaj iz StoreFronta</button>`;
    return;
  }
  if (!c || !c.list) {
    const failed = S.user.clrInfo && S.user.clrInfo.how !== 'cancelled' && (S.user.clrInfo.diag || S.user.clrInfo.err || (S.user.clrInfo.parts || []).some((p) => p.got === 0 && !p.limited && p.found !== 0));
    body.innerHTML = `<p class="empty">${failed ? 'Nisam uspio pročitati listu.' : 'Lista još nije učitana.'}</p>
      <button class="btn btn-primary btn-block" type="button" data-act="clear-refresh">${icon('refresh')}${failed ? 'Pokušaj ponovo' : 'Učitaj iz StoreFronta'}</button>
      <p class="hint">Čitaju se artikli sa statusom ${clrStatuses().join(' i ')} koji su na zalihi u grupi Kućanstvo.</p>${clrDetails(failed)}`;
    return;
  }
  const v = clrView();
  const n = (s) => v.list.filter((x) => x.st === s).length;
  if (S.clr.st !== 'all' && !c.st.includes(S.clr.st)) S.clr.st = 'all';
  const sts = [['all', `Svi (${v.list.length})`], ...c.st.map((k) => [k, `${k} (${n(k)})`])];
  const sorts = [['stock', 'Količina'], ['value', 'Vrijednost'], ['num', 'Šifra'], ['new', 'Novi status']];
  body.innerHTML = `${seg}${otherPick}<div class="clr-sum" id="clrSum"></div>
    <div class="clr-tools">
      <div class="seg seg-sm" role="radiogroup" aria-label="Status">${sts.map(([v, t]) => `<button class="seg-btn" type="button" role="radio" aria-checked="${S.clr.st === v}" data-clr-st="${v}">${t}</button>`).join('')}</div>
      <form class="search" id="clrForm" role="search" autocomplete="off">
        <svg class="ico search-ico" aria-hidden="true"><use href="#i-search"/></svg>
        <input id="clrQ" type="search" inputmode="search" enterkeyhint="search" placeholder="Šifra ili naziv artikla" aria-label="Traži u listi" spellcheck="false" autocapitalize="off" autocorrect="off" value="${esc(S.clr.q)}">
      </form>
      <div class="clr-sort"><span>Poredaj:</span>${sorts.map(([v, t]) => `<button class="chip" type="button" aria-pressed="${S.clr.sort === v}" data-clr-sort="${v}">${t}</button>`).join('')}</div>
    </div>
    <div id="clrList"></div><p class="clr-note" id="clrNote"></p>${clrDetails(false)}`;
  $('#clrQ').addEventListener('input', (e) => { S.clr.q = e.target.value; renderClearList(); });
  $('#clrForm').addEventListener('submit', (e) => { e.preventDefault(); $('#clrQ').blur(); });
  renderClearList();
}

window.onClearance = (r) => {
  if (!r || r.how === 'cancelled') return;
  const prev = S.user.clear;
  const want = clrStatuses();
  const got = {};
  const limited = [];
  const short = [];
  const info = [];
  for (const p of Array.isArray(r.parts) ? r.parts : []) {
    if (!/^\d{2}$/.test(p.st) || !want.includes(p.st)) continue;
    if (p.limited) { limited.push(p.st); info.push({ st: p.st, found: -1, got: 0, limited: true }); continue; }
    const rows = core.parseArticleCards(p.text, p.st);
    got[p.st] = rows;
    if (p.found > 0 && rows.length < p.found) short.push({ st: p.st, found: p.found, got: rows.length });
    info.push({ st: p.st, found: typeof p.found === 'number' ? p.found : -1, got: rows.length, ex: String(p.text || '').split(/\n{2,}/)[0].split('\n').join(' | ').slice(0, 420) });
  }
  const dg = r.diag && typeof r.diag === 'object' ? r.diag : null;
  S.user.clrInfo = { at: r.at || Date.now(), how: String(r.how || ''), parts: info, diag: dg ? JSON.parse(JSON.stringify(dg, (k, v) => (typeof v === 'string' ? v.slice(0, 800) : v))) : null, err: String(r.err || '').slice(0, 80) };
  if (!Object.keys(got).length) {
    saveUser();
    toast(limited.length ? `StoreFront: za status ${limited.join(' i ')} ima previše rezultata.` : 'Nisam uspio pročitati artikle. Detalji su na ekranu Za rasprodaju.');
    if (top().id === 'clearance') renderClearance();
    return;
  }
  // a status that was read replaces its old rows; one that could not be read keeps what was there
  const list = [];
  for (const st of want) list.push(...(got[st] || (prev && prev.list ? prev.list.filter((x) => x.st === st) : [])));
  S.user.clear = { at: r.at || Date.now(), st: want, group: r.group || cfg().group, list, limited, short };
  saveUser();
  const partial = r.how !== 'ok' || limited.length || short.length;
  const shown = clrView(false, S.user.clear).list.length; // what the list will show: only the ones in stock, without Christmas
  toast(partial ? 'Lista je učitana samo djelimično.' : `Učitano: ${shown} ${plural(shown, 'artikal', 'artikla', 'artikala')}`);
  if (top().id === 'clearance') renderClearance();
  if (top().id === 'plans') renderPlans();
  renderClearBar();
};


  return { clrDmOff, clrSrc, clrStatuses, clrView, loadClr2, money, onClearDept, openClearance, refreshClearance, renderClearBar, renderClearance, showMoreClearance: () => renderClearList(true), whole };
}
