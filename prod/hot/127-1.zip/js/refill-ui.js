// Ostali alati → Punjenje (owner, 13. 11. 2026): the refill lists the employee made in StoreFront (/ui/refilling),
// used while carrying goods from the store room, and "Dodaj na punjenje" from a planogram.
//
// The data comes through ONE source, `api()`. StoreFront's own refill API is not wired yet: its addresses and field
// names were never seen by the app. Until then `api()` is null in the real app and every button says what it does:
// "Otvori Punjenje u StoreFrontu" (the official page, the phone's sign-in). While that page is open, the app notes the
// NAMES of the page's own requests and answer fields (StorefrontActivity, never values) for wiring the reader later.
// Tests (localhost only) give a synthetic source: window.__refillApi = { lists(), items(id), add({ list, num, qty, op }) }.
// Nothing here is sent to the diagnostics.

export function createRefillUi(ctx) {
  const { $, A, S, esc, icon, go, top, back, thumb, nameOf, planSpots, onPlanTap, sfCode, ageText, toast, openSheet, closeSheet, saveUser, plural, whole, copyCode, stCall, offline, planServerBtn, cfg, setCfg } = ctx;
  const flow = ctx.flow || null; // 1.97: the flow log (Postavke → Pregledaj dijagnostiku)
  const artOf = ctx.artOf || null; // a scanned/typed code -> article number (planogram, linked barcode)
  const scanFor = ctx.scanFor || null; // the scanner, its answer to this window instead of opening an article

  const local = /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
  // 14. 11. 2026: StoreFront's own refill calls (store-task.js refilllists / refillitems / refilladd), read from its
  // /ui/refilling page's code: lists newest first (StoreFront 6.5.0), the items in the order they were added (6.9.0).
  const call = (arg) => new Promise((ok, no) => {
    const sent = stCall(arg, (r) => {
      if (r.how === 'ok' && r.res) { if (r.res.org) S.user.sfOrg = String(r.res.org).slice(0, 10); ok(r.res); return; }
      no({ how: r.how === 'login' ? 'login' : r.err === 'context' ? 'context' : /^http 4/.test(String(r.err || '')) ? 'rejected' : offline() ? 'offline' : arg.mode === 'refilladd' || arg.mode === 'refilldel' ? 'lost' : 'error' });
    });
    if (!sent) no({ how: 'offline' });
  });
  const real = {
    async lists() {
      const r = await call({ mode: 'refilllists' });
      const t = (x) => { const v = Date.parse(x.created); return Number.isFinite(v) ? v : 0; };
      return { store: r.store, who: r.who || '', total: r.total, lists: (r.lists || []).slice().sort((a, b) => t(b) - t(a)) };
    },
    async items(id) { const r = await call({ mode: 'refillitems', id }); return { store: r.store, items: r.items || [] }; },
    // 1.97: shelf capacity (all shelves of the article in this store) and sellable stock; null = StoreFront has none
    async info(num) { const r = await call({ mode: 'refillinfo', num }); return r; },
    // 1.97: one list by id (exists, count) and its deletion (StoreFront's own DELETE)
    async check(id) { return call({ mode: 'refillcheck', id }); },
    async del({ id, store, who }) { return call({ mode: 'refilldel', id, store, who }); },
    // StoreFront's update-article sets the quantity: the app sends what the list will hold (had + what is added)
    async add({ list, num, qty, had = 0 }) {
      const r = await call({ mode: 'refilladd', id: list.id || '', name: list.id ? '' : list.name, num, qty: had + qty, exists: had > 0 });
      return { ok: true, list: { id: r.id, name: list.name } };
    },
  };
  const api = () => (local && window.__refillApi !== undefined ? window.__refillApi : A.storeTask ? real : null);
  const komada = (n) => `${whole(n)} ${plural(n, 'komad', 'komada', 'komada')}`;
  const day = (t) => { const d = new Date(t); return Number.isFinite(d.getTime()) ? `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}.` : ''; };
  const view = { busy: false, err: '', list: null, listBusy: false, listErr: '' };

  /** The kept last good reading, of one store only: { store, at, lists, items: { id: { at, items } } } */
  function kept(store) {
    const k = S.user.refill;
    if (!k || (store && k.store !== store)) return null;
    return k;
  }
  function keep(store, patch) {
    const k = S.user.refill && S.user.refill.store === store ? S.user.refill : { store, items: {} };
    S.user.refill = { ...k, ...patch, items: { ...k.items, ...(patch.items || {}) } };
    saveUser();
  }
  const why = (e) => (e && e.how === 'login' ? 'StoreFront traži prijavu. Otvori ga jednom i prijavi se.' : e && e.how === 'offline' ? 'Nema interneta.' : 'StoreFront nije odgovorio.');
  const openOfficial = () => { try { A.storefrontPage('refilling'); } catch (e) { toast('Punjenje u StoreFrontu se nije otvorilo.'); } };

  // ------------------------------------------------------------------ Moje liste za punjenje
  function open() {
    if (!api()) { renderLists(); go('refill'); return; }
    go('refill');
    loadLists().then(() => drainDeletes());
  }
  async function loadLists() {
    view.busy = true; view.err = ''; renderLists();
    try {
      const r = await api().lists();
      keep(r.store, { at: Date.now(), lists: r.lists || [], who: r.who || '' });
    } catch (e) { view.err = why(e); }
    view.busy = false;
    if (top().id === 'refill') renderLists();
  }
  // ------------------------------------------------------------------ Izbriši listu (1.97, owner): asked now, sent when
  // there is a network and a valid sign-in. StoreFront's own Punjenje deletes a list with DELETE {org}/{store}/{id}
  // (its list screen, "acknowledge-delete"). The request is bound to the list's id, the store and the signed-in user
  // (a short one-way mark), kept in user.json (survives closing the app and a restart), never sent twice blind: a
  // lost answer is checked on THAT list (by id: the list of lists shows at most 100) before anything else.
  //   waiting  asked, not sent yet (Poništi possible)       review  the list changed since: shown, asked again
  //   sending  the request is out                            unsure  sent, answer lost: checked when possible
  //   held     another store or user is signed in now        done    StoreFront confirmed (kept 24 h to be seen)
  //   failed   StoreFront refused: the list is back
  const dq = () => (S.user.refillDel = Array.isArray(S.user.refillDel) ? S.user.refillDel : []);
  const pendingDel = (id) => dq().some((x) => x.id === id && !['done', 'gone', 'failed'].includes(x.state));
  const DEL_TEXT = { waiting: 'Brisanje čeka slanje', sending: 'Brisanje se šalje', unsure: 'Zahtjev poslan, potvrda nije stigla · provjera čeka mrežu',
    review: 'Lista je u međuvremenu izmijenjena', held: 'Prijavljena je druga prodavnica ili drugi korisnik: brisanje čeka', done: 'StoreFront potvrdio brisanje', gone: 'Liste više nema u StoreFrontu (StoreFront sam briše liste starije od 2 dana): ništa nije trebalo slati', failed: 'StoreFront odbio brisanje: lista je vraćena' };
  const delFlows = new Map(); // id -> the flow of this deletion (flow log), this session
  function delFlow(x) {
    if (!flow) return null;
    let f = delFlows.get(x.id);
    if (!f || !f.open) { f = flow.start('refill', 'Brisanje liste', { step: 'nastavak' }); delFlows.set(x.id, f); }
    return f;
  }
  function askDelete() {
    const l = view.list;
    if (!l) return;
    const k = kept();
    const got = k && k.items && k.items[l.id];
    const n = got ? got.items.length : null;
    openSheet({
      title: 'Izbriši listu',
      body: `<p><b>${esc(l.name)}</b>${n !== null ? ` · ${n} ${plural(n, 'stavka', 'stavke', 'stavki')}` : ''}</p>
        <p class="hint">Lista se briše i u StoreFrontu. Bez mreže brisanje čeka slanje; dok nije poslano, možeš ga poništiti.</p>`,
      actions: [{ label: 'Izbriši listu', kind: 'btn-danger', onClick: () => { closeSheet(); queueDelete(l, n); } }, { label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }],
    });
  }
  function queueDelete(l, n) {
    if (pendingDel(l.id)) { toast('Brisanje ove liste već čeka.'); return; } // a double tap: one request
    const k = S.user.refill || {};
    const x = { id: l.id, name: l.name, count: n, store: k.store || '', who: k.who || '', at: Date.now(), state: 'waiting', tries: 0, msg: '' };
    dq().push(x);
    saveUser();
    const f = flow ? flow.start('refill', 'Brisanje liste') : null;
    if (f) { delFlows.set(x.id, f); f.step('potvrđeno na telefonu, čeka slanje', 'waiting'); }
    if (top().id === 'refillList') back();
    renderLists();
    toast('Brisanje čeka slanje.');
    drainDeletes();
  }
  function undoDelete(id) {
    const x = dq().find((y) => y.id === id);
    if (!x || !['waiting', 'review', 'held'].includes(x.state)) { toast('Zahtjev je već poslan: ne može se poništiti.'); return; }
    S.user.refillDel = dq().filter((y) => y !== x);
    saveUser();
    const f = delFlows.get(id); if (f && f.open) f.end('cancelled', { step: 'poništeno prije slanja' });
    renderLists();
    toast('Brisanje je poništeno.');
  }
  function confirmAgain(id) {
    const x = dq().find((y) => y.id === id);
    if (!x || x.state !== 'review') return;
    x.state = 'waiting'; x.count = x.now; x.msg = ''; saveUser();
    drainDeletes();
  }
  let draining = false, drainTimer = 0;
  /** Sends what waits, when there is a network and a sign-in; called at start, on network back, on Punjenje, every minute. */
  async function drainDeletes() {
    clearTimeout(drainTimer);
    const q = dq();
    // a request that was out when the app closed: its outcome is not known
    for (const x of q) if (x.state === 'sending') { x.state = 'unsure'; x.msg = ''; }
    for (const x of q) if ((x.state === 'done' || x.state === 'gone') && Date.now() - x.at > 86400000) x.gone = true;
    S.user.refillDel = q.filter((x) => !x.gone && !(x.state === 'failed' && Date.now() - x.at > 86400000));
    const work = dq().filter((x) => ['waiting', 'unsure', 'held'].includes(x.state));
    if (work.length) drainTimer = setTimeout(drainDeletes, 60000);
    if (draining || !work.length || !api() || !api().del) return;
    if (offline()) { for (const x of work) { const f = delFlow(x); if (f && x.msg !== 'mreža') { f.step('čeka mrežu', 'waiting'); x.msg = 'mreža'; } } saveUser(); return; }
    draining = true;
    try {
      let ctx;
      try { const r = await api().lists(); ctx = { store: r.store, who: r.who || '' }; keep(r.store, { at: Date.now(), lists: r.lists || [], who: r.who || '' }); } catch (e) {
        for (const x of work) { const f = delFlow(x); if (f) f.step(e && e.how === 'login' ? 'čeka prijavu u StoreFront' : 'čeka mrežu', e && e.how === 'login' ? 'login' : 'network'); x.msg = e && e.how === 'login' ? 'Čeka prijavu u StoreFront.' : 'Čeka mrežu.'; }
        return;
      }
      for (const x of work) {
        const f = delFlow(x);
        if (ctx.store !== x.store || (x.who && ctx.who && x.who !== ctx.who)) { x.state = 'held'; x.msg = ''; if (f) f.step('druga prodavnica ili korisnik prijavljen', 'held'); continue; }
        // what is THAT list now (by its id)?
        let c;
        try { c = await api().check(x.id); } catch (e) { x.msg = e && e.how === 'login' ? 'Čeka prijavu u StoreFront.' : 'Čeka mrežu.'; if (f) f.step('provjera liste nije prošla', e && e.how === 'login' ? 'login' : 'network'); continue; }
        if (!c.exists) {
          // 1.98 (MYJYSK 226274 "Dopunjavanje": "Sve liste starije od dva dana automatski se brišu"): a list that was gone
          // before this phone sent anything was not deleted by this request; said so, not "StoreFront potvrdio"
          x.state = x.tries ? 'done' : 'gone'; x.at = Date.now(); x.msg = '';
          if (f) f.end('ok', { step: x.tries ? 'StoreFront potvrdio brisanje (liste više nema)' : 'liste već nema u StoreFrontu' });
          continue;
        }
        if (x.state === 'waiting' && Number.isFinite(x.count) && Number.isFinite(c.count) && c.count !== x.count) {
          x.state = 'review'; x.now = c.count; x.msg = `Sada ${c.count} ${plural(c.count, 'stavka', 'stavke', 'stavki')} (bilo ${x.count}).`;
          if (f) f.step('lista izmijenjena prije slanja', 'colleague', { why: `sada ${c.count} stavki, bilo ${x.count}` });
          continue;
        }
        x.state = 'sending'; x.tries++; saveUser();
        if (f) f.step('zahtjev poslan', 'sent', { tries: x.tries });
        try {
          await api().del({ id: x.id, store: x.store, who: x.who });
          // the answer came: is the list gone now?
          let gone = true;
          try { const c2 = await api().check(x.id); gone = !c2.exists; } catch (e) { gone = null; }
          if (gone === false) { x.state = 'unsure'; x.msg = 'StoreFront je odgovorio, a lista je još tu.'; if (f) f.step('odgovor stigao, lista još postoji', 'unsure'); }
          else { x.state = 'done'; x.at = Date.now(); x.msg = gone === null ? 'Provjera nakon brisanja nije stigla.' : ''; if (f) f.end('ok', { step: 'StoreFront potvrdio brisanje' }); }
        } catch (e) {
          const h = e && e.how;
          if (h === 'lost' || h === 'timeout' || h === 'offline' || h === 'error') { x.state = 'unsure'; x.msg = ''; if (f) f.step('veza prekinuta prije potvrde · provjera čeka mrežu', 'unsure'); }
          else if (h === 'login') { x.state = 'waiting'; x.msg = 'Čeka prijavu u StoreFront.'; if (f) f.step('čeka prijavu u StoreFront', 'login'); }
          else if (h === 'context') { x.state = 'held'; if (f) f.step('druga prodavnica ili korisnik prijavljen', 'held'); }
          else { x.state = 'failed'; x.at = Date.now(); x.msg = ''; if (f) f.end('rejected', { step: 'StoreFront odbio brisanje' }); }
        }
      }
    } finally {
      draining = false;
      saveUser();
      if (top().id === 'refill') renderLists();
    }
  }
  function delRows() {
    const q = dq().filter((x) => x.state !== 'failed' || Date.now() - x.at < 86400000);
    if (!q.length) return '';
    return `<p class="stk-h">Brisanje lista</p><div class="list refill-del">${q.map((x) => `<div class="item item-static refill-del-row is-${x.state}">
      <span class="item-main"><span class="item-name">${esc(x.name)}${Number.isFinite(x.count) ? ` · ${x.count} ${plural(x.count, 'stavka', 'stavke', 'stavki')}` : ''}</span>
      <small class="item-age">${esc(DEL_TEXT[x.state] || x.state)}${x.msg ? ` · ${esc(x.msg)}` : ''}</small>
      ${['waiting', 'held'].includes(x.state) ? `<button class="link" type="button" data-refill-undo="${esc(x.id)}">Poništi</button>` : ''}
      ${x.state === 'review' ? `<span><button class="link" type="button" data-refill-del-again="${esc(x.id)}">Ipak izbriši</button> · <button class="link" type="button" data-refill-undo="${esc(x.id)}">Poništi</button></span>` : ''}</span></div>`).join('')}</div>`;
  }

  function renderLists() {
    const body = $('#refillBody');
    if (!api()) {
      body.innerHTML = `<div class="set-card refill-off"><div class="set-row set-col"><div class="set-txt"><b>Liste se još čitaju samo u StoreFrontu</b>
        <small>Pregled lista u aplikaciji još nije povezan sa StoreFrontom. Otvori službeno Punjenje; dok je otvoreno, aplikacija zapamti samo nazive polja (bez šifri i količina) da bi se pregled mogao povezati.</small></div></div>
        <button class="set-act" type="button" data-refill-sf>${icon('link')}<span class="set-txt"><b>Otvori Punjenje u StoreFrontu</b><small>Tvoja prijava, službeni ekran</small></span>${icon('chev', 'chev')}</button></div>`;
      return;
    }
    const k = S.user.refill;
    const lists = ((k && k.lists) || []).filter((l) => !pendingDel(l.id)); // 1.97: asked to delete: not an active list
    const head = `<div class="ord-head"><p class="count-line">${k && k.at ? `Očitano ${esc(ageText(k.at))}` : ''}</p><button class="sort-btn" type="button" data-refill-sf>Uredi u StoreFrontu</button></div>
      <button class="btn btn-primary btn-block refill-new-btn" type="button" data-refill-add-new>${icon('plus')}Nova lista i artikal</button>`;
    let h = head;
    if (view.busy) h += '<p class="count-line"><i class="mj-busy"></i> Čitam liste iz StoreFronta…</p>';
    if (view.err) h += `<p class="ord-trust is-unknown">${esc(view.err)}${lists.length ? ' Prikazane su liste iz zadnjeg čitanja.' : ''} <button class="link" type="button" data-refill-reload>Pokušaj ponovo</button></p>`;
    if (!view.busy && !view.err && k && !lists.length) h += '<p class="empty">Nema nijedne liste za punjenje. Napravi je ovdje („Nova lista i artikal“).</p>';
    if (lists.length) {
      h += `<div class="list">${lists.map((l) => `<button class="item" type="button" data-refill-list="${esc(l.id)}">
        <span class="item-main"><span class="item-name">${esc(l.name)}</span><small class="ocard-made">Kreirano ${esc(day(l.created))}${Number.isFinite(l.count) ? ` · ${l.count} ${plural(l.count, 'stavka', 'stavke', 'stavki')}` : ''}</small></span>${icon('chev', 'chev')}</button>`).join('')}</div>`;
    }
    h += delRows();
    body.innerHTML = h;
  }

  // ------------------------------------------------------------------ one list, for carrying goods
  function openList(id) {
    const k = S.user.refill;
    const l = k && (k.lists || []).find((x) => x.id === id);
    if (!l) return;
    if (pendingDel(id)) { toast('Ova lista čeka brisanje.'); return; }
    view.list = l;
    $('#refillTitle').textContent = l.name;
    go('refillList', id);
    loadItems(id);
  }
  async function loadItems(id) {
    view.listBusy = true; view.listErr = ''; renderList();
    try {
      const r = await api().items(id);
      if (S.user.refill && r.store && r.store !== S.user.refill.store) { S.user.refill = null; saveUser(); view.listErr = 'Prijavljena je druga prodavnica. Otvori Punjenje ponovo.'; }
      else keep(r.store, { items: { [id]: { at: Date.now(), items: r.items || [] } } });
    } catch (e) { view.listErr = why(e); }
    view.listBusy = false;
    if (top().id === 'refillList') renderList();
  }
  function where(num) {
    const spots = planSpots(num);
    if (!spots.length) return `<p class="refill-where">Nije na planogramima na ovom telefonu</p>${planServerBtn ? planServerBtn(num) : ''}`;
    if (spots.length === 1 && spots[0].kind === 'list') return `<button class="onplan is-list" type="button" data-onplan="${esc(num)}">${icon('list')}<span>Pozicija nije označena · ${esc(spots[0].title)} · str. ${spots[0].page + 1}</span></button>`;
    if (spots.length > 1) return `<button class="onplan" type="button" data-onplan="${esc(num)}">${icon('map')}<span>Na planogramu · ${spots.length} ${plural(spots.length, 'mjesto', 'mjesta', 'mjesta')}</span></button>`;
    return `<button class="onplan" type="button" data-onplan="${esc(num)}">${icon('map')}<span>Na planogramu · ${esc(spots[0].title)} · str. ${spots[0].page + 1}</span></button>`;
  }
  function renderList() {
    const body = $('#refillListBody');
    const l = view.list;
    if (!l) { body.innerHTML = ''; return; }
    const k = kept();
    const got = k && k.items && k.items[l.id];
    const all = (got && got.items) || [];
    const hide = !!(cfg && cfg().refillHide);
    const picked = all.filter((x) => x.checked).length;
    const items = hide ? all.filter((x) => !x.checked) : all;
    let h = `<div class="ord-head"><p class="count-line">${got ? `Očitano ${esc(ageText(got.at))}` : ''}${items.length ? ` · ${items.length} ${plural(items.length, 'artikal', 'artikla', 'artikala')}` : ''}</p><button class="sort-btn" type="button" data-refill-sf>Uredi u StoreFrontu</button></div>
      <button class="btn btn-primary btn-block refill-new-btn" type="button" data-refill-add-here>${icon('plus')}Dodaj artikal na ovu listu</button>`;
    const delBtn = `<button class="btn btn-danger btn-block refill-del-btn" type="button" data-refill-del>Izbriši listu</button>`;
    if (picked) h += `<div class="chips ord-filter"><button class="chip" type="button" role="checkbox" aria-checked="${hide}" data-refill-hide>Sakrij odabrane (${picked})</button></div>`;
    if (view.listBusy && !got) h += '<p class="count-line"><i class="mj-busy"></i> Čitam listu…</p>';
    if (view.listErr) h += `<p class="ord-trust is-unknown">${esc(view.listErr)}${got ? ' Prikazana je lista iz zadnjeg čitanja.' : ''} <button class="link" type="button" data-refill-retry="${esc(l.id)}">Pokušaj ponovo</button></p>`;
    if (got && !items.length) h += '<p class="empty">Lista je prazna. Dodaj artikal gore, s planograma („Dodaj na punjenje“) ili u StoreFrontu.</p>';
    if (items.length) {
      h += `<div class="list">${items.map((it) => {
        const name = it.name || nameOf(it.num) || 'Bez naziva';
        const det = [Number.isFinite(it.cap) ? `Kapacitet svih polica ${whole(it.cap)}` : '', Number.isFinite(it.sm) ? `SM ${whole(it.sm)}` : '', Number.isFinite(it.dm) ? `DM ${whole(it.dm)}` : '', it.st ? `Status ${esc(it.st)}` : ''].filter(Boolean).join(' · ');
        return `<div class="item item-sum refill-row${it.checked ? ' is-picked' : ''}" data-refill-num="${esc(it.num)}">
          <div class="item-open">${thumb(it.num)}<span class="item-main">
            <span class="item-name">${esc(name)}</span>
            <span class="refill-qty">Za dopunu: <b>${whole(it.qty)}</b> kom${it.checked ? ' <span class="pill pill-muted">odabrano u StoreFrontu</span>' : ''}</span>
            <span>${sfCode(it.num)}</span>
            ${Number.isFinite(it.stock) ? `<small class="item-age">Zaliha u prodavnici: ${whole(it.stock)} kom</small>` : ''}${it.series ? `<small class="item-age">${esc(it.series)}</small>` : ''}
            ${det ? `<details class="refill-det"><summary>Detalji</summary><small>${det}</small></details>` : ''}
          </span></div>
          ${where(it.num)}
        </div>`;
      }).join('')}</div>`;
    }
    body.innerHTML = h + delBtn;
  }

  // ------------------------------------------------------------------ Dodaj na punjenje (Punjenje itself, or a planogram)
  // 1.96 (owner): everything in the app, the result in StoreFront: choose a list (or name a new one), scan or type the
  // article, the quantity, "Spremi"; afterwards the list as StoreFront has it. The same window from a planogram.
  const add = { num: '', name: '', art: '', qty: 1, list: null, newName: '', creating: false, busy: false, msg: '', loading: false, seq: 0, from: 'plan', unsure: false,
    info: null, infoBusy: false, infoErr: '', note: '' };
  // 1.97 (owner): "Max" = how much may still go on the chosen list. The list may hold up to the smaller of the shelf
  // capacity and the sellable stock (StoreFront's own Punjenje "Max" is that minimum); what is on the list already is
  // taken off; never below 0. Capacity alone or stock alone still bounds +, the keyboard and Spremi, but the Max
  // button needs both. Unknown is never 0.
  function limits() {
    const had = add.list && add.num ? existingQty(add.list.id, add.num) : add.creating ? 0 : null;
    const k = kept();
    const row = add.list && k && k.items && k.items[add.list.id] ? k.items[add.list.id].items.find((x) => x.num === add.num) : null;
    const i = add.info && add.info.num === add.num ? add.info : null;
    // the list's own sellableQty (read with the list, fresh before the write) first; else the article's
    const free = row && Number.isFinite(row.stock) ? row.stock : i && Number.isFinite(i.free) ? i.free : null;
    const cap = i && Number.isFinite(i.cap) ? i.cap : null;
    const ceil = cap !== null && free !== null ? Math.min(cap, free) : cap !== null ? cap : free;
    const room = ceil === null || had === null ? null : Math.max(0, ceil - had);
    return { had, free, cap, ceil, room, max: cap !== null && free !== null && had !== null ? room : null };
  }
  async function loadInfo(num) {
    if (!num || !api() || !api().info) return;
    add.infoBusy = true; add.infoErr = '';
    if (isOpen()) renderAdd();
    try { const r = await api().info(num); if (add.num === num) add.info = r && r.found !== false ? { ...r, num } : { num, cap: null, free: null }; } catch (e) { if (add.num === num) add.infoErr = why(e); }
    if (add.num !== num) return;
    add.infoBusy = false;
    clampQty();
    if (isOpen()) renderAdd();
  }
  /** The quantity never above what may still be added (when that is known); said once when it was lowered. */
  function clampQty() {
    const L = limits();
    if (L.room !== null && L.room >= 1 && add.qty > L.room) { add.qty = L.room; add.note = `Najviše možeš dodati još ${whole(L.room)}.`; }
  }
  // one write at a time for the whole app (a window opened again while a write still waits never writes a second time)
  let writing = null;
  let openSeq = 0; // the window opened last (its reading of the lists), apart from add.seq (the article's name)
  const lastKey = () => (S.user.refill && S.user.refill.store) || '';
  function existingQty(listId, num) {
    const k = kept();
    const got = k && k.items && k.items[listId];
    if (!got) return null;
    return got.items.filter((x) => x.num === num).reduce((n, x) => n + (+x.qty || 0), 0);
  }
  // the window is there at once (code, name, the kept lists) and fills in when StoreFront answers
  async function openAdd(num = '', opts = {}) {
    const seq = ++openSeq;
    const nseq = ++add.seq;
    Object.assign(add, { num: num || '', name: '', art: num || '', qty: opts.qty || 1, creating: !!opts.creating, newName: opts.newName || '', busy: false, unsure: false, info: null, infoErr: '', note: '',
      msg: '', from: opts.from || (num ? 'plan' : 'refill') });
    const lists = () => (S.user.refill && S.user.refill.lists) || [];
    const pickLast = () => {
      const want = opts.listId || (S.user.refillLast || {})[lastKey()];
      add.list = add.creating || pendingDel(want) ? null : lists().find((x) => x.id === want) || null;
    };
    if (api()) { pickLast(); add.loading = true; }
    renderAdd();
    if (num) { nameFor(num, nseq); loadInfo(num); }
    if (!api()) return;
    try { const r = await api().lists(); keep(r.store, { at: Date.now(), lists: r.lists || [] }); } catch (e) { add.msg = why(e); if (e && e.how === 'login') loginNeeded(); }
    if (seq !== openSeq) return; // another window meanwhile
    if (!add.creating && (!add.list || !lists().some((x) => x.id === add.list.id))) pickLast();
    if (add.list && add.num) await refreshExisting();
    if (seq !== openSeq) return;
    add.loading = false;
    clampQty();
    if (isOpen()) renderAdd();
  }
  const isOpen = () => !$('#sheet').hidden && $('#sheet').classList.contains('is-refill');
  async function refreshExisting() {
    if (!add.list || !api()) return;
    try { const r = await api().items(add.list.id); keep(r.store, { items: { [add.list.id]: { at: Date.now(), items: r.items || [] } } }); } catch (e) { /* the sum says "čitam" */ }
  }
  /** The article's name: the planogram's, the kept StoreFront one, else StoreFront's (lookup). */
  function nameFor(num, seq) {
    add.name = nameOf(num) || (S.stock.get(num) && S.stock.get(num).d && S.stock.get(num).d.md && S.stock.get(num).d.md.name) || '';
    if (add.name || !stCall || !/^\d{4,9}$/.test(num)) return;
    stCall({ mode: 'lookup', num }, (r) => {
      if (seq !== add.seq || add.num !== num) return;
      if (r.how === 'ok' && r.res && r.res.found) add.name = (r.res.a && r.res.a.name) || '';
      else if (r.how === 'ok' && r.res && !r.res.found) add.msg = `StoreFront ne nalazi šifru ${num}. Provjeri broj na etiketi.`;
      if (isOpen()) renderAdd();
    });
  }
  /** A typed or scanned code -> the article number (planogram, linked barcode, the number itself). */
  function setArt(code) {
    const c = String(code || '').replace(/\s+/g, '');
    add.art = c;
    add.msg = '';
    const num = c ? (artOf ? artOf(c) : /^\d{7}$/.test(c) ? c : '') : '';
    if (c && !num) add.msg = 'Ovaj barkod još nije povezan s artiklom. Upiši šifru artikla s etikete (7 cifara).';
    add.num = num;
    add.name = '';
    const seq = ++add.seq;
    add.info = null; add.note = '';
    if (num) { nameFor(num, seq); loadInfo(num); if (add.list) refreshExisting().then(() => { if (seq === add.seq) { clampQty(); if (isOpen()) renderAdd(); } }); }
    renderAdd();
  }
  /** "Na policu stane 20 · Slobodna zaliha 7 · Na listi 3", and why Max is what it is. */
  function limitLine(L) {
    const parts = [L.cap !== null ? `Na police stane ${whole(L.cap)} (sve police artikla u prodavnici)` : 'Kapacitet police nije poznat',
      L.free !== null ? `Slobodna zaliha ${whole(L.free)}` : add.infoBusy ? 'Slobodna zaliha: čitam…' : 'Slobodna zaliha nepoznata'];
    if (L.had !== null) parts.push(`Na listi ${whole(L.had)}`);
    let why2 = '';
    if (L.free !== null && L.free <= 0) why2 = 'Slobodne zalihe nema: dodavanje nije moguće.';
    else if (L.ceil !== null && L.had !== null && L.had > L.ceil) why2 = `Na listi je već ${whole(L.had)}, više od granice ${whole(L.ceil)}; ta količina ostaje, dodati se ne može.`;
    else if (L.room === 0) why2 = 'Lista je već na granici: dodati se ne može.';
    const refresh = !add.infoBusy && (L.cap === null || L.free === null) ? ' <button class="link" type="button" data-refill-info>Osvježi</button>' : '';
    return `${esc(parts.join(' · '))}${refresh}${why2 ? `<br><b>${esc(why2)}</b>` : ''}${add.infoErr ? `<br>${esc(add.infoErr)}` : ''}`;
  }
  function renderAdd() {
    const L = limits();
    const lists = ((S.user.refill && S.user.refill.lists) || []).filter((l) => !pendingDel(l.id)); // 1.97
    const had = add.list && add.num ? existingQty(add.list.id, add.num) : null;
    const dup = add.creating && add.newName.trim() && lists.find((l) => l.name.trim().toLowerCase() === add.newName.trim().toLowerCase());
    const art = add.num
      ? `<p class="refill-art"><b>${esc(add.name || 'Artikal')}</b><br><span class="code">Šifra ${esc(add.num)}</span>${add.from === 'refill' ? ' <button class="link" type="button" data-refill-art-clear>Drugi artikal</button>' : ''}</p>`
      : `<p class="stk-h">Artikal</p><div class="refill-art-in"><input class="set-input" id="refillArt" type="text" inputmode="numeric" placeholder="Šifra s etikete ili barkod" value="${esc(add.art)}" aria-label="Šifra artikla ili barkod" autocapitalize="off">
         <button class="btn btn-soft" type="button" data-refill-scan>Skeniraj</button></div>`;
    // "Na listi 2 · Dodaješ 3 · Ukupno 5": what the list holds, what this adds, what it will hold (owner, 14. 11.)
    const sum = !add.num ? '' : add.list
      ? `<p class="refill-target"><b>${esc(add.list.name)}</b>: ${had === null ? 'Na listi: čitam…' : L.room === 0 ? `Na listi ${whole(had)} · ništa se ne može dodati` : `Na listi ${whole(had)} · Dodaješ ${whole(add.qty)} · Ukupno <b>${whole(had + add.qty)}</b>`}</p>`
      : add.creating && add.newName.trim() && !dup ? `<p class="refill-target">Nova lista <b>${esc(add.newName.trim())}</b>: Dodaješ ${whole(add.qty)} · Ukupno <b>${whole(add.qty)}</b></p>` : '';
    const body = !api()
      ? `<p class="refill-art"><b>${esc(add.name || 'Artikal')}</b><br><span class="code">Šifra ${esc(add.num)}</span></p>
         <p class="hint">Dodavanje iz aplikacije još nije povezano sa StoreFrontom. Šifra se kopira, a otvara se službeno Punjenje gdje je zalijepiš u pretragu i izabereš listu i količinu.</p>`
      : `${art}
      <p class="stk-h">Lista za dopunu</p>
      <div class="chips refill-lists">${lists.map((l) => `<button class="chip" type="button" role="radio" aria-checked="${!!add.list && add.list.id === l.id}" data-refill-pick="${esc(l.id)}">${esc(l.name)}</button>`).join('')}
        <button class="chip" type="button" data-refill-new aria-pressed="${add.creating}">+ Nova lista</button></div>
      ${add.creating ? `<input class="set-input" id="refillNewName" type="text" placeholder="Naziv nove liste" value="${esc(add.newName)}" aria-label="Naziv nove liste" autocapitalize="off">
        ${dup ? `<p class="hint">Lista „${esc(dup.name)}“ već postoji. <button class="link" type="button" data-refill-pick="${esc(dup.id)}">Dodaj na nju</button></p>` : ''}` : ''}
      <p class="stk-h">Količina koju dodaješ</p>
      <div class="refill-step"><button class="btn btn-soft" type="button" data-refill-step="-1" aria-label="Manje">−</button>
        <input class="set-input" id="refillQty" type="number" inputmode="numeric" min="1" max="${L.room !== null ? Math.max(1, L.room) : 9999}" value="${add.qty}" aria-label="Količina koju dodaješ">
        <button class="btn btn-soft" type="button" data-refill-step="1" aria-label="Više"${L.room !== null && add.qty >= L.room ? ' disabled' : ''}>+</button>
        <button class="btn btn-soft refill-max" type="button" data-refill-max${L.max === null || L.max < 1 ? ' disabled' : ''} aria-label="${L.max === null ? 'Max nije poznat' : `Najviše još ${L.max}`}">Max${L.max === null ? '' : ` ${whole(L.max)}`}</button></div>
      ${add.num ? `<p class="refill-limits">${limitLine(L)}</p>` : ''}
      ${add.note ? `<p class="hint">${esc(add.note)}</p>` : ''}
      ${add.loading ? '<p class="count-line"><i class="mj-busy"></i> Čitam liste iz StoreFronta…</p>' : ''}
      ${sum || (add.list || add.creating ? '' : '<p class="hint">Izaberi listu ili napravi novu.</p>')}
      ${writing && !add.busy ? '<p class="ord-trust is-unknown">Prethodni upis još čeka odgovor StoreFronta. Sačekaj ga prije novog.</p>' : ''}
      ${add.msg ? `<p class="ord-trust is-unknown">${esc(add.msg)}</p>` : ''}`;
    const can = api() && !add.busy && !writing && !add.loading && !add.unsure && add.num && (add.list || (add.creating && add.newName.trim() && !dup)) && add.qty >= 1
      && (L.room === null || add.qty <= L.room);
    openSheet({
      title: 'Dodaj na punjenje',
      body,
      cls: 'is-refill',
      actions: !api()
        ? [{ label: 'Otvori Punjenje u StoreFrontu', kind: 'btn-primary', onClick: () => { closeSheet(); copyCode(add.num); openOfficial(); } }, { label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }]
        : add.unsure
          ? [{ label: 'Pročitaj listu ponovo', kind: 'btn-primary', onClick: () => recheck() }, { label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet }]
          : [{ label: add.busy ? 'Spremam…' : 'Spremi', kind: 'btn-primary', onClick: () => { if (can) confirm(); } }, { label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }],
    });
    const btn = $('#sheetActions button');
    if (btn && api() && !add.unsure) btn.disabled = !can;
    const q = $('#refillQty');
    if (q) q.addEventListener('change', () => { add.note = ''; add.qty = Math.max(1, Math.min(9999, Math.round(+q.value || 1))); clampQty(); renderAdd(); });
    const n = $('#refillNewName');
    if (n) { n.addEventListener('input', () => { add.newName = n.value; }); n.addEventListener('change', () => renderAdd()); }
    const a = $('#refillArt');
    if (a) a.addEventListener('change', () => setArt(a.value));
  }
  /** After "Nije potvrđeno": the list as StoreFront has it now, then the employee decides. */
  async function recheck() {
    add.msg = '';
    add.busy = true;
    renderAdd();
    if (add.creating && add.newName.trim()) {
      try { const r = await api().lists(); keep(r.store, { at: Date.now(), lists: r.lists || [] }); const l = (r.lists || []).find((x) => x.name.toLowerCase() === add.newName.trim().toLowerCase()); if (l) { add.list = l; add.creating = false; } } catch (e) { add.msg = `Lista se ne može pročitati: ${why(e)}`; }
    }
    if (add.list) {
      try { const it = await api().items(add.list.id); keep(it.store, { items: { [add.list.id]: { at: Date.now(), items: it.items || [] } } }); add.unsure = false; add.msg = `Na listi ${add.list.name} je sada ${komada(existingQty(add.list.id, add.num))}. Ako dodaješ ponovo, to je novi upis.`; } catch (e) { add.msg = `Lista se ne može pročitati: ${why(e)}`; }
    } else if (!add.msg) add.unsure = false;
    add.busy = false;
    renderAdd();
  }
  /** StoreFront wants a sign-in: what was prepared is kept, its official page (with the sign-in) opens; back -> here. */
  function loginNeeded() {
    S.refillPending = { num: add.num, qty: add.qty, listId: add.list ? add.list.id : '', creating: add.creating, newName: add.newName, from: add.from };
    add.msg = 'StoreFront traži prijavu. Otvaram službenu prijavu; kad se vratiš, nastavljaš ovdje s istim unosom.';
    if (isOpen()) renderAdd();
    setTimeout(openOfficial, 600);
  }
  function resumePending() {
    const p = S.refillPending;
    if (!p) return false;
    S.refillPending = null;
    if (p.from === 'refill' && p.listId && top().id !== 'refillList') {
      const l = ((S.user.refill && S.user.refill.lists) || []).find((x) => x.id === p.listId);
      if (l) openList(l.id);
    }
    openAdd(p.num, { qty: p.qty, listId: p.listId, creating: p.creating, newName: p.newName, from: p.from });
    return true;
  }
  /** One tap = one write: the button is off while it runs; a lost answer is checked against the list before any retry. */
  async function confirm() {
    if (add.busy || writing) return;
    add.busy = true; add.msg = '';
    let release;
    writing = new Promise((r) => { release = r; });
    const mine = openSeq;
    // 1.97: this Spremi in the flow log: read before the write, sent, confirmed / not confirmed
    const fl = flow ? flow.start('refill', 'Dodaj artikal') : null;
    const F = { step: (st, o, x) => { if (fl) fl.step(st, o, x); }, end: (o, x) => { if (fl && fl.open) fl.end(o, x); } };
    try { await write(mine, F); } catch (e) { F.end('app_error', { step: 'greška aplikacije', why: e && e.name ? `${e.name}: ${e.message}` : String(e) }); throw e; } finally {
      F.end(add.unsure ? 'unsure' : add.msg ? 'incomplete' : 'ok', { step: add.unsure ? 'nije potvrđeno — provjeri listu' : add.msg ? 'nije spremljeno' : 'kraj' });
      writing = null; release();
      // a window opened meanwhile (the write waited) gets its button back, with what the list holds now
      if (mine === openSeq) add.busy = false;
      else if (add.list && add.num) refreshExisting().then(() => { if (isOpen()) renderAdd(); });
    }
    if (isOpen()) renderAdd();
  }
  async function write(mine, F = { step() {}, end() {} }) {
    renderAdd();
    // only this write's own window is changed by it (closed, its message): another one opened meanwhile is left alone
    const own = () => mine === openSeq;
    const num = add.num, qty = add.qty;
    const target = add.list ? { id: add.list.id, name: add.list.name } : { name: add.newName.trim() };
    // StoreFront's update SETS the quantity (had + qty): what the list holds is read again right before the write (a
    // colleague may have changed it); without that reading nothing is written
    let before = 0;
    if (add.list) {
      try {
        const it = await api().items(add.list.id);
        keep(it.store, { items: { [add.list.id]: { at: Date.now(), items: it.items || [] } } });
        before = existingQty(add.list.id, num) || 0;
        // 1.97: the limit again with what the list holds NOW (a colleague may have added): no write above it
        const L = limits();
        if (L.room !== null && qty > L.room) {
          F.end('colleague', { step: 'lista se promijenila: novi maksimum', n: L.room });
          add.msg = L.room > 0 ? `Na listi je sada ${komada(before)}. Najviše možeš dodati još ${whole(L.room)}; izaberi količinu i spremi ponovo.`
            : `Na listi je sada ${komada(before)}: granica je dostignuta, ništa nije poslano.`;
          return;
        }
      } catch (e) {
        if (e && e.how === 'login') { F.end('login', { step: 'čeka prijavu u StoreFront' }); loginNeeded(); return; }
        F.end(e && e.how === 'offline' ? 'network' : 'network', { step: 'čitanje liste prije upisa nije uspjelo' });
        add.msg = `Nije spremljeno: ne mogu pročitati listu ${add.list.name} (${why(e)}). Ništa nije poslano.`;
        return;
      }
    }
    const op = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    let res = null, lost = false;
    F.step('zahtjev poslan', 'sent', { n: qty });
    try { res = await api().add({ list: target, num, qty, had: before, op }); } catch (e) {
      if (e && e.how === 'lost') { lost = true; F.step('veza prekinuta prije potvrde · čitam listu', 'unsure'); }
      else if (e && e.how === 'login') { F.end('login', { step: 'čeka prijavu u StoreFront (ništa nije upisano)' }); loginNeeded(); return; } // the sign-in is checked before anything is written
      else { F.end(e && e.how === 'rejected' ? 'rejected' : 'network', { step: 'nije spremljeno' }); add.msg = `Nije spremljeno: ${why(e)}`; return; }
    }
    if (lost) {
      // the answer did not come back: the list is read again before anything else is offered
      try {
        const r = await api().lists();
        keep(r.store, { at: Date.now(), lists: r.lists || [] });
        const l = (r.lists || []).find((x) => (target.id ? x.id === target.id : x.name.toLowerCase() === target.name.toLowerCase()));
        if (!l) { add.msg = `Nije spremljeno: lista ${target.name} ne postoji u StoreFrontu. Možeš pokušati ponovo.`; return; }
        const it = await api().items(l.id);
        keep(it.store, { items: { [l.id]: { at: Date.now(), items: it.items || [] } } });
        const now = (it.items || []).filter((x) => x.num === num).reduce((n, x) => n + (+x.qty || 0), 0);
        if (now === before + qty) { res = { ok: true, list: l, qty: now }; F.step('lista pročitana: upis je tu', 'ok'); }
        else if (now === before && target.id) { add.msg = `Nije spremljeno: na listi je i dalje ${komada(now)}. Možeš pokušati ponovo.`; return; }
        else { add.list = l; add.creating = false; add.unsure = true; add.msg = `Nije potvrđeno — provjeri listu. Na listi ${l.name} je sada ${komada(now)} (prije ${komada(before)}); možda je i kolega mijenjao količinu.`; return; }
      } catch (e) {
        add.unsure = true;
        add.msg = 'Nije potvrđeno — provjeri listu. Veza je prekinuta i lista se ne može pročitati.';
        return;
      }
    }
    if (res && res.ok) {
      const l = res.list || target;
      S.user.refillLast = { ...(S.user.refillLast || {}), [lastKey()]: l.id };
      saveUser();
      // what the list holds now, from StoreFront (the proof that the write arrived)
      let total = before + qty;
      try { const it = await api().items(l.id); keep(it.store, { items: { [l.id]: { at: Date.now(), items: it.items || [] } } }); total = existingQty(l.id, num); } catch (e) { /* shown next time */ }
      F.end('ok', { step: 'StoreFront potvrdio upis', n: qty });
      toast(`Spremljeno u StoreFront: ${num} na ${l.name} · ukupno ${whole(total)} kom`);
      if (!own()) return;
      closeSheet();
      if (add.from === 'refill') {
        // back on the list, as StoreFront has it now (a new list: added to the lists first)
        if (!((S.user.refill && S.user.refill.lists) || []).some((x) => x.id === l.id)) { try { const r = await api().lists(); keep(r.store, { at: Date.now(), lists: r.lists || [] }); } catch (e) { /* next time */ } }
        if (top().id === 'refillList' && view.list && view.list.id === l.id) renderList();
        else openList(l.id);
      }
    }
  }
  function onClick(t) {
    if ('refillSf' in t.dataset) { openOfficial(); return true; }
    if ('refillReload' in t.dataset) { loadLists(); return true; }
    if ('refillHide' in t.dataset) { setCfg({ refillHide: !(cfg().refillHide) }); renderList(); return true; }
    if (t.dataset.refillList) { openList(t.dataset.refillList); return true; }
    if (t.dataset.refillRetry) { loadItems(t.dataset.refillRetry); return true; }
    if ('refillDel' in t.dataset) { askDelete(); return true; }
    if (t.dataset.refillUndo) { undoDelete(t.dataset.refillUndo); return true; }
    if (t.dataset.refillDelAgain) { confirmAgain(t.dataset.refillDelAgain); return true; }
    if ('refillAddHere' in t.dataset) { openAdd('', { listId: view.list && view.list.id, from: 'refill' }); return true; }
    if ('refillAddNew' in t.dataset) { openAdd('', { creating: true, from: 'refill' }); return true; }
    if ('refillScan' in t.dataset) { if (scanFor) scanFor((code) => { if (code) setArt(code); else if (isOpen()) renderAdd(); }); return true; }
    if ('refillArtClear' in t.dataset) { add.num = ''; add.art = ''; add.name = ''; add.msg = ''; renderAdd(); setTimeout(() => { const a = $('#refillArt'); if (a) a.focus(); }, 50); return true; }
    if (t.dataset.refillPick) {
      const l = ((S.user.refill && S.user.refill.lists) || []).find((x) => x.id === t.dataset.refillPick);
      add.list = l || null; add.creating = false;
      renderAdd();
      refreshExisting().then(() => { clampQty(); if (isOpen()) renderAdd(); });
      return true;
    }
    if ('refillNew' in t.dataset) { add.creating = true; add.list = null; renderAdd(); setTimeout(() => { const n = $('#refillNewName'); if (n) n.focus(); }, 50); return true; }
    if (t.dataset.refillStep) {
      const q = $('#refillQty');
      add.note = '';
      add.qty = Math.max(1, Math.min(9999, (Math.round(+(q && q.value) || add.qty)) + +t.dataset.refillStep));
      clampQty();
      renderAdd();
      return true;
    }
    if ('refillMax' in t.dataset) { const L = limits(); if (L.max !== null && L.max >= 1) { add.qty = L.max; add.note = ''; renderAdd(); } return true; }
    if ('refillInfo' in t.dataset) { loadInfo(add.num); return true; }
    return false;
  }
  return { open, renderLists, renderList, openAdd, onClick, api, resumePending, drainDeletes };
}
