// Injected into StoreFront's own page (the employee's sign-in, inside the app) by StoreTask. window.__stArg says what
// to do; the same calls StoreFront's pages make:
//   { mode: 'find', code }          an article by number or barcode, whatever its status code (21 and 81 included)
//   { mode: 'article', num }        one article: stock, SM/DM, price, sales and the stock history
//   { mode: 'top', cat, days }      the department's best sellers (StoreFront counts the last 30 days); for the first
//                                   ones also the last 7 days, from their stock history. 1.77: { all: true } every
//                                   article sold in the last 30 days (pages of 100), { any: true } every article of the
//                                   groups (any status), the candidates of a 365-day ranking
//   { mode: 'sales', nums }         1.77, read only: each article's sales from its stock history (251 sold, 252 returned)
//                                   for 7, 30 and 365 days, and how far back the history goes
//   { mode: 'smdm', cat, st }       articles of the department with these status codes and an SM value above 0
//   { mode: 'smset', items: [{ num, sm, dm }] }  saves these SM/DM values (only what the employee confirmed)
//   { mode: 'ping' }                nothing: makes the page ready (store known) for the reading that comes next
//   { mode: 'me' }                  who the employee is (name, number), to keep in the app's own settings
//   { mode: 'opcheck', items, since }  read only: stock history and Minus lista after a sending with unknown outcome
//   { mode: 'eans', nums, per }     read only: the barcodes of these articles from their master data (at most `per`, 400)
//   { mode: 'pics', nums }  read only: the picture addresses of these articles (at most 40)
//   { mode: 'histlong', num, max }  2.06, read only: one article's stock history up to `max` entries (slider, up to a year)
//   { mode: 'hier' }  read only: StoreFront's product groups (two levels), to choose another department
//   { mode: 'soon', nums | cats }  read only: articles that StoreFront says will go to 21 / 81, with the date
//   { mode: 'oopuslist', tab } | { mode: 'oopusfind', q } | { mode: 'oopusorder', bk, dg, src }  OOPUS, read only
//   { mode: 'oopushandout', bk, dg, src, no, store, sig, partialOk }  OOPUS: the customer signed, the order is handed over
//   { mode: 'ordsync', tabs, known, hist } | { mode: 'minuspeek' } | { mode: 'watch', minus }  2.15, read only: Narudžbe
//                                   and Minus lista by themselves (js/auto-sync.js) and the background look (OrderWatch)
// Only 'smset', the refill writes and 'oopushandout' change anything. The result is left in window.__st for the app to pick up.
(function () {
  if (window.__st && window.__st.state === 'busy') return;
  var arg = window.__stArg || {};
  var job = String(arg.job || '').slice(0, 40);
  window.__st = { state: 'busy', job: job };
  var ALL = ['01', '02', '11', '12', '21', '31', '32', '41', '42', '51', '81'];
  function s(v, n) { v = v == null ? '' : String(v).trim(); return v.length > n ? v.slice(0, n) : v; }
  function num(v) { v = +v; return isFinite(v) ? v : 0; }
  // 1.76: the planogram's readings give one request at most REQ_MS: a request StoreFront never answers no longer holds
  // the whole job (and every job after it) until the job's 2 min time-out. It counts as not answered (never as 0).
  var REQ_MS = { stockbatch: 15000, pricebatch: 15000, relatedstock: 15000, sales: 20000 }[arg.mode] || (arg.mode === 'top' && arg.page ? 90000 : 0); // 2.04: StoreFront took 27-43 s for one page of 50 (log 16.11.), 40 s cut most
  // 21. 11. 2026, for measuring: how long at least one StoreFront request was open (server + network, requests side by
  // side counted once); the rest of a job's time is the page and the app
  var NET = { open: 0, since: 0, ms: 0, n: 0 };
  function netOn() { if (!NET.open++) NET.since = Date.now(); NET.n++; }
  function netOff() { if (NET.open > 0 && !--NET.open) NET.ms += Date.now() - NET.since; }
  function req(method, u, body) {
    window.__st.n = (window.__st.n || 0) + 1; // requests made, for measuring (Postavke → dijagnostika)
    // 2.12: the handover sends what StoreFront's own page sends (no Accept; its answer is not always JSON)
    var h = arg.mode === 'oopushandout' && method === 'POST' ? {} : { Accept: 'application/json' };
    var raw = typeof Blob === 'function' && body instanceof Blob;
    if (body !== undefined) h['Content-Type'] = raw ? body.type || 'application/octet-stream' : 'application/json';
    if (body !== undefined || method !== 'GET') h.suppressMessages = 'true'; // as StoreFront's own page (1.97: DELETE)
    var ctl = REQ_MS && typeof AbortController === 'function' ? new AbortController() : null;
    var tm = ctl ? setTimeout(function () { ctl.abort(); }, REQ_MS) : 0;
    var o = { method: method, credentials: 'same-origin', headers: h, body: body === undefined ? undefined : raw ? body : JSON.stringify(body) };
    if (ctl) o.signal = ctl.signal;
    netOn();
    var off = function (x) { netOff(); off = function (y) { return y; }; return x; };
    return fetch(u, o).then(function (r) {
      if (r.status === 401 || r.status === 403) throw 'login';
      if ((r.headers.get('content-type') || '').indexOf('html') >= 0) throw 'login';
      return r.text().then(function (t) {
        off();
        var j = null;
        try { j = t ? JSON.parse(t) : null; } catch (e) { j = null; }
        if (!r.ok) throw 'http ' + r.status + (j && j.message ? ' ' + s(j.message, 80) : '');
        return j;
      });
    }).then(function (j) { if (tm) clearTimeout(tm); off(); return j; }, function (e) {
      if (tm) clearTimeout(tm);
      off();
      throw ctl && ctl.signal.aborted ? 'timeout' : e;
    });
  }
  var get = function (u) { return req('GET', u); };
  // the articles of the employee's own planogram (department): everything else is left out
  var only = Array.isArray(arg.only) && arg.only.length ? {} : null;
  if (only) arg.only.slice(0, 6000).forEach(function (n) { if (/^\d{7}$/.test(String(n))) only[String(n)] = 1; });
  function mine(x) { return !only || !!only[x.num]; }
  // the product groups to look in: the department's own groups when the app knows them, else the whole group
  var cats = (Array.isArray(arg.cats) ? arg.cats : []).map(function (c) { return s(c, 8); }).filter(function (c) { return /^\d{1,8}$/.test(c); }).slice(0, 80);
  var store = '', catalog = '', org = '', meUser = { name: '', num: '', user: '' };
  // the store and catalog are asked once per page: a warm page (StoreTask keeps it a minute) reuses them for 10 min,
  // one request less for every reading. Asking who the employee is ('me') always asks.
  function who() {
    var c = window.__stWho;
    // #25: not when the app was in the real StoreFront (or signed out) after this page asked (arg.whoAfter)
    if (arg.mode !== 'me' && arg.mode !== 'refilldel' && arg.mode !== 'oopushandout' && c && Date.now() - c.at < 600000 && c.store && c.catalog && !(Number(arg.whoAfter) > c.at)) {
      store = c.store; catalog = c.catalog; org = c.org || ''; meUser = c.me;
      return Promise.resolve();
    }
    return get('/api/v1/websapapi/user-details').then(function (u) {
      var ud = (u && u.userDetails) || {};
      meUser = { name: s(ud.name, 80), num: /^\d{3,12}$/.test(s(ud.employeeNumber, 12)) ? s(ud.employeeNumber, 12) : '', user: s(ud.username, 20) };
      var si = u && u.userDetails && u.userDetails.storeInfo;
      store = si && s(si.storeId, 10);
      catalog = si && s(si.catalogId, 30);
      org = (si && s(si.salesOrganisation, 10)) || '';
      if (!/^[0-9A-Za-z]{1,10}$/.test(store || '') || !/^[0-9A-Za-z-]{1,30}$/.test(catalog || '')) throw 'store';
      window.__stWho = { at: Date.now(), store: store, catalog: catalog, org: org, me: meUser };
    });
  }
  function search(body, max, fast) {
    var b = { storeId: store, catalogId: catalog, start: '0', max: String(max || 40) };
    for (var k in body) b[k] = body[k];
    // 2.19 (measured 19. 11. 2026, owner's StoreFront, "dani", 20 rows): with include=SmDm 9.4 s, without 0.4 s; the
    // answer without it has the price but its stock is not the live one, so `fast` callers read the stock afterwards
    return req('POST', '/api/v1/article/search' + (fast ? '' : '?include=SmDm'), b).then(function (j) {
      return { list: ((j && j.articleResults) || []).map(row), total: j && j.pagingInfo ? num(j.pagingInfo.total) : 0 };
    });
  }
  function salesPrice(value) {
    if (typeof value !== 'number' && !(typeof value === 'string' && value.trim())) return null;
    var price = Number(value);
    return isFinite(price) && price >= 0 ? price : null;
  }
  function row(a) {
    var d = a.smDmData || {};
    return {
      num: s(a.id, 10), name: s(a.title || d.title, 120), st: s(a.statusCode || d.articleStatus, 3), unit: s(a.unit || d.unit, 6),
      stock: num(a.storeStock != null ? a.storeStock : d.stock), free: num(a.sellableStock != null ? a.sellableStock : d.sellableStock),
      sm: num(d.smQuantity), dm: num(d.dmQuantity), cap: num(d.shelfCapacity || a.shelfCapacity), sold30: num(d.quantitySoldInPeriod),
      changed: s(d.lastChangedFmt, 20), ean: s(a.ean, 14), eans: (a.eanHistory || []).slice(0, 10).map(function (x) { return s(x, 14); }),
      // 1.77: the price only when the answer has one (never 0 for "not in this answer")
      price: salesPrice(a.activeSalesPrice),
    };
  }
  // the store's stock movements of an article, newest first: 251 sold, 252 returned, 101 received, others corrections
  // 1.99: max = only the newest entries (StoreFront's ?max=, newest first; BiH StoreFront 15. 11. 2026: a best seller's
  // whole history is 690 KB-1.2 MB, ?max=60 is 22 KB for the same server time)
  function history(n, max) {
    return get('/api/v1/stockhistory/' + encodeURIComponent(store) + '/' + encodeURIComponent(n) + (max ? '?max=' + max : '')).then(function (h) {
      return (Array.isArray(h) ? h : []).map(function (m) {
        return { t: num(m.entryTime), q: num(m.quantity), type: s(m.movementType, 4), after: num(m.totalStock), by: /^\d{1,3}$/.test(String(m.performedBy || '')) ? 'kasa' : '' };
      }).sort(function (a, b) { return b.t - a.t; });
    });
  }
  function soldSince(h, days) {
    var from = Date.now() - days * 86400000, n = 0;
    h.forEach(function (m) { if (m.t >= from && (m.type === '251' || m.type === '252')) n -= m.q; });
    return n;
  }
  // at most `size` requests at once (see pool): every mode that reads article by article
  function inBatches(list, size, fn) { return pool(list, size, fn); }
  // at most `size` at once, the next one starting as soon as any one ends (1.68 waited for the slowest of each batch
  // of `size`); answers in the order asked, a failed one as null, a sign-in stops everything
  function pool(list, size, fn) {
    return new Promise(function (resolve, reject) {
      var out = new Array(list.length), i = 0, running = 0, done = 0, stop = false;
      if (!list.length) { resolve(out); return; }
      // size: a number, or (1.76) a function: how many at once now (stockbatch lowers it when StoreFront slows down,
      // and says 0 when the app wants the page for what came on screen: the job then ends after those running, and
      // out.next tells where it stopped; what was not started is not answered at all, never as failed)
      var cap = function () { return typeof size === 'function' ? size() : size; };
      function next() {
        while (!stop && running < cap() && i < list.length) {
          (function (k) {
            running++;
            fn(list[k]).then(function (r) { out[k] = r; }, function (e) {
              if (e === 'login') { stop = true; reject(e); }
              out[k] = null;
            }).then(function () {
              running--; done++;
              window.__st.prog = done + '/' + list.length;
              if (stop) return;
              if (done === list.length) resolve(out); else next();
            });
          })(i++);
        }
        if (!stop && !running && i < list.length && cap() <= 0) { out.next = i; resolve(out); }
      }
      next();
    });
  }

  function find() {
    var code = s(arg.code, 20);
    if (!/^\d{4,14}$/.test(code)) throw 'bad code';
    // every status code (its article search page leaves out 81 by default): 1.96 says it explicitly, as topAll does
    // the search is loose (best match first: the owner's VIDAR barcode gave 175 rows) and its rows carry no barcodes,
    // so candidates are checked against their master data, which has the barcode (current and old ones). 1.96 (owner,
    // VIDAR 5707949527074 -> 6120901, status 81): the first 8 are checked, not 4 (the right one may be 5th to 8th).
    // Only an article whose master data HAS this barcode is returned; nothing is guessed from the loose search.
    // 2.04 (owner, 5900355228300): StoreFront's own page listed 10 loose rows and the app found nothing: the right one
    // can be past the 8th, so every row of the first 20 is checked (6 at a time, master data ~0.6 s each)
    // 2.04 (owner, LYDUM 3690442 / 5712110221064, checked in the owner's StoreFront 16. 11.): with fieldsToSearch
    // ['ean'] ALONE StoreFront matches the barcode exactly (LYDUM 1 row, TANGE 1, VIDAR 1, a made-up one 0); any other
    // field list is a loose search (199 rows). The scanned barcode can be one only the search knows (LYDUM's master data
    // has another one), so the exact answer is taken as it is; the loose search with master data confirmation stays
    // for barcodes only in the old EANs.
    var asked = {};
    function confirm(rows) {
      var cand = rows.filter(function (a) { if (asked[a.num]) return false; asked[a.num] = 1; return true; }).slice(0, 20);
      return pool(cand, 6, function (a) {
        return get('/api/v1/article/masterdata?article=' + a.num + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store)).then(function (j) {
          var m = Array.isArray(j) ? j[0] : j;
          if (!m) return null;
          var eans = [m.ean].concat(m.eanHistory || [], m.eans || []).map(function (x) { return s(x, 14); });
          if (eans.indexOf(code) < 0) return null;
          a.ean = code;
          var price = salesPrice(m.activeSalesPrice);
          if (price !== null) a.price = price;
          return a;
        }).catch(function (e) { if (e === 'login') throw e; return null; });
      }).then(function (l) { return { list: l.filter(Boolean), checked: cand.length }; });
    }
    function exactOf(r) { return r.list.filter(function (a) { return a.num === code || a.ean === code || a.eans.indexOf(code) >= 0; }); }
    function loose() {
      return search({ query: code, fieldsToSearch: ['id', 'ean', 'eanhistory'], statusCodes: ALL }, 20).then(function (r) {
        var exact = exactOf(r);
        if (exact.length) return { list: exact.slice(0, 6), checked: 0, total: r.total, rows: r.list.length, via: 2 };
        return confirm(r.list).then(function (c) {
          return { list: c.list, checked: c.checked, total: r.total, rows: r.list.length, via: c.list.length ? 2 : 0 };
        });
      });
    }
    if (!/^\d{8,14}$/.test(code)) return loose();
    return search({ query: code, fieldsToSearch: ['ean'], statusCodes: ALL }, 6).then(function (r) {
      // an exact barcode is on one article (rarely a few); a longer list would mean StoreFront searched loosely
      if (r.list.length && r.list.length <= 3) {
        r.list.forEach(function (a) { a.ean = code; });
        return { list: r.list, checked: 0, total: r.total, rows: r.list.length, exact: r.total, via: 1 };
      }
      return loose().then(function (x) { x.exact = r.total; return x; });
    });
  }

  // 1.96: one article by its number (the employee typed the number from the label): name, status, stock, price, the
  // picture, for "Poveži ovaj barkod" to show before the employee links it. Read only.
  // 2.15-pregled (owner, 19. 11. 2026): the home search found nothing in the planograms: StoreFront's own article
  // search for the same words (name or number), read only, the first 20 by StoreFront's relevance, all statuses
  function sfsearch() {
    var q = String(arg.q || '').replace(/\s+/g, ' ').trim().slice(0, 60);
    if (q.replace(/\s/g, '').length < 3) return Promise.resolve({ q: q, list: [], total: 0 });
    // 2.17: the statuses the employee picked (StoreFront's own statusCode filter); none or unknown = all
    var st = (Array.isArray(arg.st) ? arg.st : []).filter(function (x) { return ALL.indexOf(String(x)) >= 0; });
    return search({ query: q, statusCodes: st.length ? st : ALL }, 40, true).then(function (r) {
      return { q: q, store: store, total: r.total, list: r.list.filter(function (x) { return /^\d{4,9}$/.test(x.num); }).map(function (x) {
        // StoreFront answers status 01/02 as "1"/"2"; its stock here is not the live one (the app reads it next)
        return { num: x.num, name: x.name, st: /^\d$/.test(x.st) ? '0' + x.st : x.st, price: x.price, stock0: x.stock };
      }) };
    });
  }
  function lookup() {
    var n = s(arg.num, 10);
    if (!/^\d{4,9}$/.test(n)) throw 'bad num';
    return search({ query: n, fieldsToSearch: ['id'], statusCodes: ALL }, 20).then(function (r) {
      var a = r.list.filter(function (x) { return x.num === n; })[0];
      if (!a) return { found: false };
      return get('/api/v1/article/details?articleId=' + n + '&storeId=' + encodeURIComponent(store) + '&catalogId=' + encodeURIComponent(catalog)).then(function (j) {
        var b = (j && j.basicArticleData) || {};
        var u = s(b.webPictureUrl || b.thumbnailUrl, 200);
        if (u.indexOf('//') === 0) u = 'https:' + u;
        a.pic = /^https:\/\/(resources|cdn\d?)\.jysk\.com\/getimage\/[a-z0-9.]{1,20}\/\d{1,12}$/.test(u) ? u : '';
        return { found: true, a: a };
      }, function (e) { if (e === 'login') throw e; return { found: true, a: a }; });
    });
  }

  // Read-only stock for the article numbers of ONE planogram page (1.73-test3: faster).
  // Each article is read from its master data (GET, the same request as Uskoro and the department's groups, 8 at a time
  // as there; about a third of the time of the article search), with the stock part and the substitution chain: one
  // answer brings the stock, the price, the status, the name and the linked codes with their stock. An answer without
  // the stock part is read once more with only it (as Uskoro reads it); an article whose master data did not answer is
  // read with the article search as before 1.73-test3. A missing result, absent stock field, or failed request is NEVER
  // reported as stock zero. arg.verify (TEST builds): the first articles are read both ways and compared.
  function stockbatch() {
    var seen = {};
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(function (n) { return String(n); })
      .filter(function (n) { if (!/^\d{7}$/.test(n) || seen[n]) return false; seen[n] = 1; return true; }).slice(0, 40);
    if (!nums.length) throw 'bad input';
    var failed = [], missing = [], via = { md: 0, md2: 0, search: 0, slow: 0 };
    var check = Math.max(0, Math.min(4, +arg.verify || 0)), verify = check ? { asked: 0, same: 0, diff: [] } : null;
    var valid = function (v) { return v != null && String(v).trim() !== '' && isFinite(+v); };
    // 1.76: at most `par` requests at once (8 as since 1.73-test3, the app may ask fewer after a troubled job). A
    // request that failed lowers it by 2 for the rest of this job (never below 2); one that answered but took longer
    // than SLOW_MS by 1, never below 4: a slow network is not an overloaded StoreFront, and fewer at once over a
    // slow line only makes everything slower (the bench: 2.5 s per request, page 67 s -> 126 s with "slow = 2")
    var lim = Math.max(2, Math.min(8, Math.floor(+arg.par) || 8)), SLOW_MS = 8000;
    var slower = function (failed) { via.slow++; lim = failed ? Math.max(2, lim - 2) : Math.max(Math.min(lim, 4), lim - 1); };
    // 1.76 stream: each code's answer is put in window.__st.part as soon as it is there; the Java side passes them on
    // to the app while the job runs (StoreTask.java), the full list still comes at the end. Not for a check job.
    var stream = !!arg.stream && !check;
    if (stream) window.__st.part = [];
    if (stream && arg.yield) window.__st.yield = 1; // asked to yield while it still waited in the queue
    // 1.76 yield: the app set window.__st.yield (StoreTask.yieldJob: the employee panned to other articles while this
    // background job ran): no new request starts, those running finish, the rest comes back as `skipped`
    var cap = function () { return stream && window.__st && window.__st.yield ? 0 : lim; };
    // 1.84 (owner, 13. 11.): a code whose substitution chain the app already knows (fresh, < 3 days) is read without
    // the chain (include=SmDm, the request md2 has always used); the chain is only learned from the others. Time per
    // request of each kind is kept (via.chainMs/.chainN, via.liteMs/.liteN), so the phone's log can compare them.
    var lite = {};
    (Array.isArray(arg.lite) ? arg.lite : []).forEach(function (n) { if (/^\d{7}$/.test(String(n))) lite[String(n)] = 1; });
    via.chainMs = 0; via.chainN = 0; via.liteMs = 0; via.liteN = 0;
    var md = function (n, inc) {
      var t = Date.now();
      return get('/api/v1/article/masterdata?article=' + n + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=' + inc).then(function (j) {
        var ms = Date.now() - t;
        if (inc === 'SmDm') { via.liteMs += ms; via.liteN++; } else { via.chainMs += ms; via.chainN++; }
        if (ms > SLOW_MS) slower(false);
        return j;
      }, function (e) { if (e !== 'login') slower(true); throw e; });
    };
    // the article search, one article (the reading before 1.73-test3): { stock, free } or null
    var searchOne = function (n) {
      return req('POST', '/api/v1/article/search?include=SmDm', {
        storeId: store, catalogId: catalog, query: n, fieldsToSearch: ['id'], start: '0', max: '5'
      }).then(function (j) {
        if (!j || !Array.isArray(j.articleResults)) throw 'bad response';
        var a = j.articleResults.filter(function (a) { return String(a.id) === n; })[0];
        if (!a) return null;
        var d = a.smDmData || {};
        var raw = a.storeStock != null ? a.storeStock : d.stock, free = a.sellableStock != null ? a.sellableStock : d.sellableStock;
        if (!valid(raw)) return null;
        var out = { num: n, stock: +raw, unit: s(a.unit || d.unit, 6), st: s(a.statusCode || d.articleStatus, 3), name: s(a.title || d.title, 60) };
        if (valid(free)) out.free = +free;
        if (valid(a.activeSalesPrice) && +a.activeSalesPrice >= 0) { out.price = +a.activeSalesPrice; out.cur = s(a.activePriceCurrency || d.activePriceCurrency || 'BAM', 4); }
        return out;
      });
    };
    var chainOf = function (n, a) {
      if (!Array.isArray(a.substitutionChain)) return null; // not in this answer: unknown, not "none"
      var l = [], dd = {};
      a.substitutionChain.forEach(function (c) {
        var code = s(c && c.articleNumber, 10);
        if (!/^\d{7}$/.test(code) || code === n || dd[code]) return;
        dd[code] = 1;
        var d = c.smDmData || {};
        var x = { num: code, st: s(c.statusCode, 3), name: s(c.title || c.articleTitle || c.name || '', 60), known: valid(d.stock) };
        if (x.known) x.stock = +d.stock;
        if (valid(d.sellableStock)) x.free = +d.sellableStock;
        l.push(x);
      });
      return l;
    };
    // arg.via 'search': the article search only, 3 at a time (the reading before 1.73-test3), when the app found the
    // master data's stock different from the search's on this phone
    if (arg.via === 'search') {
      return inBatches(nums, 3, function (n) {
        return searchOne(n).then(function (x) { if (x) via.search++; else failed.push(n); return x; },
          function (e) { if (e === 'login') throw e; failed.push(n); return null; });
      }).then(function (list) { return { list: list.filter(Boolean), missing: missing, failed: failed, asked: nums.length, via: via, store: store }; });
    }
    var sent = function (x) {
      if (stream && x && window.__st && Array.isArray(window.__st.part)) {
        // 22. 11. 2026 (audit, "podaci prethodne prodavnice"): every part says the store it was read in, so the app
        // forgets another store's kept values at the FIRST answer, not only when the whole job ends (seconds later)
        var p = { w: store };
        for (var k in x) p[k] = x[k];
        window.__st.part.push(p);
      }
      return x;
    };
    return inBatches(nums, cap, function (n) {
      var light = !!lite[n];
      return md(n, light ? 'SmDm' : 'SubstitutionChainSmDm').then(function (j) {
        if (j == null) throw 'empty';
        if (Array.isArray(j) && !j.length) { missing.push(n); return null; } // StoreFront has no such article
        var a = Array.isArray(j) ? j[0] : j;
        if (!a || typeof a !== 'object') throw 'odd';
        // pm: the master data's price fields were looked at (a price, or StoreFront has none): no price job needed
        var out = { num: n, name: s(a.title, 60), st: s(a.statusCode, 3), unit: s(a.unit, 6), group: s(a.groupId, 8), groupName: s(a.groupTitle, 60), pm: true };
        if (valid(a.activeSalesPrice) && +a.activeSalesPrice >= 0) { out.price = +a.activeSalesPrice; out.cur = s(a.activePriceCurrency || 'BAM', 4); }
        if (valid(a.normalSalesPrice) && +a.normalSalesPrice >= 0) out.normal = +a.normalSalesPrice;
        var chain = chainOf(n, a);
        if (chain) { out.chain = chain.slice(0, 5); if (chain.length > 5) out.limited = true; }
        var put = function (d) { out.stock = +d.stock; if (valid(d.sellableStock)) out.free = +d.sellableStock; };
        var d = a.smDmData;
        if (d && valid(d.stock)) { put(d); via.md++; return out; }
        // this answer has no stock part: the master data once more with only it (already asked that way: the search)
        if (light) throw 'no stock fields';
        return md(n, 'SmDm').then(function (k) {
          var b = Array.isArray(k) ? k[0] : k;
          var d2 = b && b.smDmData;
          if (!d2 || !valid(d2.stock)) throw 'no stock fields';
          put(d2); via.md2++;
          return out;
        });
      }).then(function (out) {
        if (!out || !verify || verify.asked >= check) return out;
        verify.asked++;
        return searchOne(n).then(function (x) {
          if (x && x.stock === out.stock) verify.same++;
          else if (verify.diff.length < 3) verify.diff.push({ num: n, md: out.stock, search: x ? x.stock : null });
          return out;
        }, function (e) { if (e === 'login') throw e; if (verify.diff.length < 3) verify.diff.push({ num: n, md: out.stock, search: null }); return out; });
      }).catch(function (e) {
        if (e === 'login') throw e;
        // the master data did not answer (or had no stock): the article search for this one, as before
        return searchOne(n).then(function (x) { if (x) via.search++; else failed.push(n); return x; },
          function (e2) { if (e2 === 'login') throw e2; failed.push(n); return null; });
      }).then(sent);
    }).then(function (list) {
      var r = { list: list.filter(Boolean), missing: missing, failed: failed, asked: nums.length, via: via, par: lim, store: store };
      if (verify) r.verify = verify;
      if (list.next != null && list.next < nums.length) r.skipped = nums.slice(list.next);
      return r;
    });
  }

  // Read-only price fallback for article search results that omit price fields.
  // Limit to the currently viewed/zoomed PDF area; never query all store articles.
  function pricebatch() {
    var seen = {};
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(String)
      .filter(function (n) { if (!/^\d{7}$/.test(n) || seen[n]) return false; seen[n] = 1; return true; })
      .slice(0, 12);
    if (!nums.length) throw 'bad input';
    var failed = [];
    // 1.76: as many at once as the stock reading (the same request; one planogram job runs at a time), was 2
    return inBatches(nums, Math.max(2, Math.min(8, Math.floor(+arg.par) || 8)), function (n) {
      return get('/api/v1/article/masterdata?article=' + n +
        '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store))
        .then(function (j) {
          var a = Array.isArray(j) ? j[0] : j;
          if (!a) return null;
          var v = a.activeSalesPrice;
          if (v == null || String(v).trim() === '' || !isFinite(+v) || +v < 0) return null;
          return { num: n, price: +v, cur: s(a.activePriceCurrency || 'BAM', 4) };
        }).catch(function (e) {
          if (e === 'login') throw e;
          failed.push(n);
          return null;
        });
    }).then(function (list) { return { list: list.filter(Boolean), failed: failed, asked: nums.length, store: store }; });
  }

  // Read-only substitution stock, ALWAYS for the signed-in employee's own store.
  // The chain is authoritative; similar names or photos are NOT substitutes.
  function relatedstock() {
    var seen = {};
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(String).filter(function(n) {
      if (!/^\d{7}$/.test(n) || seen[n]) return false;
      seen[n] = true; return true;
    }).slice(0, 8);
    if (!nums.length) throw 'bad input';
    // 2.03: 4 at once (was 2): since 2.02 this job runs only when the planogram's stock jobs are done, alone on the
    // engine, and on a StoreFront that gives no stock next to the chain it carries all the chains of a page
    return inBatches(nums, 4, function(n) {
      return get('/api/v1/article/masterdata?article=' + n +
        '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) +
        '&include=SubstitutionChainSmDm').then(function(j) {
        var a = Array.isArray(j) ? j[0] : j;
        var chain = a && Array.isArray(a.substitutionChain) ? a.substitutionChain : [];
        var linked = [], dedupe = {};
        chain.forEach(function(c) {
          var code = s(c.articleNumber, 10), status = s(c.statusCode, 3);
          if (/^\d{7}$/.test(code) && code !== n && !dedupe[code]) {
            dedupe[code] = 1;
            linked.push({ num: code, st: status });
          }
        });
        // To avoid unbounded queries, stop at 5 verified links and mark partial.
        var limited = linked.length > 5;
        linked = linked.slice(0, 5);
        return inBatches(linked, 2, function(x) {
          return req('POST', '/api/v1/article/search?include=SmDm', {
            storeId: store, catalogId: catalog, query: x.num,
            fieldsToSearch: ['id'], start: '0', max: '5'
          }).then(function(reply) {
            var p = reply && Array.isArray(reply.articleResults) ?
              reply.articleResults.filter(function(v) { return String(v.id) === x.num; })[0] : null;
            if (!p) return { num: x.num, st: x.st, known: false };
            var d = p.smDmData || {}, raw = p.storeStock != null ? p.storeStock : d.stock;
            var free = p.sellableStock != null ? p.sellableStock : d.sellableStock;
            // Missing quantity or a failed request is UNKNOWN, never zero.
            if (raw == null || free == null || String(raw).trim() === '' ||
                String(free).trim() === '' || !isFinite(+raw) || !isFinite(+free)) {
              return { num: x.num, st: x.st, known: false };
            }
            return { num: x.num, st: s(p.statusCode || x.st, 3), name: s(p.title || d.title, 60),
              stock: +raw, free: +free, known: true };
          }).catch(function(e) {
            if (e === 'login') throw e;
            return { num: x.num, st: x.st, known: false };
          });
        }).then(function(items) { return { num: n, linked: items, limited: limited }; });
      }).catch(function(e) {
        if (e === 'login') throw e;
        return { num: n, linked: [], error: true };
      });
    }).then(function(list) { return { list: list.filter(Boolean), asked: nums.length }; });
  }

  // 1.98 (owner: "Imate li ovaj artikal i koliko košta?"): measured on the BiH StoreFront (14. 11. 2026, the owner's
  // session): masterdata ~105 ms, masterdata include=SmDm ~400 ms, the article search ~550 ms, the stock history
  // ~650 ms; before, the article waited for all three. Now ONE masterdata include=SmDm brings the price (active, normal,
  // JYSK+) AND this store's stock (total, sellable, SM, DM, capacity, sold): it is passed on at once (window.__st.part,
  // arg.stream) and the history follows in the full answer. The search is asked only when SmDm has no stock.
  // A missing price stays null (num() made it 0 before: "0,00 KM").
  function article() {
    var n = s(arg.num, 10);
    if (!/^\d{7}$/.test(n)) throw 'bad num';
    var val = function (v) { return v != null && String(v).trim() !== '' && isFinite(+v) ? +v : null; };
    // the store these requests are made for: with `hinted` (below) who() may find another store while they run and the
    // article is read again; what this first reading still brings after that is not passed on (w0 !== store)
    var w0 = store;
    var md = get('/api/v1/article/masterdata?article=' + n + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=SmDm').then(function (j) {
      var a = Array.isArray(j) ? j[0] : j;
      if (!a) return { md: {}, sd: null };
      var m = { price: val(a.activeSalesPrice), normal: val(a.normalSalesPrice), cur: s(a.activePriceCurrency, 4), st: s(a.statusCode, 3), stDate: s(a.dateStatusChangeFmt, 12), group: s(a.groupTitle, 60), name: s(a.title, 120), unit: s(a.unit, 6),
        // StoreFront 6.9.0: the JYSK+ member price, only when StoreFront gives one
        member: val(a.membershipPrice) !== null && +a.membershipPrice > 0 ? +a.membershipPrice : null };
      var d = a.smDmData || {};
      var stock = val(d.stock);
      // the stock part of the master data, in the shape of a search row (row()); none when it has no stock
      var sd = stock === null ? null : { num: n, name: s(d.title || a.title, 120), st: s(d.articleStatus || a.statusCode, 3), unit: s(d.unit || a.unit, 6), stock: stock,
        free: val(d.sellableStock), sm: val(d.smQuantity), dm: val(d.dmQuantity), cap: val(d.shelfCapacity), sold30: val(d.quantitySoldInPeriod), changed: s(d.lastChangedFmt, 20), via: 'md' };
      // 22. 11. 2026: w = the store of this part (a page started with the app's last store, see `hinted` below, may learn
      // that another one is signed in: the app then takes the second quick part, not only the first)
      if (arg.stream && window.__st && w0 === store) (window.__st.part = window.__st.part || []).push({ num: n, quick: 1, w: w0, md: m, sd: sd });
      return { md: m, sd: sd };
    }).catch(function (e) { if (e === 'login') throw e; return { md: {}, sd: null }; });
    var sd = md.then(function (x) {
      if (x.sd) return x.sd;
      return search({ query: n, fieldsToSearch: ['id'], statusCodes: ALL }, 5).then(function (r) {
        var row = r.list.filter(function (a) { return a.num === n; })[0] || null;
        if (row && arg.stream && window.__st && w0 === store) (window.__st.part = window.__st.part || []).push({ num: n, quick: 1, w: w0, md: x.md, sd: row });
        return row;
      });
    });
    // 1.99 (owner: the history is slow): the newest 60 entries first (what the screen shows: 7 grouped rows), passed on at
    // once; only when they do not reach 30 days back (a best seller) the newest 400 after them, for the sold counts. A
    // count the entries read do not cover is null ("?"), never a made-up number. A history that could not be read is
    // null with histErr (1.98 made it [], shown as "Nema promjena zalihe").
    var FIRST = 60, MORE = 400;
    var covers = function (h, max, days) { return h.length < max || (h.length && h[h.length - 1].t <= Date.now() - days * 86400000); };
    var sums = function (h, max) {
      var last = h.filter(function (m) { return m.type === '101' && m.q > 0; })[0] || null;
      return { sold7: covers(h, max, 7) ? soldSince(h, 7) : null, sold30h: covers(h, max, 30) ? soldSince(h, 30) : null, recv: last };
    };
    var hs = history(n, FIRST).then(function (h) {
      if (arg.stream && window.__st && w0 === store) {
        var s0 = sums(h, FIRST);
        (window.__st.part = window.__st.part || []).push({ num: n, histOnly: 1, hist: h.slice(0, 60), store: store, sold7: s0.sold7, sold30h: s0.sold30h, recv: s0.recv });
      }
      if (covers(h, FIRST, 30)) return { h: h, max: FIRST };
      return history(n, MORE).then(function (h2) { return { h: h2, max: MORE }; }, function (e) { if (e === 'login') throw e; return { h: h, max: FIRST }; });
    }, function (e) { if (e === 'login') throw e; return null; });
    return Promise.all([md, sd, hs]).then(function (x) {
      var r = x[2];
      if (!r) return { num: n, store: store, catalog: catalog, md: x[0].md, sd: x[1], sold7: null, sold30h: null, recv: null, hist: null, histErr: 1 };
      var s1 = sums(r.h, r.max);
      return { num: n, store: store, catalog: catalog, md: x[0].md, sd: x[1], sold7: s1.sold7, sold30h: s1.sold30h, recv: s1.recv, hist: r.h.slice(0, 60) };
    });
  }

  // 2.06 (owner, 16. 11. 2026): read only, one article's longer stock history for the slider of the history box (6 months,
  // a year). Asked only when the employee moves the slider past what the article screen already read (60 entries).
  // full: StoreFront gave fewer than asked, so this is all it has; else the oldest entry says how far back it reaches.
  function histlong() {
    var n = s(arg.num, 10);
    if (!/^\d{7}$/.test(n)) throw 'bad num';
    var max = Math.max(60, Math.min(2000, Math.floor(+arg.max) || 1000));
    return history(n, max).then(function (h) {
      var from = Date.now() - 400 * 86400000;
      var l = h.filter(function (m) { return m.t >= from; });
      return { num: n, store: store, hist: l, full: h.length < max, max: max };
    });
  }

  // 1.77: every article of the groups, page by page (100 a request, at most `cap`): sold in the last 30 days (orderBy:
  // sales, it ends at the first article with none), or any (all statuses: the candidates of a 365-day ranking)
  function topAll(cat, any) {
    var cap = Math.max(100, Math.min(3000, +arg.cap || 2000)), out = [], total = 0;
    function page(start) {
      var b = { categories: cats.length ? cats : [cat], statusCodes: ALL, start: String(start), max: '100' };
      if (!any) { b.orderBy = 'quantitySoldInPeriod'; b.orderByDirection = 'DESC'; }
      return search(b, 100).then(function (r) {
        total = r.total;
        var l = r.list.filter(mine);
        out = out.concat(any ? l : l.filter(function (a) { return a.sold30 > 0; }));
        window.__st.prog = out.length + '/' + (any ? total : '?');
        var more = r.list.length === 100 && start + 100 < total && out.length < cap;
        if (!any && r.list.length && r.list[r.list.length - 1].sold30 <= 0) more = false; // sorted: the rest sold nothing
        return more ? page(start + 100) : out;
      });
    }
    return page(0).then(function (l) {
      var seen = {};
      l = l.filter(function (a) { if (seen[a.num]) return false; seen[a.num] = 1; return true; });
      return { list: l.slice(0, cap), total: total, limited: l.length >= cap || (any && l.length < total && !only), store: store };
    });
  }

  // 1.77 read only: sales of each article from its stock history, 4 requests at once (at most 30 articles a job: a
  // visible planogram page waits at most one such job). Net sales: sold (251) minus returned by customers (252);
  // transfers, receipts, stocktaking and write-offs are not sales. `oldest`: the first movement the history has.
  function sales() {
    var seen = {};
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(String).filter(function (n) { if (!/^\d{7}$/.test(n) || seen[n]) return false; seen[n] = 1; return true; }).slice(0, 30);
    if (!nums.length) throw 'bad input';
    var failed = [];
    return inBatches(nums, 4, function (n) {
      return history(n).then(function (h) {
        var sold = 0, ret = 0, from365 = Date.now() - 365 * 86400000;
        h.forEach(function (m) { if (m.t >= from365) { if (m.type === '251') sold -= m.q; else if (m.type === '252') ret += m.q; } });
        return { num: n, s7: soldSince(h, 7), s30: soldSince(h, 30), s365: soldSince(h, 365), sold365: sold, ret365: ret,
          oldest: h.length ? h[h.length - 1].t : 0, n: h.length };
      }, function (e) { if (e === 'login') throw e; failed.push(n); return null; });
    }).then(function (l) { return { list: l.filter(Boolean), failed: failed, store: store }; });
  }

  function top() {
    var cat = s(arg.cat, 10);
    if (!/^[0-9A-Za-z]{1,10}$/.test(cat)) throw 'bad cat';
    // 1.78: ONE page per job ({ page: { start, max } }): the app asks page after page, shows each at once and can stop,
    // carry on and retry a smaller page. 1.77 read up to 20 pages of 100 in one job and lost everything at the
    // job's 2 min time-out (Homeware: "top error (timeout)").
    if (arg.page) {
      var start = Math.max(0, Math.floor(+arg.page.start) || 0), max = Math.max(10, Math.min(100, Math.floor(+arg.page.max) || 50));
      var b = { categories: cats.length ? cats : [cat], statusCodes: ALL, start: String(start), max: String(max) };
      if (!arg.any) { b.orderBy = 'quantitySoldInPeriod'; b.orderByDirection = 'DESC'; }
      var t0 = Date.now();
      return search(b, max).then(function (r) {
        var rows = r.list;
        return { list: rows.filter(mine).filter(function (a) { return arg.any || a.sold30 > 0; }), n: rows.length, start: start, total: r.total,
          last: rows.length ? rows[rows.length - 1].sold30 : 0, ms: Date.now() - t0, store: store };
      });
    }
    if (arg.all || arg.any) return topAll(cat, !!arg.any);
    var deep = Math.max(0, Math.min(60, +arg.deep || 40));
    return search({ categories: cats.length ? cats : [cat], statusCodes: ALL, orderBy: 'quantitySoldInPeriod', orderByDirection: 'DESC' }, only ? 300 : 80).then(function (r) {
      var list = r.list.filter(function (a) { return a.sold30 > 0 && mine(a); }).slice(0, 80);
      // the last 7 days: from the stock history of the first ones
      return inBatches(list.slice(0, deep), 6, function (a) { return history(a.num).then(function (h) { a.sold7 = soldSince(h, 7); }); }).then(function () {
        return { list: list, total: r.total };
      });
    });
  }

  // articles of the department with these status codes that still have an SM or a DM value (two searches, merged)
  function smdm() {
    var cat = s(arg.cat, 10);
    // 1.98: StoreFront's own SM & DM filter "Discontinued articles with SM/DM value" asks for statuses 21, 81 and 42
    var st = (Array.isArray(arg.st) ? arg.st : ['21', '81', '42']).map(function (x) { return s(x, 3); }).filter(function (x) { return /^\d{2}$/.test(x); });
    if (!/^[0-9A-Za-z]{1,10}$/.test(cat) || !st.length) throw 'bad input';
    var limited = false;
    function all(field) {
      var out = [];
      function page(start) {
        var b = { storeId: store, catalogId: catalog, categories: cats.length ? cats : [cat], statusCodes: st, smDmQuantityParameters: [{ operator: 'GT', value: 0, field: field }], start: String(start), max: '100' };
        return req('POST', '/api/v1/article/search?include=SmDm', b).then(function (j) {
          var l = ((j && j.articleResults) || []).map(function (a) {
            // 1.98: an SM or DM value StoreFront did not give is null ("Nije očitano"), never 0
            var x = row(a), d = a.smDmData || {};
            x.sm = smv(d.smQuantity); x.dm = smv(d.dmQuantity);
            return x;
          });
          out = out.concat(l);
          var total = j && j.pagingInfo ? num(j.pagingInfo.total) : 0;
          if (l.length && out.length < total && out.length < 500) return page(start + l.length);
          if (out.length < total) limited = true;
          return out;
        });
      }
      return page(0);
    }
    return Promise.all([all('SM'), all('DM')]).then(function (ab) {
      var a = ab[0], b = ab[1];
      {
        var seen = {};
        var list = a.concat(b).filter(function (x) { if (seen[x.num] || !mine(x)) return false; seen[x.num] = 1; return true; });
        if (arg.nosucc) return { list: list, total: list.length, limited: limited };
        // the article's replacement number (substitution chain) that is still sold: its SM/DM may have to take over
        return inBatches(list, 6, function (x) {
          return get('/api/v1/article/masterdata?article=' + x.num + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=SubstitutionChainSmDm').then(function (j) {
            var m = Array.isArray(j) ? j[0] : j;
            var c = ((m && m.substitutionChain) || []).filter(function (e) {
              var st = s(e.statusCode, 3);
              return /^\d{7}$/.test(s(e.articleNumber, 10)) && s(e.articleNumber, 10) !== x.num && st !== '21' && st !== '81';
            })[0];
            if (!c) return;
            var d = c.smDmData || {};
            x.succ = { num: s(c.articleNumber, 10), st: s(c.statusCode, 3), sm: num(d.smQuantity), dm: num(d.dmQuantity), stock: num(d.stock) };
          });
        }).then(function () { return { list: list, total: list.length, limited: limited }; });
      }
    });
  }

  // everything of the department that has an SM or a DM value (any status), the replacement numbers of the ones
  // that go out, and the best sellers of the last 30 days: the material for a full check of the values
  function audit() {
    var cat = s(arg.cat, 10);
    if (!/^[0-9A-Za-z]{1,10}$/.test(cat)) throw 'bad input';
    function all(field) {
      var out = [];
      function page(start) {
        var b = { storeId: store, catalogId: catalog, categories: cats.length ? cats : [cat], statusCodes: ALL, smDmQuantityParameters: [{ operator: 'GT', value: 0, field: field }], start: String(start), max: '100' };
        return req('POST', '/api/v1/article/search?include=SmDm', b).then(function (j) {
          var l = ((j && j.articleResults) || []).map(row);
          out = out.concat(l);
          var total = j && j.pagingInfo ? num(j.pagingInfo.total) : 0;
          window.__st.prog = field + ' ' + out.length + '/' + total;
          if (l.length && out.length < total && out.length < 800) return page(start + l.length);
          return out;
        });
      }
      return page(0);
    }
    var list = [], top = [];
    return Promise.all([all('SM'), all('DM')]).then(function (ab) {
      var a = ab[0], b = ab[1];
      {
        var seen = {};
        list = a.concat(b).filter(function (x) { if (seen[x.num] || !mine(x)) return false; seen[x.num] = 1; return true; });
        var out = list.filter(function (x) { return x.st === '21' || x.st === '81'; });
        return inBatches(out, 6, function (x) {
          return get('/api/v1/article/masterdata?article=' + x.num + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=SubstitutionChainSmDm').then(function (j) {
            var m = Array.isArray(j) ? j[0] : j;
            var c = ((m && m.substitutionChain) || []).filter(function (e) {
              var st = s(e.statusCode, 3);
              return /^\d{7}$/.test(s(e.articleNumber, 10)) && s(e.articleNumber, 10) !== x.num && st !== '21' && st !== '81';
            })[0];
            if (!c) return;
            var d = c.smDmData || {};
            x.succ = { num: s(c.articleNumber, 10), st: s(c.statusCode, 3), sm: num(d.smQuantity), dm: num(d.dmQuantity), stock: num(d.stock) };
          });
        });
      }
    }).then(function () {
      return search({ categories: cats.length ? cats : [cat], statusCodes: ['01', '02', '11', '12', '31', '32', '41'], orderBy: 'quantitySoldInPeriod', orderByDirection: 'DESC' }, only ? 200 : 40);
    }).then(function (r) {
      top = r.list.filter(function (a) { return a.sold30 > 0 && mine(a); }).slice(0, 40);
      return { list: list, top: top };
    });
  }

  // the product groups (5 digits, e.g. 50101 Svijećnjaci) of the articles of the employee's planogram: his department
  // in StoreFront's terms, so that old articles (21/81, no longer in the planogram) of those groups are found too
  function groups() {
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).filter(function (n) { return /^\d{7}$/.test(String(n)); }).slice(0, 1500);
    if (!nums.length) throw 'bad input';
    var by = {};
    return inBatches(nums, 8, function (n) {
      return get('/api/v1/article/masterdata?article=' + n + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store)).then(function (j) {
        var a = Array.isArray(j) ? j[0] : j;
        var g = a && s(a.groupId, 8);
        if (!g || !/^\d{3,8}$/.test(g)) return;
        by[g] = by[g] || { id: g, title: s(a.groupTitle, 60), n: 0 };
        by[g].n++;
      });
    }).then(function () {
      return { groups: Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return b.n - a.n; }), asked: nums.length };
    });
  }

  // the articles to sell out (status 21 / 81) of these groups that the store still has: in stock, or on display (DM)
  // with nothing left in stock. With price, date of the status and the replacement number that is still sold.
  function clear() {
    var cs = cats.length ? cats : [s(arg.cat || '5', 8)];
    // StoreFront ignores the stock filter and answers with every 21/81 article of the group (furniture: ~2600 rows,
    // ~25 s in one request). The same rows are asked for as two requests side by side, one per status code, so the
    // answer comes in about the time of the bigger half; the list is the same.
    var by = function (st) { return { storeId: store, catalogId: catalog, categories: cs, statusCodes: [st], stockValueQuantityParameters: [{ operator: 'GT', value: 0 }], start: '0', max: '3000' }; };
    var d = { storeId: store, catalogId: catalog, categories: cs, statusCodes: ['21', '81'], smDmQuantityParameters: [{ operator: 'GT', value: 0, field: 'DM' }], start: '0', max: '500' };
    return Promise.all([req('POST', '/api/v1/article/search?include=SmDm', by('21')), req('POST', '/api/v1/article/search?include=SmDm', by('81')), req('POST', '/api/v1/article/search?include=SmDm', d)]).then(function (r) {
      var seen = {}, list = [];
      var overflow = r.some(function (part) {
        return part && part.pagingInfo && num(part.pagingInfo.total) >
          ((part.articleResults || []).length);
      });
      ((r[0] && r[0].articleResults) || []).concat((r[1] && r[1].articleResults) || [], (r[2] && r[2].articleResults) || []).forEach(function (a) {
        var x = row(a);
        x.chg = s(a.dateStatusChangeFmt, 10);
        if (seen[x.num] || !(x.stock > 0 || x.dm > 0)) return;
        // Some StoreFront catalog responses already contain the fields that were
        // previously fetched with an extra per-article masterdata request.
        // Trust only PRESENT fields; never pretend a missing substitution chain is empty.
        if (a.activeSalesPrice != null) x.price = num(a.activeSalesPrice);
        if (a.normalSalesPrice != null) x.reg = num(a.normalSalesPrice);
        if (a.groupId != null) x.group = s(a.groupId, 8);
        if (a.groupTitle != null) x.groupName = s(a.groupTitle, 60);
        if (Array.isArray(a.substitutionChain)) {
          x.chainKnown = true;
          var c = a.substitutionChain.filter(function (e) {
            var st = s(e.statusCode, 3);
            return /^\d{7}$/.test(s(e.articleNumber, 10)) && s(e.articleNumber, 10) !== x.num && st !== '21' && st !== '81';
          })[0];
          if (c) x.succ = { num: s(c.articleNumber, 10), st: s(c.statusCode, 3) };
        }
        seen[x.num] = 1;
        list.push(x);
      });
      window.__st.prog = '0/' + list.length;
      // Skip redundant metadata GETs only when the search result already carries
      // a price, category, status date and explicit substitution chain.
      var enrich = list.slice(0, 600).filter(function (x) {
        return x.price == null || x.reg == null || !x.group || !x.chg || !x.chainKnown;
      });
      return inBatches(enrich, 6, function (x) {
        return get('/api/v1/article/masterdata?article=' + x.num + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=SubstitutionChainSmDm').then(function (j) {
          var m = Array.isArray(j) ? j[0] : j;
          if (!m) return;
          x.price = num(m.activeSalesPrice);
          x.reg = num(m.normalSalesPrice);
          x.group = s(m.groupId, 8);
          x.groupName = s(m.groupTitle, 60);
          x.chg = s(m.dateStatusChangeFmt, 12) || x.chg;
          var c = (m.substitutionChain || []).filter(function (e) {
            var st = s(e.statusCode, 3);
            return /^\d{7}$/.test(s(e.articleNumber, 10)) && s(e.articleNumber, 10) !== x.num && st !== '21' && st !== '81';
          })[0];
          if (c) x.succ = { num: s(c.articleNumber, 10), st: s(c.statusCode, 3) };
        });
      }).then(function () { return { list: list.slice(0, 600).map(function (x) { delete x.chainKnown; return x; }), total: list.length, limited: overflow || list.length > 600 }; });
    });
  }

  // SM/DM values are SET (not added), so sending the same line twice gives the same result. What can go wrong is a
  // stale screen: someone else changed the value since the list was read, or the same article is twice in one batch
  // with different values. So for every line that says what the screen showed (was), the current value is read
  // first: already the wanted value = done; different from what the screen showed = not written ("promijenjeno").
  // StoreFront has no compare-and-set: between this read and the write someone could still change it (seconds).
  function smv(v) { return v != null && String(v).trim() !== '' && isFinite(+v) ? Math.round(+v) : null; }
  // 1.98: the current SM and DM of these articles (article/details, as smset reads before and after a write): after a
  // saving whose answer was lost, or a row StoreFront gave without a value. Read only. { list: [{ num, sm, dm }] };
  // a value that cannot be read is null.
  function smread() {
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(String).filter(function (n) { return /^(\d{7}|S\d{6})$/.test(n); }).slice(0, 300);
    if (!nums.length) throw 'bad input';
    var out = [];
    return inBatches(nums, 4, function (n) {
      return get('/api/v1/article/details?articleId=' + encodeURIComponent(n) + '&storeId=' + encodeURIComponent(store) + '&catalogId=' + encodeURIComponent(catalog)).then(function (j) {
        var b = (j && j.basicArticleData) || {}, d = b.smDmData || {};
        out.push({ num: n, sm: smv(d.smQuantity), dm: smv(d.dmQuantity), st: s(b.statusCode || d.articleStatus, 3) });
      }, function (e) { if (e === 'login') throw e; out.push({ num: n, sm: null, dm: null, err: 1 }); });
    }).then(function () { return { list: out }; });
  }
  function smset() {
    var raw = (Array.isArray(arg.items) ? arg.items : []).slice(0, 300).filter(function (x) {
      return x && /^(\d{7}|S\d{6})$/.test(String(x.num)) && isFinite(+x.sm) && +x.sm >= 0 && +x.sm <= 9999 && isFinite(+x.dm) && +x.dm >= 0 && +x.dm <= 9999;
    });
    if (!raw.length) throw 'bad input';
    var done = [], failed = [], same = [];
    // the same article twice: same values = once; different values = neither (the app's screens disagree)
    var by = {}, clash = {};
    raw.forEach(function (x) {
      var n = String(x.num), p = by[n];
      if (!p) { by[n] = x; return; }
      if (Math.round(+p.sm) !== Math.round(+x.sm) || Math.round(+p.dm) !== Math.round(+x.dm)) clash[n] = 1;
    });
    var items = Object.keys(by).filter(function (n) {
      if (clash[n]) { failed.push({ num: n, why: 'dvaput u seriji s različitim vrijednostima' }); return false; }
      return true;
    }).map(function (n) { return by[n]; });
    // test build: nothing is saved, the answer is played (the app shows it like a real one)
    if (arg.dry) return new Promise(function (ok) { setTimeout(function () { ok({ done: items.map(function (x) { return String(x.num); }), failed: failed, same: [], dry: true }); }, 800); });
    function want(x) { return { sm: Math.round(+x.sm), dm: Math.round(+x.dm) }; }
    function current(n) {
      return get('/api/v1/article/details?articleId=' + encodeURIComponent(n) + '&storeId=' + encodeURIComponent(store) + '&catalogId=' + encodeURIComponent(catalog)).then(function (j) {
        var d = j && j.basicArticleData && j.basicArticleData.smDmData;
        if (!d || !isFinite(+d.smQuantity) || !isFinite(+d.dmQuantity)) throw 'nije pročitano';
        return { sm: Math.round(+d.smQuantity), dm: Math.round(+d.dmQuantity) };
      });
    }
    // four at a time: one by one, 50 articles took StoreFront minutes
    return inBatches(items, 4, function (x) {
      var n = String(x.num), w = want(x);
      var was = x.was && isFinite(+x.was.sm) && isFinite(+x.was.dm) ? { sm: Math.round(+x.was.sm), dm: Math.round(+x.was.dm) } : null;
      // no line is written without the value the screen showed and a fresh read of StoreFront's current value
      if (!was) { failed.push({ num: n, why: 'bez prikazane vrijednosti, nije upisano' }); return Promise.resolve(); }
      return current(n).then(function (cur) {
        if (cur.sm === w.sm && cur.dm === w.dm) { done.push(n); same.push(n); return; } // already so (e.g. sent before)
        if (cur.sm !== was.sm || cur.dm !== was.dm) { failed.push({ num: n, why: 'promijenjeno u međuvremenu: sada SM ' + cur.sm + ', DM ' + cur.dm, cur: cur, changed: 1 }); return; }
        return req('POST', '/api/v1/article-smdm-data/update', { storeId: store, articleId: n, module: 'SM_DM', smQuantity: w.sm, dmQuantity: w.dm })
          // 1.77: read back: "done" only when StoreFront now has the values (a 200 without saving is not done). A
          // read-back that fails says so; sending again is safe (the values are absolute, "already so" is not written)
          .then(function () {
            return current(n).then(function (now) {
              if (now.sm === w.sm && now.dm === w.dm) done.push(n);
              else failed.push({ num: n, why: 'StoreFront nije potvrdio upis: sada SM ' + now.sm + ', DM ' + now.dm, cur: now });
            }, function (e) { if (e === 'login') throw e; failed.push({ num: n, why: 'upisano, ali provjera nije pročitana: provjeri u StoreFrontu', unsure: 1 }); });
          });
      }).then(null, function (e) { if (e === 'login') throw e; failed.push({ num: n, why: s(e, 100) }); });
    }).then(function () { return { done: done, failed: failed, same: same }; });
  }

  // who the employee is (name and number, as StoreFront has them): the app keeps it in its own settings, on the phone
  function me() {
    // the store comes from the sign-in (user-details), never from the app: colleagues of other stores use it too
    return Promise.resolve({ name: meUser.name, num: meUser.num, store: s(store, 10) });
  }

  // Read only. After a sending whose outcome is not known: what StoreFront's stock history shows for these articles
  // since shortly before the sending, and whether they are still on the Minus lista. The app compares; it never
  // decides on its own that something went through.
  function opcheck() {
    var items = (Array.isArray(arg.items) ? arg.items : []).slice(0, 60).filter(function (x) {
      return x && /^\d{7}$/.test(String(x.num)) && /^\d{7}$/.test(String(x.target));
    });
    if (!items.length) throw 'bad input';
    var since = +arg.since || 0;
    var arts = {};
    items.forEach(function (x) { arts[x.num] = 1; arts[x.target] = 1; });
    var mineIds = [meUser.user, meUser.num].filter(Boolean);
    var hist = [];
    return inBatches(Object.keys(arts), 4, function (a) {
      return get('/api/v1/stockhistory/' + encodeURIComponent(store) + '/' + a).then(function (h) {
        (Array.isArray(h) ? h : []).forEach(function (x) {
          var t = typeof x.entryTime === 'number' ? x.entryTime : Date.parse(String(x.entryTimeIsoTime || '').replace(/\[.*\]$/, ''));
          if (!isFinite(t) || t < since - 6 * 3600000) return;
          hist.push({ art: a, q: num(x.quantity), type: s(x.movementType, 4), t: t,
            mine: mineIds.indexOf(s(x.username, 20)) >= 0 || mineIds.indexOf(s(x.performedBy, 20)) >= 0 });
        });
      });
    }).then(function () {
      return get('/api/v1/minus-list/' + encodeURIComponent(store) + '?include=Article');
    }).then(function (list) {
      var minus = {};
      (Array.isArray(list) ? list : []).forEach(function (x) { minus[s(x.articleId, 10)] = num(x.totalStock); });
      return { at: Date.now(), hist: hist, minus: minus };
    });
  }

  // the pictures StoreFront shows for these articles (read only): the small and the medium picture of JYSK's own
  // image server, for articles that are not in any of the employee's planograms
  function pics() {
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(function (n) { return s(n, 10); }).filter(function (n) { return /^\d{7}$/.test(n); }).slice(0, 40);
    var ok = function (u) {
      u = s(u, 200);
      if (u.indexOf('//') === 0) u = 'https:' + u;
      return /^https:\/\/(resources|cdn\d?)\.jysk\.com\/getimage\/[a-z0-9.]{1,20}\/\d{1,12}$/.test(u) ? u : '';
    };
    return inBatches(nums, 4, function (n) {
      return get('/api/v1/article/details?articleId=' + n + '&storeId=' + encodeURIComponent(store) + '&catalogId=' + encodeURIComponent(catalog)).then(function (j) {
        var b = (j && j.basicArticleData) || {};
        return { num: n, s: ok(b.thumbnailUrl), m: ok(b.webPictureUrl) };
      });
    }).then(function (l) { return { pics: l.filter(Boolean) }; });
  }

  // the barcodes (EAN, older EANs) of these articles (read only), so a scanned barcode finds its article at once
  // The barcodes are NOT in the search rows (see find): StoreFront has them in the master data of each article.
  // 1.63-1.68 read them from the search rows and so never found one (fixed in 1.69: barkodova 0 on the phone).
  // One master data read per article, at most 6 at once.
  function eans() {
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(function (n) { return s(n, 10); }).filter(function (n) { return /^\d{7}$/.test(n); });
    var per = Math.max(0, Math.min(400, +arg.per || 400));
    var valid = function (e) { return /^\d{8,14}$/.test(e); };
    // err: why the reads that brought nothing failed (1.72: the phone showed 0 answers marked "ok" and nothing more)
    //   net: no connection (fetch failed at once), http: StoreFront answered with an error status, empty: an empty or
    //   unreadable body, odd: an error message instead of master data. None of these is "the article has no barcode".
    var info = { keys: null, withEan: 0, none: 0, per: per, err: { net: 0, http: 0, empty: 0, odd: 0 }, status: {} };
    var eanKey = function (k) { return /ean|gtin|bar/i.test(k); };
    return pool(nums.slice(0, per), 6, function (n) {
      return get('/api/v1/article/masterdata?article=' + n + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store)).then(function (j) {
        if (j == null) throw 'empty';
        if (Array.isArray(j) && !j.length) { info.none++; return { num: n, eans: [], none: true }; } // StoreFront has no such article
        var m = Array.isArray(j) ? j[0] : j;
        if (!m || typeof m !== 'object') throw 'odd';
        var ks = Object.keys(m);
        if (!ks.some(eanKey) && (ks.indexOf('message') >= 0 || ks.indexOf('error') >= 0 || ks.indexOf('errors') >= 0)) throw 'odd';
        // the names of the fields (never their values), once, for the diagnostics
        if (!info.keys) info.keys = ks.filter(eanKey).slice(0, 12);
        var l = [m.ean].concat(m.eanHistory || [], m.eans || []).map(function (x) { return s(x, 14); }).filter(valid);
        l = l.filter(function (e, i) { return l.indexOf(e) === i; }).slice(0, 10);
        if (l.length) info.withEan++;
        return { num: n, eans: l };
      }).catch(function (e) {
        if (e === 'login') throw e;
        var k = e === 'empty' || e === 'odd' ? e : typeof e === 'string' && e.indexOf('http ') === 0 ? 'http' : 'net';
        info.err[k]++;
        if (k === 'http') { var c = e.split(' ')[1]; info.status[c] = (info.status[c] || 0) + 1; }
        throw e;
      });
    }).then(function (l) { return { list: l.filter(Boolean), info: info }; });
  }


  // read only: StoreFront's product groups, two levels (e.g. 4 Namještaj > its subgroups), to choose a department
  function hier() {
    return get('/api/v1/catalog/product-hierarchy-groups?catalogId=' + encodeURIComponent(catalog)).then(function (j) {
      var ok = function (g) { return g && /^\d{1,8}$/.test(s(g.groupId, 8)) && s(g.title, 60); };
      return { groups: (Array.isArray(j) ? j : []).filter(ok).slice(0, 40).map(function (g) {
        return { id: s(g.groupId, 8), title: s(g.title, 60), subs: (Array.isArray(g.subGroups) ? g.subGroups : []).filter(ok).slice(0, 60).map(function (x) { return { id: s(x.groupId, 8), title: s(x.title, 60) }; }) };
      }) };
    });
  }

  // Read only. Articles whose coming status change StoreFront already knows (futurestatusCode with the date it is
  // valid from): those that go to 21 (discontinued) or 81. Either these article numbers (the employee's planogram)
  // or every article of these product groups that is not 21/81 yet. Sorted by the date, the soonest first.
  function soon() {
    var nums = (Array.isArray(arg.nums) ? arg.nums : []).map(function (n) { return s(n, 10); }).filter(function (n) { return /^\d{7}$/.test(n); });
    var first;
    if (nums.length) first = Promise.resolve(nums);
    else {
      if (!cats.length) throw 'bad input';
      var out = [];
      var page = function (start) {
        return req('POST', '/api/v1/article/search?include=SmDm', { storeId: store, catalogId: catalog, categories: cats, statusCodes: ['01', '02', '11', '12', '31', '32', '41', '42', '51'], start: String(start), max: '500' }).then(function (j) {
          var l = (j && j.articleResults) || [];
          l.forEach(function (a) { var n = s(a.id, 10); if (/^\d{7}$/.test(n)) out.push(n); });
          var total = j && j.pagingInfo ? num(j.pagingInfo.total) : 0;
          if (l.length && start + l.length < total && out.length < 2500) return page(start + l.length);
          return out;
        });
      };
      first = page(0);
    }
    var found = [], asked = 0;
    return first.then(function (list) {
      var seen = {};
      list = list.filter(function (n) { if (seen[n]) return false; seen[n] = 1; return true; }).slice(0, 2500);
      asked = list.length;
      window.__st.prog = '0/' + asked;
      return inBatches(list, 8, function (n) {
        return get('/api/v1/article/masterdata?article=' + n + '&catalog=' + encodeURIComponent(catalog) + '&store=' + encodeURIComponent(store) + '&include=SmDm').then(function (j) {
          var m = Array.isArray(j) ? j[0] : j;
          if (!m) return;
          var fut = s(m.futurestatusCode, 3), st = s(m.statusCode, 3), from = +m.futurestatusCodeValidFrom;
          // a date of the year 9999 means "no date"; an article already in that status is not news
          if ((fut !== '21' && fut !== '81') || st === fut || !isFinite(from) || from <= 0 || from > 4102444800000) return;
          var d = m.smDmData || {};
          found.push({ num: n, name: s(m.title || d.title, 120), st: st, fut: fut, from: new Date(from).toISOString().slice(0, 10),
            sm: num(d.smQuantity), dm: num(d.dmQuantity), stock: num(d.stock), sold30: num(d.quantitySoldInPeriod), cap: num(d.shelfCapacity),
            price: num(m.activeSalesPrice), unit: s(m.unit || d.unit, 6), group: s(m.groupId, 8), groupName: s(m.groupTitle, 60) });
        });
      });
    }).then(function () {
      found.sort(function (a, b) { return a.from < b.from ? -1 : a.from > b.from ? 1 : a.num < b.num ? -1 : 1; });
      return { list: found.slice(0, 1500), asked: asked };
    });
  }

  // ---- Punjenje (owner, 14. 11. 2026): StoreFront's own refill lists, the same calls as its /ui/refilling page
  // (read from its code: GET refilling-list/{org}/{store}, GET refilling-list/bff/{org}/{store}/{id}, POST create,
  // POST add-article, PUT update-article; the "checked" box is StoreFront's "odabrano", never set by the app)
  function okOrg() { if (!/^[0-9A-Za-z]{1,10}$/.test(org || '')) throw 'store'; }
  var RID = /^[0-9A-Za-z_-]{1,64}$/;
  // 1.97: who is signed in, as a short one-way mark (never the user name itself): a pending deletion is bound to it
  function whoMark() {
    var t = String(meUser.user || meUser.num || ''), h = 5381;
    for (var i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) >>> 0;
    return t ? 'u' + h.toString(36) : '';
  }
  function refilllists() {
    okOrg();
    return get('/api/v1/refilling-list/' + encodeURIComponent(org) + '/' + encodeURIComponent(store)).then(function (j) {
      var l = (Array.isArray(j) ? j : []).filter(function (x) { return x && RID.test(String(x.id)) && x.countName; });
      return { store: store, org: org, who: whoMark(), total: l.length, lists: l.slice(0, 100).map(function (x) { return { id: String(x.id), name: s(x.countName, 60), created: s(x.createdDateTime, 40) }; }) };
    });
  }
  // 1.97: ONE list by its id (the list of lists shows at most 100, so missing there proves nothing): exists, how
  // many items. 404 = it is not there any more.
  function refillcheck() {
    okOrg();
    var id = String(arg.id || '');
    if (!RID.test(id)) throw 'bad input';
    return get('/api/v1/refilling-list/bff/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '/' + encodeURIComponent(id)).then(function (j) {
      var l = (j && Array.isArray(j.refillingArticleInfoList)) ? j.refillingArticleInfoList : [];
      return { store: store, org: org, who: whoMark(), id: id, exists: !!j, count: l.length, sum: l.reduce(function (n, a) { return n + num(a && a.qty); }, 0) };
    }, function (e) {
      if (/^http 404/.test(String(e))) return { store: store, org: org, who: whoMark(), id: id, exists: false };
      throw e;
    });
  }
  // 1.97 (owner): delete one whole list, as StoreFront's own Punjenje page does (its list screen: a delete button per
  // list with "acknowledge-delete", DELETE /api/v1/refilling-list/{salesOrg}/{storeId}/{id}). Only for the store and
  // the signed-in user the deletion was asked under (else 'context': nothing sent). Never repeated here; the app
  // checks the list (refillcheck) before any retry. TEST builds (dry): nothing is sent.
  function refilldel() {
    okOrg();
    var id = String(arg.id || '');
    if (!RID.test(id)) throw 'bad input';
    if (String(arg.store || '') !== String(store) || !arg.who || !whoMark() || String(arg.who) !== whoMark()) throw 'context';
    if (arg.dry) return { ok: true, id: id, store: store, dry: true };
    return req('DELETE', '/api/v1/refilling-list/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '/' + encodeURIComponent(id)).then(function () {
      return { ok: true, id: id, store: store, who: whoMark() };
    });
  }
  function refillitems() {
    okOrg();
    var id = String(arg.id || '');
    if (!RID.test(id)) throw 'bad input';
    return get('/api/v1/refilling-list/bff/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '/' + encodeURIComponent(id)).then(function (j) {
      var l = (j && Array.isArray(j.refillingArticleInfoList)) ? j.refillingArticleInfoList : [];
      var out = [];
      l.slice(0, 400).forEach(function (a) {
        var n = s(a && a.articleNumber, 10);
        if (!/^\d{7}$/.test(n)) return;
        var x = { num: n, name: s(a.title, 80), series: s(a.series, 40), st: s(a.statusCode, 3), qty: num(a.qty), unit: s(a.unit, 6), checked: a.checked === true };
        if (a.sellableQty != null && String(a.sellableQty).trim() !== '' && isFinite(+a.sellableQty)) x.stock = +a.sellableQty;
        out.push(x);
      });
      return { store: store, org: org, id: id, name: s(j && j.countName, 60), items: out };
    });
  }
  // 1.97 (owner, Punjenje "Max"): one article's shelf capacity and sellable stock in this store, read only. Unlike row()
  // (num(d.shelfCapacity || a.shelfCapacity): a missing value became 0 there) a missing or non-numeric value stays
  // null here, so the app can tell "StoreFront has no capacity" from a real 0. shelfCapacity is the capacity of ALL
  // shelves of this article in this store (StoreFront 6.1.0); sellableStock is the stock StoreFront's own Punjenje
  // "Max" uses (min of the two), the same basis as sellableQty of a list's items.
  function refillinfo() {
    var n = s(arg.num, 10);
    if (!/^\d{7}$/.test(n)) throw 'bad num';
    var val = function (v) { return v != null && String(v).trim() !== '' && isFinite(+v) ? +v : null; };
    return req('POST', '/api/v1/article/search?include=SmDm', { storeId: store, catalogId: catalog, query: n, fieldsToSearch: ['id'], statusCodes: ALL, start: '0', max: '20' }).then(function (j) {
      var a = ((j && j.articleResults) || []).filter(function (x) { return String(x.id) === n; })[0];
      if (!a) return { found: false, num: n };
      var d = a.smDmData || {};
      var cap = val(d.shelfCapacity); if (cap === null) cap = val(a.shelfCapacity);
      var free = val(a.sellableStock); if (free === null) free = val(d.sellableStock);
      var stock = val(a.storeStock); if (stock === null) stock = val(d.stock);
      return { found: true, num: n, cap: cap, free: free, stock: stock, store: store, at: Date.now() };
    });
  }

  // one write: a new list (when no id), then the article added, or its quantity set when it is on the list already
  function refilladd() {
    okOrg();
    var n = s(arg.num, 10), q = Number(arg.qty), id = String(arg.id || ''), name = s(arg.name, 60);
    // Never silently round a write quantity; empty, fractional and non-finite input is invalid.
    if (arg.qty == null || (typeof arg.qty === 'string' && !arg.qty.trim()) || !Number.isSafeInteger(q)) throw 'bad input';
    if (!/^\d{7}$/.test(n) || !(q >= 1 && q <= 9999) || (id && !RID.test(id)) || (!id && !name)) throw 'bad input';
    if (arg.dry) return { ok: true, id: id || 'dry', store: store, dry: true }; // TEST builds: nothing is sent
    var made = id ? Promise.resolve(id) : req('POST', '/api/v1/refilling-list/create', { salesOrg: org, storeId: store, countName: name }).then(function (r) {
      if (!r || !RID.test(String(r.id))) throw 'create';
      return String(r.id);
    });
    return made.then(function (lid) {
      var body = { storeId: store, salesOrg: org, refillingListId: lid, articleId: n, qty: q, checked: false };
      return (arg.exists ? req('PUT', '/api/v1/refilling-list/update-article', body) : req('POST', '/api/v1/refilling-list/add-article', body))
        .then(function () { return { ok: true, id: lid, store: store }; });
    });
  }

  // ------------------------------------------------------------------ OOPUS (1.98, owner): online orders picked up in
  // the store. The same calls as StoreFront's own page Orders → OOPUS (GK) (/ui/legacy-oopus-orders, read from its code
  // on 14. 11. 2026): the list of a tab (LEGACY_UNCOMPLETED "Aktivan", LEGACY_NOT_YET_ARRIVED, LEGACY_COMPLETED), the
  // tab counts, a search (order number = the barcode on the customer's order, name, phone, e-mail, article) and one
  // order with its history. Only what the employee needs comes back: no address, phone or e-mail.
  var OOPUS_TABS = ['LEGACY_UNCOMPLETED', 'LEGACY_NOT_YET_ARRIVED', 'LEGACY_COMPLETED'];
  var OSRC = /^[A-Z]{2,6}$/;
  function oopusRow(o) {
    var c = (o && o.customer) || {};
    // 1.99: every line (1.98 cut at 80: an order of 81 lines lost its last one, in the sum too); 500 = a sane bound
    var lines = (Array.isArray(o.orderlines) ? o.orderlines : []).slice(0, 500).map(function (l) {
      var a = (l && l.article) || {};
      return { num: s(a.articleId, 10), name: s(a.title, 80), st: s(a.statusCode, 3), qty: num(l.quantity), state: s(l.orderLineState, 20) };
    });
    var qty = 0; lines.forEach(function (l) { qty += l.qty; });
    var who = (s(c.firstName, 40) + ' ' + s(c.lastName, 40)).trim() || s(c.companyName, 60);
    // 1.99 (owner): the customer's phone as StoreFront shows it to the signed-in employee (customer.contactInfo.phone,
    // e.g. "+38761…"), only for the order sheet and a tap to the dialer; never an e-mail or an address
    var ph = s(c.contactInfo && c.contactInfo.phone, 30);
    if (!/^\+?[\d\s()\/-]{6,30}$/.test(ph) || ph.replace(/\D/g, '').length < 6) ph = '';
    return {
      no: s(o.orderNumber, 14), bk: s(o.businessKey, 20), dg: num(o.deliveryGroupId), src: OSRC.test(String(o.ordersSource || '')) ? String(o.ordersSource) : 'WSS',
      st: s(o.state, 24), ret: s(o.returnState, 24), who: s(who, 60), ph: ph, b2b: s(c.customerType, 4) === 'B2B',
      amount: o.totalAmount != null && isFinite(+o.totalAmount) ? +o.totalAmount : null, cur: s(o.currencyCode, 4),
      created: num(o.createdDate), expected: num(o.expectedDeliveryDate), issue: o.issueWaiting === true, comm: o.orderCommented === true,
      remarks: o.orderHasRemarks === true, resched: o.rescheduled === true, lines: lines, qty: qty,
    };
  }
  function oopusQs(max, start, tab) {
    return '?start=' + (start || 0) + '&max=' + max + '&orderBy=EARLIEST_DELIVERY&orderByDirection=' + (tab === 'LEGACY_COMPLETED' ? 'DESC' : 'ASC') + '&source=WSS';
  }
  function oopusBase() { okOrg(); return '/api/v1/oopus-order/' + encodeURIComponent(org) + '/' + encodeURIComponent(store); }
  // the tab's orders (pages of 100, at most 300) and the counts of the three tabs, in parallel
  function oopuslist() {
    var tab = OOPUS_TABS.indexOf(arg.tab) >= 0 ? arg.tab : 'LEGACY_UNCOMPLETED';
    var B = oopusBase();
    var page = function (start) { return get(B + '/' + tab + oopusQs(100, start, tab)); };
    var totals = get('/api/v1/oopus-order/order-totals/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '?source=WSS').then(function (j) {
      var o = {}; (Array.isArray(j) ? j : []).forEach(function (x) { if (x && OOPUS_TABS.indexOf(x.state) >= 0) o[x.state] = num(x.count); }); return o;
    }).catch(function (e) { if (e === 'login') throw e; return null; });
    var list = page(0).then(function (j) {
      var all = (j && j.oopusOrders) || [], total = j && j.pagingInfo ? num(j.pagingInfo.total) : all.length;
      var more = [];
      for (var st = 100; st < Math.min(total, 300); st += 100) more.push(page(st));
      return Promise.all(more).then(function (r) { r.forEach(function (x) { all = all.concat((x && x.oopusOrders) || []); }); return { all: all, total: total }; });
    });
    return Promise.all([list, totals]).then(function (x) {
      return { store: store, org: org, tab: tab, orders: x[0].all.map(oopusRow), total: x[0].total, totals: x[1], at: Date.now() };
    });
  }
  // StoreFront's own search; it finds orders of every tab, so each answer keeps its own state
  function oopusfind() {
    var q = s(arg.q, 60);
    if (q.length < 3 || /[\/\\?#%]/.test(q)) throw 'bad input';
    okOrg();
    return get('/api/v1/oopus-order/query/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '/' + encodeURIComponent(q) + '/LEGACY_UNCOMPLETED' + oopusQs(40, 0, '')).then(function (j) {
      return { store: store, org: org, q: q, orders: ((j && j.oopusOrders) || []).map(oopusRow), total: j && j.pagingInfo ? num(j.pagingInfo.total) : 0 };
    });
  }
  function oopusKey() {
    var bk = s(arg.bk, 20), dg = String(arg.dg == null ? '' : arg.dg), src = String(arg.src || 'WSS');
    if (!/^[0-9A-Za-z_-]{1,20}$/.test(bk) || !/^-?\d{1,9}$/.test(dg) || !OSRC.test(src)) throw 'bad input'; // GK (legacy) orders: a negative group id
    return { bk: bk, dg: dg, src: src, path: '/' + encodeURIComponent(bk) + '/' + encodeURIComponent(dg) };
  }
  function oopusOne(k) {
    return get(oopusBase() + k.path + '?source=' + k.src).then(function (o) {
      if (!o || !o.orderNumber) throw 'not found';
      return oopusRow(o);
    });
  }
  // one order and its history (CSC's comments, "ready" messages, reminders): what StoreFront's order sheet shows
  function oopusorder() {
    var k = oopusKey();
    return oopusOne(k).then(function (o) {
      return get('/api/v1/oopus-order/order-history/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + k.path + '/' + encodeURIComponent(o.no) + '?source=' + k.src).then(function (h) {
        o.hist = (Array.isArray(h) ? h : []).slice(0, 40).map(function (x) {
          return { t: num(x.eventDate), type: s(x.type, 48), text: s(x.text, 400), csc: x.customerServiceCase === true, comm: x.commented === true };
        }).sort(function (a, b) { return b.t - a.t; });
        return o;
      }, function (e) { if (e === 'login') throw e; o.hist = null; return o; });
    }).then(function (o) { return { store: store, org: org, order: o, at: Date.now() }; });
  }
  // The handover, as StoreFront's "Označi kao završeno" → "Potpis kupca" → "Spremi": the customer's signature as a PNG
  // (white background, black pen) is the body of POST handout/{salesOrg}/{storeId}/{businessKey}/{deliveryGroupId}.
  // Before it the order is read again: only READY_FOR_PICKUP and not returned (partly returned only when the employee
  // saw that warning), only for the store the employee opened it under. After it the order is read once more and its
  // state comes back (COMPLETED: StoreFront has it in "Završeno"). Never repeated here. TEST builds (dry): nothing sent.
  // The signature is dropped from the page's own variables at once and never comes back in the answer.
  function oopushandout() {
    var sig = String(arg.sig || '');
    try { window.__stArg.sig = null; } catch (e) { /* the page's copy */ }
    arg.sig = null;
    var k = oopusKey();
    if (String(arg.store || '') !== String(store) || !/^\d{6,14}$/.test(String(arg.no || ''))) throw 'context';
    var m = /^data:image\/png;base64,([A-Za-z0-9+\/=]+)$/.exec(sig);
    if (!m || m[1].length < 200 || m[1].length > 1500000) throw 'bad input';
    return oopusOne(k).then(function (o) {
      if (o.no !== String(arg.no)) throw 'context';
      // 1.99: a return state that is missing or unknown stops the handover before the signature leaves the phone
      // (1.98 let it through: only RETURNED and an unchecked PARTIALLY_RETURNED were stopped)
      var retOk = o.ret === 'NOT_RETURNED' || (o.ret === 'PARTIALLY_RETURNED' && !!arg.partialOk);
      if (o.st !== 'READY_FOR_PICKUP' || !retOk) throw 'state ' + s(o.st, 24) + ' ' + (s(o.ret, 24) || 'NONE');
      if (arg.dry) return { ok: true, dry: true, state: 'COMPLETED', no: o.no, store: store };
      var bin = atob(m[1]), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      bin = null; m = null; sig = '';
      return req('POST', oopusBase().replace('/oopus-order/', '/oopus-order/handout/') + k.path + '?source=' + k.src, new Blob([bytes], { type: 'image/png' })).then(function () {
        return oopusOne(k).then(function (a) { return { ok: true, state: a.st, no: a.no, store: store }; }, function (e) {
          if (e === 'login') throw e;
          return { ok: true, state: '', no: o.no, store: store }; // sent and confirmed by StoreFront; the reading after it failed
        });
      });
    });
  }

  // ---- 2.15 (owner, 18. 11. 2026): Narudžbe and Minus lista by themselves. All three only READ (GET), the same calls
  // StoreFront's own Customer Orders and Minus lista pages make; StoreFront offers no event, ETag or change time
  // (measured 18. 11.: no-store answers, no WebSocket/SSE), so the app asks again now and then.
  var OKEY = { Ispunjen: 'LEGACY_FULFILLED', Stigao: 'LEGACY_ARRIVED_AT_STORE', Zakasnio: 'LEGACY_OVERDUE', Aktivan: 'LEGACY_UNCOMPLETED' };
  var OTABS = ['Ispunjen', 'Stigao', 'Zakasnio', 'Aktivan']; // the more specific first, as orders-fast.js
  var OSTATE = { CREATED: 'Kreirano', IN_TRANSIT: 'U tranzitu', ARRIVED_IN_STORE: 'Stiglo u prodavnicu', READY_FOR_HANDOUT: 'Spremno za podjelu' };
  function ostate(v) { v = s(v, 40); return OSTATE[v] || v.replace(/_/g, ' ').toLowerCase().replace(/^./, function (c) { return c.toUpperCase(); }); }
  function cname(c) { if (!c) return ''; var co = s(c.companyName, 80); return co || (s(c.firstName, 60) + ' ' + s(c.lastName, 60)).trim(); }
  // the same order as orders-fast.js toOrder (tests/auto-sync-reader.test.mjs compares both); the times come raw,
  // the app turns them into its own (orders-time.js), so this page needs nothing of the app
  function corder(o, tab) {
    var lines = Array.isArray(o.orderlines) ? o.orderlines : [], items = [];
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i] || {}, a = l.article || {}, n = s(a.articleId, 10);
      if (!/^\d{7}$/.test(n)) continue;
      var it = { num: n, qty: +l.quantity || 0, name: s(a.title, 120), st: s(l.orderLineStateText, 40) };
      if (typeof l.handOutQuantity === 'number' && isFinite(l.handOutQuantity)) it.hq = l.handOutQuantity;
      if (s(l.orderLineHandoutState, 30)) it.hs = s(l.orderLineHandoutState, 30);
      items.push(it);
    }
    var c = o.customer || {}, ci = c.contactInfo || {}, d = s(o.expectedPickUpDateFmt, 20);
    return { rcF: s(o.receiptCreatedAtFmt, 25), cF: s(o.createdDateFmt, 25), cI: s(o.createdDateIso, 40), c: typeof o.createdDate === 'number' ? o.createdDate : null,
      pay: o.additionalStorePaymentRequired === true, no: '#' + s(o.orderNumber, 30).replace(/^#/, ''), name: cname(c), status: ostate(o.state),
      date: /2099$/.test(d) ? '' : d, n: items.length || lines.length, tab: tab, ph: s(ci.phone, 30), items: items };
  }
  function ototals() {
    okOrg();
    return get('/api/v1/customer-order/order-totals/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '?source=WSS').then(function (j) {
      if (!Array.isArray(j)) throw 'shape';
      var t = {};
      for (var i = 0; i < j.length; i++) for (var k in OKEY) if (j[i] && OKEY[k] === j[i].state) t[k] = num(j[i].count);
      return t;
    });
  }
  // the minus list as the app keeps it (minus-reader.js), without the replacement chains (those are read again only
  // when the list has changed): a few kB
  function mitems(list) {
    return list.slice(0, 300).map(function (x) {
      var a = x.article || {};
      // 2.15 audit: a quantity StoreFront did not give is null (unknown), never 0 (minus-reader.js does the same)
      return { num: s(x.articleId || a.articleNumber, 10), name: s(a.title, 120), st: s(a.statusCode, 3), qty: known(x.totalStock), blocked: known(x.blockedStock), unit: s(a.unit, 6), group: s(a.groupTitle, 60) };
    }).filter(function (x) { return /^\d{7}$/.test(x.num); });
  }
  function known(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
  // one short mark of the list: the same function is in js/auto-sync.js (minusSig), tested to give the same mark.
  // 2.15 audit: an unknown quantity is "?" (never the same mark as a real 0), and the number of ALL rows of the list
  // (sets and other codes the app does not show, the rows past 300) is in the mark too
  function msig(items, total) {
    var q = function (v) { return typeof v === 'number' && isFinite(v) ? String(v) : '?'; };
    var ok = items.filter(function (x) { return /^\d{7}$/.test(x.num); });
    var k = 'n' + (typeof total === 'number' && isFinite(total) ? total : '?') + '|' + ok.map(function (x) { return x.num + ':' + q(x.qty) + ':' + q(x.blocked); }).sort().join(',');
    var h = 5381;
    for (var i = 0; i < k.length; i++) h = ((h * 33) ^ k.charCodeAt(i)) >>> 0;
    return ok.length + ':' + h.toString(16);
  }
  function mlist() {
    return get('/api/v1/minus-list/' + encodeURIComponent(store) + '?include=Article').then(function (l) {
      if (!Array.isArray(l)) throw 'shape';
      return l;
    });
  }
  // every order of the chosen tabs with its lines (a page holds 500: the owner's store had 201 open orders, 21 kB
  // over the network), and the history only of orders the app has not seen yet. A tab that is not read whole fails
  // the whole reading: the app keeps what it had, a half list is never taken for the store's list.
  function ordsync() {
    okOrg();
    var want = Array.isArray(arg.tabs) ? arg.tabs : OTABS;
    var tabs = OTABS.filter(function (t) { return want.indexOf(t) >= 0; });
    if (!tabs.length) tabs = OTABS;
    var known = {};
    (Array.isArray(arg.known) ? arg.known : []).slice(0, 3000).forEach(function (x) { if (/^#[0-9A-Za-z]{8,30}$/.test(String(x))) known[String(x)] = 1; });
    var hmax = Math.max(0, Math.min(40, +arg.hist || 0));
    var base = '/api/v1/customer-order/' + encodeURIComponent(org) + '/' + encodeURIComponent(store) + '/';
    var seen = {}, orders = [], counts = {}, inTab = {};
    function page(tab, start, got) {
      return get(base + OKEY[tab] + '?start=' + start + '&max=500&orderBy=EXPECTED_PICKUP_DATE&orderByDirection=DESC&source=WSS').then(function (j) {
        var list = j && Array.isArray(j.customerOrders) ? j.customerOrders : null;
        if (!list) throw 'shape';
        var total = j.pagingInfo && typeof j.pagingInfo.total === 'number' ? j.pagingInfo.total : -1;
        var mine = inTab[tab] || (inTab[tab] = { n: 0 });
        for (var i = 0; i < list.length; i++) {
          var o = corder(list[i] || {}, tab);
          if (!mine[o.no]) { mine[o.no] = 1; mine.n++; }
          if (o.no.length < 9) continue;
          if (seen[o.no]) { if (seen[o.no].tabs.indexOf(tab) < 0) seen[o.no].tabs.push(tab); continue; }
          o.tabs = [tab];
          seen[o.no] = o;
          orders.push(o);
        }
        got += list.length;
        if (list.length === 500 && (total < 0 || got < total) && start + 500 < 5000) return page(tab, start + 500, got);
        // StoreFront said more than it gave; 22. 11. 2026 (audit): also when its pages (sorted by pickup date, which is
        // not unique) gave one order twice: then another one was skipped, though the rows add up to the total
        if (total >= 0 && (got < total || mine.n < total)) throw 'incomplete';
        // 2.15 audit: the tab's number as THIS page gave it (a separate totals answer of another second could
        // differ when an order moves meanwhile: emulator 18. 11., Aktivan 202 against a list of 201)
        counts[tab] = total >= 0 ? total : got;
        return null;
      });
    }
    var chain = Promise.resolve();
    tabs.forEach(function (t) { chain = chain.then(function () { if (window.__st) window.__st.prog = t; return page(t, 0, 0); }); });
    return chain.then(function () {
      var fresh = orders.filter(function (o) { return !known[o.no]; });
      var todo = fresh.slice(0, hmax), qi = 0;
      var hist = base.replace('/customer-order/', '/customer-order/order-history/');
      function one() {
        if (qi >= todo.length) return Promise.resolve();
        var o = todo[qi++], n = encodeURIComponent(o.no.replace(/^#/, ''));
        return get(hist + n + '/-1/' + n + '?source=WSS').then(function (h) {
          if (!Array.isArray(h)) return;
          var ev = [], notes = [];
          for (var x = 0; x < h.length && x < 80; x++) {
            var e = h[x] || {};
            if (s(e.eventDateFmt, 25)) ev.push({ f: s(e.eventDateFmt, 25), t: /^[A-Z][A-Z0-9_]{0,40}$/.test(e.type || '') ? e.type : '' });
            if (e.type === 'CORRESPONDENCE_INTERNAL_TEXT' && s(e.text, 200)) notes.push(s(e.text, 200));
          }
          o.h = ev;
          if (notes.length) o.note = notes.join(' · ').slice(0, 160);
        }).catch(function (e) { if (e === 'login') throw e; /* no history for this one: the order still counts */ }).then(one);
      }
      return Promise.all([one(), one(), one(), one()]).then(function () {
        return { store: store, tabs: counts, tot: counts, orders: orders, histNew: todo.length, histLeft: fresh.length - todo.length, at: Date.now() };
      });
    });
  }
  // the minus list now, for the comparison with the one the app has (same mark: nothing is drawn again)
  function minuspeek() {
    return mlist().then(function (l) {
      var items = mitems(l);
      return { store: store, total: l.length, items: items, sig: msig(items, l.length), at: Date.now() };
    });
  }
  // the phone's background look (OrderWatch): only the numbers of the tabs and the mark of the minus list
  function watch() {
    var t = ototals().catch(function (e) { if (e === 'login') throw e; return null; });
    var m = arg.minus ? mlist().then(function (l) { return msig(mitems(l), l.length); }).catch(function (e) { if (e === 'login') throw e; return null; }) : Promise.resolve(null);
    return Promise.all([t, m]).then(function (x) { return { store: store, tot: x[0], minus: x[1], at: Date.now() }; });
  }

  // nothing but the store (who): a page made ready while the scanner is open
  function ping() { return { ready: true }; }

  // 21. 11. 2026 (StoreFront audit): StoreFront's "Zamjena" list (Akcijska lista → Substitution List): discontinued
  // articles that the store still has to replace on the shelf by new ones (not yet marked done here), read only, the
  // request StoreFront's own page makes (~4 s on StoreFront's side). Only article numbers, names, status and stock.
  function subst() {
    okOrg();
    return get('/api/v1/substitutionLists/unhandled/' + encodeURIComponent(catalog) + '/' + encodeURIComponent(org) + '/' + encodeURIComponent(store)
      + '?onlyPositiveATPAvailable=false&pageSize=9999&pageNumber=0').then(function (j) {
      var l = [], st = function (v) { v = s(v, 3); return /^\d$/.test(v) ? '0' + v : v; };
      var q = function (v) { return typeof v === 'number' && isFinite(v) ? v : null; };
      ((j && j.substitutions) || []).forEach(function (c) {
        ((c && c.changes) || []).forEach(function (x) {
          var o = x && x.oldArticle, n = x && x.newArticle;
          if (!o || !n || !/^\d{4,9}$/.test(String(o.id)) || !/^\d{4,9}$/.test(String(n.id))) return;
          l.push([s(o.id, 9), s(o.title, 80), st(o.statusCode), q(o.stock), s(n.id, 9), s(n.title, 80), st(n.statusCode), q(n.stock)]);
        });
      });
      return { store: store, total: num(j && j.totalElements), l: l.slice(0, 600) };
    });
  }

  var run = { ping: ping, me: me, pics: pics, eans: eans, opcheck: opcheck, find: find, sfsearch: sfsearch, lookup: lookup, histlong: histlong, refillinfo: refillinfo, refillcheck: refillcheck, refilldel: refilldel, article: article, stockbatch: stockbatch, pricebatch: pricebatch, relatedstock: relatedstock, refilllists: refilllists, refillitems: refillitems, refilladd: refilladd, oopuslist: oopuslist, oopusfind: oopusfind, oopusorder: oopusorder, oopushandout: oopushandout, top: top, sales: sales, smdm: smdm, smset: smset, smread: smread, audit: audit, groups: groups, clear: clear, hier: hier, soon: soon, ordsync: ordsync, minuspeek: minuspeek, watch: watch, subst: subst }[arg.mode];
  var H = arg.hint || {};
  var hinted = arg.mode === 'article' && !window.__stWho && /^[0-9A-Za-z]{1,10}$/.test(String(H.store || '')) && /^[0-9A-Za-z-]{1,30}$/.test(String(H.catalog || ''));
  var go = !run ? Promise.reject('bad mode') : !hinted ? who().then(run) : (function () {
    // 1.99 (owner: the history is slow): a page opened just now asks who is signed in first (~300 ms) and only then
    // starts the article's requests. With the store the app last saw, they start at once, side by side with that
    // question; if the signed-in store is another one, that answer is dropped and the article is read again.
    store = String(H.store); catalog = String(H.catalog);
    var early = run();
    early.then(null, function () { /* judged below */ });
    return who().then(function () {
      if (store === String(H.store) && catalog === String(H.catalog)) return early;
      if (window.__st) window.__st.part = []; // what the hint gave is dropped
      return run();
    });
  })();
  go.then(function (res) {
    window.__st = { state: 'ok', job: job, res: res, n: NET.n, net: NET.ms };
  }, function (e) {
    var m = String(e && e.message ? e.message : e);
    window.__st = { state: m === 'login' ? 'login' : 'error', job: job, err: s(m, 120), prog: (window.__st || {}).prog || '', n: NET.n, net: NET.ms };
  });
})();
