// Order times already rendered in the store's local clock. Used by both WebViews.
globalThis.PolicaOrderTime = (() => {
  function stamp(value) {
    if (typeof value !== 'string') return null;
    const s = value.trim();
    const m = /^(\d{2})\.(\d{2})\.(\d{4})(?: (\d{2}):(\d{2})(?::(\d{2}))?)?$/.exec(s);
    if (!m) return null;
    const [, d, mo, y, h, min, sec] = m;
    const day = new Date(Date.UTC(+y, +mo - 1, +d));
    if (day.getUTCFullYear() !== +y || day.getUTCMonth() + 1 !== +mo || day.getUTCDate() !== +d
        || +h > 23 || +min > 59 || +sec > 59) return null;
    // Missing clock precision never manufactures seconds in the displayed value.
    return { text: s, clock: h !== undefined, key: y + mo + d + (h || '') + (min || '') + (sec || '') };
  }

  function keepTime(newValue, oldValue) {
    const fresh = stamp(newValue);
    const old = stamp(oldValue);
    if (!fresh) return old?.text;
    if (old && old.key.startsWith(fresh.key) && old.key.length > fresh.key.length) return old.text;
    return fresh.text;
  }

  const two = (n) => String(n).padStart(2, '0');
  /** The phone's local clock text of a moment ("dd.mm.yyyy hh:mm:ss"), or ''. */
  function local(ms) {
    const d = new Date(ms);
    if (!Number.isFinite(d.getTime())) return '';
    return two(d.getDate()) + '.' + two(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds());
  }
  /**
   * StoreFront's own creation time of the order (owner's phone, 13. 11. 2026: the order answer has createdDate,
   * createdDateFmt and createdDateIso next to expectedPickUpDate*). The store-formatted text first (it is what the
   * page shows), then the ISO moment with its offset, then milliseconds; both of those shown in the phone's clock.
   */
  function fromApi(fmt, iso, ms) {
    const f = stamp(fmt);
    if (f && f.clock) return f.text;
    if (typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})$/.test(iso.trim())) {
      const t = local(Date.parse(iso.trim()));
      if (t) return t;
    }
    if (typeof ms === 'number' && Number.isInteger(ms) && ms > 1e12 && ms < 1e13) return local(ms);
    return f ? f.text : '';
  }

  function info(order) {
    const receipt = stamp(order.receiptCreated);
    const created = stamp(order.orderCreated);
    if (!(receipt && receipt.clock) && created && created.clock) return { rank: 0, stamp: created, label: 'Narudžba kreirana' };
    const note = stamp(order.made);
    if (receipt && receipt.clock) return { rank: 0, stamp: receipt, label: 'Račun kreiran' };
    // made: the oldest entry of the order's history = when the order was created (owner, 14. 11. 2026, his example:
    // the store's internal comment written with the order). 14. 11. 2026 (owner): when the oldest entry that StoreFront
    // still gives is a message to the customer (SMS, e-mail) the history may be incomplete: its time is shown with its
    // source and counts as approximate. Kept readings of 1.94 have no type and stay "Kreirano" until read again.
    if (note && note.clock) {
      const kind = typeof order.madeType === 'string' ? order.madeType : '';
      if (!kind || /INTERNAL/.test(kind)) return { rank: 0, stamp: note, label: 'Kreirano' };
      return { rank: 1, stamp: note, label: /SMS/.test(kind) ? 'Prva poruka kupcu (SMS)' : /MAIL/.test(kind) ? 'Prvi e-mail kupcu' : 'Prvi zapis u historiji' };
    }
    if (receipt || created || note) return { rank: 2, stamp: receipt || created || note, label: receipt ? 'Datum računa' : created ? 'Datum narudžbe' : 'Datum kreiranja' };
    return { rank: 3, stamp: null, label: 'Vrijeme računa nepoznato' };
  }

  function sorted(orders) {
    const rows = orders.map(order => ({ order, time: info(order) }));
    const cmp = (a, b) => a < b ? -1 : a > b ? 1 : 0;
    rows.sort((a, b) => a.time.rank - b.time.rank
      || cmp(a.time.stamp?.key || '', b.time.stamp?.key || '')
      || cmp(String(a.order.no), String(b.order.no)));
    return rows.map(r => r.order);
  }

  function fromDetail(lines) {
    for (let i = 0; i < lines.length; i++) {
      const m = /^(?:Datum (?:i vrijeme )?kreiranja računa|Vrijeme kreiranja računa|Račun kreiran)\s*(?::\s*(.*))?$/i.exec(lines[i]);
      if (!m) continue;
      const time = stamp(m[1] || lines[i + 1]);
      if (time) return time.text;
    }
    return '';
  }

  // Audit 13. 11. 2026: which fields StoreFront's own order answers carry, to confirm where the receipt time is.
  // Only field NAMES and, for values that look like a time, their shape with every digit replaced by 9
  // ("05.11.2026 16:40:12" -> "99.99.9999 99:99:99"). Never a value, name, phone, number or text.
  function shape(v) {
    if (v == null || v === '') return 'prazno';
    if (Array.isArray(v)) return '[]';
    if (typeof v === 'object') return '{}';
    if (typeof v === 'number') return Number.isInteger(v) && v > 1e9 && v < 1e14 ? 'broj' + String(v).length : '';
    const s = String(v).trim();
    return /^[\d.:\-T Z+\/]{6,32}$/.test(s) && /\d{2}/.test(s) ? s.replace(/\d/g, '9') : '';
  }
  function fields() {
    const groups = {};
    return {
      add(group, obj) {
        if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return;
        const g = groups[group] || (groups[group] = {});
        for (const k of Object.keys(obj).slice(0, 80)) {
          if (!/^[A-Za-z][A-Za-z0-9_]{0,40}$/.test(k)) continue;
          const set = g[k] || (g[k] = []);
          const sh = shape(obj[k]);
          if (sh && set.length < 3 && set.indexOf(sh) < 0) set.push(sh);
        }
      },
      type(group, t) {
        const g = groups[group] || (groups[group] = {});
        if (typeof t === 'string' && /^[A-Z][A-Z0-9_]{0,40}$/.test(t)) g['tip ' + t] = g['tip ' + t] || [];
      },
      text() {
        return Object.keys(groups).map((grp) => grp + ': ' + Object.keys(groups[grp]).sort()
          .map((k) => k + (groups[grp][k].length ? '=' + groups[grp][k].join('|') : '')).join(', ')).join('; ').slice(0, 1800);
      },
    };
  }

  return { stamp, keepTime, info, sorted, fromDetail, fromApi, shape, fields };
})();
