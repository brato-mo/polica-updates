// Jysk Reloaded: scan or type an article, see its picture and where it stands on the shelf.
import '../orders-time.js';
import * as orderWaiting from './order-waiting.js';
import * as rz from './reservations.js';
import { createRefillUi } from './refill-ui.js';
import { createOopusUi } from './oopus-ui.js';
import * as core from './core.js';
import * as store from './store.js';
import * as docs from './docs.js';
import * as news from './news.js';
import * as ar from './ar.js';
import * as smcheck from './smcheck.js';
import * as tips from './tips.js';
import * as minusop from './minusop.js';
import { createEans } from './eans.js';
import { createNav } from './navigation.js';
import { createCropCache } from './crop-cache.js';
import { createMinusUi } from './minus-ui.js';
import { createMyjyskUi } from './myjysk-ui.js';
import { createClearanceUi } from './clearance-ui.js';
import { createNewsUi } from './news-ui.js';
import { createTopSoonUi } from './top-soon-ui.js';
import { createTipsUi } from './tips-ui.js';
import { createArUi } from './ar-ui.js';
import { createMjPlansUi } from './mjplans-ui.js';
import { createWelcomeSetup } from './welcome-setup.js';
import { updateErrorText, installResultText } from './update-status.js';
import { loadHierarchy as loadWelcomeHierarchy, pickerHtml, validGroup } from './other-depts.js';
import { createArticleUi } from './article-ui.js';
import { createMissingUi } from './missing-ui.js';
import { createPlanGet } from './plan-get.js';
import { createSearchUi } from './search-ui.js';
import { createAutoSync, minusSig } from './auto-sync.js';
import { createImportUi } from './import.js';
import { createSmdmUi } from './smdm-ui.js';
import { createRegsUi } from './regs-ui.js';
import { createChainUi } from './chain-ui.js';
import { createRegAdjustUi } from './reg-adjust-ui.js';
import { ST as ST_INFO } from './regs.js';
import { createFlowLog, errWhy, isBad, MOD as FLOW_MOD, OUT as FLOW_OUT } from './flow-log.js';

const A = window.Android;
// 1.97: the flow log (Postavke → Pregledaj dijagnostiku): what the employee started, where it stopped (js/flow-log.js)
const flow = createFlowLog({
  read: () => { try { return A.readText('flow-log.json'); } catch (e) { return ''; } },
  write: (t) => { try { A.writeText('flow-log.json', t); } catch (e) { /* never breaks the app */ } },
  version: () => { try { return A.version ? String(A.version()) : ''; } catch (e) { return ''; } },
});
// unexpected JavaScript errors: class, short message, file:line (no content); the app goes on
window.addEventListener('error', (ev) => { try { flow.one('app', 'Neočekivana greška', 'JavaScript', 'app_error', { why: errWhy(ev.error || ev.message, `${String(ev.filename || '').split('/').pop()}:${ev.lineno || 0}`) }); } catch (e) { /* ignore */ } });
window.addEventListener('unhandledrejection', (ev) => { try { flow.one('app', 'Neočekivana greška', 'JavaScript (obećanje)', 'app_error', { why: errWhy(ev.reason) }); } catch (e) { /* ignore */ } });
window.addEventListener('pagehide', () => flow.flush());
document.addEventListener('visibilitychange', () => { if (document.hidden) flow.flush(); });
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__flow = flow;
const orderTime = globalThis.PolicaOrderTime;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

const S = {
  plans: [], // { id, name, size, imported, key, title, concept, deadline, sections, pages, count, plan }
  index: core.buildIndex([]),
  user: { recent: [], learned: {}, changes: {}, orders: null },
  stack: [{ id: 'home', state: null }],
  item: null, // { num, info, loc, focus }
  importTarget: null,
  busy: false,
  refreshing: false,
  tried: new Set(), // barcodes already asked in StoreFront this session
  storeCb: null,
  mode: 'plan', // home tab: 'plan' (planograms), 'orders' (customer orders) or 'news' (MYJYSK tasks and news)
  ar: { busy: '', scores: {}, notes: {}, err: null, done: null }, // AR screen: what is being done, the chosen scores and comments
  mj: { busy: false, open: new Set(), loc: 'open', more: false }, // Vijesti screen: reading now, opened news, filter of the store's tasks
  planMore: new Set(), // "<plan id>|<status>": cards whose whole row of article numbers is open on the Planogrami screen
};

// ------------------------------------------------------------------ helpers

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = (name, cls = '') => `<svg class="ico ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

function plural(n, one, few, many) {
  const a = n % 10, b = n % 100;
  if (a === 1 && b !== 11) return one;
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return few;
  return many;
}
const artikala = (n) => `${n} ${plural(n, 'artikal', 'artikla', 'artikala')}`;

function dateBs(ms) {
  const d = new Date(ms);
  return `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()}.`;
}

function fixtureText(d) {
  if (!d) return '';
  const out = [];
  const m = /Shelf\s*(\d+)\s*cm/i.exec(d);
  if (/hanging\s*bar|\bbar\b/i.test(d)) out.push('šipka za vješanje');
  else if (m) out.push(`polica ${m[1]} cm`);
  if (/w\/?\s*light/i.test(d)) out.push('sa svjetlom');
  if (/lock/i.test(d)) out.push('zaključana');
  if (/rub\.?\s*mat/i.test(d)) out.push('s gumenom podlogom');
  return out.length ? out.join(', ') : d;
}
const isBar = (d) => /hanging\s*bar|\bbar\b/i.test(d || '');

let toastTimer = 0;
function toast(msg, ms = 3200) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, ms);
}

function debounce(fn, ms) {
  let t = 0;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).replace(/^data:[^,]*,/, ''));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

// --------------------------------------------------------------------- data

function saveUser() { store.write('user.json', S.user); }

/**
 * 1.97: Pregledaj dijagnostiku: the flow log first (what was started, where it stopped, what was last confirmed),
 * "Samo greške", "Kopiraj sažetak" (the cleaned summary), then the technical log as before.
 */
function openFlowView(raw, onlyErrors = false) {
  const d = flow.data;
  const rows = flow.list(onlyErrors).slice(0, 150);
  const card = (t, x) => (x ? `<p class="flow-card"><b>${t}</b><br>${esc(FLOW_MOD[x.mod] || x.mod)} · ${esc(x.act)}${x.last ? ` · stalo na: ${esc(x.last)}` : ''}${x.last !== undefined && x.lastOk !== undefined ? ` · zadnje potvrđeno: ${esc(x.lastOk || 'ništa')}` : ''}${x.out ? ` · ${esc(FLOW_OUT[x.out] || x.out)}` : ''} · #${esc(x.id)}</p>` : '');
  const open = Object.entries(d.open || {});
  openSheet({
    title: 'Dijagnostika',
    body: `<p class="hint">Zapis ostaje na telefonu. „Kopiraj sažetak“ kopira samo vrste radnji, korake, ishode, vremena i tehničke razloge (bez imena, telefona, brojeva računa, naziva lista i sadržaja).</p>
      ${card('Zadnji dovršen tok', d.done)}${card('Zadnji prekinut tok', d.broken)}
      ${open.length ? `<p class="flow-card"><b>U toku</b><br>${open.map(([id, f]) => `${esc(FLOW_MOD[f.mod] || f.mod)} · ${esc(f.act)} · ${esc(f.last || 'započeto')} · #${esc(id)}`).join('<br>')}</p>` : ''}
      <div class="chips"><button class="chip" type="button" role="checkbox" aria-checked="${onlyErrors}" id="flowOnlyErr">Samo greške</button></div>
      <pre class="diag-text flow-text">${rows.length ? rows.map((e) => `${isBad(e.out) ? '! ' : '  '}${esc(flow.line(e))}`).join('\n') : '(nema zapisa)'}</pre>
      <details class="flow-raw"><summary>Tehnički zapis</summary><pre class="diag-text">${esc(raw)}</pre></details>`,
    actions: [
      { label: 'Kopiraj sažetak', kind: 'btn-primary', onClick: () => {
        let copied = false;
        try { copied = !!(A.copyLong && A.copyLong(flow.summary())); } catch (e) { copied = false; }
        toast(copied ? 'Sažetak dijagnostike je kopiran.' : 'Kopiranje nije uspjelo.', 4200);
      } },
      { label: 'Kopiraj tehnički zapis', onClick: () => {
        let copied = false;
        try { copied = !!(A.copyLong && A.copyLong(raw)); } catch (e) { copied = false; }
        toast(copied ? 'Tehnički zapis je kopiran.' : 'Kopiranje nije uspjelo.', 4200);
      } },
      { label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet },
    ],
  });
  const b = document.getElementById('flowOnlyErr');
  if (b) b.addEventListener('click', () => openFlowView(raw, !onlyErrors));
}

/** A line for the diagnostics (Postavke → Kopiraj dijagnostiku): timings measured on the phone. */
function note(text) { try { if (A.note) A.note(String(text).slice(0, 240)); } catch (e) { /* older app */ } }

function savePlansList() {
  return store.write('plans.json', S.plans.map(({ plan, ...meta }) => meta));
}

function rebuildIndex() {
  const byAge = S.plans.slice().sort((a, b) => a.imported - b.imported);
  S.index = core.buildIndex(byAge.map((p) => ({ id: p.id, plan: p.plan })));
  // 27. 11. 2026: the kept name fixes find their row through one map (each was a walk through every name)
  const fixes = Object.entries((S.user && S.user.nameFix) || {});
  if (fixes.length) { const at = new Map(S.index.names.map((n) => [n.num, n])); for (const [num, nm] of fixes) fixName(num, nm, false, at); }
  if (typeof cropForget === 'function') cropForget(); // planograms changed: drawn crops may show an older drawing
  eanSoon(3000);
}

// ------------------------------------------- barcodes of the planogram articles, from StoreFront (js/eans.js)
const eans = createEans({
  store, stCall: (arg, cb) => stCall(arg, cb), plans: () => S.plans, ready: () => !!S.index, has: () => !!A.storeTask,
  log: (t) => note(t),
  defer: () => top().id === 'viewer',
});
const eanSoon = (ms) => eans.soon(ms);
const eanStore = () => eans.data();
const eanOf = (code) => eans.of(code);

function dropFiles(id) {
  A.removePdf(`${id}.pdf`);
  A.removeThumbs(id);
  pageCache.drop(id);
  store.remove(`plan-${id}.json`);
  docs.forget(id);
  cropForget();
}

/**
 * Planograms whose every section is now covered by newer PDFs are not needed any more. Taken out of the list only;
 * their files are deleted by the caller once the new list is safely written (dropFiles). Kept when the newer PDFs
 * have far fewer articles in those sections (probably read badly): the newer ones still win in search.
 */
function pruneSuperseded() {
  const gone = [];
  for (const p of S.plans.slice()) {
    const codes = [...core.sectionCodes(p.plan)];
    if (!codes.length || codes.some((c) => S.index.owner.get(c) === p.id)) continue;
    const set = new Set(codes);
    const old = core.articlesIn(p.plan, set);
    const now = S.plans.filter((x) => x.id !== p.id && codes.some((c) => S.index.owner.get(c) === x.id)).reduce((a, x) => a + core.articlesIn(x.plan, set), 0);
    if (old >= 10 && now < old * 0.5) continue;
    S.plans = S.plans.filter((x) => x.id !== p.id);
    delete S.user.changes[p.id];
    gone.push(p);
  }
  if (gone.length) rebuildIndex();
  return gone;
}

// 2.05 (owner, 16. 11. 2026): shared barcodes. Every phone downloads the list the Worker merged from all phones
// (StoreFront-confirmed links at once, manual ones only when two phones sent them). The employee's own links win;
// a shared link he removed ("Promijeni vezu") stays off on his phone (S.user.noShared).
// 2.08 (owner, phone 16. 11.): the history had its own scroller (300 px), which caught the finger and stopped the page.
// Now the page scrolls everywhere: the first HIST_PREVIEW changes, the rest with "Prikaži sve promjene" (in the page).
const HIST_PREVIEW = 8;
const histAllOpen = new Set();
const SHARED_EVERY = 6 * 3600000;
// 2.21 (owner, 20. 11.): the links made on a build without the server (2.19/2.20 local) were never queued; every start
// offers all kept links again. Java takes them only with sharing on and skips what the server already has. A link whose
// kind is not known (older than 2.21) goes as "manual": the server shares it only when a second phone has the same.
function shareLearned() {
  if (!A.shareLearned) return;
  const kind = S.user.linkKind || {};
  const list = Object.entries(S.user.learned || {}).filter(([c, n]) => /^\d{8,14}$/.test(c) && /^\d{4,7}$/.test(String(n)))
    .map(([code, num]) => ({ code, num: String(num), kind: kind[code] === 'sf' ? 'sf' : 'manual' }));
  if (!list.length) return;
  try { const n = A.shareLearned(JSON.stringify(list)); if (n > 0) note(`barkodovi: ponuđeno ${n} sačuvanih veza za kolege`); } catch (e) { /* older shell */ }
}

function loadShared() {
  const j = store.read('shared-codes.json', null);
  const m = {};
  if (j && Array.isArray(j.list)) for (const p of j.list) if (Array.isArray(p) && /^\d{8,14}$/.test(p[0]) && /^\d{4,7}$/.test(p[1])) m[p[0]] = p[1];
  S.shared = m;
}
/** The links a scan uses: shared ones, minus the ones the employee removed, then his own over them. */
function codes() {
  const off = S.user.noShared || {};
  const out = {};
  for (const k in S.shared || {}) if (!off[k]) out[k] = S.shared[k];
  return Object.assign(out, S.user.learned);
}
function pullShared(force = false) {
  if (!A.pullSharedCodes) return;
  if (!force && Date.now() - (S.user.sharedAt || 0) < SHARED_EVERY) return;
  try { A.pullSharedCodes(); } catch (e) { /* older shell */ }
}
window.onSharedCodes = (n) => {
  if (!(n >= 0)) return;
  S.user.sharedAt = Date.now();
  saveUser();
  loadShared();
  note(`barkodovi: zajednička lista ${n}`);
};

function load() {
  const u = store.read('user.json', null);
  if (u) S.user = { recent: [], learned: {}, changes: {}, orders: null, ...u };
  if (Array.isArray(S.user.orders?.list)) S.user.orders.list = orderTime.sorted(S.user.orders.list);
  loadShared();
  migrate158();
  const list = store.read('plans.json', []);
  S.plans = [];
  for (const meta of list) {
    const plan = store.read(`plan-${meta.id}.json`, null);
    if (plan && plan.items) S.plans.push({ ...meta, plan });
  }
  rebuildIndex();
}

/**
 * Records of 1.57 and older, once. Lines waiting for Regulacija were put there by 1.57 also when the answer to the
 * Regulacija never came (a dropped connection counted as "not sent"): some of them may have gone through. Each is
 * marked "from 1.57" and cannot be sent again until the employee has checked it (Minus lista → Čeka Regulaciju).
 */
function migrate158() {
  const u = S.user;
  if (!u || (u.dataVer || 0) >= 158) return;
  for (const p of u.minusPending || []) if (p && typeof p === 'object') p.legacy = true;
  u.dataVer = 158;
  saveUser();
}

/** Every place an article is shown, across all planograms. */
function locationsOf(num) {
  const out = [];
  for (const e of S.index.byNum.get(num) || []) {
    const meta = S.plans.find((p) => p.id === e.id);
    // 1.96 (owner, BRONSIT 6112159): one label that carries the number twice ("9200001 9200001") is ONE place; it gave
    // two tabs with the same picture. Different labels stay different places, also on the same shelf.
    const seenB = new Set();
    for (const oc of e.it.oc) {
      const k = `${oc.p}|${oc.b.map((v) => Math.round(v)).join(',')}`;
      if (seenB.has(k)) continue;
      seenB.add(k);
      out.push({ e, meta, oc, place: core.placeOf(e.plan, oc) });
    }
    if (!e.it.oc.length) {
      // only on a product list: show its shelf on the drawing; the list itself only when no drawing has that shelf
      const seen = new Set();
      for (const r of e.it.rw) {
        const oc = core.shelfOfRow(e.plan, r);
        if (oc) {
          const k = `${oc.p}:${oc.g}`;
          if (seen.has(k)) continue;
          seen.add(k);
          out.push({ e, meta, oc, row: r, place: core.placeOf(e.plan, oc) });
        } else {
          out.push({ e, meta, row: r, place: null });
        }
      }
      if (!e.it.rw.length) out.push({ e, meta, place: null });
    }
  }
  return out;
}

function nameOf(num) {
  for (const e of S.index.byNum.get(num) || []) if (e.it.nm) return e.it.nm;
  return '';
}

/** The article's picture, or null. */
function pictureOf(num) {
  const url = (id, plan) => `/files/thumbs/${id}/${num}.webp?v=${plan.v || 1}`;
  for (const e of S.index.byNum.get(num) || []) if (e.it.im) return url(e.id, e.plan);
  for (const p of S.plans) if (p.plan.items[num] && p.plan.items[num].im) return url(p.id, p.plan);
  return null;
}

// ------------------------------------------- pictures from StoreFront
// StoreFront names the article's picture (read only), the phone fetches it from JYSK's own image server and keeps it:
// sf-pics.json = { num: { f: file name | '' (StoreFront has none), at } }. A picture is asked for once; "none" is
// asked again after a week. Nothing is asked without a StoreFront sign-in.
const SF_DIR = 'sf-slike';
let sfMap = null;
const sfPend = new Set();
let sfBusy = false, sfTimer = 0, sfPause = 0;
function sfPics() {
  if (!sfMap) { sfMap = store.read('sf-pics.json', {}) || {}; if (typeof sfMap !== 'object' || Array.isArray(sfMap)) sfMap = {}; }
  return sfMap;
}
const sfKnownNone = (num) => { const p = sfPics()[num]; return !!p && !p.f && Date.now() - (p.at || 0) < 7 * 86400000; };
// 1.99: ?v= the time it was kept: a picture fetched again under the same file name is not taken from the WebView's cache
const sfSrc = (num) => { const p = sfPics()[num]; return p && p.f ? `/files/thumbs/${SF_DIR}/${encodeURIComponent(p.f)}?v=${p.at || 0}` : null; };
// 1.99 (owner): one fetch per picture at a time (two screens asking for the same code), a kept picture asked for again
// after 30 days (StoreFront may have a new one; the old one stays on the screen until the new one is there)
const sfFlying = new Set();
const SF_REFRESH = 30 * 86400000;

/** An article's picture. StoreFront's picture comes first (it is the article's own; a picture cut out of a
 *  planogram PDF can belong to the neighbour). Until StoreFront's is here, or when StoreFront has none, the
 *  planogram's is shown. StoreFront's is asked for when the row is on screen.
 *  big: a tap on the picture opens it large (not for rows that open something themselves). */
function thumb(num, cls = '', big = false) {
  const own = pictureOf(num);
  if (!/^\d{7}$/.test(String(num || ''))) return `<span class="thumb ${cls}">${own ? `<img src="${own}" alt="" loading="lazy" decoding="async">` : icon('box')}</span>`;
  const b = big ? ` data-bigok="1"` : '';
  const sf = sfSrc(num);
  if (sf) return `<span class="thumb thumb-sf ${cls}" data-pic="${esc(num)}"${b}${big ? ` data-big="${esc(num)}"` : ''}><img src="${sf}" alt="" loading="lazy" decoding="async"></span>`;
  const want = sfKnownNone(num) ? '' : ' data-want="1"';
  return `<span class="thumb ${cls}" data-pic="${esc(num)}"${b}${want}>${own ? `<img src="${own}" alt="" loading="lazy" decoding="async">` : icon('box')}</span>`;
}

/** Thumb of a row that opens nothing itself: a tap on the picture opens it large. */
const sfThumb = (num) => thumb(num, '', true);

// a picture is asked for only once its row is on the screen (a long Rasprodaja list does not ask for hundreds)
const sfSeen = 'IntersectionObserver' in window
  ? new IntersectionObserver((es) => {
    for (const e of es) {
      if (!e.isIntersecting) continue;
      sfSeen.unobserve(e.target);
      if (e.target.dataset.want) sfWant(e.target.dataset.pic);
    }
  }, { rootMargin: '200px' })
  : null;
function sfWatch(root) {
  for (const el of root.querySelectorAll ? root.querySelectorAll('[data-want]') : []) {
    if (sfSeen) sfSeen.observe(el); else sfWant(el.dataset.pic);
  }
}
new MutationObserver((ms) => {
  for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) { if (n.dataset && n.dataset.want) sfWatch(n.parentNode || n); else sfWatch(n); }
}).observe(document.documentElement, { childList: true, subtree: true });

function sfWant(num) {
  const p = sfPics()[num];
  if (sfFlying.has(num) || sfPend.has(num)) return;
  if (p && (p.f ? Date.now() - (p.at || 0) < SF_REFRESH : Date.now() - (p.at || 0) < 7 * 86400000)) return;
  if (!A.fetchSfPictures || !A.storeTask) return;
  sfPend.add(num);
  clearTimeout(sfTimer);
  sfTimer = setTimeout(sfAsk, 600);
}

function sfAsk() {
  if (sfBusy || !sfPend.size || Date.now() < sfPause) return;
  const nums = [...sfPend].slice(0, 40);
  nums.forEach((n) => { sfPend.delete(n); sfFlying.add(n); });
  sfBusy = true;
  const ok = stCall({ mode: 'pics', nums }, (r) => {
    if (r.how !== 'ok' || !r.res) {
      sfBusy = false;
      nums.forEach((n) => { sfFlying.delete(n); sfPend.add(n); });
      sfPause = Date.now() + 5 * 60000; // not signed in or no connection: again in a few minutes, not in a loop
      return;
    }
    const list = (r.res.pics || []).map((x) => ({ num: x.num, url: x.m || x.s || '' }));
    nums.forEach((n) => { if (!list.some((x) => x.num === n)) sfFlying.delete(n); });
    if (!list.length) { sfBusy = false; sfAsk(); return; }
    sfBatch = list.map((x) => x.num);
    A.fetchSfPictures(JSON.stringify(list));
  });
  if (!ok) { sfBusy = false; nums.forEach((n) => { sfFlying.delete(n); sfPend.add(n); }); }
}
// 1.99: pictures removed to keep the folder within its size (SfPictures.trim): forgotten, asked again when shown
window.onSfPicturesGone = (nums) => {
  const m = sfPics();
  for (const n of nums || []) if (/^\d{7}$/.test(String(n))) delete m[n];
  store.write('sf-pics.json', m);
};

let sfBatch = [];
window.onSfPictures = (list) => {
  sfBusy = false;
  sfBatch.forEach((n) => sfFlying.delete(n)); // a picture that failed to come is asked again another time
  sfBatch = [];
  const m = sfPics();
  for (const x of list || []) {
    if (!/^\d{7}$/.test(String(x.num))) continue;
    sfFlying.delete(String(x.num));
    // a refresh that found nothing keeps the picture the phone has
    if (!x.file && m[x.num] && m[x.num].f) { m[x.num].at = Date.now(); continue; }
    m[x.num] = { f: String(x.file || ''), at: Date.now() };
    const src = sfSrc(x.num);
    if (!src) continue;
    for (const el of document.querySelectorAll(`[data-pic="${x.num}"]`)) {
      el.classList.add('thumb-sf');
      el.removeAttribute('data-want');
      if (el.dataset.bigok) el.dataset.big = x.num;
      el.innerHTML = `<img src="${src}" alt="" decoding="async">`;
    }
  }
  store.write('sf-pics.json', m);
  if (sfPend.size) setTimeout(sfAsk, 300);
};

function sfBig(num, el) {
  const src = sfSrc(num);
  if (!src) return;
  const row = el && el.closest('.item');
  const nm = nameOf(num) || (row && row.querySelector('.item-name') ? row.querySelector('.item-name').textContent : '');
  openSheet({ title: `${num} ${nm || ''}`.trim(), body: `<div class="sf-big"><img src="${src}" alt=""></div><p class="hint">Slika iz StoreFronta.</p>`, actions: [{ label: 'Zatvori', onClick: closeSheet }] });
}

const isFav = (num) => (S.user.favs || []).includes(num);
function toggleFav(num) {
  const f = S.user.favs || [];
  S.user.favs = f.includes(num) ? f.filter((n) => n !== num) : [num, ...f].slice(0, 40);
  saveUser();
  toast(isFav(num) ? 'Dodano u favorite' : 'Uklonjeno iz favorita');
}

/** One tap on a code: it goes to the phone's clipboard. */
function copyCode(num) {
  try { A.copyText(num); toast(`Šifra ${num} kopirana`); } catch (e) {
    try { navigator.clipboard.writeText(num); toast(`Šifra ${num} kopirana`); } catch (e2) { toast('Kopiranje ne radi u ovoj verziji.'); }
  }
}

function rememberRecent(num) {
  S.user.recent = [{ num, t: Date.now() }, ...S.user.recent.filter((r) => r.num !== num)].slice(0, 15);
  saveUser();
}

// --------------------------------------------------------------- navigation (js/navigation.js)
// S.stack holds { id, state } for each open screen; back() restores the one below.
const nav = createNav({
  stack: S.stack, $, $$,
  onShow: () => { try { viewer.fullSync(); } catch (e) { /* the viewer is not set up yet */ } },
  onLeave: (left) => { if (left.id === 'viewer') { viewer.close(); const d = docs.drawSummary(); if (d) note(d); } if (left.id === 'item') stopPrefetch(); if (left.id === 'oopusOrder') oopusUi.leaveOrder(); },
  onReturn: (t) => {
    // coming back from the planogram view, the article screen is still as it was
    if (t.id === 'item' && S.item !== t.state) { S.item = t.state; renderItem(); }
    // Returning from an article must restore the PDF bitmap, not just the stock SVG overlay.
    // Android WebView may discard the canvas GPU backing while the article is visible.
    if (t.id === 'viewer') viewer.resume();
    if (t.id === 'missing') renderMissing(t.state);
    if (t.id === 'changes') renderChanges(t.state);
    if (t.id === 'attach') renderAttach();
    if (t.id === 'minus') renderMinus();
    if (t.id === 'plans') renderPlans();
    if (t.id === 'ar') renderAr();
    if (t.id === 'top') renderTop();
    if (t.id === 'smdm') renderSm();
    if (t.id === 'soon') renderSoon();
    if (t.id === 'audit') renderAudit();
    if (t.id === 'tips') renderTips();
    if (t.id === 'home') renderHome();
    if (t.id === 'refill') refillUi.renderLists();
    if (t.id === 'regAdj') regAdjUi.render();
    if (t.id === 'refillList') refillUi.renderList();
    // 1.98: OOPUS (js/oopus-ui.js); back from the signature without saving = back to the checks, nothing sent
    if (t.id === 'oopus') oopusUi.renderList();
    if (t.id === 'oopusOrder') { oopusUi.onLeaveSign(); oopusUi.renderOrder(); }
    if (t.id === 'oopusSign') oopusUi.renderSign();
  },
});
const show = (id, how) => nav.show(id, how);
const top = () => nav.top();
const go = (id, state, opts) => { nav.go(id, state, opts); rememberScreen(); };
const back = () => { const r = nav.back(); rememberScreen(); return r; };

// Android may end the app while it is in the background (it asks for memory back often, the phone showed): coming back
// within 10 minutes, the article that was open is opened again instead of the start screen (1.71). Only the article
// screen: the others read StoreFront when opened, which needs the employee.
const LAST = 'polica:last-screen';
function rememberScreen() {
  try {
    const t = top();
    localStorage.setItem(LAST, JSON.stringify({ id: t.id, num: t.id === 'item' && t.state && t.state.num ? String(t.state.num) : '', at: Date.now() }));
  } catch (e) { /* no storage: nothing to remember */ }
}
function restoreScreen() {
  try {
    const l = JSON.parse(localStorage.getItem(LAST) || 'null');
    if (!l || l.id !== 'item' || !l.num || !(Date.now() - l.at < 10 * 60000) || !S.index.byNum.has(l.num)) return;
    openItem(l.num, { via: 'restore' });
  } catch (e) { /* stay on the start screen */ }
}

window.handleBack = () => {
  if (!$('#sheet').hidden) {
    if (sheet.dismissible) closeSheet();
    else if (sheet.cancel) sheet.cancel(); // a wait with a way out (planogram download): back takes it
    return true;
  }
  if (top().id === 'settings' && S.setGroup) { openSettingsGroup(null); return true; }
  if (top().id === 'home' && S.mode === 'orders' && S.ordBack && $('#q').value) { ordersBackToList(); return true; }
  if (back()) return true;
  // leaving the app while a planogram is being read would stop the import
  if (S.busy) { toast('Uvoz planograma još traje. Sačekaj da se završi.'); return true; }
  return false;
};

// --------------------------------------------------------------------- rows

function pills(place, row, more = 0) {
  let h;
  if (place && place.segment) {
    h = `<span class="pill">Modul <b>${esc(place.module)}</b></span><span class="pill">${isBar(place.fixture) ? 'Šipka' : 'Polica'} <b>${esc(place.shelf)}</b></span><span class="pill">Notch <b>${esc(place.notch)}</b></span>`;
  } else if (row && row.fx) {
    h = `<span class="pill pill-muted">${esc(row.fx)}</span>`;
  } else {
    h = '<span class="pill pill-muted">Bez mjesta na crtežu</span>';
  }
  if (more > 0) h += `<span class="more">+${more} ${plural(more, 'mjesto', 'mjesta', 'mjesta')}</span>`;
  return `<span class="pills">${h}</span>`;
}

// ------------------------------------------------------------ customer orders

const titleCase = (s) => String(s || '').toLowerCase().replace(/(^|[\s.-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());

/**
 * The phone says it has no network at all (Wi-Fi and mobile data off or no signal). S.net: Android's own word
 * (1.72-test3). 1.79: the WebView's navigator.onLine alone is not believed while StoreFront answered within
 * SF_FRESH_MS: on the phone (1.78) the app said "no internet" for a clearance list at 20:22 while StoreFront pings
 * answered in 151 ms (20:21:38) and 156 ms (20:24:32) and Android reported no loss. Each change is written to the
 * diagnostics with both values and Android's own state (netDiag).
 */
const SF_FRESH_MS = 120000;
let sfOkAt = 0; // StoreFront's last "ok" (a job or the status check)
let netDiagKey = '';
const offline = () => {
  const nav = navigator.onLine === false;
  const fresh = Date.now() - sfOkAt < SF_FRESH_MS;
  const off = S.net === false || (nav && !fresh);
  const key = `${S.net}|${nav}|${off}`;
  if (key !== netDiagKey) netDiag(key, off, nav && fresh && S.net !== false ? 'navigator.onLine=false zanemaren (StoreFront upravo odgovorio)' : '');
  return off;
};
function netDiag(key, off, why) {
  const first = !netDiagKey;
  netDiagKey = key;
  if (first && !off && !why) return; // the usual start: online, nothing to say
  let android = 'Android stanje nepoznato';
  try { if (A.netState) android = String(A.netState()); } catch (e) { /* older app */ }
  note(`mreža (ekran): offline ${off ? 'DA' : 'ne'}${why ? ` (${why})` : ''}; S.net=${S.net}, navigator.onLine=${navigator.onLine}, StoreFront ok prije ${sfOkAt ? Math.round((Date.now() - sfOkAt) / 1000) + ' s' : 'nikad'}, ekran ${top().id}; ${android}`);
}
// the WebView's own change, written even when no screen asks offline() at that moment
window.addEventListener('offline', () => offline());
window.addEventListener('online', () => offline());

function ageText(ms) {
  const m = Math.max(0, Math.round((Date.now() - ms) / 60000));
  if (m < 2) return 'upravo sada';
  if (m < 60) return `prije ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `prije ${h} h`;
  const d = Math.round(h / 24);
  return d === 1 ? 'jučer' : `prije ${d} dana`;
}

/** 27. 11. 2026 (owner, scan of EGEDAL 3670069: an order the customer had already collected was listed): this article's
 *  lines in that order are all picked up (StoreFront „Završeno“): the order is not shown for the article any more. */
function pickedUp(ord, num) {
  const ls = (ord.items || []).filter((it) => orderWaiting.sameNum(it.num, num));
  return ls.length > 0 && ls.every((it) => orderWaiting.lineKey(it.st) === 'done');
}
/** Customer orders that contain this article and still concern it (not already picked up by the customer). */
function ordersOf(num) {
  const o = S.user.orders;
  if (!o || !o.list) return [];
  const out = [];
  for (const ord of o.list) {
    if (pickedUp(ord, num)) continue;
    for (const it of ord.items || []) if (orderWaiting.sameNum(it.num, num)) out.push({ ord, qty: it.qty, st: it.st });
  }
  return out;
}

// ------------------------------------------------ Narudžbe: order of articles and of customers (owner, 13. 11. 2026)
const LIST_SORTS = [['oldest', 'Najstarije prvo'], ['newest', 'Najnovije prvo'], ['qty', 'Najviše komada'], ['orders', 'Najviše narudžbi'], ['number', 'Po broju narudžbe']];
const CUST_SORTS = [['oldest', 'Najstarije prvo'], ['newest', 'Najnovije prvo'], ['qty', 'Najviše komada na jednoj narudžbi'], ['number', 'Po broju narudžbe']];
const sortName = (list, k) => (list.find((x) => x[0] === k) || list[0])[1];
const komada = (n) => `${n} ${plural(n, 'komad', 'komada', 'komada')}`;
const narudzbi = (n) => `${n} ${plural(n, 'narudžba', 'narudžbe', 'narudžbi')}`;
/** The order-number check over what is loaded (memoised per reading). */
let refillUi = null; // js/refill-ui.js, created before boot()
let oopusUi = null; // js/oopus-ui.js (1.98)
let numCheckMemo = null;
function numCheck() {
  const o = S.user.orders;
  if (!o) return { agree: 0, differ: 0, none: 0, useful: false };
  if (!numCheckMemo || numCheckMemo.list !== o.list) numCheckMemo = { list: o.list, r: orderWaiting.numberCheck(o.list) };
  return numCheckMemo.r;
}
const listSort = () => { const k = cfg().ordSort || 'oldest'; return k === 'number' && !numCheck().useful ? 'oldest' : k; };
const custSort = () => { const k = cfg().ordCustSort || 'oldest'; return k === 'number' && !numCheck().useful || !CUST_SORTS.some((x) => x[0] === k) ? 'oldest' : k; };
// 25. 11. 2026 (review): the list of orders has its own order (with the value in KM); the customers of one article keep
// theirs (who came first), never sorted by a value that screen does not show
const ORDER_SORTS = [...CUST_SORTS, ['valueDesc', 'Najveća vrijednost (KM)'], ['valueAsc', 'Najmanja vrijednost (KM)']];
const orderSort = () => { const k = cfg().ordOrderSort || custSort(); return k === 'number' && !numCheck().useful || !ORDER_SORTS.some((x) => x[0] === k) ? 'oldest' : k; };
/** One row per order that has the article (its lines summed), in the chosen order of customers. */
function custRowsOf(num, onlyWaiting = false) {
  const o = S.user.orders;
  if (!o) return [];
  const e = orderWaiting.articles(o.list, { onlyWaiting }).find((x) => x.num === num);
  if (!e) return [];
  return orderWaiting.sortCustomers(e.orders.filter((r) => !pickedUp(r.ord, num)), custSort()).map((r) => {
    const lines = (r.ord.items || []).filter((it) => orderWaiting.sameNum(it.num, num));
    return { ...r, st: lines.length === 1 || lines.every((it) => it.st === lines[0].st) ? lines[0].st : lines.map((it) => it.st).join(', ') };
  });
}
/** How sure the order of customers is, said on the screen. */
function trustLine(rows) {
  const r = orderWaiting.reliability(rows);
  if (r.level === 'sure') return '<p class="ord-trust is-sure">Redoslijed po potvrđenom vremenu kreiranja.</p>';
  if (r.level === 'approx') return `<p class="ord-trust is-approx">${esc(r.why)}</p>`;
  return `<p class="ord-trust is-unknown">${esc(r.why || 'Iz podataka se ne zna ko je prvi.')}</p>`;
}
function custSortBar(num, onlyWaiting = false) {
  const rows = custRowsOf(num, onlyWaiting);
  return `<div class="ord-sortbar"><span>${trustLine(rows)}</span><button class="sort-btn" type="button" data-ordsort-open="cust">Poredaj: ${esc(sortName(CUST_SORTS, custSort()))}</button></div>`;
}
function numCheckText() {
  const c = numCheck();
  return `Broj narudžbe i vrijeme kreiranja: ${c.agree} ${plural(c.agree, 'par se slaže', 'para se slažu', 'parova se slaže')}, ${c.differ} ${plural(c.differ, 'odstupa', 'odstupaju', 'odstupa')}, za ${c.none} nema dovoljno podataka. `
    + (c.useful ? 'Broj prati vrijeme kreiranja.' : 'Premalo slaganja da bi broj bio pouzdan redoslijed.');
}
function openOrderSort(which) {
  if (which === 'res') {
    // 25. 11. 2026: the order of the reservations (Najbliže isteku ... Najnovije rezervacije)
    const cur = resSort();
    const age = !rz.RULES.hold.confirmed;
    openSheet({
      title: 'Poredaj rezervacije',
      body: `<div class="set-card">${rz.RES_SORT_LIST.map(([k, label]) => `<button class="set-act" type="button" role="radio" aria-checked="${k === cur}" data-ordsort-pick="res:${k}"><span class="set-txt"><b>${k === cur ? '● ' : ''}${esc(label)}</b>${age && (k === 'soonest' || k === 'longest') ? `<small>Po ${rz.RULES.hold.days} dana od kreiranja (početak roka nije potvrđen). Ostale idu poslije njih.</small>` : ''}</span></button>`).join('')}</div>`
        + '<p class="hint">Nepoznata vrijednost je uvijek na kraju, i od najveće i od najmanje.</p>',
      actions: [{ label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet }],
    });
    return;
  }
  const list = which === 'cust' ? CUST_SORTS : which === 'ord' ? ORDER_SORTS : LIST_SORTS;
  const cur = which === 'cust' ? custSort() : which === 'ord' ? orderSort() : listSort();
  const useful = numCheck().useful;
  openSheet({
    title: which === 'cust' ? 'Poredaj kupce' : which === 'ord' ? 'Poredaj narudžbe' : 'Poredaj artikle',
    body: `<div class="set-card">${list.map(([k, label]) => {
      const off = k === 'number' && !useful;
      return `<button class="set-act" type="button" role="radio" aria-checked="${k === cur}" data-ordsort-pick="${which}:${k}"${off ? ' disabled' : ''}><span class="set-txt"><b>${k === cur ? '● ' : ''}${esc(label)}</b>${off ? '<small>Nije ponuđeno: broj ne prati dovoljno pouzdano vrijeme kreiranja.</small>' : ''}</span></button>`;
    }).join('')}</div><p class="hint ord-note-help"><b>Kreirano:</b> vrijeme prvog (najstarijeg) zapisa u historiji narudžbe u StoreFrontu; taj zapis nastaje kad se narudžba kreira. Kasniji zapisi su poruke kupcu i komentari kolega. Ako je najstariji zapis koji StoreFront još daje poruka kupcu (SMS, e-mail), piše „Prva poruka kupcu“: historija može biti nepotpuna, pa je to vrijeme približno.</p><p class="hint">${esc(numCheckText())}</p>`,
    actions: [{ label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet }],
  });
}

// 2.06 (owner, 16. 11. 2026, Caffe Labud): a scanned article that a customer ordered shows the OTHER lines of that order
// too, so the whole order can be collected; each line opens its article. From the order as read (StoreFront's detail).
function orderLines(ord, num) {
  const items = ord.items || [];
  // 2.10 (owner, 17. 11. 2026, TAMHOLT + FANDRUP screenshot): the scanned article is in the list too, first and marked
  // "Skenirano", so the whole order is visible in one place; the other lines follow.
  const mine = items.filter((it) => orderWaiting.sameNum(it.num, num));
  const other = items.filter((it) => !orderWaiting.sameNum(it.num, num));
  const partial = ord.n > items.length ? `<small class="ord-lines-note">Pročitano ${items.length} od ${ord.n} stavki narudžbe. <button class="link" type="button" data-orders="1">Osvježi</button></small>` : '';
  if (!items.length) return partial ? `<div class="ord-lines">${partial}</div>` : '';
  const rows = mine.map((it) => olItem(it, true, true)).join('') + other.map((it) => olItem(it, false)).join('');
  const only = !other.length && !partial ? '<small class="ord-lines-note">Na narudžbi je samo ovaj artikal.</small>' : '';
  return `<div class="ord-lines"><div class="ord-lines-head">Na ovoj narudžbi (${items.length})</div><ul class="olines">${rows}</ul>${only}${partial}</div>`;
}
// 2.08 (owner, 16. 11. 2026, layout A): who waits for what, readable in two seconds. Words come ONLY from StoreFront's
// line states (order-waiting.js lineKey / orderState); payment ("Čeka plaćanje") is its own chip, never a goods state.
// Codes, the full order number, notes and the phone are under "Više detalja" / the order's own view.
const OST_WORD = { wait: 'čeka robu', part: 'djelimično stiglo', ready: 'u magacinu', done: 'preuzeto', unknown: 'status nije potvrđen' };
const OST_TAB = { wait: 'Čeka robu', part: 'Djelimično stiglo', ready: 'Sve stiglo', done: 'Preuzeto', unknown: 'Status nije potvrđen' };
const OCAT = [['all', 'Sve'], ['wait', 'Čeka robu'], ['part', 'Djelimično'], ['ready', 'Sve stiglo'], ['other', 'Ostalo']];
const ocCat = (k) => (k === 'wait' || k === 'part' || k === 'ready' ? k : 'other');
const ocOpen = new Set(); // orders whose details are open on the article screen (kept across re-renders)
// 2.15: what the automatic look found new on an order (3 h): Nova / Roba stigla / Promijenjeno
const ORD_MARK = { new: 'Nova', arrived: 'Roba stigla', part: 'Stigao dio robe', state: 'Promijenjeno' };
const ordMarkChip = (no) => { const k = autoSync ? autoSync.mark('ordMarks', no) : ''; return k ? `<span class="ord-chip is-mark is-${k}">${ORD_MARK[k]}</span>` : ''; };
const shortDate = (ord) => { const m = /^(\d{1,2}\.\d{1,2}\.)/.exec(orderWaiting.timeOf(ord).text || ''); return m ? m[1] : ''; };
/** The state of one article on one order (two lines of it in different states: partly). */
function lineKeyOf(ord, num) {
  const ks = [...new Set((ord.items || []).filter((it) => orderWaiting.sameNum(it.num, num)).map((it) => orderWaiting.lineKey(it.st)))];
  return ks.length === 1 ? ks[0] : ks.length ? 'part' : 'unknown';
}
const ocQty = (q, unsure) => (q > 0 ? `${unsure ? 'do ' : ''}${q} kom` : '? kom'); // an unknown quantity is never 0
function ocDetails(ord) {
  const tel = ord.ph && cfg().phone ? `<a class="ord-tel" href="tel:${esc(telOf(ord.ph))}">${esc(ord.ph)}</a>` : '';
  return `<div class="oc-det">${madeHtml(ord)}<small>Narudžba ${esc(ord.no)}${ord.date ? ` · dostava ${esc(ord.date)}` : ''}${ord.status ? ` · ${esc(ord.status)}` : ''}</small>${tel}${noteHtml(ord)}</div>`;
}
/** One order of the scanned article: name, date · number · state, pieces; the other lines and details on a tap. */
function ocArticleCard(r, num) {
  const ord = r.ord;
  const k = lineKeyOf(ord, num);
  const other = new Set((ord.items || []).filter((it) => !orderWaiting.sameNum(it.num, num)).map((it) => orderWaiting.numKey(it.num))).size;
  const open = ocOpen.has(ord.no);
  const meta = [shortDate(ord), esc(ord.no.slice(-6)), `<span class="oc-st">${OST_WORD[k]}</span>`].filter(Boolean).join(' · ');
  const more = other ? `+ još ${other} ${plural(other, 'artikal', 'artikla', 'artikala')} na narudžbi` : 'Više detalja';
  return `<div class="oc is-${k}" data-oc="${esc(ord.no)}">
    <div class="oc-top"><b class="oc-name">${esc(custName(ord))}</b><span class="oc-q">${ocQty(r.qty, r.unsure)}</span></div>
    <small class="oc-meta">${meta}</small>
    ${ord.pay ? '<span class="ord-chip is-pay">Čeka plaćanje</span>' : ''}${ordMarkChip(ord.no)}
    <button class="oc-more" type="button" data-oc-more="${esc(ord.no)}" data-more="${esc(more)}" aria-expanded="${open}">${open ? 'Sakrij detalje' : more} ›</button>
    <div class="oc-box"${open ? '' : ' hidden'}>${orderLines(ord, num)}${ocDetails(ord)}</div>
  </div>`;
}
/** The yellow summary over the article's orders: pieces and orders, then pieces per state (never a guessed 0). */
function ocSummary(rows, num) {
  const by = {};
  let total = 0, unknownQty = false;
  for (const r of rows) {
    const k = lineKeyOf(r.ord, num);
    by[k] = (by[k] || 0) + r.qty;
    total += r.qty;
    if (!(r.qty > 0)) unknownQty = true;
  }
  const IC = { ready: '✓ ', wait: '⏳ ' };
  const pills = ['ready', 'wait', 'part', 'done', 'unknown'].filter((k) => k in by)
    .map((k) => `<span class="oc-pill is-${k}">${IC[k] || ''}${by[k] > 0 ? `${by[k]} ` : ''}${OST_WORD[k]}</span>`).join('');
  return `<div class="oc-sum"><small>${rows.length > 1 ? 'Kupci su naručili ovaj artikal' : 'Kupac je naručio ovaj artikal'}</small>
    <b class="oc-big">${total} kom${unknownQty ? '+' : ''} · ${narudzbi(rows.length)}</b><div class="oc-pills">${pills}</div></div>`;
}
// ---------------------------------------------- 25. 11. 2026 (owner): value in KM and Rezervacije (js/reservations.js)
const resOn = () => cfg().ordRes === true;
const resSub = () => (rz.RES_FILTERS.includes(cfg().ordResSub) ? cfg().ordResSub : 'all');
const resSort = () => (rz.RES_SORTS[cfg().ordResSort] ? cfg().ordResSort : 'soonest');
/** The reservation chips of a card: what it is (a tap explains why), how it is paid, how long it is held. */
function rzRow(ord, r) {
  if (!r) return '';
  // owner, 25. 11. 2026: "klik" / "click" = a Click & Collect order whose goods the store reserved in the BO
  const chip = r.level !== 'sure' ? 'Rezervacija? · Provjeri' : r.cc ? 'Rezervacija · C&C' : 'Rezervacija';
  const t = rz.holdText(r.hold);
  return `<div class="rz-row"><button class="rz-chip is-${r.level}" type="button" data-rz-info="${esc(ord.no)}" aria-label="${esc(chip)}: zašto i odakle">${esc(chip)}</button>`
    + `<span class="rz-pay is-${r.pay.cat}">${esc(rz.payText(r.pay))}</span>`
    + (t ? `<span class="rz-time is-${r.hold.tone}" data-rzt="${esc(ord.no)}">${esc(t)}</span>` : '')
    // owner, 25. 11. 2026: the deadline runs from the creation even while the goods are not here; that is said, not changed
    + (r.hold.away && r.pay.cat !== 'paid' ? '<span class="rz-away">Roba još nije stigla</span>' : '') + '</div>';
}
/** One order in Narudžbe (quick view): name, value, pieces, state, its first lines; a tap opens the whole order. */
function ocOrderCard(ord, hit, r = rz.reservationOf(ord)) {
  const s = orderWaiting.orderState(ord);
  const p = orderWaiting.orderPieces(ord);
  const items = ord.items || [];
  const shown = items.slice().sort((a, b) => (hit && hit(b) ? 1 : 0) - (hit && hit(a) ? 1 : 0)).slice(0, 3);
  const lines = shown.map((it) => {
    const k = orderWaiting.lineKey(it.st);
    return `<li class="${hit && hit(it) ? 'is-hit' : ''}"><span class="oc-dot is-${k}"></span><span class="ocl-name">${esc(it.name || it.num)}</span><span class="ocl-q">${ocQty(+it.qty)} · ${OST_WORD[k]}</span></li>`;
  }).join('');
  const more = items.length - shown.length;
  const amt = rz.amountOf(ord);
  // 2.11: an order read only partly names the lines StoreFront says it has, not only the ones read
  const meta = [shortDate(ord), esc(ord.no.slice(-6)), `${p.total}${p.atLeast ? '+' : ''} kom`, p.partial ? `${s.of} ${plural(s.of, 'stavka', 'stavke', 'stavki')}` : `${p.lines} ${plural(p.lines, 'artikal', 'artikla', 'artikala')}`].filter(Boolean).join(' · ');
  return `<div class="oc oc-order ocard-c is-${s.key}${r ? ' is-rz' : ''}" role="button" tabindex="0" data-oq="${esc(ord.no)}">
    <div class="oc-top"><b class="oc-name">${esc(custName(ord))}</b><span class="oc-q${amt === null ? ' is-unknown' : ''}"${amt === null ? ' title="StoreFront nije dao vrijednost"' : ''}>${esc(rz.money(amt))}</span></div>
    <small class="oc-meta">${meta} · <button class="oc-st" type="button" data-st-ord="${esc(ord.no)}" aria-label="${esc(OST_TAB[s.key])}: šta znači status">${OST_TAB[s.key]}${s.partial && (s.key === 'wait' || s.key === 'part') ? ` · nepotpuno ${s.read}/${s.of}` : ''}</button></small>
    ${rzRow(ord, r)}${ord.pay && !r ? '<span class="ord-chip is-pay">Čeka plaćanje</span>' : ''}${ordMarkChip(ord.no)}
    ${lines ? `<ul class="ocl">${lines}</ul>` : ''}${more > 0 ? `<small class="oc-note">+ još ${more} na narudžbi</small>` : ''}${s.read < s.of ? `<small class="oc-note">Pročitano ${s.read} od ${s.of} stavki narudžbe</small>` : ''}
  </div>`;
}
/**
 * What the Narudžbe list shows now: every order once, the reservations among them, the chosen goods group (OCAT) and,
 * within Rezervacije, the chosen kind. The reservation summary counts the group before that kind (its counters choose
 * the kind); the value line counts exactly what is listed. Classification is memoised (js/reservations.js).
 */
function ordView(o, now = Date.now()) {
  const all = orderWaiting.uniqueOrders(o.list);
  const keyOf = new Map(all.map((ord) => [ord.no, orderWaiting.orderState(ord).key]));
  // counting needs only what does not change with the clock; the time of a reservation is worked out for the ones that
  // are listed (or counted in the Rezervacije summary), not for every order of the store at each drawing
  const resSet = new Set();
  let unread = 0;
  for (const ord of all) {
    if (!rz.noteKnown(ord)) { unread++; continue; }
    if (rz.isReservation(ord)) resSet.add(ord.no);
  }
  const on = resOn();
  const base = on ? all.filter((ord) => resSet.has(ord.no)) : all;
  const cnt = { all: base.length, wait: 0, part: 0, ready: 0, other: 0 };
  for (const ord of base) cnt[ocCat(keyOf.get(ord.no))]++;
  const cat = OCAT.some((x) => x[0] === cfg().ordCat) ? cfg().ordCat : 'all';
  const inCat = base.filter((ord) => cat === 'all' || ocCat(keyOf.get(ord.no)) === cat);
  const sub = on ? resSub() : 'all';
  const resOf = new Map();
  if (on) for (const ord of inCat) { const r = rz.reservationOf(ord, now); if (r) resOf.set(ord.no, r); }
  const rsum = on ? rz.sums(inCat.filter((ord) => resOf.has(ord.no)).map((ord) => ({ ord, r: resOf.get(ord.no) }))) : null;
  const pick = on ? inCat.filter((ord) => resOf.has(ord.no) && (sub === 'all' || rz.inFilter(resOf.get(ord.no), sub))) : inCat;
  return { all, keyOf, resSet, resOf, unread, on, cnt, cat, sub, rsum, pick, now };
}
/** The reservation summary: counters that choose the kind of reservation; expired ones are a part of the unpaid. */
function rzSumHtml(v) {
  const s = v.rsum;
  const lab = (k) => rz.filterLabel(k);
  const c = (k, n, extra = '') => `<button class="rz-c${v.sub === k ? ' is-on' : ''}${n ? '' : ' is-zero'} is-${k}" type="button" data-rz-sub="${k}" aria-pressed="${v.sub === k}"><b>${n}</b><span>${lab(k)}${extra}</span></button>`;
  const total = s.all && s.noAmt === s.all ? 'vrijednost još nije učitana' : `${rz.money(s.sum)}${s.noAmt ? ` poznato · ${s.noAmt} bez iznosa` : ''}`;
  const age = !rz.RULES.hold.confirmed;
  // the value of the ones over their deadline, paid or not (an unknown value among them: "+", never counted as 0)
  // review: when none of them has a value it is "? KM", never 0,00
  const expMoney = s.expired && s.noAmtExpired === s.expired ? '? KM' : `${rz.money(s.sumExpired)}${s.noAmtExpired ? '+' : ''}`;
  const expVal = `<div class="rz-c rz-cv"><b>${expMoney}</b><span>${age ? `preko ${rz.RULES.hold.days} dana` : 'isteklo'}</span></div>`;
  // the parts of the payment add up to all (an expired one is one of them, never one more)
  const parts = [[s.paid, `${plural(s.paid, 'plaćena', 'plaćene', 'plaćenih')}${s.paidLikely ? ` (${s.paidLikely} vjerovatno, avans)` : ''}`], [s.unpaid, plural(s.unpaid, 'neplaćena', 'neplaćene', 'neplaćenih')],
    [s.partial, 'djelimično'], [s.deposit, 'avans, iznos nepoznat'], [s.unknown, 'plaćanje nepoznato'], [s.conflict, 'kontradiktorno']]
    .filter((x) => x[0]).map((x) => `${x[0]} ${x[1]}`).join(' + ');
  return `<div class="rz-sum-top"><b>${s.all} ${plural(s.all, 'rezervacija', 'rezervacije', 'rezervacija')}</b><span>${total}</span></div>`
    + `<div class="rz-cs">${c('all', s.all)}${c('paid', s.paid)}${c('unpaid', s.unpaid)}${c('partial', s.partial)}${c('expired', s.expired)}${c('soon', s.soon)}${c('check', s.check)}${expVal}</div>`
    + `<small class="rz-sum-note">${s.all ? `${parts} = ${s.all}` : ''}`
    + (age ? ` · početak roka od ${rz.RULES.hold.days} dana nije potvrđen: piše starost` : '')
    + (v.unread ? ` · opis nije pročitan za ${v.unread} ${plural(v.unread, 'narudžbu', 'narudžbe', 'narudžbi')}` : '') + '</small>';
}
/** The value of what is listed: how many, the known sum, how many without a value (never a missing value as 0). */
function ordValHtml(v) {
  const x = rz.valueOf(v.pick);
  const sum = !x.n ? '' : x.noAmt === x.n ? ' · vrijednost još nije učitana' : ` · <b>${rz.money(x.sum)}</b>${x.noAmt ? ` poznato · ${x.noAmt} bez iznosa` : ''}`;
  const res = v.on ? '' : ` · <button class="link" type="button" data-rz-tog>${v.resSet.size}${v.unread ? '+' : ''} ${plural(v.resSet.size, 'rezervacija', 'rezervacije', 'rezervacija')}</button>`;
  const o = S.user.orders;
  const inc = o && o.part ? ' · <span class="ord-inc">lista nije cijela</span>' : '';
  // the values come from the automatic reading: when they are clearly older than the list, that is said
  const old = o && x.n > x.noAmt && (!o.vAt || o.at - o.vAt > 10 * 60000) ? ` · <span class="ord-inc">iznosi ${o.vAt ? esc(ageText(o.vAt)) : 'nisu osvježeni'}</span>` : '';
  const dg = v.pick.filter((ord) => ord.dgn > 1).length;
  const dgs = dg ? ` · ${dg} s više grupa isporuke (iznos nepoznat)` : '';
  return `<p class="ord-val" data-ord-val>${narudzbi(x.n)}${sum}${dgs}${res}${inc}${old}</p>`;
}
/** Narudžbe without a search (2.08 default): the orders, grouped by goods state, in the chosen order of customers. */
function ordersByOrder(o) {
  const v = ordView(o);
  const rows = v.on ? rz.sortRes(v.pick.map((ord) => ({ ord, r: v.resOf.get(ord.no) })), resSort(), v.now)
    : orderWaiting.sortCustomers(v.pick.map((ord) => ({ ord, qty: orderWaiting.orderPieces(ord).total, t: orderWaiting.timeOf(ord) })), orderSort());
  const max = 150;
  const sortBtn = v.on ? `<button class="sort-btn" type="button" data-ordsort-open="res">${esc(sortName(rz.RES_SORT_LIST, resSort()))} ▾</button>`
    : `<button class="sort-btn" type="button" data-ordsort-open="ord">${esc(sortName(ORDER_SORTS, orderSort()))} ▾</button>`;
  const tog = `<button class="chip rz-tog" type="button" role="switch" aria-checked="${v.on}" data-rz-tog>Rezervacije <b>${v.resSet.size}${v.unread ? '+' : ''}</b></button>`;
  const empty = v.on ? (v.resSet.size ? 'Nema rezervacija u ovom izboru.' : 'Nijedna narudžba nije prepoznata kao rezervacija.') : 'Nema narudžbi u ovoj grupi.';
  return `<div class="ord-head"><p class="count-line">${narudzbi(v.all.length)} · stanje <span class="ord-age">${esc(ageText(o.at))}</span><span class="auto-note">${esc(autoSync ? autoSync.note('orders') : '')}</span></p>${sortBtn}</div>`
    + `<div class="chips ord-cats">${tog}<span class="ord-catset" role="radiogroup" aria-label="Grupa narudžbi">${OCAT.map(([k, l]) => `<button class="chip" type="button" role="radio" aria-checked="${k === v.cat}" data-ocat="${k}">${l} <b>${v.cnt[k]}</b></button>`).join('')}</span></div>`
    + (v.on ? `<div class="rz-sum" data-rz-sumbox>${rzSumHtml(v)}</div>` : '')
    + ordValHtml(v)
    + (rows.length ? rows.slice(0, max).map((x) => ocOrderCard(x.ord, null, v.on ? v.resOf.get(x.ord.no) || null : undefined)).join('') : `<p class="empty">${empty}</p>`)
    + (rows.length > max ? `<p class="count-line">Prikazano prvih ${max}. Upiši ime ili broj da suziš.</p>` : '');
}
/**
 * 25. 11. 2026: one tick a minute (the app's own) writes the time of the reservations that are on screen and the
 * summary's numbers; the list itself is never drawn again for it.
 */
function rzTick() {
  const o = S.user.orders;
  if (!o) return;
  const els = document.querySelectorAll('[data-rzt]');
  const now = Date.now();
  // review: the summary first (also when no time is on screen, e.g. an empty filter)
  const box = document.querySelector('#results [data-rz-sumbox]');
  if (box && resOn() && top().id === 'home') {
    const v = ordView(o, now);
    const html = rzSumHtml(v);
    if (box.innerHTML !== html) box.innerHTML = html;
    // a reservation that crossed the 48 h or the 12 h leaves or enters the chosen kind: the list is drawn again then
    // (only then, keeping its place), never every minute
    const shown = [...document.querySelectorAll('#results .oc-order[data-oq]')].map((e) => e.dataset.oq).join();
    const want = rz.sortRes(v.pick.map((ord) => ({ ord, r: v.resOf.get(ord.no) })), resSort(), now).slice(0, 150).map((x) => x.ord.no).sort().join();
    if (v.sub !== 'all' && shown.split(',').filter(Boolean).sort().join() !== want) { keepPlace('#home .scroll', runOrdersSearch); return; }
  }
  if (!els.length) return;
  const by = new Map(orderWaiting.uniqueOrders(o.list).map((x) => [x.no, x]));
  for (const el of els) {
    const ord = by.get(el.dataset.rzt);
    const r = ord && rz.reservationOf(ord, now);
    if (!r) continue;
    const t = rz.holdText(r.hold), cls = `rz-time is-${r.hold.tone}`;
    if (el.textContent !== t) el.textContent = t;
    if (el.className !== cls) el.className = cls;
  }
}
// 25. 11. 2026 (owner, from the MYJYSK / StoreFront research): what a status of the ORDER means; a meaning MYJYSK does
// not confirm is said to be uncertain. The goods state of the lines and the payment are other things.
const STATE_INFO = {
  Kreirano: { t: 'Narudžba je kreirana na blagajni; roba može već biti na stanju.', src: 'StoreFront „Created“; MYJYSK: novokreirana narudžba' },
  'U tranzitu': { t: 'Roba je vjerovatno na putu prema prodavnici.', src: 'StoreFront „In transit“; značenje nije potpuno potvrđeno u MYJYSK-u', unsure: true },
  'Stiglo u prodavnicu': { t: 'Roba je stigla, ali kupac još nije obaviješten.', src: 'MYJYSK, Smjernice za narudžbe kupaca' },
  'Spremno za podjelu': { t: 'Roba je stigla i kupac je obaviješten (SMS iz StoreFronta).', src: 'MYJYSK, Smjernice za narudžbe kupaca' },
};
const LINE_INFO = [['Otvoreno', 'nije zaprimljeno'], ['Djelomično', 'zaprimljen dio'], ['Popunjeno', 'zaprimljeno, čeka kupca'], ['Završeno', 'kupac preuzeo']];
/** A tap on an order's status: what the order's status, the goods on it and the payment each say (three things). */
function openStatusInfo(no) {
  const o = S.user.orders;
  const ord = o && orderWaiting.uniqueOrders(o.list).find((x) => x.no === no);
  if (!ord) return;
  const row = (k, v) => `<div class="rz-info-row"><span>${k}</span><div>${v}</div></div>`;
  const si = STATE_INFO[ord.status];
  const s = orderWaiting.orderState(ord);
  const r = rz.reservationOf(ord);
  const lines = (ord.items || []).map((it) => `<li>${esc(it.name || it.num)}: ${esc(it.st || '?')}</li>`).join('');
  const pay = r ? `${esc(rz.payText(r.pay))}<small>${esc(r.pay.why)}</small>` : ord.pay ? 'StoreFront: „Čeka se plaćanje“' : 'StoreFront za narudžbe kupaca ne daje status plaćanja (samo oznaku „Čeka se plaćanje“, koje ovdje nema).';
  openSheet({
    title: `Status: ${ord.status || '?'}`,
    body: `<div class="rz-info">`
      + row('Narudžba', `${esc(ord.status || 'nepoznat')}<small>${si ? `${esc(si.t)} (${esc(si.src)})` : 'Značenje ovog statusa nije potvrđeno.'}</small>`)
      + row('Roba', `${esc(OST_TAB[s.key])}<small>Po stanju svakog artikla na narudžbi (StoreFront).</small>${lines ? `<ul>${lines}</ul>` : ''}`)
      + row('Plaćanje', pay)
      + `<p class="hint">${Object.entries(STATE_INFO).map(([k, x]) => `<b>${esc(k)}</b>: ${esc(x.t)}${x.unsure ? ' (nije potpuno potvrđeno)' : ''}`).join('<br>')}<br>${LINE_INFO.map(([k, t]) => `${esc(k)} = ${esc(t)}`).join(' · ')}</p></div>`,
    actions: [{ label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet }],
  });
}
/** Why the app takes this order for a reservation, how it is paid and how long it is held, and where each comes from. */
function openRzInfo(no) {
  const o = S.user.orders;
  const ord = o && orderWaiting.uniqueOrders(o.list).find((x) => x.no === no);
  const now = Date.now();
  const r = ord && rz.reservationOf(ord, now);
  if (!r) return;
  const row = (k, v) => `<div class="rz-info-row"><span>${k}</span><div>${v}</div></div>`;
  const H = rz.RULES.hold;
  const hold = rz.holdText(r.hold);
  const time = r.created == null ? 'Vrijeme kreiranja nije potvrđeno (najstariji zapis historije nije zapis blagajne).'
    : `Kreirana ${esc(rz.sarajevoText(r.created))} (najstariji zapis historije u StoreFrontu).${hold ? ` <b>${esc(hold)}</b>.` : ''}`;
  // owner, 26. 11. 2026: an ordinary reservation by MYJYSK 3.03.2 (14 days, paid or not), Click & Collect by MYJYSK 3.10
  const rule = r.cc ? `MYJYSK 3.10: Click & Collect se ne plaća unaprijed; kupac je preuzima do kraja dana kreiranja + 48 sati${r.hold.end ? ` (do ${esc(rz.sarajevoText(r.hold.end - 60000))})` : ''}.`
    : H.confirmed ? `MYJYSK 3.03.2: rezervisana roba najviše ${H.days} dana u BO-u, zatim kontaktirati kupca (ako je ne želi: poništiti, vratiti na slobodnu zalihu, vratiti avans). Važi i za plaćene. Računa se od kreiranja na blagajni (StoreFront ne kaže kad je roba ušla u BO).`
      : `MYJYSK 3.03.2: najviše ${H.days} dana u BO-u. Od kada teče nije potvrđeno, pa aplikacija ne kaže „istekla“, nego koliko je stara.`;
  const pay = `${esc(rz.payText(r.pay))}<small>${esc(r.pay.why)}${r.pay.src === 'text' || r.pay.src === 'both' ? '. Ono što piše u opisu nije potvrda iz sistema plaćanja: StoreFront za narudžbe kupaca daje samo „Čeka se plaćanje“.' : ''}</small>`;
  openSheet({
    title: r.level === 'sure' ? 'Rezervacija' : 'Vjerovatna rezervacija',
    body: `<div class="rz-info">`
      + row('Kupac', `${esc(custName(ord))}<small>Narudžba ${esc(ord.no)} · ${esc(rz.money(r.amt))} (StoreFront, cijena narudžbe)</small>`)
      + row('Zašto', `${esc(r.why.join('; '))}${r.cc ? '<small>Click & Collect: kupac je naručio preko web-stranice, a artikal je rezervisan u BO-u (klik u opisu).</small>' : ''}<small>Opis računa: „${esc(ord.note || '')}“ (zapis blagajne u historiji narudžbe)</small>`)
      + row('Plaćanje', pay)
      // owner, 26. 11. 2026: a deadline written in the description ("do petka") is only a note; the rule above holds
      + row('Vrijeme', `${time}<small>${esc(rule)}</small>${r.due ? `<small>U opisu piše i rok „${esc(r.due)}“: samo napomena, važi rok iznad.</small>` : ''}`)
      + row('Status', `${esc(ord.status || '')}${STATE_INFO[ord.status] ? `<small>${esc(STATE_INFO[ord.status].t)} (${esc(STATE_INFO[ord.status].src)})</small>` : ''}${r.hold.away ? '<small>Roba još nije stigla u prodavnicu; rok ipak teče od kreiranja.</small>' : ''}`)
      + (r.check.length ? row('Provjeri', `<ul>${r.check.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`) : '')
      + `<p class="hint">Rokovi: obična rezervacija ${H.days} dana od kreiranja (MYJYSK 3.03.2), Click & Collect do kraja dana kreiranja + 48 h (MYJYSK 3.10). Aplikacija samo informiše: ništa ne otkazuje, ništa ne šalje kupcu i ništa ne mijenja u StoreFrontu.</p></div>`,
    actions: [{ label: 'Otvori narudžbu', kind: 'btn-soft', onClick: () => { closeSheet(); if (!$('#q').value.trim()) S.ordBack = { scroll: $('#home .scroll').scrollTop }; $('#q').value = ord.no; runOrdersSearch(); showResultsTop(); } }, { label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet }],
  });
}
const ordMainSwitch = () => `<div class="seg-mini ord-main" role="group" aria-label="Glavni prikaz"><button type="button" data-omain="orders" aria-pressed="${cfg().ordMain !== 'articles'}">Po narudžbama</button><button type="button" data-omain="articles" aria-pressed="${cfg().ordMain === 'articles'}">Po artiklima</button></div>`;

/** 2.08: one short line over the drawing ("Kupci čekaju ovaj artikal · 3 narudžbe ›"); a tap goes to the full block. */
function ordersHint(num) {
  const rows = custRowsOf(num);
  if (!rows.length) return '';
  const wait = rows.filter((r) => ['wait', 'part'].includes(lineKeyOf(r.ord, num))).length;
  return `<button class="ord-hint" type="button" data-ord-jump>${icon('info')}<span><b>${wait ? 'Kupci čekaju ovaj artikal' : 'Kupci su naručili ovaj artikal'}</b> · ${narudzbi(rows.length)}</span><span class="go">›</span></button>`;
}
function ordersBlock(num, { after = false, label = '' } = {}) {
  const o = S.user.orders;
  const hits = ordersOf(num);
  if (!o) return after ? `<button class="btn btn-soft btn-block btn-small store-btn" type="button" data-orders="1">${icon('link')}Provjeri narudžbe kupaca</button>` : '';
  if (hits.length && !after) {
    const rows = custRowsOf(num);
    const stale = Date.now() - o.at > cfg().stale * 3600 * 1000;
    const trust = rows.length > 1 && orderWaiting.reliability(rows).level !== 'sure' ? trustLine(rows) : '';
    return `<section class="ord-hit oc-wrap">${ocSummary(rows, num)}${label ? `<div class="ord-sub">${esc(label)}</div>` : ''}
      <div class="oc-head"><span>Narudžbe</span>${rows.length > 1 ? `<button class="sort-btn oc-sort" type="button" data-ordsort-open="cust">${esc(sortName(CUST_SORTS, custSort()))} ▾</button>` : ''}</div>${trust}
      ${rows.map((r) => ocArticleCard(r, num)).join('')}
      ${stale ? `<p class="ord-none">Podaci su ${esc(ageText(o.at))}. <button class="link" type="button" data-orders="1">Osvježi</button></p>` : ''}</section>`;
  }
  if (!hits.length && after) {
    return `<p class="ord-none">Nema narudžbi kupaca za ovaj artikal (Aktivan, Zakasnio, Stigao, Ispunjen), stanje ${esc(ageText(o.at))}. <button class="link" type="button" data-orders="1">Osvježi</button></p>`;
  }
  return '';
}

// ----------------------------------------------------------------- app updates

// 1.74: the app looks for a new version by itself (at start, then at most every 3 h) in its own channel of the public
// repository (TEST builds: test/, the real app: prod/), shows the version and what changed, and downloads only after
// "Preuzmi ažuriranje". The download is checked (size, SHA-256, same app and signing key) and Android's installer asks
// to confirm; the app's data stays.
function renderUpdate() {
  const u = S.update;
  const b = $('#updateBar');
  if (!b) return;
  const show = u && ['downloading', 'ready', 'available', 'permission'].includes(u.state);
  b.hidden = !show;
  if (!show) return;
  const nm = esc(u.name || '');
  const note = u.notes ? `<small>${esc(String(u.notes).split('\n')[0].slice(0, 160))}</small>` : '';
  b.dataset.state = u.state;
  if (u.state === 'downloading') b.innerHTML = `<span class="work-dot"></span><span><b>Preuzimam verziju ${nm}</b><small>${u.pct || 0}% · provjera SHA-256 i potpisa poslije</small></span>`;
  else if (u.state === 'permission') b.innerHTML = `${icon('info')}<span><b>Dozvoli instalaciju</b><small>Uključi „Dozvoli iz ovog izvora“ pa se vrati u Jysk Reloaded i tapni opet</small></span><span class="go">Instaliraj</span>`;
  else if (u.state === 'ready') b.innerHTML = `${icon('info')}<span><b>Verzija ${nm} je preuzeta i provjerena</b>${note}</span><span class="go">Instaliraj</span>`;
  else b.innerHTML = `${icon('info')}<span><b>Nova verzija ${nm}</b>${note}</span><span class="go">Preuzmi ažuriranje</span>`;
}

/** Looks in the channel (no download): what is new shows with "Preuzmi ažuriranje". */
function checkUpdate(manual = false) {
  if (!A.checkUpdate) return;
  if (!manual && !cfg().upd) return;
  S.updError = '';
  S.updChecked = Date.now();
  S.updManual = manual;
  A.checkUpdate(false);
  hotCheck(manual);
}

// 2.24 (docs/HOT-UPDATES.md): a new version of the screens (this folder: html, css, js) comes without an install. Java
// looks in the same channel, checks the signature with the app's own certificate and that the bundle is for exactly
// this APK, and keeps it ready. A bundle that does not start is put back by itself (the watchdog in MainActivity, the
// self-check below) and never taken again.
// 2.25 (owner: "a fix waits while I work"): a ready fix starts by itself only when the page is quiet: on the home
// screen, nothing open, nothing under way (hotIdle) and Java finds nothing running (HotGate) — when the app is opened
// again after a minute away, or when the home screen was left untouched for 45 s. The process is never ended for it.
const HOT_AWAY_MS = 60 * 1000;
const HOT_IDLE_MS = 45 * 1000;
const HOT_CHECK_MS = 30 * 60 * 1000; // a look in the channel (one small file) at most this often while the app is used
let hotInputAt = Date.now(), hotHiddenAt = 0, hotErrs = 0, hotHealthSent = false;
for (const t of ['pointerdown', 'keydown', 'input']) document.addEventListener(t, () => { hotInputAt = Date.now(); }, { capture: true, passive: true });
// errors of the app's own scripts in this run (a bundle that keeps throwing is put aside after two such runs)
window.addEventListener('error', (ev) => {
  if (!/\/assets\//.test(String(ev.filename || ''))) return;
  hotErrs++;
  if (hotErrs >= 5) hotHealth(false);
});

function hotState() {
  try { return A.hotState ? JSON.parse(A.hotState()) : null; } catch (e) { return null; }
}

function hotCheck(manual = false) {
  if (!A.hotCheck) return;
  S.hotManual = manual;
  S.hotChecked = Date.now();
  try { A.hotCheck(!!manual); } catch (e) { /* older shell */ }
}

function hotHealth(ok) {
  if (hotHealthSent || !A.hotHealth) return;
  hotHealthSent = true;
  try { A.hotHealth(!!ok); } catch (e) { /* older shell */ }
}

/** Work of this page that a new start would cut (Minus, OOPUS signature, an import, a StoreFront answer awaited). */
function hotWorkBusy() {
  if (S.minusApplying || S.minusBusy) return 'minus';
  try { const h = oopusUi && oopusUi._v && oopusUi._v.hand; if (h && h.phase && h.phase !== 'idle') return 'oopus'; } catch (e) { /* not loaded */ }
  if (S.busy) return 'import';
  if (S.ordReading) return 'orders';
  if (stJobs.size) return 'storefront';
  return '';
}

/** The page's half of "may the new fix start now" ('' = yes; Java's half is HotGate): home screen and quiet. */
function hotIdle() {
  if (top().id !== 'home') return 'screen';
  if (!$('#sheet').hidden || !$('#gate').hidden) return 'sheet';
  const ae = document.activeElement;
  if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return 'input';
  return hotWorkBusy();
}

function hotWaiting() {
  if (S.hot && S.hot.state === 'ready') return true;
  const h = hotState();
  return !!(h && h.waiting);
}

/** 2.25: after the start, the main parts of the page are there; Java marks a bundle that lacks one and starts the APK's. */
function hotSelfCheck() {
  const miss = [];
  for (const id of ['home', 'settings', 'sheet', 'gate', 'toast', 'hotBar', 'updateBar', 'q', 'viewer']) if (!document.getElementById(id)) miss.push('#' + id);
  const fns = { renderHome, renderSettings, openSheet, closeSheet, toast, stCall, checkUpdate, hotCheck, handleBack: window.handleBack, appResume: window.appResume, appPause: window.appPause, onStoreTask: window.onStoreTask, onHot: window.onHot, onHotApply: window.onHotApply };
  for (const [k, f] of Object.entries(fns)) if (typeof f !== 'function') miss.push(k);
  // the styles arrived (app.css sets the colours on :root)
  try { if (!getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()) miss.push('app.css'); } catch (e) { miss.push('app.css'); }
  // the Java methods this page cannot work without (a bundle never runs on an APK without them: HotBundle.verify)
  for (const m of ['version', 'storeTask', 'hotState', 'hotApply', 'hotReport', 'readText', 'writeText']) if (typeof A[m] !== 'function') miss.push('Android.' + m);
  // errors so far are reported, not a reason by themselves (one odd record on one phone must not block every fix):
  // a bundle that throws again and again is caught by hotHealth (two runs with 5 or more)
  return { ok: !miss.length, miss: miss.slice(0, 20), errs: hotErrs };
}

function hotReport() {
  const r = hotSelfCheck();
  try { if (A.hotReport) A.hotReport(JSON.stringify(r)); else if (A.hotReady && r.ok) A.hotReady(); } catch (e) { /* older shell */ }
  // after two minutes of work: few errors = healthy (two bad runs in a row and the bundle is put aside)
  setTimeout(() => hotHealth(hotErrs < 5), 120000);
}

function renderHot() {
  const b = $('#hotBar');
  if (!b) return;
  const h = S.hot;
  const up = S.update && ['downloading', 'ready', 'available', 'permission'].includes(S.update.state);
  const show = !!(h && h.state === 'ready') && !up; // a new APK first: it carries the new screens too
  b.hidden = !show;
  if (!show) return;
  const note = h.notes ? `<small>${esc(String(h.notes).split('\n')[0].slice(0, 160))}</small>` : '<small>Primjenjuje se sama na početnom ekranu, bez instalacije</small>';
  b.dataset.state = 'hot';
  b.innerHTML = `${icon('info')}<span><b>Nova popravka je spremna</b>${note}</span><span class="go">Primijeni</span>`;
}

/** reason: manual (the bar or Postavke) | reset | resume | idle. By hand only the page's own work holds it back. */
function applyHot(reason = 'manual') {
  const hand = reason === 'manual' || reason === 'reset';
  const why = hand ? hotWorkBusy() : hotIdle();
  if (why) {
    if (hand) toast(reason === 'reset' ? 'Ugrađeni ekrani se vraćaju čim se završi posao koji je u toku, ili pri sljedećem otvaranju.' : 'Prvo završi posao koji je u toku, pa tapni „Primijeni“.', 4200);
    return false;
  }
  if (!A.hotApply) { if (hand) toast('Popravka se primjenjuje pri sljedećem otvaranju aplikacije.', 4200); return false; }
  S.hotAsked = Date.now();
  try { A.hotApply(reason); } catch (e) { return false; }
  return true;
}

/** Java's answer when the new start did not happen: why = none | minus | storefront:... | myjysk | plans | hidden ... */
window.onHotApply = (why, reason) => {
  if (reason !== 'manual' && reason !== 'reset') return; // the automatic ones try again later by themselves
  if (why === 'none') toast(reason === 'reset' ? 'Ekrani su već ugrađeni.' : 'Nema nove popravke za primjenu.');
  else toast('Aplikacija još nešto radi u pozadini (StoreFront, MYJYSK ili upis). Popravka se primjenjuje sama čim se završi, ili pri sljedećem otvaranju.', 5200);
};

/** Every 15 s while shown: a ready fix starts on a quiet home screen (Java is asked at most once a minute). */
function hotTick() {
  if (document.hidden || !appShown || !A.hotApply) return;
  if (Date.now() - hotInputAt < HOT_IDLE_MS) return;
  if (S.hotAsked && Date.now() - S.hotAsked < 60000) return;
  if (!hotWaiting() || hotIdle()) return;
  applyHot('idle');
}

/** Back in the app after a while: a ready fix starts now if the page is quiet; else a look in the channel, at most every 30 min. */
function hotResume() {
  const away = hotHiddenAt ? Date.now() - hotHiddenAt : 0;
  hotHiddenAt = 0;
  if (away >= HOT_AWAY_MS && hotWaiting() && !hotIdle() && applyHot('resume')) return true;
  if (cfg().upd && (!S.hotChecked || Date.now() - S.hotChecked > HOT_CHECK_MS)) hotCheck(false);
  return false;
}

window.onHot = (r) => {
  if (!r) return;
  if (r.state === 'ready') {
    S.hot = r;
    if (S.hotManual) toast('Nova popravka je spremna. Primjenjuje se sama na početnom ekranu.');
  } else {
    if (r.state === 'error' && S.hotManual) toast('Provjera popravki nije uspjela. Pokušaj kasnije.', 4200);
    S.hot = null;
  }
  S.hotManual = false;
  renderHot();
  if (top().id === 'settings') renderSettings();
};


/** "Preuzmi ažuriranje": download and check; when it is ready Android's installer asks to confirm. */
function getUpdate() {
  if (!A.checkUpdate) return;
  S.updWant = true;
  S.updError = '';
  S.updManual = true;
  A.checkUpdate(true);
}

function installUpdate() {
  if (S.update && S.update.state === 'available') { getUpdate(); return; }
  const r = A.installUpdate();
  if (r === 'permission') S.update = { ...(S.update || {}), state: 'permission' };
  else if (r !== 'ok') { toast('Instalacija nije uspjela. Pokušaj opet za koji trenutak.'); S.update = null; }
  renderUpdate();
}

// ------------------------------------------------------- first screen: sign-in

/** Shown until the employee signs in (or chooses "Kasnije" for this start). Nothing else is shown before it. */
function gateNeeded() {
  if (S.gateLater) return false;
  // only when no login is kept at all; a refused one is said in a line (the sessions may well still be open)
  try { return !!A.loginState && A.loginState() === 'none'; } catch (e) { return false; }
}

function showGate(msg = '') {
  const g = $('#gate');
  if (!g) return;
  g.hidden = false;
  setGateMsg(msg);
  // 1.74: a public APK on a phone that never had the app: the addresses first (nothing can be checked without them)
  const h = hostsNow(), box = $('#gateHosts'), edit = $('#gateHostsEdit');
  const fields = (lead) => {
    const now = hostsNow() || {};
    box.innerHTML = `<p class="gt-lead"><b>Adrese servera</b><br>${lead}</p>
      ${hostField('sf', now.sf)}${hostField('mj', now.mj)}${hostField('pl', now.pl)}<p class="gt-msg" id="gateHostsMsg" role="status" hidden></p>
      <button class="gt-cta" type="button" id="gateHostsGo">Sačuvaj adrese</button>`;
    box.hidden = false;
    $('#gateHostsGo').onclick = () => { if (saveHosts(box, $('#gateHostsMsg'))) { box.hidden = true; toast('Adrese su sačuvane.'); $('#gateUser').focus(); } };
  };
  // 1.75: a mistyped address must not lock the app out: it can be changed right here, before any sign-in
  if (edit) {
    edit.hidden = !h;
    edit.onclick = () => fields('Ako prijava ne prolazi jer je adresa pogrešno upisana, ispravi je ovdje. Ostaju samo na ovom telefonu.');
  }
  if (box && h && !h.sf) {
    fields('Ova verzija aplikacije nema u sebi adrese servera. Upiši ih jednom, kako ih vidiš u pregledniku na računaru u radnji. Ostaju samo na ovom telefonu.');
    return;
  }
  if (box) box.hidden = true;
  setTimeout(() => { if (!$('#gateUser').value) $('#gateUser').focus(); }, 300);
}

function setGateMsg(msg) {
  const m = $('#gateMsg');
  m.textContent = msg || '';
  m.hidden = !msg;
}

function hideGate() {
  $('#gate').hidden = true;
  $('#gatePass').value = '';
}

function gateBusy(on) {
  $('#gateGo').disabled = on;
  $('#gateGo').textContent = on ? 'Provjeravam prijavu…' : 'Prijavi se';
}

$('#gateForm')?.addEventListener('submit', (ev) => {
  ev.preventDefault();
  const u = $('#gateUser').value.trim(), p = $('#gatePass').value;
  if (!u || !p) { setGateMsg('Upiši korisničko ime i lozinku.'); return; }
  setGateMsg('');
  gateBusy(true);
  try { A.saveLogin(u, p); } catch (e) { gateBusy(false); setGateMsg('Ova verzija aplikacije ne zna prijavu. Javi se meni.'); }
});

$('#gateEye')?.addEventListener('click', () => {
  const f = $('#gatePass');
  f.type = f.type === 'password' ? 'text' : 'password';
  $('#gateEye').textContent = f.type === 'password' ? 'Prikaži' : 'Sakrij';
  $('#gateEye').setAttribute('aria-label', f.type === 'password' ? 'Prikaži lozinku' : 'Sakrij lozinku');
});

$('#gateLater')?.addEventListener('click', () => { S.gateLater = true; hideGate(); });

window.onLoginSaved = (ok, why) => {
  gateBusy(false);
  if (ok) {
    if (S.user.sfSignedOut) { delete S.user.sfSignedOut; saveUser(); } // 2.15 audit: signed in again
    hideGate();
    toast('Prijava je uspjela.');
    checkOnline();
    renderHome();
    if (welcomeSetup) welcomeSetup.start();
    return;
  }
  if (why === 'offline') {
    // the login is kept; StoreFront cannot be reached right now, so it is checked again later
    hideGate();
    toast('Prijava je sačuvana. Provjeri kad budeš na mreži.');
    checkOnline();
    return;
  }
  const W = {
    refused: 'StoreFront ne prihvata ovu lozinku. Provjeri je i pokušaj ponovo.',
    empty: 'Upiši korisničko ime i lozinku.',
    save: 'Prijava se ne može sačuvati na ovom telefonu.',
  };
  $('#gatePass').value = '';
  setGateMsg(W[why] || 'Prijava nije uspjela. Pokušaj ponovo.');
};

function checkOnline() {
  try { if (A.storeStatus) A.storeStatus(); } catch (e) { /* ignore */ }
}
window.onStoreStatus = (on, counts) => {
  const e = $('#onl');
  if (!e) return;
  if (on && counts) {
    S.site = {};
    for (const p of String(counts).split(',')) { const [k, v] = p.split(':'); S.site[k] = +v; }
    renderOrdersBar();
    // the orders are read only when the employee taps (the bar then says what changed)
  }
  if (on) sfOkAt = Date.now();
  e.hidden = false;
  e.className = 'onl ' + (on ? 'is-on' : 'is-off');
  e.textContent = on ? 'online' : 'offline';
};
// 2.15 audit: one tick a minute for both: the online check every 5th (as before, 5 min), the automatic looks each time
let tickN = 0;
setInterval(() => {
  if (++tickN % 5 === 0 && !document.hidden && top().id === 'home') checkOnline();
  if (autoSync) autoSync.tick();
  if (!document.hidden) rzTick(); // 25. 11. 2026: the time of the reservations on screen (text only, no list drawn again)
  if (tickN >= 2 && !document.hidden && appShown) substSync(); // not in the first minutes (the app's own start comes first)
  if (tickN >= 3 && !document.hidden && appShown && regsUi) regsUi.daily(); // 24. 11. 2026: MYJYSK rules and StoreFront codes, once a day
}, 60000);

/**
 * 21. 11. 2026 (StoreFront audit, owner's store: 169 open): StoreFront's "Zamjena" list, discontinued articles the store
 * still has to replace on the shelf by new ones. Read only, in the background (a free StoreFront page, never before
 * what the employee does), at most every 6 h while the app is open and StoreFront signed in. Kept on the phone: article
 * numbers, names, status and stock (product data). The article screen says it; marking it done stays in StoreFront.
 */
const SUBST_EVERY = 6 * 3600000;
let substBusy = false, substTried = 0, appShown = true; // appShown: false between appPause and appResume (nothing read in the background)
const substStore = () => String((S.user.sfHint && S.user.sfHint.store) || (S.user.orders && S.user.orders.store) || '');
function substSync() {
  if (substBusy || !A.storeTask || !(S.user.store && S.user.store.ok) || S.user.sfSignedOut || offline()) return;
  const s = S.user.subst, store = substStore();
  if (s && s.at && s.at <= Date.now() && Date.now() - s.at < SUBST_EVERY && (!store || s.store === store)) return;
  if (Date.now() - substTried < 30 * 60000) return; // a failed reading: not again for 30 min
  substTried = Date.now();
  substBusy = true;
  stCall({ mode: 'subst', bg: true }, (r) => {
    substBusy = false;
    if (!r || r.how !== 'ok' || !r.res || !Array.isArray(r.res.l) || !r.res.store) return;
    S.user.subst = { at: Date.now(), store: String(r.res.store).slice(0, 12), n: Number(r.res.total) || r.res.l.length, l: r.res.l.slice(0, 600) };
    saveUser();
    if (top().id === 'item' && S.item) renderItem(); // the open article gets its note
  });
}
/** The open replacement this article is in (as the old or the new one), from the list of the store signed in. */
function substOf(num) {
  const s = S.user.subst, store = substStore();
  if (!s || !Array.isArray(s.l) || (store && s.store !== store) || !s.at || Date.now() - s.at > 3 * SUBST_EVERY) return null;
  const n = String(num);
  const row = s.l.find((x) => x[0] === n) || s.l.find((x) => x[4] === n);
  if (!row) return null;
  const side = (i) => ({ num: row[i], name: row[i + 1] || '', st: row[i + 2] || '', stock: Number.isFinite(row[i + 3]) ? row[i + 3] : null });
  return { old: side(0), neu: side(4), isOld: row[0] === n, at: s.at };
}
const agoText = (t) => { const m = Math.max(0, Math.round((Date.now() - t) / 60000)); return m < 60 ? `prije ${m} min` : `prije ${Math.round(m / 60)} h`; };
function substNote(num) {
  const z = substOf(num);
  if (!z) return '';
  const stock = (x) => (x.stock == null ? '' : ` · za prodaju ${x.stock}`);
  const other = z.isOld ? z.neu : z.old;
  const open = `<button class="link" type="button" data-subst-open="${esc(other.num)}">${esc(other.num)}</button>`;
  return `<p class="notice notice-subst">${icon('info')}<span>${z.isOld
    ? `<b>Zamjena čeka:</b> na polici ga mijenja novi artikal ${open} ${esc(other.name)}${esc(stock(other))}.`
    : `<b>Zamjena čeka:</b> ovaj artikal na polici mijenja stari ${open} ${esc(other.name)}${esc(stock(other))}.`}
    <small>StoreFront, Akcijska lista → Zamjena (pročitano ${esc(agoText(z.at))}). „Označi kao obrađeno“ ostaje u StoreFrontu.</small></span></p>`;
}

/**
 * 1.72-test3: Android says the network went or is back (MainActivity → window.onNet, about a second after it happens).
 * Gone: said at once, what was read stays shown (and may be old); the hidden pages hold their background readings.
 * Back: StoreFront itself is asked (a ping) after NET_SETTLE_MS; only its answer makes the mark "online" again (a
 * network is not StoreFront). Then the barcodes go on, and a stock reading that failed meanwhile is read again (only
 * readings: nothing that writes is ever repeated here). StoreFront not answering: asked again after 5, 10, 20, 40, 60
 * s, then left to the next job; a sign-in on the way (AutoLogin on the hidden page) is waited for the same way.
 */
const NET_SETTLE_MS = 1500;
const NET_RETRY = [5, 10, 20, 40, 60];
let netGen = 0;
window.onNet = (up, downMs) => {
  const was = S.net;
  S.net = !!up;
  // 1.97: what waits to be sent (a list deletion) goes when the network is back
  if (up && !was && refillUi) setTimeout(() => refillUi.drainDeletes(), 3000);
  offline(); // the diagnostics line of this change (netDiag)
  const gen = ++netGen;
  const onl = $('#onl');
  if (!up) {
    if (onl) { onl.hidden = false; onl.className = 'onl is-off'; onl.textContent = 'offline'; onl.title = 'Nema interneta: prikazani podaci mogu biti zastarjeli'; }
    if (was !== false) toast('Nema interneta. Ono što je učitano ostaje prikazano, ali može biti zastarjelo.');
    stLineSoon();
    viewer.netChanged(false); // the planogram's stock badges say it at once (old, *)
    return;
  }
  if (was !== false) return; // it never went (the first report at start)
  if (onl) { onl.hidden = false; onl.className = 'onl is-off'; onl.textContent = 'provjeravam'; onl.title = 'Mreža je tu, provjeravam StoreFront'; }
  const t0 = Date.now();
  let sawLogin = false;
  const ask = (n) => {
    if (gen !== netGen || S.net === false) return; // gone again: the next "back" starts over
    stCall({ mode: 'ping', bg: true }, (r) => {
      if (gen !== netGen) return;
      if (r.how === 'ok') {
        window.onStoreStatus(true, '');
        if (sawLogin) note('StoreFront sesija obnovljena');
        note(`StoreFront ponovo dostupan ${Date.now() - t0} ms nakon povratka mreže (bez mreže ${Math.round((+downMs || 0) / 1000)} s${n ? `, ${n + 1}. pokušaj` : ''})`);
        netResume();
        return;
      }
      if (r.how === 'login') sawLogin = true;
      const why = r.how === 'login' ? 'traži prijavu' : r.err === 'offline' ? 'nema mreže' : `nedostupan${r.err ? ` (${String(r.err).slice(0, 40)})` : ''}`;
      if (n >= NET_RETRY.length) {
        note(`StoreFront ${why}; oporavak prekinut nakon ${n + 1} pokušaja (nastavlja se sa sljedećim poslom)`);
        if (onl) { onl.className = 'onl is-off'; onl.textContent = 'offline'; onl.title = 'StoreFront ne odgovara'; }
        return;
      }
      note(`StoreFront ${why}; ponovo za ${NET_RETRY[n]} s`);
      setTimeout(() => ask(n + 1), NET_RETRY[n] * 1000);
    });
  };
  setTimeout(() => ask(0), NET_SETTLE_MS);
};

/** StoreFront answers again: what waits on it goes on (readings only). */
function netResume() {
  eans.resume();
  viewer.netChanged(true); // the open planogram reads what failed or got old
  let n = 0;
  for (const el of document.querySelectorAll('[data-stock]')) {
    const num = el.dataset.stock, c = S.stock.get(num);
    if (c && c.err && !c.busy) { stockLoad(num, true); n++; }
  }
  if (n) note(`čitanje zalihe nastavljeno: ${n}`);
  toast('Internet je ponovo tu, StoreFront odgovara.');
}

// 1.75: Android did not install the update (declined, no room, refused). The checked file stays on the phone, so the
// bar keeps "Instaliraj"; what happened is said in words.
window.onInstallResult = (why) => {
  toast(installResultText(why), 6000);
  renderUpdate();
};

window.onUpdate = (r) => {
  if (!r) return;
  if (r.state === 'none') {
    S.update = null;
    S.updError = '';
    if (S.updManual) toast('Imaš najnoviju verziju.');
  } else if (r.state === 'error') {
    S.update = null;
    S.updError = updateErrorText(r.msg);
    if (S.updManual) toast(S.updError, 5200);
  } else {
    S.update = r;
    S.updError = '';
  }
  if (r.state !== 'downloading') S.updManual = false;
  // downloaded and checked after "Preuzmi ažuriranje": straight to Android's installer (it asks to confirm)
  const go = r.state === 'ready' && S.updWant;
  if (r.state !== 'downloading') S.updWant = false;
  renderUpdate();
  renderHot();
  if (top().id === 'settings') renderSettings();
  if (go) setTimeout(installUpdate, 300);
};

const CLR_ST = ['21', '81'];
// ----------------------------------------------- articles to sell out (status 21 / 81)

// created just before boot() (everything it uses exists by then): js/clearance-ui.js; these forward to it
let clearanceUi = null;
function clrDmOff(...a) { return clearanceUi.clrDmOff(...a); }
function onClearDept(...a) { return clearanceUi.onClearDept(...a); }
function clrSrc(...a) { return clearanceUi.clrSrc(...a); }
function clrStatuses(...a) { return clearanceUi.clrStatuses(...a); }
function clrView(...a) { return clearanceUi.clrView(...a); }
function loadClr2(...a) { return clearanceUi.loadClr2(...a); }
function money(...a) { return clearanceUi.money(...a); }
function openClearance(...a) { return clearanceUi.openClearance(...a); }
function refreshClearance(...a) { return clearanceUi.refreshClearance(...a); }
function renderClearBar(...a) { return clearanceUi.renderClearBar(...a); }
function renderClearance(...a) { return clearanceUi.renderClearance(...a); }
function whole(...a) { return clearanceUi.whole(...a); }
// ----------------------------------------------------------------- settings

const DEFAULTS = {
  vib: true, // short buzz when a barcode is read
  mode: 'plan', // search that is open when the app starts
  auto: true, // ask StoreFront about unknown barcodes without a tap
  tabs: { Aktivan: true, Zakasnio: true, Stigao: true, Ispunjen: true }, // customer-order tabs that are read
  name: true, // show the customer's name
  phone: true, // show the customer's phone
  stale: 12, // hours after which the orders data is called old
  theme: 'auto', // auto = follows the phone, or light / dark
  watch: false, // look at the order numbers in the background and send a notification
  // 2.15 (owner, 18. 11. 2026): Narudžbe (10 min) and Minus lista (30 min) keep themselves fresh while the app is open
  autoOrders: true,
  autoMinus: true,
  watchMinus: false, // the background look also compares the minus list and sends a notification
  clr: { 21: true, 81: true }, // statuses on the list of articles to sell
  group: '5', // product group of that list (5 = the department's own)
  noxmas: true, // leave Christmas and New Year articles out of that list
  xmas: core.XMAS_WORDS, // the words that make a name a Christmas / New Year one
  upd: true, // look for a new version of the app when it is opened
  mj: true, // read MYJYSK every morning at 8:00 and send a notification when there is something new
  mjMe: null, // who the employee is in MYJYSK (names, numbers, comma between); null = not known yet (filled once from StoreFront, kept on the phone)
  plSide: 'left', // the store's planograms: left or right side
  plCompact: false, // SC 3.0 Compact store
  plOrg: '1014BIH', // the country whose planograms are taken
  plOff: null, // planograms not taken: { '<sis>|<sub>': true }; null = only the Christmas one with the wall left out
};
const cfg = () => ({ ...DEFAULTS, ...(S.user.settings || {}), tabs: { ...DEFAULTS.tabs, ...((S.user.settings || {}).tabs || {}) }, clr: { ...DEFAULTS.clr, ...((S.user.settings || {}).clr || {}) } });
function setCfg(patch) {
  S.user.settings = { ...(S.user.settings || {}), ...patch };
  saveUser();
}

const sw = (key, label, sub, on) => `<div class="set-row"><div class="set-txt"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</div>
  <button class="switch" type="button" role="switch" aria-checked="${on}" aria-label="${esc(label)}" data-set="${key}"><i></i></button></div>`;
const choice = (key, label, opts, cur) => `<div class="set-row set-col"><div class="set-txt"><b>${label}</b></div>
  <div class="seg seg-sm" role="radiogroup" aria-label="${esc(label)}">${opts.map(([v, t]) => `<button class="seg-btn" type="button" role="radio" aria-checked="${String(v) === String(cur)}" data-choice="${key}" data-v="${v}">${t}</button>`).join('')}</div></div>`;
const act = (id, label, sub, danger) => `<button class="set-act${danger ? ' is-danger' : ''}" type="button" data-act="${id}"><span class="set-txt"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</span>${icon('chev', 'chev')}</button>`;

// 1.74: the server addresses this phone keeps (a public APK carries none; the first install or Postavke gives them)
const HOST_LABEL = { sf: 'StoreFront', mj: 'MYJYSK', pl: 'Server planograma' };
function hostsNow() {
  try { return A.hosts ? JSON.parse(A.hosts() || 'null') : null; } catch (e) { return null; }
}
/** The address fields in root ([data-host]) to the phone; false with the reason in msg when one is not an address. */
function saveHosts(root, msg) {
  const v = {};
  for (const i of root.querySelectorAll('[data-host]')) v[i.dataset.host] = i.value.trim();
  let r = '';
  try { r = String(A.setHosts(JSON.stringify(v)) || ''); } catch (e) { r = 'old'; }
  if (r === 'ok') return true;
  msg.textContent = r.startsWith('bad:') ? `${HOST_LABEL[r.slice(4)] || 'Adresa'}: to nije adresa servera. Upiši samo ime servera, npr. server.primjer.com.` : 'Adrese nisu sačuvane.';
  msg.hidden = false;
  return false;
}
const hostField = (k, v) => `<label class="host-field"><span>${HOST_LABEL[k]}</span><input class="set-input" data-host="${k}" type="text" inputmode="url" value="${esc(v || '')}" placeholder="server.primjer.com" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="${HOST_LABEL[k]}"></label>`;
function openHosts() {
  const h = hostsNow() || {};
  openSheet({
    title: 'Adrese servera',
    body: `<p>Upiši adrese kako ih vidiš u pregledniku na računaru u radnji (samo ime servera). Ostaju samo na ovom telefonu i ne šalju se nikome.</p>
      ${hostField('sf', h.sf)}${hostField('mj', h.mj)}${hostField('pl', h.pl)}<p class="form-msg" id="hostsMsg" role="alert" hidden></p>`,
    actions: [{ label: 'Sačuvaj', kind: 'btn-primary', onClick: () => { if (saveHosts($('#sheet'), $('#hostsMsg'))) { closeSheet(); toast('Adrese su sačuvane.'); if (top().id === 'settings') renderSettings(); } } },
      { label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }],
  });
}

// audit 13. 11. 2026: Postavke open on five short rows; each opens its group. Every control and saved choice is the
// same as before (same keys in user.json), only grouped: [key, title]
const SET_GROUPS = [
  ['login', 'Prijava i prodavnica'],
  ['work', 'Rad u prodavnici'],
  ['plans', 'Planogrami i podaci'],
  ['look', 'Izgled i ažuriranja'],
  ['privacy', 'Privatnost i dijagnostika'],
];
S.setGroup = null;
const hm = (ms) => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
function settingsSummary(k, c, learned) {
  if (k === 'login') {
    let st = 'none';
    try { st = A.loginState ? A.loginState() : 'none'; } catch (e) { /* older shell */ }
    const h = hostsNow();
    const miss = h && ['sf', 'mj', 'pl'].some((x) => !h[x]);
    return (st === 'ok' ? 'Automatska prijava uključena' : st === 'refused' ? 'Lozinka nije prihvaćena' : 'Automatska prijava isključena') + (miss ? ' · adresa nije podešena' : '');
  }
  if (k === 'work') {
    const tabs = TABS_ALL.filter((t) => c.tabs[t]).length;
    return `Otvara ${c.mode === 'orders' ? 'Narudžbe' : c.mode === 'news' ? 'Vijesti' : 'Planograme'} · narudžbe: ${tabs} od 4 kartice · rasprodaja: ${CLR_ST.filter((x) => c.clr[x]).join(' i ') || 'nijedan status'}`;
  }
  if (k === 'plans') return `${S.plans.length} ${plural(S.plans.length, 'planogram', 'planograma', 'planograma')} · ${learned} ${plural(learned, 'povezan barkod', 'povezana barkoda', 'povezanih barkodova')}`;
  if (k === 'look') return `Tema: ${c.theme === 'light' ? 'svijetla' : c.theme === 'dark' ? 'tamna' : 'kao telefon'} · verzija ${esc(A.version())}${S.update && S.update.state ? ' · ima nova verzija' : ''}`;
  const t = tmStatus();
  if (!t || !t.enabled) return 'Ova verzija ne šalje dijagnostiku · zapis ostaje na telefonu';
  if (t.consent !== 'yes') return 'Dijagnostika isključena';
  return t.dgAckAt ? `Dijagnostika uključena · zadnje potvrđeno ${hm(t.dgAckAt)}` : 'Dijagnostika uključena · još ništa potvrđeno';
}
/** Postavke -> Privatnost i dijagnostika: the field names of the last orders reading (no values), to confirm the receipt time. */
function sfFieldsRow() {
  const x = S.user.sfFields;
  const has = x && typeof x.f === 'string';
  const time = has ? (x.f.match(/[A-Za-z0-9_]+=(?:[9.:\-T Z+/|]|prazno|broj\d+)+/g) || []) : [];
  return `<div class="set-row set-col"><div class="set-txt"><b>Polja vremena u narudžbama StoreFronta</b><small>${has
    ? `Iz čitanja ${esc(ageText(x.at))}. Samo nazivi polja i oblik vremena (svaka cifra je 9), bez vrijednosti: ${esc(time.join(', ') || 'nijedno polje s vremenom')}`
    : 'Pojavi se nakon sljedećeg osvježenja narudžbi. Prikazuju se samo nazivi polja, nikad vrijednosti.'}</small>${has
    ? `<details class="sf-fields"><summary>Sva polja (nazivi)</summary><small>${esc(x.f)}</small></details>` : ''}</div></div>`;
}

/** Shows the five rows, or one group's sections (the template draws them all; the other groups are hidden). */
function settingsGroups(c, o, learned) {
  const body = $('#settingsBody');
  const g = SET_GROUPS.find((x) => x[0] === S.setGroup);
  $('#settings .top-title').textContent = g ? g[1] : 'Postavke';
  for (const el of body.querySelectorAll('[data-grp]')) el.hidden = !g || el.dataset.grp !== g[0];
  if (g) return;
  body.insertAdjacentHTML('afterbegin', `<section class="set-block set-groups"><div class="set-card">${SET_GROUPS.map(([k, title]) =>
    `<button class="set-act" type="button" data-set-grp="${k}"><span class="set-txt"><b>${title}</b><small>${settingsSummary(k, c, learned)}</small></span>${icon('chev', 'chev')}</button>`).join('')}</div></section>`);
}
function openSettingsGroup(k) {
  S.setGroup = SET_GROUPS.some((x) => x[0] === k) ? k : null;
  renderSettings();
  const sc = $('#settings .scroll');
  if (sc) sc.scrollTop = 0;
  const h = $('#settings .top-title');
  if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
}

function renderSettings() {
  const c = cfg();
  const o = S.user.orders;
  const learned = Object.keys(S.user.learned || {}).length;
  const tabNames = [['Aktivan', 'Aktivan'], ['Zakasnio', 'Zakasnio'], ['Stigao', 'Stigao'], ['Ispunjen', 'Ispunjen']];
  $('#settingsBody').innerHTML = `
  <section class="set-block" data-grp="look"><h3>Izgled</h3><div class="set-card">
    ${choice('theme', 'Tema', [['auto', 'Kao telefon'], ['light', 'Svijetla'], ['dark', 'Tamna']], c.theme)}
  </div></section>

  ${(() => {
    let st = 'none';
    try { st = A.loginState ? A.loginState() : (A.plansLoginKept && A.plansLoginKept() ? 'ok' : 'none'); } catch (e) { /* older shell */ }
    const line = st === 'ok' ? 'Uključena. Kad te MYJYSK ili StoreFront odjavi, Jysk Reloaded se sama ponovo prijavi. Ista lozinka se koristi i za potvrdu Minus liste, pa ništa ne kucaš.'
      : st === 'refused' ? 'Lozinka nije prihvaćena (možda je promijenjena). Upiši novu, do tada se aplikacija ne prijavljuje sama.'
      : 'Isključena. Upiši korisničko ime i lozinku i aplikacija se sama prijavljuje kad te sistem odjavi.';
    let last = '';
    try {
      const [at, what, host] = String((A.loginLast && A.loginLast()) || '').split('|');
      const W = { sent: 'poslano korisničko ime i lozinka', refused: 'stranica je odbila lozinku', stopped: 'nije pokušano (lozinka ranije odbijena)', nologin: 'nije pokušano (nema sačuvane lozinke)', noform: 'stranica za prijavu otvorena, ali forma nije pronađena', link: 'otvorena nova sesija', retry: 'forma se vratila bez greške, pokušano još jednom', error: 'greška pri popunjavanju' };
      if (+at && W[what]) {
        const d = new Date(+at);
        last = `Zadnji pokušaj: ${d.getDate()}.${d.getMonth() + 1}. u ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} · ${W[what]}${host ? ` (${esc(host)})` : ''}`;
      }
    } catch (e) { /* older shell */ }
    return `<section class="set-block" data-grp="login"><h3>Prijava</h3><div class="set-card">
    <div class="set-row"><div class="set-txt"><b>Automatska prijava</b><small class="${st === 'refused' ? 'is-bad' : ''}">${line}</small>${last ? `<small>${last}</small>` : ''}</div></div>
    ${act('login-set', st === 'none' ? 'Upiši korisničko ime i lozinku' : 'Promijeni korisničko ime i lozinku', 'Isti za MYJYSK, StoreFront i planograme. Ostaju samo na ovom telefonu, šifrovani.')}
    ${st !== 'none' ? act('login-forget', 'Zaboravi korisničko ime i lozinku', 'Brišu se s ovog telefona', true) : ''}
    ${act('signout', 'Odjavi se iz StoreFronta', 'Briše i narudžbe kupaca s telefona; sljedeći put se ponovo prijaviš na njihovoj stranici', true)}
  </div></section>`;
  })()}

  ${(() => {
    // 1.74: the APKs of the public update channel carry no server addresses; the app keeps its own
    const h = hostsNow();
    if (!h) return '';
    const row = (k) => `<div class="set-row"><div class="set-txt"><b>${HOST_LABEL[k]}</b><small class="${h[k] ? '' : 'is-bad'}">${h[k] ? 'Podešena' : 'Nije podešena'}</small></div></div>`;
    return `<section class="set-block" data-grp="login"><h3>Adrese servera</h3><div class="set-card">
    ${row('sf')}${row('mj')}${row('pl')}
    ${act('hosts-set', 'Upiši ili promijeni adrese', 'Ostaju samo na ovom telefonu. Verzije iz javnog kanala ažuriranja ih nemaju u sebi.')}
  </div></section>`;
  })()}

  <section class="set-block" data-grp="work"><h3>Pretraga i skeniranje</h3><div class="set-card">
    ${choice('mode', 'Pri otvaranju', mjOn() ? [['plan', 'Planogrami'], ['orders', 'Narudžbe'], ['news', 'Vijesti']] : [['plan', 'Planogrami'], ['orders', 'Narudžbe']], c.mode)}
    ${sw('vib', 'Vibracija pri skeniranju', 'Kratka vibracija kad se barkod pročita', c.vib)}
    ${sw('auto', 'StoreFront traži nepoznate barkodove', 'Kad barkod nije poznat, sam se pita StoreFront (bez dodira dugmeta)', c.auto)}
  </div></section>

  <section class="set-block" data-grp="work"><h3>Automatske provjere i obavijesti</h3><div class="set-card">
    ${sw('autoOrders', 'Automatske provjere Narudžbi', 'Dok je aplikacija otvorena: svakih 10 minuta, pri otvaranju i povratku u aplikaciju. Samo čita iz StoreFronta.', c.autoOrders)}
    ${sw('autoMinus', 'Automatske provjere Minus liste', 'Dok je aplikacija otvorena: svakih 30 minuta. Samo čita; nikad ne šalje Minus ni Regulaciju.', c.autoMinus)}
    ${sw('watch', 'Obavijesti za Narudžbe', 'Kad je aplikacija zatvorena: oko svakih pola sata (7–21 h, ne dok je baterija slaba) uporedi broj narudžbi po karticama i javi novu narudžbu ili robu koja je stigla. Android može odgoditi provjeru.', c.watch)}
    ${sw('watchMinus', 'Obavijesti za Minus listu', 'U istoj pozadinskoj provjeri uporedi Minus listu i javi kad se promijeni.', c.watchMinus)}
    <p class="set-note">Obavijest ne sadrži ime kupca, telefon ni broj narudžbe. Ne dolazi samo zato što je provjera uspjela, nego kad se stanje stvarno promijeni.</p>
    ${(c.watch || c.watchMinus) && (() => { try { return A.notifOk && A.notifOk() === false; } catch (e) { return false; } })() ? '<p class="set-note auto-note">Android trenutno ne dozvoljava obavijesti ovoj aplikaciji: Postavke telefona → Aplikacije → JYSK Reloaded → Obavijesti. Dok je tako, pozadinska provjera ništa ne čita.</p>' : ''}
  </div></section>

  <section class="set-block" data-grp="work"><h3>Narudžbe kupaca</h3><div class="set-card">
    <div class="set-row set-col"><div class="set-txt"><b>Koje narudžbe čitati</b><small>Manje kartica znači kraće čitanje. Završene narudžbe se nikad ne čitaju.</small></div>
      <div class="chips">${tabNames.map(([k, t]) => `<button class="chip" type="button" role="checkbox" aria-checked="${c.tabs[k]}" data-tab="${k}">${t}</button>`).join('')}</div></div>
    ${sw('name', 'Prikaži ime kupca', '', c.name)}
    ${sw('phone', 'Prikaži telefon kupca', '', c.phone)}
    ${choice('stale', 'Upozori da su podaci stari nakon', [[6, '6 h'], [12, '12 h'], [24, '24 h']], c.stale)}
    ${act('orders-refresh', 'Osvježi narudžbe sada', o ? `${orderWaiting.uniqueOrders(o.list).length} narudžbi, ${esc(ageText(o.at))}` : 'Još nisu učitane')}
    ${act('orders-clear', 'Obriši narudžbe s telefona', 'Imena, telefoni i artikli se brišu s ovog telefona', true)}
  </div></section>

  <section class="set-block" data-grp="work"><h3>Za rasprodaju</h3><div class="set-card">
    <div class="set-row set-col"><div class="set-txt"><b>Koji statusi</b><small>Artikli s ovim statusom koji su na zalihi u prodavnici (grupa Kućanstvo)</small></div>
      <div class="chips">${CLR_ST.map((k) => `<button class="chip" type="button" role="checkbox" aria-checked="${c.clr[k]}" data-cst="${k}">Status ${k}</button>`).join('')}</div></div>
    ${sw('noxmas', 'Sakrij božićne i novogodišnje artikle', 'Ne prikazuju se artikli kojima u nazivu piše neka od riječi ispod. Lista ih i dalje čita, pa se mogu vratiti.', c.noxmas)}
    ${c.noxmas ? `<div class="set-row set-col"><div class="set-txt"><b>Riječi za sakrivanje</b><small>Odvoji zarezom. Veliko ili malo slovo i č, ć, š, ž, đ nisu bitni, a riječ se traži na početku riječi u nazivu.</small></div>
      <input class="set-input" id="xmasWords" type="text" value="${esc(c.xmas)}" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="Riječi za sakrivanje"></div>` : ''}
    ${act('clear-refresh', 'Učitaj listu sada', clrSrc() && clrSrc().list ? `${clrView().list.length} artikala, ${esc(ageText(clrSrc().at))}` : 'Još nije učitana')}
    ${act('clear-clear', 'Obriši listu s telefona', '', true)}
  </div></section>

  ${mjOn() ? `<section class="set-block" data-grp="work"><h3>Vijesti (MYJYSK)</h3><div class="set-card">
    ${sw('mj', 'Svako jutro u 8:00', 'Zadaci i vijesti iz MYJYSK se sami učitaju, a obavijest dođe kad ima nešto novo. Android može pomjeriti za koju minutu. Radi dok si prijavljen u MYJYSK.', c.mj)}
    <div class="set-row set-col"><div class="set-txt"><b>Ja u MYJYSK</b><small>Ime i prezime ili broj, odvojeno zarezom. Zadaci na kojima piše ovo idu pod „Za mene“, kao i zadaci za Store Staff i sve uloge. Čuva se samo na ovom telefonu; ako je prazno, aplikacija ga jednom uzme iz StoreFronta.</small></div>
      <input class="set-input" id="mjMe" type="text" value="${esc(mjMe())}" autocapitalize="words" autocorrect="off" spellcheck="false" aria-label="Ja u MYJYSK"></div>
    ${act('mj-refresh', 'Osvježi sada', S.user.mj && S.user.mj.at ? `Stanje ${esc(ageText(S.user.mj.at))}` : 'Još nije učitano')}
  </div></section>

  <section class="set-block" data-grp="plans"><h3>Planogrami iz MYJYSK</h3><div class="set-card">
    ${choice('plSide', 'Strana trgovine', [['left', 'Lijeva'], ['right', 'Desna']], c.plSide)}
    ${sw('plCompact', 'SC 3.0 Compact trgovina', 'Uključi samo ako je trgovina Compact', c.plCompact)}
    ${planChips()}
    ${act('pl-check', 'Provjeri nove planograme', planCheckLine())}
    ${act('mj-clear', 'Obriši vijesti i zadatke s telefona', '', true)}
  </div></section>` : ''}

  <section class="set-block" data-grp="plans"><h3>Podaci na telefonu</h3><div class="set-card">
    ${act('plans', 'Planogrami', `${S.plans.length} na telefonu`)}
    ${act('welcome-setup', 'Izbor odjela i planograma', 'Ponovo otvori vodič za glavni i dodatne odjele')}
    ${act('recent', 'Obriši zadnje traženo', `${S.user.recent.length} artikala`, true)}
    ${act('learned', 'Zaboravi povezane barkodove', `${learned} povezanih`, true)}
    ${backupsOf().map((b) => act('restore:' + b.name, `Vrati kopiju ${b.name.startsWith('vraceno') ? 'od prije vraćanja' : 'od prije nadogradnje'}`, `${new Date(b.at).toLocaleString('bs-BA')} · ${b.files} datoteka. Planogrami i prijava ostaju. Dodirni dvaput.`, true)).join('')}
  </div></section>

  ${sandboxOn() ? `<section class="set-block" data-grp="work"><h3>TEST: simulacija slanja</h3><div class="set-card">
    <div class="set-row set-col"><div class="set-txt"><b>Ova verzija ništa ne šalje</b><small>Minus lista, Regulacija, SM/DM i AR se ne šalju u StoreFront ni MYJYSK. Čitanje radi normalno. Ovdje biraš kako se odigrano slanje završi.</small></div></div>
    ${SIMS.map(([k, label, sub]) => `<button class="set-row set-act" type="button" data-sim="${k}"><div class="set-txt"><b>${k === simNow() ? '● ' : ''}${esc(label)}</b><small>${esc(sub)}</small></div></button>`).join('')}
    <button class="set-row set-act" type="button" data-sim-reset><div class="set-txt"><b>Zaboravi odigrana slanja Minus liste</b><small>Samo u TEST verziji: briše oznake „urađeno“ i „Čeka Regulaciju“ u ovoj aplikaciji, da isti red možeš ponovo probati. Zapis zadnjeg slanja ostaje.</small></div></button>
  </div></section>` : ''}
  <div id="tmBlock" data-grp="privacy">${tmBlock()}</div>
  <section class="set-block" data-grp="privacy"><h3>Zapis na telefonu</h3><div class="set-card">
    ${act('diag-copy', 'Pregledaj dijagnostiku', 'Tehnički zapis ostaje na telefonu. Pregledaj ga prije eventualnog dijeljenja.')}
    ${sfFieldsRow()}
    ${(() => { const x = S.user.sfRefillFields; return `<div class="set-row set-col"><div class="set-txt"><b>Polja Punjenja u StoreFrontu</b><small>${x && x.f
      ? `Iz otvaranja ${esc(ageText(x.at))}. Samo putanje zahtjeva (cifre su 9) i nazivi polja, bez vrijednosti.</small><details class="sf-fields"><summary>Nazivi</summary><small>${esc(x.f)}</small></details>`
      : 'Pojavi se kad otvoriš Ostali alati → Punjenje → Otvori Punjenje u StoreFrontu i pregledaš listu. Samo nazivi, nikad šifre ni količine.</small>'}</div></div>`; })()}
  </div></section>
  <section class="set-block" data-grp="look"><h3>O aplikaciji</h3><div class="set-card">
    <div class="set-row"><div class="set-txt"><b>Jysk Reloaded</b><small>Verzija ${esc(A.version())}${(() => { const h = hotState(); return h && h.active ? ` · popravka ${esc(String(h.seq))}` : ''; })()} · ${esc(A.device())}</small></div></div>
    ${S.crash ? `<div class="set-row set-col"><div class="set-txt"><b>Zadnja greška</b><small class="crash">${esc(S.crash.slice(0, 700))}</small></div></div>${act('crash-clear', 'Obriši zapis o grešci', '')}` : ''}
    ${(() => { let ch = ''; try { ch = A.updateChannel ? A.updateChannel() : ''; } catch (e) { /* older shell */ } return `<div class="set-row"><div class="set-txt"><b>Kanal ažuriranja</b><small>${ch === 'test' ? 'TEST: samo TEST verzije ove aplikacije' : ch === 'prod' ? 'Prava aplikacija: samo njene verzije' : 'Ova verzija ne traži ažuriranja'}</small></div></div>`; })()}
    ${sw('upd', 'Provjeri nove verzije pri otvaranju', 'Aplikacija sama pogleda ima li nova verzija i ponudi je. Preuzima se tek kad tapneš „Preuzmi ažuriranje“.', c.upd)}
    ${S.updError ? `<div class="set-row set-col" role="status"><div class="set-txt"><b>Problem s ažuriranjem</b><small>${esc(S.updError)}</small></div></div>` : ''}
    ${S.update && S.update.state === 'ready' ? act('upd-install', `Instaliraj verziju ${esc(S.update.name || '')}`, 'Preuzeta i provjerena (SHA-256, isti potpis)')
      : S.update && S.update.state === 'downloading' ? `<div class="set-row"><div class="set-txt"><b>Preuzimam ${esc(S.update.name || '')}</b><small>${S.update.pct || 0}%</small></div></div>`
      : S.update && S.update.state === 'available' ? act('upd-get', `Preuzmi ažuriranje ${esc(S.update.name || '')}`, esc(String(S.update.notes || 'Nova verzija').slice(0, 400)))
      : act('upd-check', 'Provjeri nove verzije sada', '')}
    ${(() => { const h = hotState(); if (!h || !h.on) return ''; const a = h.active ? `Popravka ${esc(String(h.seq))}${h.notes ? ' · ' + esc(String(h.notes).split('\n')[0].slice(0, 120).replace(/[\s.]+$/, '')) : ''}` : 'Ugrađeni (iz instalirane verzije)';
      const st = h.stats || {};
      const tech = [`APK ${esc(A.version())} (${esc(String(h.code || ''))})`, h.active ? `paket ${esc(h.active)}` : 'bez paketa',
        st.lastDl ? `zadnje preuzimanje ${esc(new Date(st.lastDl).toLocaleString('bs-BA'))}` : '', st.act ? `primijenjeno ${esc(String(st.act))}` : '',
        st.rb ? `vraćeno ${esc(String(st.rb))}` : '', st.sigBad ? `pogrešan potpis ${esc(String(st.sigBad))}` : '', st.lastErr ? `zadnja greška: ${esc(st.lastErr)}` : ''].filter(Boolean).join(' · ');
      return `<div class="set-row"><div class="set-txt"><b>Ekrani aplikacije</b><small>${a}. Nove popravke ekrana stižu bez instalacije, potpisane istim ključem kao aplikacija, i primjenjuju se same na početnom ekranu kad ništa ne radiš, nikad usred posla.</small><small class="hot-tech">${tech}</small></div></div>`
        + (hotWaiting() ? act('hot-apply', 'Primijeni novu popravku sada', 'Početni ekran se ponovo učita za sekundu (posao u toku se ne prekida)') : '')
        + (h.active ? act('hot-reset', 'Vrati ugrađene ekrane', 'Ova popravka se više ne uzima; sljedeća nova hoće') : ''); })()}
  </div></section>`;
  settingsGroups(c, o, learned);
  if (tmStatus()) setTimeout(() => tmRefresh(), 0); // follows a waiting test event / registration on screen
}

// 1.81 telemetry pilot (telemetry/CLAUDE-CODE-ANDROID.md): Postavke → Dijagnostika. Only in a build made with
// TELEMETRY=1; elsewhere A.telemetryStatus says enabled:false and nothing is shown. Only a synthetic test event is
// sent; the real diagnostics (diag.log) stay on the phone.
const tmStatus = () => { try { return A.telemetryStatus ? JSON.parse(A.telemetryStatus()) : null; } catch (e) { return null; } };
const tmTime = (ms) => { const d = new Date(ms); return `${d.getDate()}.${d.getMonth() + 1}. u ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`; };
const tmRow = (title, sub) => `<div class="set-row set-col"><div class="set-txt"><b>${title}</b>${sub ? `<small>${sub}</small>` : ''}</div></div>`;
// 15. 11. 2026: the automatic sending in one word; a refused or expired batch has its own row (never hidden)
function tmSendState(t) {
  if (t.dgPending && t.dg === 'sending') return 'slanje u toku';
  if (t.dgPending && !t.online) return 'čeka internet';
  if (t.dgPending) return 'čeka slanje';
  if (t.dgErrorsWaiting) return 'čeka kraj sata';
  return 'nema događaja za slanje';
}
const TM_OP = { stockbatch: 'zalihe planograma', pricebatch: 'cijene planograma', plan: 'planogram', top: 'najprodavanije', sales: 'prodaja', soon: 'uskoro',
  find: 'pretraga artikla', eans: 'barkodovi', hier: 'odjeli', groups: 'grupe', relatedstock: 'povezane šifre', pics: 'slike', me: 'prijava', ping: 'veza',
  article: 'artikal', audit: 'provjera statusa (SM/DM)', lookup: 'traženje šifre', oopusfind: 'OOPUS pretraga', oopuslist: 'OOPUS lista',
  oopusorder: 'OOPUS narudžba', refillcheck: 'Punjenje provjera', refillinfo: 'Punjenje podaci', refillitems: 'Punjenje lista', refilllists: 'Punjenje liste',
  smdm: 'SM/DM', smread: 'SM/DM čitanje', other: 'ostala čitanja', check: 'provjera', download: 'preuzimanje' };
const TM_OUT = { timeout: 'isteklo vrijeme', network: 'nema mreže', login: 'treba prijava', lost: 'odgovor izgubljen', offline_gave_up: 'odustao bez mreže',
  other: 'ostalo', need_login: 'treba prijava', auth_refused: 'prijava odbijena', wrong_host: 'drugi server', not_https: 'nije https', too_many_redirects: 'previše preusmjeravanja' };
/** "diag.storefront_job|find|timeout|0" -> "StoreFront · pretraga artikla · isteklo vrijeme" (closed words only). */
function tmErrWords(s) {
  const [type, op, out, http] = String(s).split('|');
  const area = type === 'diag.planogram_refresh' ? 'Provjera planograma' : 'StoreFront';
  return `${area} · ${TM_OP[op] || op} · ${out === 'http' ? `HTTP ${http}` : TM_OUT[out] || out}`;
}
const TM_LOCAL_ONLY = 'Ovaj zapis ostaje na telefonu i ne šalje se. Automatski se broje samo greške čitanja StoreFronta i provjere planograma; upisi (Minus, Regulacija, SM/DM, Punjenje, OOPUS predaja) nikad.';
const TM_WHAT = 'Tehnička dijagnostika bez imena i broja zaposlenika. Telefon nakon svakog sata u kojem je nešto zapelo pošalje samo brojeve: koja vrsta čitanja StoreFronta ili provjere planograma nije uspjela i zašto (npr. isteklo vrijeme, nema mreže, HTTP 503), koliko puta, verziju aplikacije i Androida. Server ovu instalaciju razlikuje po nasumičnom ključu koji telefon sam napravi (nije vezan za tvoje ime). Nikad se ne šalju: ime, broj zaposlenika, prodavnica, kupci, narudžbe, cijene, zalihe, adrese ni tekst grešaka. Šifra artikla ide samo kao par „barkod → šifra“ za zajedničku listu barkodova.';
// 2.05: sharing barcode links is its own choice: the diagnostics text promises that article numbers are never sent
const SHARE_WHAT = 'Kad povežeš barkod s artiklom, telefon pošalje samo par „barkod → šifra artikla“ (bez imena, broja zaposlenika i prodavnice). Server od parova svih telefona sastavi zajedničku listu: par koji je potvrdio StoreFront ide odmah, ručno povezan tek kad ga povežu dvije osobe. Zajedničku listu telefon preuzima i kad je ovo isključeno.';
// 2.08 (owner, 16. 11. 2026): no question in the middle of work any more; sharing is switched on or off only in
// Postavke → Dijagnostika, and Java keeps the choice (#22): it refuses and deletes queued links when it is off.
function syncShareCodes() {
  try { if (A.setShareCodes) A.setShareCodes(S.user.shareCodes === 'yes'); } catch (e) { /* older shell */ }
}
function tmBlock() {
  const t = tmStatus();
  if (!t || !t.enabled) return '';
  const on = t.consent === 'yes';
  const REG = { none: 'registrujem telefon…', unknown: 'registrujem telefon…', pending: 'čeka odobrenje (dnevna granica novih telefona); šalje se samo kad bude odobren', active: 'telefon je prijavljen', revoked: 'ovaj telefon je isključen sa servera' };
  let diag;
  if (!on) {
    diag = `${tmRow('Slanje dijagnostike: isključeno', TM_WHAT)}
    ${act('tm-consent-yes', 'Uključi dijagnostiku', 'Telefon se sam prijavi; ništa drugo ne treba')}
`;
  } else {
    // three separate answers (owner, 13. 11.): is sending on, is something waiting, when did Cloudflare last confirm
    const reg = [t.regBusy ? 'registrujem telefon…' : (REG[t.reg] || esc(t.reg || '')),
      t.regError && t.reg !== 'active' ? `Zadnji pokušaj prijave: ${esc(t.regError)}` : ''].filter(Boolean).join('<br>');
    // 15. 11. 2026 (owner): one precise word for the automatic sending, never a green "nothing" that hides a refusal
    const sendState = tmSendState(t);
    const wait = [
      t.dgPending ? `Paket od ${t.dgPendingN || '?'} stavki${t.dgError ? ` · zadnji pokušaj: ${esc(t.dgError)}` : ''}${t.dgNext > Date.now() ? ` · sljedeći pokušaj oko ${tmTime(t.dgNext)}` : ''}` : '',
      t.dgErrorsWaiting ? `Zabilježeno ${t.dgErrorsWaiting} grešaka i ${t.dgOkWaiting} uspješnih; šalje se nakon kraja sata` : '',
    ].filter(Boolean).join('<br>');
    const ack = t.dgAckAt
      ? `Telefon: ${tmTime(t.dgAckAt)}${t.dgAckReceived ? ` · Cloudflare: ${tmTime(t.dgAckReceived * 1000)}` : ''}<br>${t.dgAckAccepted} stavki primljeno${t.dgAckDuplicates ? `, ${t.dgAckDuplicates} već ranije` : ''}${t.dgAckBatch ? ` · paket ${esc(t.dgAckBatch)}` : ''}<br>Sati bez greške ne šalju paket: ovaj datum se zato može dugo ne mijenjati.`
      : 'Još nijedan. Šalje se samo nakon sata u kojem je nešto zapelo; sat bez greške ne šalje ništa.';
    // a batch that ended without Cloudflare's confirmation (refused, too old, held) is said, with its time
    const notSent = !t.dgPending && ['failed', 'expired', 'held'].includes(t.dg)
      ? `${t.dg === 'held' ? 'Zadržan' : 'Nije poslan'}${t.dgDoneAt ? ` ${tmTime(t.dgDoneAt)}` : ''}: ${esc(t.dgError || 'nepoznat razlog')}${t.dg === 'failed' ? '. Paket je odbačen i ne šalje se ponovo.' : t.dg === 'held' ? '. Šalje se kad telefon bude prijavljen.' : ''}` : '';
    const dropped = t.dgDropped ? `${t.dgDropped} ${t.dgDropped === 1 ? 'greška nije poslana' : 'grešaka nije poslano'}: telefon više od 48 h nije mogao slati${t.dgDroppedAt ? ` (${tmTime(t.dgDroppedAt)})` : ''}.` : '';
    // what went into the automatic count last (closed words from Telemetry.count)
    const counted = 'dgLastErr' in t ? (t.dgLastErr ? `${tmTime(t.dgLastErrAt)} · ${esc(tmErrWords(t.dgLastErr))}` : 'Nijedna otkad je ova verzija instalirana.') : '';
    // 1.97: the last error the phone noted itself (flow log): it stays on the phone and is never sent
    const lastErr = flow.list(true)[0];
    const lastLocal = `${lastErr ? esc(flow.line(lastErr)) : 'Nema zabilježenih grešaka.'}<br>${TM_LOCAL_ONLY}`;
    diag = `${tmRow('Slanje dijagnostike: uključeno', reg)}
    ${tmRow(`Automatsko slanje: ${sendState}`, wait)}
    ${notSent || dropped ? tmRow('Zadnji automatski paket nije potvrđen', [notSent, dropped].filter(Boolean).join('<br>')) : ''}
    ${tmRow('Zadnji automatski paket koji je Cloudflare potvrdio', ack)}
    ${counted ? tmRow('Zadnja greška u automatskom brojanju', counted) : ''}
    ${tmRow('Zadnja greška zabilježena na telefonu', lastLocal)}
    ${tmRow(`Dijeljenje barkodova s kolegama: ${S.user.shareCodes === 'yes' ? 'uključeno' : 'isključeno'}`, SHARE_WHAT)}
    ${act('share-codes', S.user.shareCodes === 'yes' ? 'Isključi dijeljenje barkodova' : 'Uključi dijeljenje barkodova', 'Zajedničku listu telefon preuzima uvijek')}
    ${act('tm-consent-no', 'Isključi dijagnostiku', 'Brojevi koji još nisu poslani se brišu s telefona')}`;
  }
  // the test event of the pilot (owner): unchanged, only when this phone already has a key
  let ev = '';
  if (t.key) {
    let s = 'Još nije poslan';
    if (t.obPending && t.ob === 'sending') s = 'Šaljem…';
    else if (t.obPending) s = `Čeka slanje${t.obError ? ` (${esc(t.obError)})` : ''}`;
    else if (t.ob === 'acked') s = `Potvrđeno ${tmTime(t.ackAt)}`;
    else if (t.ob === 'failed' || t.ob === 'expired') s = `Nije poslano: ${esc(t.obError)}`;
    ev = `${tmRow(`Ručni probni događaj: ${s}`, `Nije dio automatske dijagnostike.${t.fingerprint ? ` Ključ ovog telefona: ${esc(t.fingerprint)}` : ''}`)}
    ${t.reg === 'active' ? act('tm-send', 'Pošalji probni događaj', 'Jedan sintetički događaj; „Potvrđeno“ tek nakon provjerene potvrde servera') : ''}`;
  }
  return `<section class="set-block"><h3>Dijagnostika</h3><div class="set-card">
    ${diag}
    ${ev}
    ${tmRow('Zapis na telefonu se ne šalje', '„Pregledaj dijagnostiku“ ostaje na telefonu; šalju se samo gore navedeni brojevi.')}
  </div></section>`;
}
// 2.09 (owner, 16. 11. 2026): JYSK allows sharing barcode links between phones and sending technical diagnostics, so
// both are ON by default (no question). The employee is told once what is sent (a notice with "U redu" / "Isključi")
// and can switch either off in Postavke → Dijagnostika; that choice is kept (S.user.tmOff / S.user.shareOff) and the
// app never switches it back on by itself.
const AUTO_NOTICE = 1;
function tmAutoOn(tries = 0) {
  const t = tmStatus();
  if (!t || !t.enabled) return;
  if (!S.user.tmOff && t.consent !== 'yes') { try { A.telemetryConsent(true); } catch (e) { /* older shell */ } }
  if (!S.user.shareOff && S.user.shareCodes !== 'yes') { S.user.shareCodes = 'yes'; saveUser(); syncShareCodes(); }
  if ((S.user.tmNotice || 0) >= AUTO_NOTICE || tries > 180) return; // the notice: once, up to ~1 h after start
  const free = top().id === 'home' && $('#gate').hidden && $('#sheet').hidden;
  if (!free) { setTimeout(() => tmAutoOn(tries + 1), 20000); return; }
  const seen = () => { S.user.tmNotice = AUTO_NOTICE; saveUser(); };
  openSheet({
    title: 'Tehnička dijagnostika i barkodovi',
    body: `<p>${TM_WHAT}</p><p>${SHARE_WHAT}</p><p class="hint">Oboje je uključeno. Možeš isključiti ovdje ili kasnije u Postavke → Dijagnostika.</p>`,
    actions: [
      { label: 'U redu', kind: 'btn-primary', onClick: () => { seen(); closeSheet(); } },
      { label: 'Isključi', kind: 'btn-quiet', onClick: () => { tmSwitchOff(); seen(); closeSheet(); toast('Dijagnostika i dijeljenje barkodova su isključeni.'); } },
    ],
  });
}
/** The employee's own "off": kept, never switched on again by the app. */
function tmSwitchOff() {
  try { A.telemetryConsent(false); } catch (e) { /* older shell */ }
  S.user.tmOff = true; S.user.shareOff = true; S.user.shareCodes = 'no';
  saveUser(); syncShareCodes();
}
let tmTimer = 0;
function tmRefresh(forMs = 0) {
  if (forMs) S.tmUntil = Date.now() + forMs;
  clearTimeout(tmTimer);
  const el = document.getElementById('tmBlock');
  if (!el || top().id !== 'settings') return;
  el.innerHTML = tmBlock();
  const t = tmStatus();
  const busy = t && t.enabled && (t.regBusy || t.obPending || t.dgPending);
  if (busy || Date.now() < (S.tmUntil || 0)) tmTimer = setTimeout(() => tmRefresh(), 2000);
}

// test builds only (Sandbox): how a played Minus/Regulacija sending ends
const sandboxOn = () => { try { return !!(A.sandbox && A.sandbox()); } catch (e) { return false; } };
const simNow = () => { try { return (A.sim && A.sim()) || 'ok'; } catch (e) { return 'ok'; } };
const SIMS = [
  ['ok', 'Uspjeh', 'Oba koraka prihvaćena → Potvrđeno'],
  ['drop-minus', 'Pad mreže na Minus listi', 'Odgovor ne stigne → Ishod nepoznat'],
  ['drop-adjust', 'Pad mreže na Regulaciji', 'Minus prihvaćen, Regulacija bez odgovora → Ishod nepoznat'],
  ['500-minus', 'Greška servera na Minus listi', '→ Ishod nepoznat'],
  ['422-adjust', 'Regulacija odbijena (HTTP 422)', '→ Ishod nepoznat: 422 se ne smatra sigurnim odbijanjem'],
  ['auth', 'Pogrešna lozinka', '→ Neuspjelo, ništa nije promijenjeno'],
  ['hang-minus', 'Bez odgovora na Minus listi', 'Za test zatvaranja aplikacije; nakon 2 min → Ishod nepoznat'],
  ['hang-adjust', 'Bez odgovora na Regulaciji', 'Za test zatvaranja aplikacije; nakon 2 min → Ishod nepoznat'],
  ['slow', 'Sporo (15 s po koraku)', 'Za test zatvaranja ili isključenja interneta usred slanja'],
];

/** Copies of the records the phone made before an update (newest first). */
const backupsOf = () => { try { return JSON.parse((A.backups && A.backups()) || '[]'); } catch (e) { return []; } };

function onSettingsClick(t) {
  if (t.dataset.act && t.dataset.act.startsWith('restore:')) {
    const name = t.dataset.act.slice(8);
    if (S.restoreArmed !== name) { S.restoreArmed = name; toast('Dodirni još jednom za vraćanje kopije. Sadašnji podaci se prvo sačuvaju.'); setTimeout(() => { S.restoreArmed = null; }, 5000); return; }
    S.restoreArmed = null;
    let ok = false;
    try { ok = !!A.restoreBackup(name); } catch (e) { ok = false; }
    toast(ok ? 'Kopija vraćena. Učitavam…' : 'Vraćanje nije uspjelo. Podaci od prije pokušaja su sačuvani kao nova kopija ovdje.');
    return;
  }
  if ('simReset' in t.dataset && sandboxOn()) { S.user.minusDone = {}; S.user.minusPending = []; S.legacyCheck = null; saveUser(); renderMinusBar(); toast('TEST: oznake Minus liste su obrisane.'); return; }
  if (t.dataset.sim) { try { A.setSim(t.dataset.sim); } catch (e) { /* not a test build */ } renderSettings(); toast('Simulacija: ' + (SIMS.find((x) => x[0] === t.dataset.sim) || [])[1]); return; }
  if (t.dataset.set) {
    const k = t.dataset.set;
    setCfg({ [k]: !cfg()[k] });
    if (k === 'watch') syncWatch(true);
    if (k === 'watchMinus') syncWatchMinus(true);
    if ((k === 'autoOrders' || k === 'autoMinus') && autoSync) autoSync.wake('resume');
    if (k === 'mj') syncMyjysk(true);
  } else if (t.dataset.choice) {
    const k = t.dataset.choice;
    setCfg({ [k]: k === 'stale' ? +t.dataset.v : t.dataset.v });
    if (k === 'theme') applyTheme();
  } else if (t.dataset.cst) {
    const clr = { ...cfg().clr, [t.dataset.cst]: !cfg().clr[t.dataset.cst] };
    if (!Object.values(clr).some(Boolean)) { toast('Bar jedan status mora biti uključen.'); return; }
    setCfg({ clr });
  } else if (t.dataset.tab) {
    const tabs = { ...cfg().tabs, [t.dataset.tab]: !cfg().tabs[t.dataset.tab] };
    if (!Object.values(tabs).some(Boolean)) { toast('Bar jedna kartica mora biti uključena.'); return; }
    setCfg({ tabs });
  } else if (t.dataset.act) {
    const a = t.dataset.act;
    if (a === 'tm-consent-yes') { S.user.tmOff = false; saveUser(); try { A.telemetryConsent(true); } catch (e) { /* older shell */ } toast('Dijagnostika je uključena.'); tmRefresh(20000); return; }
    if (a === 'share-codes') { S.user.shareCodes = S.user.shareCodes === 'yes' ? 'no' : 'yes'; S.user.shareOff = S.user.shareCodes !== 'yes'; saveUser(); syncShareCodes(); toast(S.user.shareCodes === 'yes' ? 'Barkodovi koje povežeš idu u zajedničku listu.' : 'Barkodovi se više ne dijele.'); tmRefresh(); return; }
    if (a === 'tm-consent-no') { S.user.tmOff = true; saveUser(); try { A.telemetryConsent(false); } catch (e) { /* older shell */ } tmRefresh(); return; }
    if (a === 'tm-register') { try { A.telemetryRegister(); } catch (e) { /* older shell */ } toast('Šaljem zahtjev serveru…'); tmRefresh(20000); return; }
    if (a === 'tm-send') {
      let fresh = false;
      try { fresh = !!A.telemetrySendTest(); } catch (e) { fresh = false; }
      toast(fresh ? 'Probni događaj je spremljen i šalje se.' : 'Isti probni događaj se šalje ponovo.');
      tmRefresh(30000);
      return;
    }
    if (a === 'plans') { renderPlans(); go('plans'); return; }
    if (a === 'orders-refresh') { refreshOrders(); return; }
    if (a === 'clear-refresh') { refreshClearance(); return; }
    if (a === 'mj-refresh') { refreshMyjysk(false); toast('Učitavam iz MYJYSK…'); return; }
    if (a === 'pl-check') { checkPlans(); return; }
    if (a === 'welcome-setup') { if (welcomeSetup) welcomeSetup.start(true); return; }
    if (a === 'login-set') { S.loginWait = true; A.plansLogin(''); return; }
    if (a === 'login-forget') { try { A.plansLogout(); } catch (e) { /* older shell */ } toast('Korisničko ime i lozinka su obrisani s telefona.'); }
    if (a === 'diag-copy') {
      let log = '';
      try { log = A.readText('diag.log') || ''; } catch (e) { log = ''; }
      let mem = '';
      try { mem = A.memInfo ? A.memInfo() : ''; } catch (e) { mem = ''; }
      const ed = eanStore();
      const asked = Object.keys(ed.done).length;
      const withE = new Set(Object.values(ed.m));
      const noEan = Object.keys(ed.done).filter((n) => !withE.has(n)).length;
      const head = `Jysk Reloaded ${A.version ? A.version() : ''}\n${mem ? `memorija sada: ${mem}\n` : ''}planograma ${S.plans.length}, artikala ${S.index ? S.index.byNum.size : 0}, barkodova ${Object.keys(ed.m).length} (pitano artikala ${asked}, s barkodom ${withE.size}, bez barkoda ${noEan})${ed.sync ? `, prvo učitavanje barkodova ${ed.sync.work != null ? `${Math.round(ed.sync.work / 1000)} s rada, ` : ''}${Math.round(ed.sync.ms / 1000)} s od početka, ${ed.sync.jobs} poslova, ${ed.sync.n} artikala` : ''}\n`;
      const text = head + (log ? log.split('\n').slice(-120).join('\n') : '(nema zapisa)');
      openFlowView(text);
      return;
      // No automatic upload and no clipboard copy until the employee sees the log.
      // Arbitrary exception text can still contain information unknown to our sanitizer.
      openSheet({
        title: 'Dijagnostika',
        body: `<p class="hint">Zapis ostaje na telefonu. Prije dijeljenja pregledaj sadržaj i ukloni sve što ne želiš otkriti. Nema automatskog slanja na internet.</p><pre class="diag-text">${esc(text)}</pre>`,
        actions: [
          { label: 'Kopiraj nakon pregleda', onClick: () => {
            let copied = false;
            try { copied = !!(A.copyLong && A.copyLong(text)); } catch (e) { copied = false; }
            toast(copied ? 'Dijagnostika je kopirana.' : 'Kopiranje nije uspjelo.', 4200);
            closeSheet();
          } },
          { label: 'Zatvori', onClick: closeSheet }
        ]
      });
      return;
    }
    if (a === 'mj-clear') { S.user.mj = null; saveUser(); store.remove(MJ_FILE); toast('Vijesti i zadaci su obrisani s telefona.'); }
    if (a === 'clear-clear') { S.user.clear = null; S.user.clr2 = null; saveUser(); toast('Lista je obrisana s telefona.'); }
    if (a === 'crash-clear') { try { A.clearCrash(); } catch (e) { /* ignore */ } S.crash = ''; }
    if (a === 'upd-check') { checkUpdate(true); toast('Tražim novu verziju…'); return; }
    if (a === 'upd-install') { installUpdate(); return; }
    if (a === 'upd-get') { getUpdate(); return; }
    if (a === 'hot-apply') { applyHot('manual'); return; }
    if (a === 'hot-reset') {
      openSheet({ title: 'Vrati ugrađene ekrane?', body: '<p>Aplikacija koristi ekrane iz instalirane verzije: odmah ako ništa ne radi, inače čim se posao u toku završi ili pri sljedećem otvaranju. Ova popravka se više ne uzima; sljedeća nova hoće.</p>', actions: [
        { label: 'Vrati ugrađene', onClick: () => { closeSheet(); try { A.hotReset(); } catch (e) { /* older shell */ } S.hot = null; renderHot(); applyHot('reset'); } },
        { label: 'Odustani', onClick: closeSheet }
      ] });
      return;
    }
    if (a === 'hosts-set') { openHosts(); return; }
    if (a === 'orders-clear') { S.user.orders = null; saveUser(); toast('Narudžbe su obrisane s telefona.'); }
    if (a === 'recent') { S.user.recent = []; saveUser(); toast('Zadnje traženo je obrisano.'); }
    if (a === 'learned') { S.user.learned = {}; saveUser(); toast('Povezani barkodovi su zaboravljeni.'); }
    // 2.08 (security review): signing out also deletes the customer orders (names, phones, notes) kept on the phone;
    // they are read again after the next sign-in
    // 2.15 audit: and nothing is read by itself any more (screen and background) until the next sign-in
    if (a === 'signout') { A.clearStorefront(); S.user.store = null; S.user.orders = null; S.user.subst = null; S.user.sfSignedOut = true; saveUser(); planogramStock.forget(); sfWhoAt = Date.now(); if (searchUi && searchUi.sfsForget) searchUi.sfsForget(); syncWatch(); syncWatchMinus(); toast('Odjavljen si iz StoreFronta. Narudžbe kupaca su obrisane s telefona.'); }
  }
  renderSettings();
  renderHome();
}

const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd');
const custName = (ord) => (cfg().name ? titleCase(ord.name) : `Narudžba ${ord.no.slice(-6)}`);
const telOf = (p) => String(p || '').replace(/[^\d+]/g, '');
const stBadge = (st) => (st === 'Otvoreno' ? '<span class="ol-st is-open">nije zaprimljeno</span>'
  : st === 'Djelomično' ? '<span class="ol-st is-open">djelimično zaprimljeno</span>'
  : st === 'Popunjeno' ? '<span class="ol-st is-ok">zaprimljeno</span>'
  : st === 'Završeno' ? '<span class="ol-st is-done">kupac preuzeo</span>' : st ? `<span class="ol-st">${esc(st)}</span>` : '');
const noteHtml = (ord) => (ord.note ? `<div class="ord-note"><span>Opis računa</span>${esc(ord.note)}</div>` : '');
const madeHtml = (ord) => {
  const { stamp, label } = orderTime.info(ord);
  return `<small class="ocard-made">${label}${stamp ? ' ' + esc(stamp.text) : ''}</small>`;
};
/** Owner, 13. 11. 2026: a code in Narudžbe opens that very article in StoreFront; the rest of the row does its own thing. */
const sfCode = (num) => `<button class="code-link sf-code" type="button" data-store="${esc(num)}" aria-label="Šifra ${esc(num)}: otvori u StoreFrontu">${esc(num)}${icon('link', 'sf-ico')}</button>`;
/** StoreFront 6.5.0 "Čeka se plaćanje": the order must be paid before it is handed out. */
const payChip = (ord) => (ord && ord.pay ? '<span class="ord-chip is-pay">Čeka plaćanje</span>' : '');
const orderSortHint = 'Najstarije kreirana narudžba prvo; zapisi bez tačnog vremena na kraju.';

// 2.09 (owner, 16. 11. 2026, design 3 "obojeni redovi"): every line of an order is a soft row coloured by its own
// StoreFront state (green: received, amber: waits for goods, grey: the customer took it), code and name on the left,
// quantity and state on the right; the scanned / searched article is outlined.
const olTone = (st) => (st === 'Popunjeno' ? 'is-ok' : st === 'Otvoreno' || st === 'Djelomično' ? 'is-wait' : st === 'Završeno' ? 'is-done' : '');
function olItem(it, isHit, scanned) {
  return `<li class="ol ${olTone(it.st)}${isHit ? ' is-hit' : ''}"><span class="ol-l">${scanned ? '<span class="ol-tag">Skenirano</span>' : ''}${sfCode(it.num)}<button class="ol-name" type="button" data-num="${esc(it.num)}">${esc(it.name || it.num)}</button></span><span class="ol-r">${it.qty > 0 ? `<b class="ol-q">${it.qty} kom</b>` : ''}${stBadge(it.st)}</span></li>`;
}
function orderCard(ord, hit) {
  const lines = (ord.items || []).map((it) => olItem(it, !!(hit && hit(it)))).join('');
  const r = rz.reservationOf(ord);
  return `<article class="ocard${r ? ' is-rz' : ''}">
    <div class="ocard-top"><b>${esc(custName(ord))}</b><span>${r ? '' : payChip(ord)}<button class="ord-chip ord-st" type="button" data-st-ord="${esc(ord.no)}" aria-label="${esc(ord.status || ord.tab)}: šta znači status">${esc(ord.status || ord.tab)}</button></span></div>
    ${ord.ph && cfg().phone ? `<a class="ord-tel" href="tel:${esc(telOf(ord.ph))}">${esc(ord.ph)}</a>` : ''}
    ${madeHtml(ord)}
    <small class="ocard-meta">${esc(ord.no.slice(-6))} · ${esc(ord.tab)}${ord.date ? ` · dostava ${esc(ord.date)}` : ''} · <b class="ocard-km">${esc(rz.money(rz.amountOf(ord)))}</b></small>
    ${rzRow(ord, r)}
    ${noteHtml(ord)}
    ${lines ? `<ul class="olines">${lines}</ul>` : ''}
  </article>`;
}

// 2.08: "Pregled" (layout A cards, default) or "Detaljno" (every line with its code, notes, phone)
const ordDetail = () => cfg().ordDetail === true;
const ordViewSwitch = () => `<div class="seg-mini" role="group" aria-label="Prikaz narudžbi"><button type="button" data-ovw="compact" aria-pressed="${!ordDetail()}">Pregled</button><button type="button" data-ovw="cards" aria-pressed="${ordDetail()}">Detaljno</button></div>`;

/**
 * Owner, 13. 11. 2026: in Narudžbe without a search the cards (Narudžbe kupaca, rasprodaja, Minus, Prijedlozi) come
 * first and the long "Čeka prijem robe" list after them; a search puts the customers right under the search box.
 * In Planogrami the cards stay under Zadnje traženo.
 */
function placeHomeBars(cardsFirst) {
  const bars = $('#homeBars');
  if (!bars) return;
  if (cardsFirst) { if (bars.nextElementSibling !== $('#results')) $('#results').before(bars); }
  else if (bars.previousElementSibling !== $('#recentWrap')) $('#recentWrap').after(bars);
}

// 2.08 (owner, phone 16. 11.): opening one order or article from the list showed the new, short content at the old
// scroll position of the long list (the WebView clamps it), so the screen landed "somewhere". Now the results start just
// under the top of the home screen's own scroller; a filter keeps its chip bar where the finger was (anchor), no jump.
function showResultsTop() {
  const sc = $('#home .scroll');
  const r = $('#results');
  if (!sc || !r) return;
  const y = r.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop - 8;
  sc.scrollTop = Math.max(0, y);
}
/** Re-renders the list keeping the element `sel` at the same place on the screen (falls back to the results' top). */
function keepAnchor(sel, render) {
  const sc = $('#home .scroll');
  const before = document.querySelector(sel);
  const top0 = before ? before.getBoundingClientRect().top : null;
  render();
  const after = document.querySelector(sel);
  if (sc && after && top0 != null) sc.scrollTop += after.getBoundingClientRect().top - top0;
}

/**
 * 2.15: the automatic look found something new: the screen is drawn again with the card that was at the top of the
 * screen at the same place (an open order, its details, the filter, the search and the bar stay as they were).
 */
function keepPlace(scroller, render) {
  const sc = $(scroller);
  const SEL = '[data-oq],[data-oc],[data-num]';
  let key = null, attr = '', top0 = 0;
  const y0 = sc ? sc.scrollTop : 0;
  if (sc) {
    const r0 = sc.getBoundingClientRect().top;
    for (const el of sc.querySelectorAll(SEL)) {
      const b = el.getBoundingClientRect();
      if (b.height && b.bottom > r0 + 1) { attr = ['data-oq', 'data-oc', 'data-num'].find((a) => el.hasAttribute(a)); key = el.getAttribute(attr); top0 = b.top; break; }
    }
  }
  render();
  if (!sc) return;
  const el = key != null ? [...sc.querySelectorAll(`[${attr}]`)].find((x) => x.getAttribute(attr) === key) : null;
  if (el) sc.scrollTop += el.getBoundingClientRect().top - top0;
  else sc.scrollTop = y0;
}
// 2.15 audit: on an article's screen only its customers' block (and the short line over the drawing) is drawn again:
// all of renderItem would draw the planogram again and renderMissing would ask StoreFront for the article again
function swapOrders(scroller, num) {
  keepPlace(scroller, () => {
    const box = $(scroller);
    if (!box) return;
    const hit = box.querySelector('.ord-hit');
    if (hit) { const h = ordersBlock(num); if (h) hit.outerHTML = h; else hit.remove(); }
    const hint = box.querySelector('.ord-hint');
    if (hint) { const h = ordersHint(num); if (h) hint.outerHTML = h; else hint.remove(); }
  });
}
function autoRedraw() {
  const t = top();
  if (t.id === 'home') keepPlace('#home .scroll', () => renderHome());
  else if (t.id === 'item' && S.item) swapOrders('#itemBody', S.item.num);
  else if (t.id === 'minus') keepPlace('#minusBody', () => renderMinus());
  // the article that is in no planogram on the phone shows its customers too
  else if (t.id === 'missing' && /^\d{7}$/.test(String(t.state || ''))) swapOrders('#missingBody', t.state);
}
/** Nothing new: only the age of the data (and why it is not newer) changes, nothing is drawn again. */
function autoAgeChanged() {
  const o = S.user.orders;
  for (const el of document.querySelectorAll('.ord-age')) if (o) el.textContent = ageText(o.at);
  for (const el of document.querySelectorAll('.auto-note')) el.textContent = autoSync ? autoSync.note(el.closest('#minusBody') ? 'minus' : 'orders') : '';
  const m = S.user.minus;
  for (const el of document.querySelectorAll('.min-age')) if (m) el.textContent = ageText(Math.max(m.at || 0, m.seen || 0));
  // the start screen's bars say the age too; their height may change, so the cards below keep their place
  if (top().id === 'home') keepPlace('#home .scroll', () => { renderOrdersBar(); renderMinusBar(); });
}

/** From an article's customers back to the list: same filter, order and place. */
function ordersBackToList() {
  const y = S.ordBack ? S.ordBack.scroll : 0;
  S.ordBack = null;
  $('#q').value = '';
  runOrdersSearch();
  const sc = $('#home .scroll');
  sc.scrollTop = y;
  requestAnimationFrame(() => { sc.scrollTop = y; });
}

function runOrdersSearch() {
  const q = $('#q').value.trim();
  if (!q) S.ordBack = null;
  placeHomeBars(!q);
  $('#clearQ').hidden = !q;
  const box = $('#results');
  box.hidden = false;
  $('#recentWrap').hidden = true;
  const o = S.user.orders;
  if (!o) { box.innerHTML = '<p class="empty">Narudžbe još nisu učitane. Tapni „Učitaj“ iznad.</p>'; return; }
  // 2.08: the list keeps at least one screen of height, so a short or empty group does not pull the chip bar away
  // (the WebView would clamp the scroll position to the shorter page: the "jump to the top")
  box.style.minHeight = '';
  if (!q && cfg().ordMain !== 'articles') { box.innerHTML = ordMainSwitch() + ordersByOrder(o); box.style.minHeight = `${$('#home .scroll').clientHeight}px`; return; }
  if (!q) {
    // owner, 13. 11. 2026: the articles customers wait for, in the chosen order, both numbers on each row (2.08: "Po artiklima")
    const only = cfg().ordWaitOnly !== false;
    const how = listSort();
    const arr = orderWaiting.sortArticles(orderWaiting.articles(o.list, { onlyWaiting: only }), how);
    const ST_WORD = { Otvoreno: 'nije zaprimljeno', Djelomično: 'djelimično zaprimljeno', Popunjeno: 'zaprimljeno', Završeno: 'preuzeto' };
    const times = o.list.map((x) => orderWaiting.timeOf(x));
    const trust = times.some((t) => t.tier === 0 && t.sure) ? '' : times.some((t) => t.tier === 0)
      ? 'Vremena su iz prve interne napomene: redoslijed po vremenu je približan.' : 'Narudžbe nemaju vrijeme: redoslijed po vremenu nije pouzdan.';
    const since = (e) => (e.oldest ? `<small class="ocard-made">Najranije čeka od ${esc(e.oldest.text)}${e.oldest.sure ? '' : e.oldest.tier === 0 ? ` (${esc(String(e.oldest.label || '').toLowerCase())}, približno)` : ' (samo datum)'}</small>` : '<small class="ocard-made">Vrijeme narudžbe nepoznato</small>');
    box.innerHTML = ordMainSwitch() + `<div class="ord-head"><p class="count-line">${only ? 'Čeka prijem robe' : 'Sve stavke narudžbi'}: ${arr.length ? artikala(arr.length) : 'ništa'}</p><button class="sort-btn" type="button" data-ordsort-open="list">Poredaj: ${esc(sortName(LIST_SORTS, how))}</button></div>`
      + `<div class="chips ord-filter"><button class="chip" type="button" role="checkbox" aria-checked="${only}" data-ordwait>Samo što još čeka</button></div>`
      + (arr.length && trust ? `<p class="ord-trust is-approx">${trust}</p>` : '')
      + (arr.length ? `<div class="list">${arr.map((e) => `<div class="item" role="button" tabindex="0" data-owait="${esc(e.num)}">
          <span class="item-main"><span class="item-name">${esc(e.name) || 'Bez naziva'}</span><span>${sfCode(e.num)}</span>
          <span class="pills"><span class="pill pill-order">${e.unsure ? 'do ' : ''}${komada(e.qty)} · ${narudzbi(e.n)}</span>${e.unsure ? '<span class="pill pill-muted">dio robe stigao: tačna količina nepoznata</span>' : ''}${e.orders.some((x) => x.ord.pay) ? `<span class="pill pill-warn">${e.orders.filter((x) => x.ord.pay).length} čeka plaćanje</span>` : ''}${only ? '' : Object.entries(e.st).map(([k, v]) => `<span class="pill pill-muted">${esc(ST_WORD[k] || k)} ${v}</span>`).join('')}</span>
          ${since(e)}</span>${icon('chev', 'chev')}</div>`).join('')}</div>` : '')
      + '<p class="empty">Ili upiši šifru artikla, ime kupca, telefon ili broj narudžbe.</p>';
    return;
  }
  const d = q.replace(/[\s/+()-]/g, '');
  const digits = /^\d{3,}$/.test(d);
  const toks = norm(q).split(/\s+/).filter(Boolean);
  const found = [];
  // 2.08: an order StoreFront shows in two tabs (Aktivan and Stigao) is one order, found once
  for (const ord of orderWaiting.uniqueOrders(o.list)) {
    let ok = false;
    if (digits) {
      ok = (ord.items || []).some((it) => (d.length >= 7 ? orderWaiting.numKey(it.num) === d.slice(0, 7) : orderWaiting.numKey(it.num).includes(d)))
        || ord.no.includes(d) || String(ord.ph || '').replace(/\D/g, '').includes(d);
    } else {
      const hay = norm(`${ord.name} ${ord.no} ${ord.note || ''} ${(ord.items || []).map((it) => it.name).join(' ')}`);
      ok = toks.every((t) => hay.includes(t));
    }
    if (ok) found.push(ord);
  }
  if (!found.length) { box.innerHTML = `<p class="empty">Nema narudžbi za „${esc(q)}“ (stanje ${esc(ageText(o.at))}).</p>`; return; }
  const exact = digits && d.length >= 7 ? d.slice(0, 7) : '';
  if (exact) {
    // one row per order in the chosen order of customers (not the article list's order)
    const pos = new Map(custRowsOf(exact).map((r, i) => [r.ord.no, i]));
    found.sort((a, b) => (pos.has(a.no) ? pos.get(a.no) : 1e9) - (pos.has(b.no) ? pos.get(b.no) : 1e9));
  }
  // "Samo što još čeka": the customers who still wait are counted and ranked; the others follow, marked
  const onlyW = !!exact && cfg().ordWaitOnly !== false;
  const waitRows = exact ? custRowsOf(exact, onlyW) : [];
  const waitNo = new Set(waitRows.map((r) => r.ord.no));
  if (onlyW) found.sort((a, b) => (waitNo.has(a.no) ? 0 : 1) - (waitNo.has(b.no) ? 0 : 1));
  const hit = exact ? (it) => orderWaiting.sameNum(it.num, exact) : digits ? (it) => orderWaiting.numKey(it.num).includes(d) : (it) => toks.some((t) => norm(it.name).includes(t));
  let head = `${found.length} ${plural(found.length, 'narudžba', 'narudžbe', 'narudžbi')}`;
  if (exact) {
    const qty = waitRows.reduce((n, r) => n + r.qty, 0);
    const upTo = waitRows.some((r) => r.unsure) ? 'do ' : '';
    const nm = (found[0].items || []).find((it) => orderWaiting.sameNum(it.num, exact));
    const rest = found.length - waitRows.length;
    head = `Artikal ${exact}${nm && nm.name ? ` · ${esc(nm.name)}` : ''}<br>${onlyW ? `Čeka: ${upTo}${komada(qty)} · ${narudzbi(waitRows.length)}${rest ? ` (još ${rest} zaprimljeno ili preuzeto)` : ''}` : `${komada(qty)} · ${head}`}`;
  }
  // a search for one order number shows that order in full, whatever the view
  const compact = !ordDetail() && !(found.length === 1 && found[0].no.includes(d) && digits);
  const max = compact ? 150 : 40;
  const backBtn = S.ordBack ? `<button class="text-btn ord-back" type="button" data-ord-back>‹ ${cfg().ordMain === 'articles' ? 'Svi artikli' : 'Sve narudžbe'}</button>` : '';
  box.innerHTML = `${backBtn}<div class="ord-head"><p class="count-line">${head}${found.length > max ? ` (prikazano prvih ${max})` : ''} · stanje <span class="ord-age">${esc(ageText(o.at))}</span><span class="auto-note">${esc(autoSync ? autoSync.note('orders') : '')}</span></p>${ordViewSwitch()}</div>`
    + (exact && waitRows.length > 1 ? custSortBar(exact, onlyW) : !exact && found.length > 1 ? `<p class="count-line">${orderSortHint}</p>` : '')
    + (exact && waitRows.length ? `<ol class="ord-who">${waitRows.map((r) => `<li><b>${esc(custName(r.ord))}</b> – ${r.unsure ? `do ${r.qty} kom (dio stigao)` : `${r.qty} kom`}${r.ord.pay ? ' <span class="ord-chip is-pay">Čeka plaćanje</span>' : ''}</li>`).join('')}</ol>` : '')
    + found.slice(0, max).map((ord) => (compact ? ocOrderCard(ord, hit) : orderCard(ord, hit))).join('');
}

function setMode(m) {
  if (S.mode === 'news' && m !== 'news') seenNews();
  // 25. 11. 2026 (owner): back in Narudžbe the list is where it was (filters are kept in the settings)
  const sc = $('#home .scroll');
  const was = S.mode;
  if (was === 'orders' && m !== 'orders' && sc) S.ordScroll = $('#q').value.trim() ? (S.ordBack ? S.ordBack.scroll : 0) : sc.scrollTop;
  S.mode = m;
  if (m === 'sf') warmStore(true); // 2.17: the StoreFront page is ready by the time the first word is typed
  $('#results').style.minHeight = ''; // 2.08: only the Narudžbe list keeps a screen of height
  $('#q').value = '';
  renderHome();
  if (m === 'orders' && was !== 'orders' && sc && S.ordScroll > 0) {
    const y = S.ordScroll;
    sc.scrollTop = y;
    // a code scanned meanwhile opens its order (handleCode fills the search after this): that one starts at the top
    requestAnimationFrame(() => { if (!$('#q').value.trim()) sc.scrollTop = y; });
  }
  if (m === 'news') freshenMyjysk();
  if (m === 'orders' && autoSync) autoSync.wake('open-orders');
}

function refreshOrders() {
  // orders with open lines are read again: goods may have been received since
  const known = ((S.user.orders && S.user.orders.list) || [])
    .filter((x) => x.items && x.items.length && x.ph !== undefined && x.items.every((i) => i.st === 'Popunjeno')).map((x) => x.no);
  const t = cfg().tabs;
  if (autoSync) autoSync.manualOrders();
  S.ordReading = true;
  A.orders(JSON.stringify(known), JSON.stringify(['Ispunjen', 'Stigao', 'Zakasnio', 'Aktivan'].filter((k) => t[k])));
}

const TABS_ALL = ['Aktivan', 'Zakasnio', 'Stigao', 'Ispunjen'];
// how many orders StoreFront shows in a tab: an order is in several tabs at once (Aktivan holds every open one)
const inTab = (list, k) => list.filter((x) => (Array.isArray(x.tabs) && x.tabs.length ? x.tabs : [x.tab]).includes(k)).length;
// numbers of the last full read, for the enabled tabs: "Aktivan:92,Stigao:45"
const baseCounts = () => {
  const o = S.user.orders;
  if (!o) return '';
  const t = cfg().tabs;
  // 2.15: StoreFront's own totals when the app has them (the background look reads the same totals)
  return TABS_ALL.filter((k) => t[k]).map((k) => `${k}:${o.tot && typeof o.tot[k] === 'number' ? o.tot[k] : inTab(o.list, k)}`).join(',');
};
const syncWatch = (ask) => { try { if (A.watch) A.watch(!!cfg().watch, watchBase(baseCounts(), S.user.orders && S.user.orders.store), !!ask); } catch (e) { /* ignore */ } };
// 2.15: the minus list's mark for the background look (count:hash, js/auto-sync.js minusSig)
// 2.15 audit: "store|count:hash" (OrderWatch says nothing for another store); nothing after a sign-out
const watchBase = (b, store) => (b && store && !S.user.sfSignedOut ? `${store}|${b}` : '');
const syncWatchMinus = (ask) => { try { const m = S.user.minus; if (A.watchMinus) A.watchMinus(!!cfg().watchMinus, m && m.items ? watchBase(minusSig(m.items, m.total), m.store) : '', !!ask); } catch (e) { /* older shell */ } };
// what StoreFront shows now against what was read: [['Aktivan', +3], ...]
function siteDiff() {
  const o = S.user.orders;
  if (!o || !S.site) return [];
  const t = cfg().tabs;
  return TABS_ALL.filter((k) => t[k] && S.site[k] != null)
    // 2.15 (emulator, owner's store 18. 11.): StoreFront counts ROWS of a tab (an order with two delivery groups is two),
    // the list holds each order once: compared with StoreFront's own totals of the last reading when the app has them
    .map((k) => [k, S.site[k] - (o.tot && typeof o.tot[k] === 'number' ? o.tot[k] : inTab(o.list, k))]).filter((x) => x[1] !== 0);
}

function renderOrdersBar() {
  const b = $('#ordersBar');
  // customer orders come from StoreFront: they work without any planogram on the phone
  // 2.23 (owner 22. 11.): an automatic refresh repaints this card; under Vijesti it stays hidden
  const has = (S.plans.length > 0 || S.mode === 'orders') && S.mode !== 'news';
  b.hidden = !has;
  if (!has) return;
  const o = S.user.orders;
  const ic = icon('info');
  if (!o) {
    b.innerHTML = `${ic}<span><b>Narudžbe kupaca</b><small>Učitaj iz StoreFronta, pa Jysk Reloaded javi kad je artikal naručen</small></span><span class="go">Učitaj</span>`;
  } else {
    const c = (t) => inTab(o.list, t);
    const df = siteDiff();
    if (df.length) {
      b.innerHTML = `${ic}<span><b>Na StoreFrontu ima promjena</b><small>${df.map(([k, n]) => `${k} ${n > 0 ? '+' : ''}${n}`).join(', ')} · ${esc(ageText(o.at))}</small></span><span class="go">Osvježi</span>`;
      return;
    }
    b.innerHTML = `${ic}<span><b>Narudžbe kupaca: ${orderWaiting.uniqueOrders(o.list).length}</b><small>Aktivan ${c('Aktivan')}, Zakasnio ${c('Zakasnio')}, Stigao ${c('Stigao')}, Ispunjen ${c('Ispunjen')} · ${esc(ageText(o.at))}</small></span><span class="go">Osvježi</span>`;
  }
}

function itemRow(num, { attr = 'data-num', sub = '' } = {}) {
  const locs = locationsOf(num);
  const first = locs[0];
  return `<button class="item" type="button" ${attr}="${esc(num)}">
    ${thumb(num)}
    <span class="item-main">
      <span class="code">${esc(num)}</span>
      <span class="item-name">${esc(nameOf(num)) || 'Bez naziva'}</span>
      ${first ? pills(first.place, first.row, locs.length - 1) : ''}
      ${ordersOf(num).length ? '<span class="pills"><span class="pill pill-order">Naručio kupac</span></span>' : ''}
      ${sub}
    </span>
    ${icon('chev', 'chev')}
  </button>`;
}


const NEWS_SHOWN = 12;
// ------------------------------------------------------- Vijesti (MYJYSK)
const MJ_FILE = 'myjysk-in.json'; // the last read, also written by the 8:00 job of the phone
const mjOn = () => { try { return !!(A.myjyskOn && A.myjyskOn()); } catch (e) { return false; } };
// created just before boot() (everything it uses exists by then): js/myjysk-ui.js; these forward to it
let myjyskUi = null;
function freshenMyjysk(...a) { return myjyskUi.freshenMyjysk(...a); }
function mjMe(...a) { return myjyskUi.mjMe(...a); }
function newsRow(...a) { return myjyskUi.newsRow(...a); }
function newsWaiting(...a) { return myjyskUi.newsWaiting(...a); }
function pickupMyjysk(...a) { return myjyskUi.pickupMyjysk(...a); }
function refreshMyjysk(...a) { return myjyskUi.refreshMyjysk(...a); }
function seenNews(...a) { return myjyskUi.seenNews(...a); }
function syncMyjysk(...a) { return myjyskUi.syncMyjysk(...a); }
function taskRow(...a) { return myjyskUi.taskRow(...a); }
// ------------------------------------------------------------------ Minus lista (StoreFront, only read)

function renderStoreBars() {
  renderTipsBar(); renderTopBar(); renderSmBar(); renderSoonBar();
  // audit 13. 11. 2026: the screens that are opened now and then share one row ("Ostali alati"); a tool that has
  // something to say (a list that was read) keeps its own line inside, unchanged
  const more = $('#moreTools');
  if (!more) return;
  const rb = $('#refillBar');
  if (rb) {
    const k = S.user.refill;
    const ob = $('#oopusBar');
    if (ob && oopusUi) ob.innerHTML = `${icon('box')}<span><b>OOPUS</b><small>${oopusUi.bar()}</small></span><span class="go">Otvori</span>`;
    const gb = $('#regBar');
    if (gb && regsUi) gb.innerHTML = regsUi.bar();
    const ab = $('#regAdjBar');
    if (ab && regAdjUi) ab.innerHTML = regAdjUi.bar();
    rb.innerHTML = `${icon('list')}<span><b>Punjenje</b><small>${refillUi && refillUi.api() ? (k && k.lists ? `${k.lists.length} ${plural(k.lists.length, 'lista', 'liste', 'lista')} · ${esc(ageText(k.at))}` : 'Liste za dopunu iz StoreFronta') : 'Otvori Punjenje u StoreFrontu'}</small></span><span class="go">Otvori</span>`;
  }
  // 1.96 (owner): "Prijem robe" is not in the StoreFront of BiH: gone from Ostali alati, its summary and its shortcut
  // ("Čeka prijem robe" in Narudžbe is another thing and stays)
  const shown = ['#topBar', '#smBar', '#soonBar', '#refillBar', '#oopusBar', '#regBar', '#regAdjBar'].filter((id) => $(id) && !$(id).hidden);
  more.hidden = !shown.length;
  // 2.23 (owner 22. 11.): a repaint after an automatic refresh must not show these under Vijesti
  if (S.mode === 'news') for (const id of ['#tipsBar', '#topBar', '#smBar', '#soonBar', '#moreTools']) { const e = $(id); if (e) e.hidden = true; }
  $('#moreToolsSub').textContent = shown.map((id) => ({ '#topBar': 'Najprodavanije', '#smBar': 'SM i DM', '#soonBar': 'Uskoro 21', '#refillBar': 'Punjenje', '#oopusBar': 'OOPUS', '#regBar': 'Regulacija', '#regAdjBar': 'Regulacija zalihe' })[id]).join(' · ');
}

// ----------------------------------------------- the short row of Zadnje traženo, favourites and search results
// audit 13. 11. 2026: name, code, stock, status and how old the stock is, from what the phone already knows (no
// StoreFront call when the start screen is drawn), and one tap to the place on the planogram.

/** Where the article stands, each place once (two places on one page are two places): [{ i (index in locationsOf), kind: 'exact'|'shelf'|'list', title, page }] */
function planSpots(num) {
  const out = [], seen = new Set();
  locationsOf(num).forEach((L, i) => {
    const page = L.oc ? L.oc.p : L.row ? L.row.p : 0;
    const box = L.oc ? L.oc.b : L.row ? L.row.b : null;
    const key = `${L.e.id}:${page}:${Array.isArray(box) ? box.map(Math.round).join(',') : ''}`;
    if (seen.has(key)) return;
    seen.add(key);
    const kind = L.oc && !L.row ? 'exact' : L.oc ? 'shelf' : 'list';
    out.push({ i, kind, page, title: String((L.meta && L.meta.title) || '').replace(/^\d{2}\s+/, ''), place: L.place });
  });
  return out;
}
const spotText = (s) => `${esc(s.title)} · str. ${s.page + 1}`;

/** The stock the phone keeps for this code in the current store: { stock, st, at, old, linked } or null. */
function keptStock(num) {
  const c = planogramStock.cache.get(num);
  const d = S.stock.get(num);
  const fromItem = d && d.d && d.d.sd && Number.isFinite(+d.d.sd.stock) ? { stock: +d.d.sd.stock, free: +(d.d.sd.free ?? NaN), st: (d.d.md && d.d.md.st) || d.d.sd.st || '', at: d.at, error: !!d.err } : null;
  const fromPlan = c && Number.isFinite(c.stock) ? { stock: c.stock, free: c.free, st: c.st || '', at: c.at, error: !!c.error } : null;
  const x = fromItem && (!fromPlan || fromItem.at > fromPlan.at) ? fromItem : fromPlan;
  const st = (x && x.st) || (c && c.st) || '';
  if (!x) return st ? { st } : null;
  return { ...x, st, old: x.error || Date.now() - x.at >= planogramStock.OLD || offline(), linked: planogramStock.linked(num) };
}

function itemSummaryRow(num) {
  const k = keptStock(num);
  const qty = k && Number.isFinite(k.stock)
    ? `<span class="pill ${k.stock <= 0 ? 'pill-zero' : 'pill-stock'}">${k.linked && k.linked.known ? 'Ova šifra ' : 'Zaliha '}<b>${whole(k.stock)}</b> kom${Number.isFinite(k.free) && k.free !== k.stock ? ` · za prodaju <b>${whole(k.free)}</b>` : ''}${k.linked && k.linked.known ? ` · ${k.linked.count === 1 ? 'povezana' : 'povezane'} <b>${esc(planogramStock.linkedText(k.linked, ' / ', 5))}</b>` : ''}</span>`
    : '<span class="pill pill-muted">Zaliha: nije očitano</span>';
  const st = k && k.st ? `<span class="pill ${k.st === '21' || k.st === '81' ? 'pill-warn' : 'pill-muted'}">Status ${esc(k.st)}${ST_SHORT[k.st] ? ` ${esc(ST_SHORT[k.st])}` : ''}</span>` : '';
  const age = k && Number.isFinite(k.at) ? `<small class="item-age${k.old ? ' is-old' : ''}">Očitano ${esc(ageText(k.at))}${k.old ? ' · staro' : ''}</small>` : '';
  const spots = planSpots(num);
  let where = '';
  if (spots.length > 1) where = `<button class="onplan" type="button" data-onplan="${esc(num)}">${icon('map')}<span>Na planogramu · ${spots.length} ${plural(spots.length, 'mjesto', 'mjesta', 'mjesta')}</span></button>`;
  else if (spots.length === 1) {
    const s = spots[0];
    where = s.kind === 'list'
      ? `<button class="onplan is-list" type="button" data-onplan="${esc(num)}">${icon('list')}<span>Na popisu, pozicija nije označena · ${spotText(s)}</span></button>`
      : `<button class="onplan" type="button" data-onplan="${esc(num)}">${icon('map')}<span>Na planogramu${s.kind === 'shelf' ? ' (okvirno)' : ''} · ${spotText(s)}</span></button>`;
  }
  return `<div class="item item-sum">
    <button class="item-open" type="button" data-num="${esc(num)}">
      ${thumb(num)}
      <span class="item-main">
        <span class="item-name">${esc(nameOf(num)) || 'Bez naziva'}</span>
        <span class="code">${esc(num)}</span>
        <span class="pills">${qty}${st}${ordersOf(num).length ? '<span class="pill pill-order">Naručio kupac</span>' : ''}</span>
        ${age}
      </span>
      ${icon('chev', 'chev')}
    </button>
    ${where}
  </div>`;
}

/** Opens the planogram page of one place of the article with the article marked (the place as the article screen would). */
/** StoreFront's "Pogledaj planogram": the planogram server's search for the article, in the app's planogram window. */
function planServerOpen(num) {
  const h = hostsNow() || {};
  if (!h.pl || !/^\d{7}$/.test(String(num))) { toast('Adresa servera planograma nije podešena.'); return; }
  const org = String(S.user.sfOrg || cfg().plOrg || '').replace(/\D/g, '');
  try { A.plansWeb(`https://${h.pl}/search?article=${encodeURIComponent(num)}${org ? `&sorg=${encodeURIComponent(org)}` : ''}`); } catch (e) { toast('Server planograma se nije otvorio.'); }
}
const planServerBtn = (num) => `<button class="onplan is-list" type="button" data-plan-server="${esc(num)}">${icon('map')}<span>Planogram na serveru (StoreFront)</span></button>`;

function openOnPlan(num, i) {
  const L = locationsOf(num)[i];
  if (!L) return;
  const page = L.oc ? L.oc.p : L.row ? L.row.p : 0;
  const focus = L.oc ? (L.oc.whole ? null : L.oc.b) : L.row ? L.row.b : null;
  closeSheet();
  viewer.open(L.e.id, page, focus);
}

/** "Na planogramu": one place opens at once, several ask which one. */
function onPlanTap(num) {
  const spots = planSpots(num);
  if (!spots.length) return;
  if (spots.length === 1) { openOnPlan(num, spots[0].i); return; }
  const where = (s) => (s.kind === 'list' ? 'na popisu, pozicija nije označena' : s.place && s.place.segment
    ? `Modul ${esc(s.place.module)}, ${isBar(s.place.fixture) ? 'šipka' : 'polica'} ${esc(s.place.shelf)}${s.kind === 'shelf' ? ' (okvirno)' : ''}` : s.kind === 'shelf' ? 'okvirna polica' : '');
  openSheet({
    title: 'Na kojem mjestu?',
    body: `<p>${esc(nameOf(num)) || esc(num)} · ${esc(num)}</p><div class="list">${spots.map((s) => `<button class="item" type="button" data-onplan-at="${esc(num)}|${s.i}">
      <span class="item-main"><span class="item-name">${spotText(s)}</span>${where(s) ? `<small class="item-age">${where(s)}</small>` : ''}</span>${icon('chev', 'chev')}</button>`).join('')}</div>`,
    actions: [{ label: 'Odustani', kind: 'btn-quiet', onClick: closeSheet }],
  });
}
// ------------------------------------------------------------------ Minus lista: js/minus-ui.js
// created just before boot() (everything it uses exists by then); these forward to it
let minusUi = null;
let autoSync = null; // 2.15: js/auto-sync.js
function loadMinus(...a) { return minusUi.loadMinus(...a); }
function minusOpNow(...a) { return minusUi.minusOpNow(...a); }
function onMinusClick(...a) { return minusUi.onMinusClick(...a); }
function openMinus(...a) { return minusUi.openMinus(...a); }
function renderMinus(...a) { return minusUi.renderMinus(...a); }
function renderMinusBar(...a) { return minusUi.renderMinusBar(...a); }

// ------------------------------------------------- an Excel attachment of a news article
// created just before boot() (everything it uses exists by then): js/news-ui.js; these forward to it
let newsUi = null;
function impItems(...a) { return newsUi.impItems(...a); }
function onAttachClick(...a) { return newsUi.onAttachClick(...a); }
function onNewsClick(...a) { return newsUi.onNewsClick(...a); }
function renderAttach(...a) { return newsUi.renderAttach(...a); }
function renderNews(...a) { return newsUi.renderNews(...a); }
// ------------------------------------------------ StoreFront jobs: stock, best sellers, SM/DM (assets/store-task.js)
//
// Each job runs in a hidden StoreFront page with the employee's own sign-in and answers through window.onStoreTask.

/**
 * The employee's own department in StoreFront's terms: the product groups (e.g. 50101 Svijećnjaci) of the articles in
 * his planograms whose title starts with the department number ("05 Homeware"). StoreFront's group 5 also holds
 * cleaning, laundry and storage (other departments); old articles (21/81) that left the planogram are still in these
 * groups, so they are found too. Learned once from StoreFront and kept; the employee can leave groups out.
 */
function deptPlans() {
  const code = String(cfg().dept || '05');
  return S.plans.filter((p) => String(p.title || core.planTitle(p.plan) || '').trim().startsWith(code));
}
const deptKey = () => deptPlans().map((p) => p.key || p.id).sort().join('|');
function deptNums() {
  const nums = new Set();
  for (const p of deptPlans()) for (const [n, it] of Object.entries(p.plan.items)) if (it.oc.length || it.rw.length) nums.add(n);
  return [...nums];
}
/** The kept groups for the planograms now on the phone, or null (not learned yet). */
function deptGroups() {
  const g = S.user.deptGroups;
  return g && g.key === deptKey() && Array.isArray(g.groups) ? g.groups : null;
}
/** Groups that count: seen at least twice in the planogram (one stray article does not make a group his). */
const deptUsed = () => (deptGroups() || []).filter((x) => x.n >= 2 && !(cfg().grpOff || {})[x.id]);
const deptArg = () => { const u = deptUsed(); return u.length ? { cats: u.map((x) => x.id) } : {}; };
const deptName = () => { const p = deptPlans()[0]; return p ? String(p.title || core.planTitle(p.plan)) : `grupa ${cfg().group || '5'}`; };
const deptSig = () => deptUsed().map((x) => x.id).join(',');

/** Learns the department's groups (once per set of planograms), then runs next(). */
S.deptWait = [];
function withDept(next) {
  if (deptGroups() || !deptPlans().length) { next(); return; }
  S.deptWait.push(next);
  if (S.deptBusy) return; // already being learned: run with the others when it is there
  S.deptBusy = true;
  const done = () => { S.deptBusy = false; const w = S.deptWait.splice(0); for (const f of w) f(); };
  const ok = stCall({ mode: 'groups', nums: deptNums() }, (r) => {
    if (r.how === 'ok' && r.res && Array.isArray(r.res.groups)) {
      S.user.deptGroups = { key: deptKey(), at: Date.now(), groups: r.res.groups.slice(0, 80).map((x) => ({ id: String(x.id), title: String(x.title || ''), n: +x.n || 0 })) };
      saveUser();
    }
    done();
  });
  if (!ok) done();
}

/** The department's groups as chips: tap leaves one out (or takes it back). */
function deptChips(screen) {
  const g = deptGroups();
  if (!g) return '';
  const off = cfg().grpOff || {};
  const used = g.filter((x) => x.n >= 2);
  return `<details class="dept-groups"><summary>${esc(deptName())}: ${deptUsed().length} ${plural(deptUsed().length, 'grupa', 'grupe', 'grupa')} proizvoda iz StoreFronta</summary>
    <p>Grupe u kojima su artikli tvog planograma. Gledaju se i stari artikli tih grupa koji više nisu u planogramu. Tapni grupu da je izbaciš ili vratiš.</p>
    <div class="chips">${used.map((x) => `<button class="chip" type="button" aria-pressed="${!off[x.id]}" data-grp="${esc(x.id)}" data-grp-screen="${screen}">${esc(x.title || x.id)} <small>${x.n}</small></button>`).join('')}</div></details>`;
}

const stJobs = new Map();
const stParts = new Map(); // 1.76: job -> what to do with the answers a running job passes on (window.onStorePart)
let stSeq = 0;
// 1.97: StoreFront jobs in the flow log: which module, how long in the queue and running, the outcome in closed words
const SF_MOD = { stockbatch: 'stock', pricebatch: 'stock', relatedstock: 'stock', article: 'stock', refilllists: 'refill', refillitems: 'refill',
  refilladd: 'refill', refillinfo: 'refill', refillcheck: 'refill', refilldel: 'refill', oopuslist: 'oopus', oopusfind: 'oopus', oopusorder: 'oopus', oopushandout: 'oopus', smdm: 'smdm', smset: 'smdm', find: 'scan', lookup: 'scan', eans: 'scan',
  top: 'stock', sales: 'stock', soon: 'smdm', audit: 'smdm', clear: 'stock', opcheck: 'minus', pics: 'stock', me: 'app', groups: 'smdm', hier: 'smdm', plan: 'plan' };
const SF_WRITE = new Set(['refilladd', 'refilldel', 'smset', 'oopushandout']);
const stFlows = new Map();
/** A StoreFront answer in closed words: ok, login, network, timeout, unsure (a write whose answer is lost), rejected... */
function sfOut(r) {
  if (!r) return { out: 'app_error', why: 'nema odgovora' };
  if (r.how === 'ok') return r.res ? { out: 'ok' } : { out: 'bad_response', why: 'prazan odgovor' };
  if (r.how === 'login') return { out: 'login' };
  const e = String(r.err || '');
  if (e === 'offline' || /Failed to fetch|NetworkError|ERR_INTERNET|ERR_NAME/.test(e)) return { out: 'network' };
  if (e === 'timeout') return { out: 'timeout' };
  if (e === 'lost') return { out: 'unsure', why: 'odgovor izgubljen' };
  if (e === 'context') return { out: 'held', why: 'druga prodavnica ili korisnik' };
  if (/^http 4\d\d/.test(e)) return { out: 'rejected', why: e.slice(0, 8) };
  if (/^http 5\d\d/.test(e)) return { out: 'network', why: e.slice(0, 8) };
  if (/bad|json|parse/i.test(e)) return { out: 'bad_response', why: e };
  return { out: 'app_error', why: e || r.how };
}
// #25 (21. 11. 2026): back from the real StoreFront (where the store can be changed or another employee sign in) or
// signed out: the hidden pages ask again who is signed in, not the store they kept for 10 min (store-task.js who())
let sfWhoAt = 0;
function stCall(arg, cb, onPart = null) {
  if (!A.storeTask) return false;
  if (sfWhoAt) arg = { ...arg, whoAfter: sfWhoAt };
  const job = `j${++stSeq}`;
  const fl = arg.flow || null;
  if (arg.flow) { arg = { ...arg }; delete arg.flow; }
  stFlows.set(job, { f: fl, mode: arg.mode, at: Date.now(), bg: !!arg.bg });
  stJobs.set(job, cb);
  if (onPart) stParts.set(job, onPart);
  if (!arg.bg && ST_LABEL[arg.mode]) stMeta.set(job, { label: ST_LABEL[arg.mode], screen: top().id, at: Date.now(), started: 0, prog: '' });
  // the job id (truthy, as true was before 1.76): stYield(job) can hand its page over
  try { A.storeTask(JSON.stringify({ ...arg, job })); stLineSoon(); return job; } catch (e) { stJobs.delete(job); stParts.delete(job); stMeta.delete(job); return false; }
}
/** 1.76: a running planogram stock job hands its page over (StoreTask.yieldJob); false: this app cannot do it. */
function stYield(job) {
  if (!A.storeYield || !stJobs.has(job)) return false;
  try { A.storeYield(job); return true; } catch (e) { return false; }
}
// 1.76: a running job's answers so far (StoreTask.java passes on window.__st.part); a job that ended is not heard
window.onStorePart = (r) => {
  const f = r && stParts.get(r.job);
  if (f && Array.isArray(r.part)) f(r.part);
};

// What runs in StoreFront now, on every screen (1.71): a reading of half a minute is not a silent wait any more.
// Only what the employee started and only after 2.5 s; background work (barcodes) is not shown.
const ST_LABEL = {
  top: 'Najprodavanije', soon: 'Uskoro 21', clear: 'Za rasprodaju', audit: 'Master provjera', smdm: 'SM i DM', smset: 'Spremam SM/DM',
  // Group discovery already reports progress inside its own screen; never show a roaming spinner.
  opcheck: 'Provjera u StoreFrontu', article: 'Zaliha', find: 'Traženje', master: 'Artikal',
};
const stMeta = new Map();
let stOfflineAt = 0;
let stLineTimer = 0;
window.onStoreProgress = (r) => {
  const m = r && stMeta.get(r.job);
  if (!m) return;
  if (!m.started) m.started = Date.now();
  if (r.prog) m.prog = String(r.prog);
};
/** "sm 300/1200" -> "300 od 1200" */
function progText(p) {
  const x = /(\d+)\s*\/\s*(\d+)\s*$/.exec(String(p || ''));
  return x && +x[2] > 0 ? `${x[1]} od ${x[2]}` : '';
}
// tests only (a page served from localhost): start a job the way a screen does
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__testOffline = offline; // tests/net-ui.mjs
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__testStCall = (arg) => !!stCall(arg, () => {}); // true: started (stCall itself gives the job id since 1.76)
// 1.73: the line (what, how far, how long) only on the screen that started the reading. 1.71 showed it on every screen,
// which confused when one navigated away while a long reading kept running (1.72.x hid it altogether); now it goes
// with the screen and comes back on return. Group discovery has its own line inside its screen (not in ST_LABEL).
function stLineSoon() { if (!stLineTimer) stLineTimer = setTimeout(stLine, 1000); }
function stLine() {
  stLineTimer = 0;
  const el = $('#sfLine');
  if (!el) return;
  const now = Date.now(), here = top().id;
  const shown = [...stMeta.values()].filter((m) => now - m.at > 2500 && m.screen === here);
  if (!shown.length) { el.hidden = true; if (stMeta.size) stLineSoon(); return; }
  const m = shown[0];
  const what = !m.started ? 'čeka StoreFront' : offline() ? 'nema interneta, čekam vezu' : progText(m.prog) || 'čitam';
  el.innerHTML = `<i></i><span><b>${esc(m.label)}</b> · ${esc(what)} · ${Math.round((now - m.at) / 1000)} s${shown.length > 1 ? ` · još ${shown.length - 1}` : ''}</span>`;
  el.hidden = false;
  stLineSoon();
}
window.onStoreTask = (r) => {
  const fg = !!(r && stMeta.has(r.job)); // started by the employee (background work stays quiet)
  // 1.97: the job into the flow log: in the action that started it, or (a failed background reading) as its own row
  const sf = r && stFlows.get(r.job);
  if (sf) {
    stFlows.delete(r.job);
    try {
      const o = sfOut(r), x = { q: r.qms, ms: r.ms ?? Date.now() - sf.at, ...(Number.isFinite(r.pg) ? { pg: r.pg } : {}), ...(Number.isFinite(r.net) ? { net: r.net } : {}), ...(o.why ? { why: o.why } : {}) };
      const step = `StoreFront ${sf.mode}${SF_WRITE.has(sf.mode) ? ' (upis)' : ''}`;
      if (sf.f) sf.f.step(step, o.out, x);
      else if (o.out !== 'ok' || !sf.bg) flow.one(SF_MOD[sf.mode] || 'sf', sf.bg ? 'Čitanje u pozadini' : 'Čitanje', step, o.out, x);
    } catch (e) { /* the log never breaks a job */ }
  }
  if (r) { stMeta.delete(r.job); stParts.delete(r.job); }
  const cb = r && stJobs.get(r.job);
  if (!cb) return;
  stJobs.delete(r.job);
  if (r.how === 'ok') {
    sfOkAt = Date.now();
    S.user.store = { ok: true };
    eans.signedIn();
    // StoreFront just answered: the "offline" mark of an older check (it can time out while jobs run) is not true
    const onl = $('#onl');
    if (onl && onl.classList.contains('is-off') && S.net !== false) window.onStoreStatus(true, ''); // (not while Android says there is no network)
  }
  // no network at all: said once a minute in plain words on any screen (1.71), the screen's own message follows
  else if (fg && offline() && Date.now() - stOfflineAt > 60000) {
    stOfflineAt = Date.now();
    toast('Nema interneta: StoreFront se ne može pročitati. Ono što je ranije učitano ostaje prikazano.');
  }
  // 1.74: a public APK carries no server addresses; this phone has no StoreFront address yet (said once a minute)
  else if (r.err === 'nohost' && Date.now() - stOfflineAt > 60000) {
    stOfflineAt = Date.now();
    toast('Adresa StoreFronta nije podešena: Postavke → Adrese servera.', 5200);
  }
  cb(r);
  if (r.res && r.res.dry) setTimeout(() => toast('TEST verzija: ništa nije spremljeno u StoreFront (samo odigrano).'), 1800);
};

/** What a status code means: StoreFront's own names (24. 11. 2026: from StoreFront's list, with 43 and 91; js/regs.js). */
const ST_TEXT = Object.fromEntries(Object.entries(ST_INFO).map(([k, v]) => [k, v.name]));
const stText = (st) => ST_TEXT[st] || '';
const ST_SHORT = Object.fromEntries(Object.entries(ST_INFO).map(([k, v]) => [k, v.short]));
const stPill = (st) => (st ? `<span class="pill ${st === '21' || st === '81' ? 'pill-warn' : 'pill-muted'}">Status ${esc(st)}${stText(st) ? `: ${esc(stText(st))}` : ''}</span>` : '');

// stock movements: what the store system calls them (SAP movement types)
const MOVE = { '251': 'Prodano', '252': 'Vraćeno', '101': 'Stiglo', '102': 'Storno prijema', '701': 'Inventura', '702': 'Inventura', '711': 'Inventura', '712': 'Inventura', '551': 'Otpis', '552': 'Storno otpisa', '311': 'Prenos', '641': 'Poslano', '643': 'Poslano', '52': 'Reklamacija' };
const moveName = (m) => MOVE[m.type] || (m.q > 0 ? 'Ulaz' : 'Izlaz');
const dm = (t) => { const d = new Date(t); return `${d.getDate()}.${d.getMonth() + 1}.`; };
const dmYear = (t) => { const d = new Date(t); return `${d.getDate()}.${d.getMonth() + 1}.${d.getFullYear()}.`; };
const signed = (n) => (n > 0 ? `+${whole(n)}` : n < 0 ? `−${whole(-n)}` : '0');

/** One article's stock in the store, kept a few minutes: num -> { at, d, busy, err } */
S.stock = new Map();

// 1.99 (owner: "historija zalihe i dalje djeluje sporo"): the last reading of an article (price, stock AND its history)
// is kept on the phone per store (art-cache.json, the 150 last opened, newest first); opening the article again shows
// it at once with its time, while StoreFront is asked in the background. Nothing about people in it.
const ART_CACHE = 'art-cache.json', ART_KEEP = 150;
let artCache = null;
function artCacheAll() {
  if (!artCache) { artCache = store.read(ART_CACHE, null); if (!artCache || typeof artCache !== 'object' || !artCache.list) artCache = { v: 1, list: {} }; }
  return artCache;
}
function artCacheGet(num) {
  const st = S.user.sfHint && S.user.sfHint.store;
  const e = st ? artCacheAll().list[`${st}:${num}`] : null;
  return e && e.d && Array.isArray(e.d.hist) ? e : null;
}
let artCacheTimer = 0;
function artCachePut(d) {
  if (!d || !d.store || !/^\d{7}$/.test(String(d.num)) || !Array.isArray(d.hist)) return;
  const all = artCacheAll();
  const { histCached, cached, partial, seeded, ...keep } = d;
  all.list[`${d.store}:${d.num}`] = { at: Date.now(), d: keep };
  const keys = Object.keys(all.list);
  if (keys.length > ART_KEEP) keys.sort((a, b) => all.list[a].at - all.list[b].at).slice(0, keys.length - ART_KEEP).forEach((k) => delete all.list[k]);
  clearTimeout(artCacheTimer);
  artCacheTimer = setTimeout(() => store.write(ART_CACHE, all), 400); // a few openings in a row are written once
}
/** 1.99: the times of the last openings (tap, price and stock, first history row, fresh answer, queue): for the flow
 *  log and the measuring test. */
const histPerf = [];
function histMark(num, what) {
  const c = S.stock.get(num);
  if (!c || !c.t0 || c[what] != null) return;
  c[what] = Date.now() - c.t0;
}

function stockLoad(num, force = false) {
  regsUi.sync(false); // 24. 11. 2026: the store's adjustments for the article screen (background, at most every 15 min)
  let c = S.stock.get(num);
  // 26. 11. 2026: the other codes of the same article (js/chain-ui.js, read only). 27. 11. 2026 (owner, 2.31 on the phone:
  // "zašto mi se sporo učitava zaliha"): it was asked BEFORE the stock, with the same priority, so it took the warm
  // StoreFront page and the stock waited for it or for a new page (up to 5 s on the phone, 20. 11.). Now the stock
  // goes first and the chain is asked when the stock job has ended (the same warm page); only without a stock job
  // (fresh numbers, or one already running whose end asks it) it is asked here.
  const chainNow = () => { if (chainUi) chainUi.load(num, force); };
  if (c && (c.busy || (!force && c.d && Date.now() - c.at < 180000))) { if (!c.busy) chainNow(); stockPaint(num); return; }
  // 1.99: the phone's own last reading of this article in this store, history included, is shown at once
  if (!(c && c.d)) {
    const k = artCacheGet(num);
    if (k) { c = { at: k.at, d: { ...k.d, cached: true, histCached: true, histAt: k.at }, err: null }; S.stock.set(num, c); }
  }
  // 1.98 (owner): what the phone already knows is on the screen at once, with its time: an earlier reading of this
  // article, or the planogram's stock and price of this code (marked "iz planograma"); the fresh answer replaces it
  if (!(c && c.d)) {
    const pc = planogramStock.cache.get(num);
    if (pc && Number.isFinite(pc.stock)) {
      c = { at: pc.at, d: { num, seeded: true, md: { price: Number.isFinite(+pc.price) && pc.price != null ? +pc.price : null, cur: pc.cur || 'BAM', st: pc.st || '', name: pc.name || '' },
        sd: { num, stock: pc.stock, free: Number.isFinite(pc.free) ? pc.free : null, st: pc.st || '' } }, err: null };
      S.stock.set(num, c);
    }
  }
  const t0 = Date.now();
  // the price and the stock come first (one master data request, js/store-task.js article()), the history as its own
  // part when it is there (1.99); a part of an older job of this code (t0) is not taken
  const quick = (parts) => {
    for (const p of parts || []) {
      const cur = S.stock.get(num);
      if (!p || String(p.num) !== num || !cur || !cur.busy || cur.t0 !== t0) continue;
      // 22. 11. 2026 (audit, "podaci prethodne prodavnice"): a page started with the app's last store (hint) may learn
      // that another store is signed in and read again: its quick part of THAT store replaces the first one at once
      // (before, the first quick part stayed until the whole answer came, seconds later)
      const otherStore = p.quick && cur.quickAt && p.w && cur.quickW && p.w !== cur.quickW;
      if (p.quick && (!cur.quickAt || otherStore)) {
        const keepHist = !otherStore && cur.d && Array.isArray(cur.d.hist) ? { hist: cur.d.hist, histAt: cur.d.histAt, histCached: cur.d.histCached, sold7: cur.d.sold7, sold30h: cur.d.sold30h, recv: cur.d.recv } : {};
        S.stock.set(num, { ...cur, at: Date.now(), quickAt: Date.now(), quickW: p.w || '', quickMs: cur.quickMs ?? Date.now() - t0, d: { ...(!otherStore && cur.d && !cur.d.seeded && !cur.d.cached ? cur.d : {}), ...keepHist, num, md: p.md || {}, sd: p.sd || null, partial: true, seeded: false, cached: false }, err: null });
      } else if (p.histOnly && Array.isArray(p.hist)) {
        const d = cur.d || { num };
        S.stock.set(num, { ...cur, d: { ...d, hist: p.hist, histAt: Date.now(), histCached: false, histErr: 0, sold7: p.sold7, sold30h: p.sold30h, recv: p.recv } });
        histMark(num, 'histMs');
      } else continue;
      stockPaint(num);
    }
  };
  const hint = S.user.sfHint && S.user.sfHint.store ? { store: S.user.sfHint.store, catalog: S.user.sfHint.catalog } : null;
  const ok = stCall({ mode: 'article', num, stream: true, ...(hint ? { hint } : {}) }, (r) => {
    // a failed refresh keeps the older numbers WITH their own time (1.68 gave them the time of the failed try, so old
    // numbers looked fresh) and says it was not refreshed
    const now = S.stock.get(num) || c; // 1.98: what is on the screen now (the quick part, a planogram value)
    if (now && now.t0 && now.t0 !== t0) return; // 1.99: an older job of this code: the newer one decides
    const keep = r.how !== 'ok' && now && now.d ? now : null;
    let d = r.how === 'ok' ? r.res : keep ? keep.d : null;
    // 1.99: the history could not be read this time: the kept one stays on the screen with its own time, said so
    if (r.how === 'ok' && d && d.histErr && now && now.d && Array.isArray(now.d.hist)) d = { ...d, hist: now.d.hist, histAt: now.d.histAt, histCached: true, sold7: now.d.sold7, sold30h: now.d.sold30h, recv: now.d.recv };
    if (r.how === 'ok' && d && Array.isArray(d.hist) && !d.histCached) d = { ...d, histAt: Date.now() };
    const perf = now ? { t0, quickMs: now.quickMs, histMs: now.histMs } : { t0 };
    S.stock.set(num, { at: keep ? keep.at : Date.now(), d, err: r.how === 'ok' ? null : r.how, ...perf });
    if (r.how === 'ok' && d && Array.isArray(d.hist)) histMark(num, 'histMs');
    const fin = S.stock.get(num);
    fin.freshMs = Date.now() - t0;
    if (r.how === 'ok' && r.res && r.res.store) {
      if (!S.user.sfHint || S.user.sfHint.store !== r.res.store || S.user.sfHint.catalog !== r.res.catalog) { S.user.sfHint = { store: String(r.res.store).slice(0, 10), catalog: String(r.res.catalog || '').slice(0, 30) }; saveUser(); }
      if (!r.res.histErr) artCachePut(r.res);
    }
    histPerf.unshift({ num, first: fin.histMs ?? null, fresh: fin.freshMs, quick: fin.quickMs ?? null, q: r.qms ?? null, job: r.ms ?? null, cached: !!(c && c.d && c.d.histCached), how: r.how });
    histPerf.length = Math.min(histPerf.length, 30);
    try { flow.one('stock', 'Historija zalihe', `prvi red ${fin.histMs ?? '–'} ms, svježe ${fin.freshMs} ms`, r.how === 'ok' ? (d && d.histErr ? 'incomplete' : 'ok') : sfOut(r).out, { ms: fin.freshMs, q: r.qms }); } catch (e) { /* the log never breaks the screen */ }
    stockPaint(num);
    sfName(num, r.how === 'ok' && r.res && r.res.md ? r.res.md.name : '');
    if (r.how !== 'login') chainNow(); // after the stock, on the page it leaves warm
  }, quick);
  if (ok) S.stock.set(num, { ...(c || {}), busy: true, t0, quickAt: 0, quickMs: undefined, histMs: c && c.d && Array.isArray(c.d.hist) ? 0 : undefined, freshMs: undefined });
  else chainNow();
  stockPaint(num);
}
window.__histPerf = histPerf; // read by tests/history-speed-ui.mjs (numbers only)

/** An article the planogram names without a name: StoreFront's name, shown where "Bez naziva" stands. */
// 2.12 (owner, 18. 11. 2026): a name the planogram broke over two lines ("Rug SANDE LTRE") gets StoreFront's spacing
// ("Rug SANDELTRE") once StoreFront answers for the article; kept in user.json (nameFix) for the planograms already read.
function fixName(num, nm, save = true, at = null) {
  const list = S.index && S.index.byNum.get(num);
  if (!list || !nm) return false;
  for (const x of list) if (x.it.nm) x.it.nm = nm;
  const n = at ? at.get(num) : S.index.names.find((y) => y.num === num);
  if (n) { n.nm = nm; n.f = core.fold(nm); n.g = n.f.replace(/ /g, ''); }
  if (save) { S.user.nameFix = { ...(S.user.nameFix || {}), [num]: nm }; saveUser(); }
  return true;
}

function sfName(num, name) {
  if (!name) return;
  const fixed = core.respace(nameOf(num), name);
  if (fixed && fixName(num, fixed)) {
    const t = document.querySelector('#item .head .title'), chip = document.querySelector('#item .head [data-copy]');
    if (t && chip && chip.dataset.copy === num) t.textContent = fixed;
  }
  // 1.96: the article of a linked barcode that is in no planogram (Nije pronađeno → Artikal)
  const mn = document.querySelector('#missName');
  if (mn && !mn.textContent.trim() && top().id === 'missing' && top().state === num) mn.textContent = name;
  const h = document.querySelector('#item .head .title');
  const chip = document.querySelector('#item .head [data-copy]');
  if (h && chip && chip.dataset.copy === num && /^Bez naziva$/.test(h.textContent.trim())) h.textContent = name;
}

function stockPaint(num) {
  for (const el of document.querySelectorAll(`[data-stock="${num}"]`)) el.innerHTML = stockHtml(num);
}

/** The stock over the last `days` days as a small line: the stock after each movement. */
function stockSpark(hist, now, days = 30) {
  const from = now - days * 86400000;
  const pts = hist.filter((m) => m.t >= from).slice().reverse();
  if (pts.length < 2) return '';
  const first = hist.find((m) => m.t < from);
  const series = [{ t: from, v: first ? first.after : pts[0].after - pts[0].q }, ...pts.map((m) => ({ t: m.t, v: m.after })), { t: now, v: pts[pts.length - 1].after }];
  const max = Math.max(1, ...series.map((p) => p.v)), min = Math.min(0, ...series.map((p) => p.v));
  const X = (t) => ((t - from) / (now - from)) * 100, Y = (v) => 26 - ((v - min) / (max - min || 1)) * 24;
  let d = '';
  series.forEach((p, i) => { d += i ? ` H${X(p.t).toFixed(1)} V${Y(p.v).toFixed(1)}` : `M${X(p.t).toFixed(1)} ${Y(p.v).toFixed(1)}`; });
  return `<div class="stk-spark"><svg viewBox="0 0 100 28" preserveAspectRatio="none" aria-hidden="true"><path d="${d}"/></svg><span>zaliha ${esc(histPeriodName(days))} · najviše ${whole(max)}</span></div>`;
}

// 2.06 (owner, 16. 11. 2026): a slider in the history box: 30 days, 3 months, 6 months, a year. The list of movements
// scrolls inside its own box. Past what the article screen read (the newest 60 entries) the longer history of this one
// article is read only when the slider asks for it (S.histLong, kept in memory for this session).
const HIST_STOPS = [30, 91, 182, 365];
function histPeriodName(days) { return days >= 365 ? 'zadnjih godinu dana' : days >= 182 ? 'zadnjih 6 mjeseci' : days >= 91 ? 'zadnja 3 mjeseca' : `zadnjih ${days} dana`; }
const histShort = (days) => (days >= 365 ? '1 god.' : days >= 182 ? '6 mj.' : days >= 91 ? '3 mj.' : '30 dana');
/** The entries for this article and how far back they surely reach (null: as far as StoreFront has). */
function histFor(num, d) {
  const L = S.histLong && S.histLong.get(num);
  const base = Array.isArray(d.hist) ? d.hist : [];
  const h = L && L.hist && L.hist.length >= base.length ? L.hist : base;
  const asked = L && L.hist ? L.max : 60;
  const full = L && L.hist ? L.full : base.length < 60;
  const reach = full || !h.length ? null : h[h.length - 1].t; // older than this is not read
  return { h, reach, L };
}
function histNeed(num, days) {
  const c = S.stock.get(num);
  if (!c || !c.d) return;
  const { reach, L } = histFor(num, c.d);
  if (reach == null || reach <= Date.now() - days * 86400000) return; // already reaches back far enough
  if (L && (L.busy || (L.hist && L.max >= 2000))) return;
  const max = L && L.hist ? Math.min(2000, L.max * 2) : 1000;
  S.histLong = S.histLong || new Map();
  S.histLong.set(num, { ...(L || {}), busy: true, err: '' });
  stockPaint(num);
  const t0 = Date.now();
  const ok = stCall({ mode: 'histlong', num, max }, (r) => {
    const cur = S.histLong.get(num) || {};
    if (r.how === 'ok' && r.res && Array.isArray(r.res.hist)) {
      S.histLong.set(num, { hist: r.res.hist, full: !!r.res.full, max: +r.res.max || max, at: Date.now(), busy: false, err: '' });
      note(`historija zalihe ${num}: ${r.res.hist.length} promjena (do ${max}${r.res.full ? ', sve što StoreFront ima' : ''}), ${Date.now() - t0} ms`);
    } else {
      S.histLong.set(num, { ...cur, busy: false, err: r.how === 'login' ? 'login' : r.err || 'greška' });
    }
    stockPaint(num);
  });
  if (!ok) { S.histLong.set(num, { ...(S.histLong.get(num) || {}), busy: false, err: 'stara verzija' }); stockPaint(num); }
}
function histSlider(num, days, reach, L) {
  const i = Math.max(0, HIST_STOPS.indexOf(days));
  const short = reach != null && reach > Date.now() - days * 86400000;
  const state = L && L.busy ? '<i class="mj-busy"></i> učitavam stariju historiju…'
    : short && L && L.err ? `starija historija nije učitana (${esc(L.err === 'login' ? 'StoreFront traži prijavu' : 'StoreFront nije odgovorio')}). <button class="text-btn" type="button" data-hist-more="${esc(num)}">Pokušaj ponovo</button>`
    : short ? `StoreFront je dao historiju od ${esc(dmYear(reach))}.` : '';
  return `<div class="stk-range"><label><span>Historija: <b data-hist-label>${esc(histShort(days))}</b></span>
      <input type="range" min="0" max="${HIST_STOPS.length - 1}" step="1" value="${i}" data-hist-range="${esc(num)}" aria-label="Period historije zalihe"></label>
      <div class="stk-range-ticks" aria-hidden="true">${HIST_STOPS.map((x) => `<span>${esc(histShort(x))}</span>`).join('')}</div>
      ${state ? `<p class="stk-range-state">${state}</p>` : ''}</div>`;
}

function stockHtml(num) {
  const open = `<button class="text-btn stk-open" type="button" data-store="${esc(num)}">${icon('link')}Otvori u StoreFrontu</button>`;
  if (!A.storeTask) return `<button class="btn btn-soft btn-block btn-small store-btn" type="button" data-store="${esc(num)}">${icon('link')}Cijena i zaliha u StoreFrontu</button>`;
  const c = S.stock.get(num) || {};
  const d = c.d;
  if (!d) {
    if (c.busy) return '<div class="stk stk-wait"><i class="mj-busy"></i>Učitavam zalihu iz StoreFronta…</div>';
    const why = c.err === 'login' ? 'StoreFront traži prijavu. Otvori ga jednom i prijavi se.' : c.err ? (offline() ? 'Nema interneta: zaliha se ne može učitati.' : 'StoreFront nije odgovorio.') : '';
    return `<div class="stk stk-wait">${why ? `${esc(why)} <button class="text-btn" type="button" data-stock-retry="${esc(num)}">Pokušaj ponovo</button>` : ''}${open}</div>`;
  }
  const a = d.sd || {}, md = d.md || {};
  if (!d.sd && !md.st && !md.name && md.price == null) {
    return `<div class="stk stk-wait">StoreFront ne pronalazi ovu šifru. ${esc('StoreFront ne prikazuje artikle povučene iz prodaje prije više od dvije godine (StoreFront 6.9.0), pa stara šifra može izgledati kao da ne postoji.')} ${open}</div>`;
  }
  const unit = (a.unit || md.unit || '').toLowerCase();
  const st = md.st || a.st;
  const now = Date.now();
  // the history grouped by day and kind: "4.11. Prodano −3 → 6"; 2.06: every row of the chosen period (slider), in a
  // box that scrolls by itself
  const days = S.histDays || 30;
  const HL = histFor(num, d);
  const fromT = now - days * 86400000;
  const rows = [];
  for (const m of HL.h) {
    if (m.t < fromT && rows.length >= 7) break; // 30 days with few movements: still the last 7 rows, as before
    const key = `${dmYear(m.t)}|${moveName(m)}`;
    const last = rows[rows.length - 1];
    if (last && last.key === key) { last.q += m.q; continue; }
    if (rows.length >= 600) break;
    rows.push({ key, day: dmYear(m.t), name: moveName(m), q: m.q, after: m.after });
  }
  const sold30 = a.sold30 != null && a.sold30 !== 0 ? a.sold30 : d.sold30h;
  // 1.98: the history is still coming (price and stock are here) / the values are the planogram's until the answer
  // 1.99: three states kept apart: loading, "Nema evidentiranih promjena" (StoreFront answered: none) and "Učitavanje
  // nije uspjelo" (1.98 showed a failed reading as "Nema promjena zalihe"); a kept history is shown with its time
  const H = Array.isArray(d.hist) ? d.hist : null;
  const waitHist = !H && !d.histErr && !!(d.partial || d.seeded || d.cached || c.busy);
  const known = a.stock != null && Number.isFinite(+a.stock); // an unknown stock is "?", never 0
  // 1.72: what to do with it, from numbers already read (nothing more asked of StoreFront)
  const stockN = known ? +a.stock : 0, smN = +(a.sm ?? 0), sold30N = +(sold30 || 0);
  const left = stockN > 0 && sold30N > 0 ? Math.round(stockN / (sold30N / 30)) : null;
  const daysLine = stockN <= 0 || waitHist ? '' : left != null
    ? `<p class="stk-line stk-days${left < 7 ? ' is-low' : ''}">Dovoljno za oko <b>${left > 365 ? 'više od godinu' : `${whole(left)} ${left === 1 ? 'dan' : 'dana'}`}</b>${left > 365 ? ' dana' : ''} <span>(po prodaji zadnjih 30 dana)</span></p>`
    : '<p class="stk-line stk-days"><span>Ništa prodano zadnjih 30 dana.</span></p>';
  const smWarn = known && smN > 0 && stockN < smN
    ? `<p class="stk-warn">${icon('info')}<span>Na stanju <b>${whole(stockN)}</b>, a SM je <b>${whole(smN)}</b>: polica nije puna. Dopuni ili naruči.</span></p>` : '';
  const facts = [
    a.sm != null ? `SM ${whole(a.sm)}` : '', a.dm ? `DM ${whole(a.dm)}` : '', a.cap ? `kapacitet svih polica ${whole(a.cap)}` : '',
  ].filter(Boolean).join(' · ');
  const curr = esc(md.cur === 'BAM' || !md.cur ? 'KM' : md.cur);
  // 1.98: an action price says so, with the regular one beside it (StoreFront gives both: active and normal)
  const action = md.price != null && md.normal != null && Number.isFinite(+md.normal) && +md.normal > +md.price;
  const price = (md.price != null && Number.isFinite(+md.price)
    ? `<strong class="stk-price">${money(md.price)} ${curr}</strong>${action ? ` <span class="stk-action">akcija · redovna <s>${money(md.normal)} ${curr}</s></span>` : ''}` : '')
    + (md.member != null && Number.isFinite(+md.member) ? `<span class="stk-member">JYSK+ ${money(md.member)} ${esc(md.cur === 'BAM' ? 'KM' : md.cur || '')}</span>` : '');
  const factsHtml = [facts ? `<span>${facts}</span>` : '', price].filter(Boolean).join('<span aria-hidden="true"> · </span>');
  return `<div class="stk">
    <div class="stk-top">
      <div class="${known && +a.stock <= 0 ? 'is-bad' : ''}"><b>${known ? whole(a.stock) : '?'}</b><span>${known ? 'na stanju' : 'zaliha nepoznata'}${unit ? ` (${esc(unit)})` : ''}</span></div>
      <div><b>${a.free != null && Number.isFinite(+a.free) ? whole(a.free) : known ? whole(a.stock) : '?'}</b><span>slobodno</span></div>
      <div><b>${waitHist ? '…' : !H || d.sold7 == null ? '?' : whole(d.sold7)}</b><span>prodano 7 dana</span></div>
      <div><b>${sold30 != null ? whole(sold30 || 0) : waitHist ? '…' : !H ? '?' : '0'}</b><span>prodano 30 dana</span></div>
    </div>
    ${smWarn}${daysLine}
    ${factsHtml || st ? `<p class="stk-facts">${st ? regsUi.stBtn(st, num) : ''}${factsHtml}</p>` : ''}${regsUi.stLine(md)}
    ${d.recv ? `<p class="stk-line">Zadnja isporuka ${dmYear(d.recv.t)} (${signed(d.recv.q)})</p>` : ''}
    ${H ? histSlider(num, days, HL.reach, HL.L) : ''}
    ${stockSpark(HL.h, now, days)}
    ${H ? `${rows.length ? `<div class="stk-hist">${(histAllOpen.has(num) ? rows : rows.slice(0, HIST_PREVIEW)).map((x) => `<div><span>${esc(x.day)}</span><span>${esc(x.name)}</span><b class="${x.q < 0 ? 'is-out' : 'is-in'}">${signed(x.q)}</b><span>→ ${whole(x.after)}</span></div>`).join('')}</div>${rows.length > HIST_PREVIEW ? `<button class="text-btn stk-hist-all" type="button" data-hist-all="${esc(num)}">${histAllOpen.has(num) ? 'Prikaži manje' : `Prikaži sve promjene (${rows.length})`}</button>` : ''}` : '<p class="stk-line stk-hist-none">Nema evidentiranih promjena zalihe.</p>'}${d.histCached ? `<p class="stk-line stk-hist-old">Historija očitana ${esc(ageText(d.histAt || c.at))}${c.busy ? ' · osvježavam…' : d.histErr ? ' · osvježavanje nije uspjelo' : ''}</p>` : ''}`
      : d.histErr ? `<p class="stk-line stk-hist-err">Učitavanje historije nije uspjelo. <button class="text-btn" type="button" data-stock-retry="${esc(num)}">Pokušaj ponovo</button></p>`
      : '<p class="stk-line stk-hist-wait"><i class="mj-busy"></i> Učitavam historiju zalihe…</p>'}
    ${regsUi.block(num)}
    ${c.err && !c.busy ? `<p class="stk-line stk-stale">Nije osvježeno: ${c.err === 'login' ? 'StoreFront traži prijavu' : offline() ? 'nema interneta' : 'StoreFront ne odgovara'}. <button class="text-btn" type="button" data-stock-retry="${esc(num)}">Pokušaj ponovo</button></p>` : ''}
    <div class="stk-foot"><small>${c.busy ? '<i class="mj-busy"></i> Osvježavam… · ' : ''}${d.seeded ? 'Iz planograma (StoreFront)' : d.cached ? 'Zadnje očitano na ovom telefonu (StoreFront)' : 'Iz StoreFronta'}, ${esc(ageText(c.at))}</small>${open}</div>
  </div>`;
}

const SMLOG = 'smset-log.json'; // the SM/DM batches record (js/smdm-ui.js writes it, boot reads it)
// ------------------------------------------------ Najprodavanije: the department's best sellers

// created just before boot() (everything it uses exists by then): js/top-soon-ui.js; these forward to it
let topSoonUi = null;
function loadTop(...a) { return topSoonUi.loadTop(...a); }
function onSoonClick(...a) { return topSoonUi.onSoonClick(...a); }
function openSoon(...a) { return topSoonUi.openSoon(...a); }
function openTop(...a) { return topSoonUi.openTop(...a); }
function renderSoon(...a) { return topSoonUi.renderSoon(...a); }
function renderSoonBar(...a) { return topSoonUi.renderSoonBar(...a); }
function renderTop(...a) { return topSoonUi.renderTop(...a); }
function renderTopBar(...a) { return topSoonUi.renderTopBar(...a); }
// ------------------------------------------------ SM i DM: values of the department's articles that go out (21, 81)
// created just before boot() (everything it uses exists by then): js/smdm-ui.js; these forward to it
let smdmUi = null;
let chainUi = null; // js/chain-ui.js (26. 11. 2026): the other codes of the same article on the article screen
/** 26. 11. 2026 (owner: "Pomakni skroz gore tu skicu odma ispod planograma"): the codes branch is its own slot right
 *  under the planogram drawing, before orders and stock; filled when the chain is read. */
const chainBox = (num) => `<div class="chain-box" data-chain="${esc(num)}">${chainUi ? chainUi.html(num) : ''}</div>`;
let regsUi = null; // js/regs-ui.js (24. 11. 2026): statuses, Regulacija codes, the store's adjustments
let regAdjUi = null; // js/reg-adjust-ui.js (2.28): Ostali alati → Regulacija zalihe, sent like StoreFront's own page
function loadAudit(...a) { return smdmUi.loadAudit(...a); }
function loadSm(...a) { return smdmUi.loadSm(...a); }
function onAuClick(...a) { return smdmUi.onAuClick(...a); }
function onSmClick(...a) { return smdmUi.onSmClick(...a); }
function openAudit(...a) { return smdmUi.openAudit(...a); }
function openSm(...a) { return smdmUi.openSm(...a); }
function renderAudit(...a) { return smdmUi.renderAudit(...a); }
function renderSm(...a) { return smdmUi.renderSm(...a); }
function renderSmBar(...a) { return smdmUi.renderSmBar(...a); }
function smJob(...a) { return smdmUi.smJob(...a); }
// ------------------------------------------------ Prijedlozi danas: what is worth doing today
// created just before boot() (everything it uses exists by then): js/tips-ui.js; these forward to it
let tipsUi = null;
function onTipClick(...a) { return tipsUi.onTipClick(...a); }
function openTips(...a) { return tipsUi.openTips(...a); }
function renderTips(...a) { return tipsUi.renderTips(...a); }
function renderTipsBar(...a) { return tipsUi.renderTipsBar(...a); }
// ------------------------------------------------ AR artikli: the weekly rating of the department in MYJYSK
// created just before boot() (everything it uses exists by then): js/ar-ui.js; these forward to it
let arUi = null;
function arBar(...a) { return arUi.arBar(...a); }
function arKept(...a) { return arUi.arKept(...a); }
function arLoad(...a) { return arUi.arLoad(...a); }
function onArClick(...a) { return arUi.onArClick(...a); }
function openAr(...a) { return arUi.openAr(...a); }
function renderAr(...a) { return arUi.renderAr(...a); }
// ------------------------------------------------ planograms from MYJYSK
// created just before boot() (everything it uses exists by then): js/mjplans-ui.js; these forward to it
let mjPlansUi = null;
function afterAutoImport(...a) { return mjPlansUi.afterAutoImport(...a); }
function checkPlans(...a) { return mjPlansUi.checkPlans(...a); }
function planCheckLine(...a) { return mjPlansUi.planCheckLine(...a); }
function planChips(...a) { return mjPlansUi.planChips(...a); }
function planOff(...a) { return mjPlansUi.planOff(...a); }
function startPlanDownload(...a) { return mjPlansUi.startPlanDownload(...a); }
// --------------------------------------------------------------------- home
// created just before boot() (everything it uses exists by then): js/search-ui.js; these forward to it
let searchUi = null;
function renderHome(...a) { return searchUi.renderHome(...a); }
function runSearch(...a) { return searchUi.runSearch(...a); }
// ------------------------------------------------------------------ article
// created just before boot() (everything it uses exists by then): js/article-ui.js; these forward to it
let articleUi = null;
function cropForget(...a) { return articleUi.cropForget(...a); }
function openItem(...a) { return articleUi.openItem(...a); }
function openViewerForItem(...a) { return articleUi.openViewerForItem(...a); }
function renderItem(...a) { return articleUi.renderItem(...a); }
function stopPrefetch(...a) { return articleUi.stopPrefetch(...a); }
// ------------------------------------------------------ barcode not known yet
// created just before boot() (everything it uses exists by then): js/missing-ui.js; these forward to it
let missingUi = null;
function openMissing(...a) { return missingUi.openMissing(...a); }
function renderMissing(...a) { return missingUi.renderMissing(...a); }
// ------------------------------------------------------------------- scanning

function startScan(any = false) {
  // 1.97: one flow per scan: "kamera nije pročitala barkod" / "barkod očitan" / "artikal nije pronađen"
  if (S.scanFlow && S.scanFlow.open) S.scanFlow.end('cancelled', { step: 'novo skeniranje' });
  S.scanFlow = (any || S.plans.length) ? flow.start('scan', 'Skeniranje') : null;
  if (!any && !S.plans.length) {
    toast('Prvo dodaj planograme.');
    return;
  }
  // 1.77: the barcodes the app already knows go with it: such a code is trusted on its first clean read
  let known = '';
  try { const d = eanStore(); known = d && d.m ? Object.keys(d.m).filter((k) => /^\d{8,14}$/.test(k)).slice(0, 20000).join(',') : ''; } catch (e) { known = ''; }
  if (A.scanKnown) A.scanKnown(cfg().vib, known); else if (A.scanWith) A.scanWith(cfg().vib); else A.scan();
  warmStore();
}

/**
 * While the scanner is open, a StoreFront page is made ready in the background (one request, at most once a minute,
 * only when StoreFront is signed in): a barcode that is in no planogram is then looked up on a page that is already
 * open, without the seconds of opening StoreFront.
 */
let warmAt = 0;
function warmStore(always = false) {
  if (!A.storeTask || !(S.user.store && S.user.store.ok) || (!cfg().auto && !always) || Date.now() - warmAt < 60000) return;
  warmAt = Date.now();
  stCall({ mode: 'ping', bg: true, warm: true }, () => {}); // 2.26: only warms (Java answers at once when a page is open)
}

/**
 * The loaded order a scanned barcode names: its digits are the order number (leading zeros aside), or contain a
 * number of 8+ digits as a whole. Article codes (7 digits) and EANs never reach here when they name an article.
 */
function orderByCode(code) {
  const o = S.user.orders;
  const d = String(code || '').replace(/\D/g, '').replace(/^0+/, '');
  if (!o || !o.list || d.length < 6 || /^\d{7}$/.test(String(code).trim())) return null;
  const hits = o.list.filter((x) => {
    const n = String(x.no || '').replace(/\D/g, '').replace(/^0+/, '');
    return n && (n === d || (n.length >= 8 && d.includes(n)));
  });
  return hits.length === 1 ? hits[0] : null;
}

function handleCode(code) {
  const c = String(code || '').trim();
  if (!c) return;
  const known = codes();
  let res = core.resolveCode(S.index, c, known);
  if (!res && eanOf(c)) res = core.resolveCode(S.index, c, { [c.replace(/\s+/g, '')]: eanOf(c) });
  const replace = ['item', 'missing'].includes(top().id);
  // StoreFront 6.2.0: the picking list carries the order's barcode; no article with that code -> that order
  const ord = res ? null : orderByCode(c);
  if (ord) {
    while (S.stack.length > 1) back();
    if (S.mode !== 'orders') setMode('orders');
    S.ordBack = null;
    $('#q').value = ord.no.replace(/\D/g, '');
    runOrdersSearch();
    return;
  }
  // Narudžbe (owner, 13. 11. 2026): a scanned code shows who waits for it, the same as typing it
  const num = res ? res.num : /^\d{7}$/.test(c) ? c : '';
  if (S.mode === 'orders' && top().id === 'home' && num) { S.ordBack = null; $('#q').value = num; runOrdersSearch(); return; }
  const sfl = S.scanFlowOpen; S.scanFlowOpen = null;
  if (res) { if (sfl) sfl.end('ok', { step: `artikal otvoren (${res.via})` }); openItem(res.num, { via: res.via, code: c, from: res.from }, { replace }); return; }
  // 1.96 (owner, VIDAR): a barcode linked to an article that is in no planogram on the phone opens that article
  // (StoreFront's view of it, "Promijeni vezu"), not "Poveži ovaj barkod" again
  const ln = known[c.replace(/\s+/g, '')];
  if (ln && /^\d{4,7}$/.test(ln)) { if (sfl) sfl.end('ok', { step: 'povezan artikal van planograma' }); S.missLinked = { num: ln, code: c.replace(/\s+/g, '') }; openMissing(ln, { replace }); return; }
  if (sfl) sfl.end('not_found', { step: 'barkod očitan, artikal nije pronađen na telefonu' });
  openMissing(c, { replace });
}

window.onStorefront = (r) => {
  checkOnline();
  sfWhoAt = Date.now(); // #25: the store may have been changed there
  if (searchUi && searchUi.sfsForget) searchUi.sfsForget();
  const t = top();
  if (r && r.org) S.user.sfOrg = String(r.org).slice(0, 10);
  if (r && r.page === 'refilling' && typeof r.fields === 'string' && r.fields) { S.user.sfRefillFields = { at: Date.now(), f: r.fields.slice(0, 1800) }; saveUser(); }
  if (r && t.id === 'missing' && r.query === t.state && S.storeCb) S.storeCb(r);
  // 1.96: back from StoreFront's sign-in that Punjenje asked for: the prepared entry again, on the chosen list
  if (S.refillPending && refillUi) refillUi.resumePending();
};

window.onOrders = (r) => {
  checkOnline();
  S.ordReading = false;
  if (autoSync) autoSync.manualOrders();
  // 1.97: an empty list is not a reading that stopped half way (flow log)
  try {
    const n = r && Array.isArray(r.orders) ? r.orders.length : 0;
    if (!r || r.how === 'cancelled') flow.one('orders', 'Čitanje narudžbi', 'prekinuto', 'cancelled');
    else if (r.how === 'ok') flow.one('orders', 'Čitanje narudžbi', n ? `pročitano ${n} narudžbi` : 'pročitano: nema narudžbi', 'ok', { n });
    else flow.one('orders', 'Čitanje narudžbi', `stalo na pola: ${n} pročitano`, r.how === 'limited' ? 'incomplete' : n ? 'incomplete' : 'network', { n, why: String(r.how || '').slice(0, 20) });
  } catch (e) { /* ignore */ }
  if (!r || r.how === 'cancelled' || !Array.isArray(r.orders)) return;
  // audit 13. 11. 2026: which fields StoreFront's order answers carry (names and digit shapes only, OrdersActivity)
  if (typeof r.fields === 'string' && r.fields) S.user.sfFields = { at: r.at || Date.now(), f: r.fields.slice(0, 1800) };
  const prevList = (S.user.orders && S.user.orders.list) || [];
  const prev = new Map(prevList.map((x) => [x.no, x]));
  const fresh = r.orders.map((x) => {
    const old = prev.get(x.no) || {};
    const made = orderTime.keepTime(x.made, old.made);
    // the kind of the history entry goes with the time that is kept (14. 11. 2026)
    const madeType = made && made === x.made ? x.madeType : made && made === old.made ? old.madeType : undefined;
    // 25. 11. 2026: the Java side of this reading keeps only the fields it knows: the value (amt), the comment flag
    // (cm), the groups of delivery (dgn) and the moment of creation (mk) come from the automatic reading and are kept
    // here (the background reading that follows this one makes them fresh). The history of an order that was not read
    // this time (a failed request, the slow reader) keeps its description: never a reservation lost by a reading.
    const keep = {};
    const amt = Number.isInteger(x.amt) ? x.amt : old.amt;
    if (Number.isInteger(amt)) keep.amt = amt;
    const cm = typeof x.cm === 'boolean' ? x.cm : old.cm;
    if (typeof cm === 'boolean' && !(x.made || x.note)) keep.cm = cm;
    if (old.dgn && !Number.isInteger(x.amt)) keep.dgn = old.dgn;
    if (Number.isFinite(old.mk) && made && made === old.made) keep.mk = old.mk;
    const histRead = !!(x.made || x.note);
    const note = x.note || (histRead ? undefined : old.note);
    const { note: _n, ...rest } = x;
    return { ...rest, ...keep, ...(note ? { note } : {}), items: x.items || old.items || null,
      receiptCreated: orderTime.keepTime(x.receiptCreated, old.receiptCreated),
      orderCreated: orderTime.keepTime(x.orderCreated, old.orderCreated),
      made, ...(madeType ? { madeType } : {}) };
  });
  if (r.how === 'ok') {
    // 2.15 audit: which tabs this reading had (a look with other tabs marks nothing "Nova"); a reading the
    // employee asked for is also a sign-in again
    S.user.orders = { at: r.at || Date.now(), list: orderTime.sorted(fresh), tabs: TABS_ALL.filter((k) => cfg().tabs[k]).join(','), ...(S.user.orders && S.user.orders.vAt ? { vAt: S.user.orders.vAt } : {}) };
    delete S.user.sfSignedOut;
    const withItems = fresh.filter((x) => x.items).length;
    toast(`Narudžbe osvježene: ${fresh.length} (${withItems} s artiklima)`);
    S.site = null;
    setTimeout(syncWatch, 0);
    // 2.15: StoreFront's own tab numbers and the store of this reading, for the background look and the automatic one
    stCall({ mode: 'watch', bg: true }, (w) => {
      const o = S.user.orders;
      if (!o || !w || w.how !== 'ok' || !w.res) return;
      if (w.res.tot) o.tot = w.res.tot;
      if (w.res.store) o.store = w.res.store;
      saveUser();
      syncWatch();
    });
    // 25. 11. 2026: the values (and the comment flags) of this very list, once, in the background: StoreFront's lists
    // only (~40 kB; the history is not read again). A value that changed in StoreFront is not shown stale for long.
    // If a reading is on its way, this one waits for it (js/auto-sync.js: never two at once, never again by itself).
    if (autoSync) setTimeout(() => autoSync.runOrders('amounts'), 0); // part of the employee's own Osvježi, also with automatic readings off
  } else if (fresh.length) {
    const seen = new Set(fresh.map((x) => x.no));
    // 25. 11. 2026: the sums say that this list is not whole (until a whole reading)
    const was = S.user.orders || {};
    S.user.orders = { at: was.at || r.at || Date.now(), list: orderTime.sorted([...fresh, ...prevList.filter((x) => !seen.has(x.no))]), part: true, ...(was.vAt ? { vAt: was.vAt } : {}), ...(was.store ? { store: was.store } : {}) };
    toast(r.how === 'limited' ? 'Prikazujem do 400 narudžbi iz ovog čitanja. Suzi izbor kartica u Postavkama.' : 'Pročitan je samo dio narudžbi. Pokušaj opet osvježiti.');
  } else {
    toast('Nisam uspio pročitati narudžbe. Provjeri prijavu u StoreFront.');
  }
  saveUser();
  const t = top();
  if (t.id === 'home') renderHome();
  else if (t.id === 'item' && S.item) renderItem();
};

window.onScan = (r) => {
  const sfl = S.scanFlow; S.scanFlow = null;
  if (sfl) {
    if (!r) sfl.end('not_read', { step: 'skener zatvoren bez očitanja' });
    else if (r.manual) sfl.end('cancelled', { step: 'izabran ručni unos' });
    else sfl.step('barkod očitan', 'ok', { why: String(r.format || '').replace(/[^A-Z0-9_]/g, '').slice(0, 12) });
  }
  // 1.96: a window that asked for a code (Punjenje: Skeniraj) gets it; nothing else opens
  if (S.scanFor) { const f = S.scanFor; S.scanFor = null; if (sfl && r && !r.manual) sfl.end('ok', { step: 'predano Punjenju' }); f(r && !r.manual ? r.code : null); return; }
  if (r && !r.manual && sfl) S.scanFlowOpen = sfl;
  if (!r) return;
  if (r.manual) {
    while (S.stack.length > 1) back();
    const q = $('#q');
    q.value = '';
    runSearch();
    setTimeout(() => q.focus(), 60);
    return;
  }
  handleCode(r.code);
};

// ------------------------------------------------------------------- sheet

const sheet = { dismissible: true, resolve: null, cancel: null };

function openSheet({ title, body = '', actions = [], dismissible = true, cls = '' }) {
  sheet.dismissible = dismissible;
  sheet.cancel = null;
  $('#sheet').className = `sheet${cls ? ` ${cls}` : ''}`; // a sheet of its own kind (the first-run steps) never leaks into the next one
  $('#sheetTitle').textContent = title;
  $('#sheetBody').innerHTML = body;
  delete $('#sheetBody').dataset.html;
  $('#sheet').style.minHeight = '';
  const box = $('#sheetActions');
  box.innerHTML = '';
  for (const a of actions) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `btn btn-block ${a.kind || ''}`;
    b.textContent = a.label;
    b.addEventListener('click', () => a.onClick && a.onClick());
    box.appendChild(b);
  }
  $('#scrim').hidden = false;
  $('#sheet').hidden = false;
}

function closeSheet() {
  $('#scrim').hidden = true;
  $('#sheet').hidden = true;
  $('#sheet').className = 'sheet';
  sheet.cancel = null;
  if (sheet.resolve) { const r = sheet.resolve; sheet.resolve = null; r(null); }
}

function ask(title, body, choices) {
  return new Promise((resolve) => {
    openSheet({
      title,
      body,
      dismissible: false,
      actions: choices.map((c) => ({
        label: c.label,
        kind: c.kind,
        onClick: () => { sheet.resolve = null; closeSheet(); resolve(c.value); },
      })),
    });
    sheet.resolve = resolve;
  });
}

// opts.cancel (1.73-test3): a wait that may not end (a server that does not answer) gets "Prekini", and the back button
// does the same; without it the sheet could only be left by closing the app
function progress(title, frac, line, opts = null) {
  const pct = Math.round(Math.max(0, Math.min(1, frac)) * 100);
  S.prog = { title, pct, line };
  // the import goes on while the employee works (1.69): a slim bar on the start screen instead of the sheet
  if (S.importBg && S.busy) { importBar(title, pct, line); return; }
  if ($('#sheet').hidden || !$('#sheetBody .progress')) {
    openSheet({ title, body: '<div class="progress"><i></i></div><p class="prog-line" id="progLine"></p>', dismissible: false });
  }
  if (opts && opts.cancel) {
    sheet.cancel = opts.cancel;
    if (!$('#sheetActions [data-cancel]')) {
      const bt = document.createElement('button');
      bt.type = 'button';
      bt.className = 'btn btn-block btn-quiet';
      bt.dataset.cancel = '1';
      bt.textContent = 'Prekini';
      bt.addEventListener('click', () => { const f = sheet.cancel; if (f) f(); });
      $('#sheetActions').appendChild(bt);
    }
  }
  if (S.busy && !$('#sheetActions [data-bg]')) {
    const bt = document.createElement('button');
    bt.type = 'button';
    bt.className = 'btn btn-block btn-quiet';
    bt.dataset.bg = '1';
    bt.textContent = 'Radi dalje dok se uvozi';
    bt.addEventListener('click', () => { S.importBg = true; closeSheet(); importBar(S.prog.title, S.prog.pct, S.prog.line); });
    $('#sheetActions').appendChild(bt);
  }
  $('#sheetTitle').textContent = title;
  $('#sheetBody .progress i').style.width = pct + '%';
  $('#progLine').textContent = line || '';
}

const queue = []; // (js/import.js reads it) { list, target } picked or shared PDFs waiting to be read
// ------------------------------------------------------------------- import
// created just before boot() (everything it uses exists by then): js/import.js; these forward to it
let importUi = null;
function addPlanograms(...a) { return importUi.addPlanograms(...a); }
function drainImports(...a) { return importUi.drainImports(...a); }
function importBar(...a) { return importUi.importBar(...a); }
function refreshOld(...a) { return importUi.refreshOld(...a); }
function repairPictures(...a) { return importUi.repairPictures(...a); }
function showResults(...a) { return importUi.showResults(...a); }
// -------------------------------------------------------------- planograms

/** The first page of the planogram that belongs to a section (the chip's section), or the first page. */
function sectionPage(p, s) {
  const secs = (p.plan && p.plan.meta && p.plan.meta.sections) || [];
  const pages = (p.plan && p.plan.pages) || [];
  const i = pages.findIndex((pg) => pg.sec >= 0 && secs[pg.sec] && secs[pg.sec].code === s.code && secs[pg.sec].name === s.name);
  return i < 0 ? 0 : i;
}

/**
 * The list of articles to sell out as the small print of a planogram card: how many have status 21 / 81 (and are in
 * stock), and which. It is the department's list, the same numbers as on the list screen: such an article is often
 * not on the planogram at all (it comes off the shelf when a new planogram arrives), so the planogram's own articles
 * would be the wrong count. `view` is clrView(false): Christmas / New Year articles stay hidden here as everywhere.
 * null = no list for this planogram: it is read for one product group only, the department's own.
 */
function planClear(p, view) {
  const c = clrSrc('home');
  const dept = p.plan && p.plan.meta && p.plan.meta.dept ? parseInt(p.plan.meta.dept.code, 10) : NaN;
  if (dept !== parseInt((c && c.group) || cfg().group, 10)) return null;
  if (!c || !c.list) return { wait: true };
  return { c, by: c.st.map((st) => ({ st, rows: view.list.filter((x) => x.st === st).sort((a, b) => a.num.localeCompare(b.num)) })) };
}

/** The small print under a planogram's name: "5 artikala sa statusom 21 na zalihi", then their numbers. */
function planClearHtml(p, view) {
  const r = planClear(p, view);
  if (!r) return '';
  if (r.wait) {
    return `<div class="plan-st"><p class="plan-st-src">Artikli sa statusom ${clrStatuses().join(' i ')} još nisu učitani · <button class="code-more" type="button" data-open-clear="1">Učitaj</button></p></div>`;
  }
  // audit 13. 11. 2026: the numbers first; the codes open on a tap. A code is called "na ovom planogramu" only when this
  // planogram's own index has it (the list is the department's, most of it is not on the drawing any more)
  const here = (num) => (S.index.byNum.get(num) || []).some((e) => e.id === p.id);
  const lines = r.by.filter((g) => g.rows.length).map((g) => {
    const key = `${p.id}|${g.st}`;
    const open = S.planMore.has(key);
    const onPlan = g.rows.filter((x) => here(x.num));
    const rows = open ? [...onPlan, ...g.rows.filter((x) => !here(x.num))] : [];
    const code = (x) => (here(x.num)
      ? `<button class="code-link is-here" type="button" data-num="${esc(x.num)}" aria-label="${esc(x.num)}, na ovom planogramu">${esc(x.num)}</button>`
      : `<button class="code-link" type="button" data-store="${esc(x.num)}">${esc(x.num)}</button>`);
    return `<div class="plan-st-line is-st${esc(g.st)}">
      <button class="plan-st-n" type="button" data-codes-more="${esc(key)}" aria-expanded="${open}"><span><b>${g.rows.length}</b> ${plural(g.rows.length, 'artikal', 'artikla', 'artikala')} sa statusom ${esc(g.st)} na zalihi${onPlan.length ? ` · <b>${onPlan.length}</b> na ovom planogramu` : ''}</span><span class="code-more">${open ? 'Sakrij šifre' : 'Prikaži šifre'}</span></button>
      ${open ? `<div class="plan-codes">${rows.map(code).join('')}</div>${onPlan.length ? '<p class="plan-st-src">Plavo: na ovom planogramu (otvara artikal). Ostale: StoreFront.</p>' : ''}` : ''}
    </div>`;
  });
  const none = lines.length ? '' : `<p class="plan-st-none">Nema artikala sa statusom ${esc(r.c.st.join(' ni '))} na zalihi</p>`;
  const partial = (r.c.limited || []).length || (r.c.short || []).length ? ' · lista nije cijela' : '';
  return `<div class="plan-st">${lines.join('')}${none}<p class="plan-st-src">Iz liste za rasprodaju · ${esc(ageText(r.c.at))}${partial} · <button class="code-more" type="button" data-open-clear="1">Otvori listu</button></p></div>`;
}

function renderPlans() {
  const body = $('#plansBody');
  let h = `<div class="plans-top">
    ${mjOn() ? `<button class="orders-bar" type="button" data-plcheck>${icon('refresh')}<span><b>Provjeri nove planograme</b><small>${esc(planCheckLine())}</small></span><span class="go">Provjeri</span></button>` : ''}
    <button class="btn btn-primary btn-block" type="button" data-add>${icon('plus')}Dodaj planograme</button>
    <p class="hint">Kad stigne novi planogram, samo ga dodaj. Jysk Reloaded prepozna isti odjel, zamijeni stari i pokaže šta se promijenilo.</p>
  </div>`;
  if (!S.plans.length) h += '<p class="empty">Još nema planograma.</p>';
  const sorted = S.plans.slice().sort((a, b) => a.title.localeCompare(b.title, 'bs'));
  const view = clrView(false, clrSrc('home'));
  for (const p of sorted) {
    const ch = S.user.changes[p.id];
    const chN = ch ? ch.added.length + ch.removed.length + ch.moved.length : 0;
    const code = /^(\d{2})\b/.exec(p.title);
    const name = p.title.replace(/^\d{2}\s+/, '');
    h += `<article class="plan">
      <h3 class="plan-h"><button class="plan-head" type="button" data-open-plan="${esc(p.id)}" data-page="0" aria-label="Otvori planogram ${esc(name)}">
        <span class="plan-tile">${esc(code ? code[1] : p.title.slice(0, 2))}</span>
        <span class="plan-ttl"><span class="plan-name">${esc(name)}</span>${p.deadline ? `<span class="plan-due">Rok za postavku: ${esc(core.deadlineLabel(p.deadline))}</span>` : ''}</span>
        ${icon('chev', 'chev')}
      </button></h3>
      ${planClearHtml(p, view)}
      <div class="secs">${p.sections.map((s) => `<button class="sec" type="button" data-open-plan="${esc(p.id)}" data-page="${sectionPage(p, s)}"><b>${esc(s.code)}</b>${esc(s.name)}</button>`).join('')}</div>
      <div class="stats">
        <div class="stat"><b>${p.count}</b><span>${plural(p.count, 'artikal', 'artikla', 'artikala')}</span></div>
        <div class="stat"><b>${p.pictures || 0}</b><span>sa slikom</span></div>
        <div class="stat"><b>${p.pages}</b><span>${plural(p.pages, 'stranica', 'stranice', 'stranica')}</span></div>
      </div>
      <p class="plan-foot">${p.concept ? `${esc(p.concept)}, ` : ''}uvezeno ${esc(dateBs(p.imported))}</p>
      <div class="plan-actions">
        <button class="btn btn-small btn-soft" type="button" data-replace="${p.id}">${icon('swap')}Zamijeni novijim</button>
        ${chN ? `<button class="btn btn-small btn-soft" type="button" data-changes="${p.id}">${icon('list')}Promjene (${chN})</button>` : ''}
        <button class="btn btn-small btn-danger" type="button" data-delete="${p.id}">${icon('trash')}Obriši</button>
      </div>
    </article>`;
  }
  const learned = Object.keys(S.user.learned).length;
  if (learned) h += `<p class="hint" style="margin:6px 4px 0">Povezanih barkodova: ${learned}. Pamte se i kad zamijeniš planogram.</p>`;
  body.innerHTML = h;
}

async function deletePlan(id) {
  const p = S.plans.find((x) => x.id === id);
  if (!p) return;
  if (S.busy) { toast('Sačekaj da se završi uvoz planograma.'); return; }
  const ok = await ask(`Obrisati ${p.title}?`, '<p>Artikli iz ovog planograma više se neće pronalaziti. PDF ostaje tamo odakle si ga uvezao.</p>',
    [{ label: 'Obriši', value: true, kind: 'btn-danger' }, { label: 'Odustani', value: false, kind: 'btn-quiet' }]);
  if (!ok) return;
  S.plans = S.plans.filter((x) => x.id !== id);
  delete S.user.changes[id];
  dropFiles(id);
  savePlansList();
  saveUser();
  rebuildIndex();
  renderPlans();
  renderHome();
  toast(`${p.title} je obrisan.`);
}

// ------------------------------------------------------------------ changes

function renderChanges(id) {
  const ch = S.user.changes[id];
  const p = S.plans.find((x) => x.id === id);
  $('#changesTitle').textContent = p ? `Promjene: ${p.title}` : 'Promjene';
  if (!ch) { $('#changesBody').innerHTML = '<p class="empty">Nema zapisanih promjena.</p>'; return; }
  const pl = (x, old = false) => pills(x && x[0] ? x[0] : null).replace('class="pills"', `class="pills${old ? ' is-old' : ''}"`);
  const row = (x, kind) => {
    const known = S.index.byNum.has(x.num);
    const where = kind === 'moved'
      ? `<span class="move">${pl(x.from, true)}${icon('arrow')}${pl(x.to)}</span>`
      : pl(kind === 'added' ? x.to : x.from, kind === 'removed');
    return `<button class="item" type="button" ${known ? `data-num="${esc(x.num)}"` : 'disabled'}>
      ${thumb(x.num)}
      <span class="item-main"><span class="code">${esc(x.num)}</span><span class="item-name">${esc(x.nm) || 'Bez naziva'}</span>${where}</span>
    </button>`;
  };
  const group = (title, list, kind) => (list.length ? `<section class="chg-group"><div class="sec-head"><h3>${title}</h3><span class="count-line" style="margin:0">${list.length}</span></div><div class="list">${list.map((x) => row(x, kind)).join('')}</div></section>` : '');
  const when = ch.from && ch.to && ch.from !== ch.to
    ? `Rok ${esc(core.deadlineLabel(ch.from))} → ${esc(core.deadlineLabel(ch.to))}, zamijenjeno ${esc(dateBs(ch.at))}`
    : `Zamijenjeno ${esc(dateBs(ch.at))}`;
  $('#changesBody').innerHTML = `<p class="chg-when">${when}</p>${group('Premješteni', ch.moved, 'moved')}${group('Novi', ch.added, 'added')}${group('Izbačeni', ch.removed, 'removed')}`;
}

// ------------------------------------------------------------------- viewer

// ------------------------------------------- pictures of whole planogram pages
//
// Drawing a planogram page from its PDF takes a second or more on a phone. Every page is drawn once, kept as a
// picture next to the article pictures (thumbs/<id>-p/) and shown from there afterwards; pages not kept yet are
// drawn quietly in the background while the app is open and nothing else is being read.
const pageCache = (() => {
  const FILE = 'pagecache.json';
  let man = null; // plan id -> { tag, have: { pageIndex: 'webp' | 'jpg' } }
  let full = false; // the phone refused to keep more
  let running = false;
  let hold = 0; // the viewer is drawing a page from the PDF
  const near = []; // [id, page] pages next to the one on screen: drawn first
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const get = () => man || (man = store.read(FILE, {}) || {});
  const save = debounce(() => store.write(FILE, get()), 1000);
  const dir = (id) => `${id}-p`;
  const dpr = () => Math.min(window.devicePixelRatio || 1, 2);
  /** Width the page is drawn at, in CSS px: sharp enough for a first zoom, the same for every page on this phone. */
  const cssW = () => Math.min(Math.min(screen.width || 400, screen.height || 400) * 1.9, 3600 / dpr());
  const tagOf = (p) => `${Number(p.imported || 0).toString(36)}-${Math.round(cssW() * dpr())}`;

  function entry(p) {
    const m = get();
    const tag = tagOf(p);
    if (!m[p.id] || m[p.id].tag !== tag) {
      if (m[p.id]) A.removeThumbs(dir(p.id)); // drawn for another screen size: draw again
      m[p.id] = { tag, have: {} };
    }
    return m[p.id];
  }
  const plan = (id) => S.plans.find((x) => x.id === id);
  const has = (id, i) => { const p = plan(id); return !!p && !!entry(p).have[i]; };
  const url = (id, i) => { const p = plan(id); const e = entry(p); return `/files/thumbs/${dir(id)}/pg${i}-${e.tag}.${e.have[i]}`; };

  /** The kept picture of a page, decoded, or null. */
  async function load(id, i) {
    if (!has(id, i)) return null;
    const img = new Image();
    img.src = url(id, i);
    try {
      await img.decode();
      return img;
    } catch (e) {
      const p = plan(id);
      if (p) { delete entry(p).have[i]; save(); } // gone from the phone: drawn again
      return null;
    }
  }

  const toBlob = (c, type, q) => new Promise((r) => c.toBlob(r, type, q));

  /** Keeps a page drawn at cssW() (the viewer's base canvas or a background one). */
  async function keep(id, i, canvas) {
    const p = plan(id);
    if (!p || full || entry(p).have[i]) return;
    try {
      let blob = await toBlob(canvas, 'image/webp', 0.8);
      let ext = 'webp';
      if (!blob || blob.type !== 'image/webp') { blob = await toBlob(canvas, 'image/jpeg', 0.85); ext = 'jpg'; }
      if (!blob) return;
      const e = entry(p);
      const b64 = await blobToBase64(blob);
      if (!plan(id) || entry(p) !== e) return; // deleted or replaced meanwhile
      if (!A.writeThumb(dir(id), `pg${i}-${e.tag}.${ext}`, b64)) { full = true; return; }
      e.have[i] = ext;
      save();
    } catch (err) {
      console.warn('pageCache', err);
    }
  }

  async function draw(id, i) {
    const p = plan(id);
    const pg = p && p.plan.pages[i];
    if (!pg) return;
    const doc = await docs.openPlan(id);
    const c = document.createElement('canvas');
    const w = cssW();
    await docs.renderRegion(doc, i + 1, [0, 0, pg.w, pg.h], c, w, (w * pg.h) / pg.w, { maxDpr: 2 });
    await keep(id, i, c);
    c.width = 1;
    docs.release(id, i + 1); // drawn and kept as a picture: pdf.js needs nothing more of it now
    c.height = 1;
  }

  /** What to draw next: pages next to the one on screen, then (only away from articles and the viewer) all others. */
  function next() {
    while (near.length) {
      const [id, i] = near.shift();
      const p = plan(id);
      if (p && i >= 0 && i < p.plan.pages.length && !entry(p).have[i]) return [id, i];
    }
    // Generating every page of every PDF immediately after login contends with
    // StoreFront and can push WebView over its bitmap budget (black PDF syndrome).
    // Only pre-render requested neighbouring pages; all others render on demand.
    return null;
  }

  async function loop() {
    if (running) return;
    running = true;
    try {
      for (let idle = 0, hid = 0; idle < 40 && !full; ) {
        // the app in the background: stop after half a minute instead of waking every 1.5 s until it comes back
        // (appResume starts it again)
        if (document.hidden) { if (++hid > 20) break; await sleep(1500); continue; }
        hid = 0;
        if (S.busy || hold) { await sleep(1500); continue; }
        const job = next();
        if (!job) {
          if (top().id !== 'item' && top().id !== 'viewer') break; // all done
          idle++;
          await sleep(1500); // waiting for the employee to leave the article or the viewer
          continue;
        }
        idle = 0;
        try {
          await draw(job[0], job[1]);
        } catch (e) {
          // the PDF was closed by another screen or the page cannot be drawn: tried again next time
          await sleep(1000);
        }
        await sleep(near.length ? 30 : 250);
      }
    } finally {
      running = false;
    }
  }

  return {
    cssW, has, load, keep,
    start() { if (!full && near.length) setTimeout(loop, 0); },
    /** The viewer shows page i: the pages before and after it are drawn first. */
    around(id, i) {
      near.length = 0;
      near.push([id, i + 1], [id, i - 1], [id, i + 2]);
      if (!full) loop();
    },
    holdOn() { hold++; },
    holdOff() { hold = Math.max(0, hold - 1); },
    drop(id) {
      const m = get();
      if (m[id]) { delete m[id]; save(); }
      A.removeThumbs(dir(id));
    },
    /** Warms the browser's picture cache, so the next page appears at once. */
    warm(id, i) { if (has(id, i)) { const img = new Image(); img.src = url(id, i); } },
  };
})();

// Stock badges belong to the rendered PDF VIEW, not to the source PDF bytes.
// 1.73: they are laid out in PAGE coordinates, each one anchored just above its own article code, and keep one size on
// screen through CSS (--k = 1/zoom). Panning moves them with the page and never lays them out again; a pinch keeps them
// on their codes; only a new zoom level or new data lays them out again. Unknown is never zero; linked codes come only
// from StoreFront's substitution chain; what was read is kept on the phone and shown as old (*) when it is.
const planogramStock = (() => {
  const cache = new Map(); // article -> { stock, free, st, name, price, cur, at, error, priceAt }; never confuse unknown with zero
  const links = new Map(); // article -> { l: [{ num, st }], at, limited, fail }: StoreFront's substitution chain
  const busy = new Set();
  const AGE = 180000; // read again when a page is opened and the value is older than this
  const OLD = 15 * 60000; // shown as old from here on (and at once when the last reading failed or there is no network)
  const LINK_AGE = 3 * 86400000; // a chain is asked again after 3 days (replacements change rarely)
  const LINK_RETRY = 10 * 60000; // a chain that could not be read is asked again after 10 min
  const KEEP = 3 * 86400000; // what is older is not kept on the phone
  const MAX = 2500;
  const FILE = 'stock-cache.json';
  let io = null, saveTimer = 0, isOffline = () => false, log = () => {}, verify = 0, searchOnly = false;
  const ok7 = (n) => /^\d{7}$/.test(String(n));

  function labels(plan, page) {
    if (!plan || !plan.pages || !plan.pages[page]) return [];
    const seen = new Set(), result = [];
    // Imported planograms store placements in plan.items[num].oc (drawing)
    // and .rw (table), NOT in plan.pages[].labels/rows (temporary import data).
    for (const [num, item] of Object.entries(plan.items || {})) {
      if (!/^\d{7}$/.test(num)) continue;
      for (const pos of [...(item.oc || []), ...(item.rw || [])]) {
        // 1.77 (#18): a code's own box when the reader knows it (two codes of one label each have theirs)
        const b = Array.isArray(pos.n) && pos.n.length === 4 && pos.n.every(Number.isFinite) ? pos.n : pos.b;
        if (+pos.p !== page || !Array.isArray(b) || b.length !== 4 ||
            !b.every(Number.isFinite)) continue;
        const key = num + '|' + b.join(',');
        if (!seen.has(key)) {
          seen.add(key);
          // 1.80: codes printed in ONE label of the PDF (pos.m, the same label box pos.b) share one badge (layout)
          const g = pos.m && Array.isArray(pos.b) && pos.b.length === 4 ? pos.b.join(',') : '';
          result.push({ num, b, ...(pos.chk ? { chk: 1 } : {}), ...(g ? { g } : {}) });
        }
      }
    }
    return result;
  }

  /** The kept values come back after a restart: shown at once (marked old when they are), read again when possible. */
  // note: a line for the diagnostics; check: TEST builds compare the new reading with the old one for a few articles
  function attach(storeApi, offlineFn, note = null, check = false) {
    io = storeApi;
    if (offlineFn) isOffline = offlineFn;
    if (note) log = note;
    // the first jobs of a session: 4 articles each read both ways (TEST: 3 jobs; the real app: the first one). Where
    // the master data's stock differs from the search's, this session reads with the search (as before 1.73).
    verify = check ? 3 : 1;
    let d = null;
    try { d = io.read(FILE, null); } catch (e) { d = null; }
    if (!d || d.v !== 1) return;
    store = typeof d.w === 'string' ? d.w.slice(0, 12) : ''; // the store these values are of (1.76; older files: none)
    const now = Date.now();
    for (const [n, x] of Object.entries(d.s || {})) {
      if (ok7(n) && x && Number.isFinite(x.stock) && Number.isFinite(x.at) && now - x.at < KEEP && !cache.has(n)) cache.set(n, { ...x, error: false });
    }
    for (const [n, at] of Object.entries(d.g || {})) {
      if (ok7(n) && Number.isFinite(at) && now - at < GONE_MS && at <= now && !cache.has(n)) cache.set(n, { at, error: true, gone: at });
    }
    for (const [n, x] of Object.entries(d.l || {})) {
      if (ok7(n) && x && Array.isArray(x.l) && Number.isFinite(x.at) && now - x.at < LINK_AGE && !links.has(n)) {
        links.set(n, { l: x.l.filter((e) => e && ok7(e.num)).slice(0, 5).map((e) => ({ num: String(e.num), st: String(e.st || '').slice(0, 3) })), at: x.at, limited: !!x.limited });
      }
    }
  }
  // 1.76: how often what can be shown changed (every change is followed by save()): the viewer lays the badges out
  // again only when this moved, not for an answer that brought nothing new (a pan over fresh codes)
  let ver = 0;
  function save() {
    ver++;
    if (!io || saveTimer) return;
    saveTimer = setTimeout(() => {
      saveTimer = 0;
      const now = Date.now(), s = {}, l = {};
      const known = [...cache.entries()].filter(([, x]) => Number.isFinite(x.stock) && now - x.at < KEEP).sort((a, b) => b[1].at - a[1].at);
      for (const [n, x] of known.slice(0, MAX)) {
        s[n] = { stock: x.stock, free: x.free, at: x.at, ...(x.st ? { st: x.st } : {}), ...(x.name ? { name: String(x.name).slice(0, 50) } : {}),
          ...(x.price != null ? { price: x.price, cur: x.cur, ...(Number.isFinite(x.pAt) ? { pAt: x.pAt } : {}) } : {}) };
      }
      for (const [n, x] of [...links.entries()].filter(([, x]) => !x.fail).sort((a, b) => b[1].at - a[1].at).slice(0, MAX)) l[n] = { l: x.l, at: x.at, ...(x.limited ? { limited: true } : {}) };
      // the memory stays bounded too: the oldest go first
      if (cache.size > MAX * 1.5) for (const [n] of [...cache.entries()].sort((a, b) => (a[1].at || 0) - (b[1].at || 0)).slice(0, cache.size - MAX)) cache.delete(n);
      if (links.size > MAX * 1.5) for (const [n] of [...links.entries()].sort((a, b) => a[1].at - b[1].at).slice(0, links.size - MAX)) links.delete(n);
      const g = {}; // 2.03: codes StoreFront said it does not have (not asked again for GONE_MS, also after a restart)
      for (const [n, x] of cache.entries()) if (goneNow(x, now) && Object.keys(g).length < MAX) g[n] = x.gone;
      try { io.write(FILE, { v: 1, s, l, ...(Object.keys(g).length ? { g } : {}), ...(store ? { w: store } : {}) }); } catch (e) { /* the phone is full: kept in memory only */ }
    }, 4000);
  }

  /** The linked codes of an article from StoreFront's substitution chain, when that chain was read (and is fresh). */
  function linksOf(num) {
    const x = links.get(num);
    return x && !x.fail && Date.now() - x.at < LINK_AGE ? x : null;
  }
  /**
   * The linked codes of an article, each with its OWN stock, in StoreFront's chain order: { count, known, unknown,
   * nums, vals: [stock or null], top: the largest known one or null, limited }, or null (none, or not asked yet).
   * 22. 11. 2026 (owner: "Nemoj automatski sabirati njihove zalihe. Prikaži ih odvojeno"): never added up (1.73-2.22
   * showed "5 / 7" for two linked codes of 3 and 4). Only StoreFront's substitution chain links codes.
   */
  function linked(num) {
    const x = linksOf(num);
    if (!x || !x.l.length) return null;
    const vals = x.l.map((e) => { const c = cache.get(e.num); return c && Number.isFinite(c.stock) ? c.stock : null; });
    const k = vals.filter((v) => v != null);
    return { count: vals.length, known: k.length, unknown: vals.length - k.length, nums: x.l.map((e) => e.num), vals,
      top: k.length ? Math.max(...k) : null, limited: !!x.limited };
  }
  /**
   * What stands on the place, for its colour and the "0" / "0–3" filters: the largest single stock of the code and
   * its linked codes (each read on its own, never a sum: 22. 11. 2026); null while the code itself is not read.
   * 0 here and 4 under a linked code is not "nothing here" (as since 1.73).
   */
  function standing(num) {
    const c = cache.get(num);
    if (!c || !Number.isFinite(c.stock)) return null;
    const l = linked(num);
    return l && l.top != null ? Math.max(c.stock, l.top) : c.stock;
  }
  /** The linked codes' values for a badge or a line: "3 / ?" (unknown is "?", never 0); at most `max`, "+" for more. */
  function linkedText(l, sep, max = 3) {
    if (!l) return '';
    return l.vals.slice(0, max).map((v) => (v == null ? '?' : String(v))).join(sep) + (l.count > max || l.limited ? '+' : '');
  }
  /** Of these articles, the ones whose chain is still to be asked. */
  function needLinks(nums) {
    const now = Date.now();
    return [...new Set(nums)].filter((n) => {
      if (!ok7(n)) return false;
      const x = links.get(n);
      return !x || (x.fail ? now - x.at >= LINK_RETRY : now - x.at >= LINK_AGE);
    });
  }
  /** A relatedstock answer: the chain of each asked article, and the stock of its linked codes (unknown stays unknown). */
  function learnLinks(list, asked) {
    const now = Date.now();
    const by = new Map((list || []).map((x) => [String(x.num), x]));
    for (const n of asked) {
      const x = by.get(String(n));
      if (!x || x.error || !Array.isArray(x.linked)) {
        const old = links.get(n);
        if (!old || old.fail || now - old.at >= LINK_AGE) links.set(n, { l: [], at: now, fail: true }); // asked again later
        continue;
      }
      // never the code itself, each linked code once (store-task.js does the same; an older answer kept in the cache
      // or a test source may not): a code counted twice would double its stock in "povezano"
      const once = new Set([String(n)]);
      const l = x.linked.filter((e) => e && ok7(e.num) && !once.has(String(e.num)) && once.add(String(e.num))).slice(0, 5);
      links.set(n, { l: l.map((e) => ({ num: String(e.num), st: String(e.st || '').slice(0, 3) })), at: now, limited: !!x.limited });
      for (const e of l) {
        const k = String(e.num), old = cache.get(k) || {};
        if (e.known && Number.isFinite(+e.stock)) {
          cache.set(k, { ...old, stock: +e.stock, free: Number.isFinite(+e.free) ? +e.free : old.free, at: now, error: false,
            ...(e.st ? { st: String(e.st).slice(0, 3) } : {}), ...(e.name ? { name: String(e.name).slice(0, 60) } : {}) });
        } else cache.set(k, { ...old, error: true }); // unknown: read with the page's next batch (no time of its own)
      }
    }
    save();
  }
  /** Old: read long ago, the last reading failed, or there is no network now (the value may have changed). */
  function oldOf(c, now = Date.now()) {
    return !!c && Number.isFinite(c.stock) && (!!c.error || now - c.at >= OLD || isOffline());
  }

  // ---- 1.76: one scheduler for the page's stock and prices --------------------------------------------------------
  // Every reading the viewer wants is a request { key, prio, need }: a tapped code (prio 0), what is on screen (1),
  // its missing prices (1.5), the rest of the page (2), the pages before and after (3). One StoreFront job at a time
  // (the Java side runs background jobs one after the other anyway, StoreTask.java), and each job is filled at the
  // moment it starts, most urgent first: a pan or a new page changes what goes next, the job that runs is left to
  // finish (at most JOB codes, about 3 rounds of 8 requests). A code wanted by several requests is read once. With
  // the Java side streaming (1.76), each code shows the moment its answer is there, not when the whole job ends.
  // codes in one stock job: with something on screen in it 24 (3 rounds of 8 requests: a pan waits at most that), the
  // background 40 (as since 1.73, fewer jobs); one price job 12
  const JOB = 24, BGJOB = 40, PJOB = 12;
  const RETRY = 60000; // a code whose reading failed is asked again after a minute at the earliest (not in a loop)
  const PAUSE = 30000; // StoreFront asked for a sign-in or the network went: the queue waits this long
  const reqs = [];
  const flying = new Set(); // codes in the job that runs now (busy: also those still waiting in a request)
  const viaMd = new Set(); // read from the master data before the check of this session ran (see stockJob)
  const tried = new Map(), ptried = new Map(); // code -> time of the last failed stock / price reading (memory only)
  let running = null, pauseUntil = 0, pauseTimer = 0, par = 8, seq = 0, store = '';
  // 2.03 (owner's phone, 15. 11.: "master podaci 8, od toga ponovo 8", "s lancem … (40), bez lanca … (40)"): this
  // StoreFront answers include=SubstitutionChainSmDm without the article's own stock part, so every code read with its
  // chain cost two requests before its stock was known. Once a job shows that, this session reads the stock with ONE
  // request (include=SmDm) and the chains come after it, from the chain job (relatedstock), when the stock is there.
  let chainApart = false;
  const freshStock = (c, now) => !!c && Number.isFinite(c.at) && now - c.at < AGE;
  // the price is known for now: read lately (with the stock or on its own), or StoreFront said lately it has none
  const priceKnown = (c, now) => !!c && ((c.price != null && Number.isFinite(c.pAt) && now - c.pAt < AGE) ||
    (Number.isFinite(c.priceAt) && now - c.priceAt < 10 * 60000));
  function expand(nums) {
    const want = [];
    for (const n of nums) {
      if (!ok7(n)) continue;
      want.push(String(n));
      const x = linksOf(String(n));
      if (x) for (const e of x.l) want.push(e.num);
    }
    return [...new Set(want)];
  }
  function syncBusy() {
    busy.clear();
    for (const r of reqs) if (r.kind === 'stock') for (const n of r.need) busy.add(n);
    for (const n of flying) if (!running || running.kind === 'stock') busy.add(n);
  }
  function finishReq(r) {
    const i = reqs.indexOf(r);
    if (i < 0) return;
    reqs.splice(i, 1);
    if (r.kind === 'stock' && r.stat && r.stat.jobs) {
      const s = r.stat;
      // 1.97 (owner: "58 traženo, 58 pročitano" next to "53 traženo, 34 pročitano"): every asked code is accounted for:
      // read by this request's own jobs, answered by a job that was already running for another request (overlap),
      // failed; asked = read + drugim poslom + bez odgovora
      log(`zalihe stranice: ${s.uniq} šifri (${s.uniq - s.asked} već svježe, ${s.asked} traženo, ${s.read} pročitano ovim zahtjevom${s.other ? `, ${s.other} stiglo drugim poslom (preklop)` : ''}${s.gone ? `, ${s.gone} nema u StoreFrontu` : ''}${s.failed ? `, ${s.failed} bez odgovora` : ''}), ${s.open > 0 ? `zahtjevi se broje na kraju posla (posao još čita druge šifre) u ${s.jobs} ${s.jobs === 1 ? 'poslu' : 'poslova'}` : `${s.req} zahtjeva u ${s.jobs} ${s.jobs === 1 ? 'poslu' : 'poslova'}`}, ${((Date.now() - s.t) / 1000).toFixed(1)} s`);
      // 2.26 (owner's log 23. 11.: "0 zahtjeva u 1 poslu" for codes that were read): the codes come in parts while the job
      // runs, so this request can be complete before its job ends and counts its StoreFront requests (stat 'req')
    }
    r.done(true);
  }
  /** These stock codes were answered (or failed): every request waiting for them hears it; a finished one ends. */
  function answered(got) {
    if (!got.length) return;
    const now = Date.now();
    for (const r of [...reqs]) {
      let hit = false;
      if (r.kind === 'stock') { for (const n of got) if (r.need.delete(n)) { hit = true; if (r.stat && !(r.counted && r.counted.has(n))) r.stat.other++; } }
      else for (const n of got) if (r.need.has(n) && priceKnown(cache.get(n), now)) { r.need.delete(n); hit = true; }
      if (!r.need.size) finishReq(r);
      else if (hit) r.done(false);
    }
    syncBusy();
  }
  /** One answered stock code into the memory (the chain that came with it too). Unknown never becomes 0. */
  function put(x, now) {
    const n = String(x.num), old = cache.get(n) || {};
    if (x.stock == null || String(x.stock).trim() === '' || !Number.isFinite(+x.stock)) return false;
    const price = x.price != null && Number.isFinite(+x.price) && +x.price >= 0;
    cache.set(n, { ...old, stock: +x.stock, free: Number.isFinite(+x.free) && x.free != null ? +x.free : undefined, at: now, error: false,
      ...(x.st ? { st: String(x.st).slice(0, 3) } : {}), ...(x.name ? { name: String(x.name).slice(0, 60) } : {}),
      ...(price ? { price: +x.price, cur: String(x.cur || 'BAM'), pAt: now } : {}),
      // the master data answered: its price fields were looked at, there is no other price to ask for now
      ...(x.pm ? { priceAt: now } : {}) });
    if (Number.isFinite(old.gone)) { const c = cache.get(n); delete c.gone; } // StoreFront has it (again)
    if (Array.isArray(x.chain)) learnLinks([{ num: n, linked: x.chain, limited: !!x.limited }], [n]);
    if (x.pm && !searchOnly) viaMd.add(n);
    tried.delete(n);
    again.delete(n);
    return true;
  }
  /** Not read: a known value stays as it was (its time too, so it shows as old), only marked as a failed reading. */
  function failed(n, now) {
    const old = cache.get(n);
    cache.set(n, { ...(old || {}), at: old && Number.isFinite(old.at) ? old.at : now, error: true });
    tried.set(n, now);
  }
  // 2.03 (owner's phone, 15. 11.: "220 šifri … 41 bez odgovora", and 52 planogram codes StoreFront does not know):
  // StoreFront answered that it has no such article (master data: an empty list). That is an answer, not a failure:
  // shown as before (no stock), but not asked again for GONE_MS (it was asked again after a minute, at every page:
  // about a fifth of a page's requests), and counted as "nema u StoreFrontu", not "bez odgovora". Kept in the file.
  const GONE_MS = 6 * 3600000;
  const goneNow = (c, now) => !!c && Number.isFinite(c.gone) && now - c.gone < GONE_MS;
  function gone(n, now) {
    failed(n, now);
    cache.set(n, { ...cache.get(n), gone: now });
  }
  // 1.76: a code whose reading failed (a 503, a request without answer) is asked once more AGAIN_MS later while its
  // requests still wait, then it waits RETRY like before (a StoreFront in trouble is never asked in a loop). Bench,
  // 15 % 503: without this, the screen was complete in under half the runs.
  const AGAIN_MS = 2500;
  const again = new Map(); // code -> { n: second tries so far, at: not before this time }
  let againTimer = 0;
  const held = (n, now) => { const x = again.get(n); return !!x && x.at > now; };
  /** true: the code is asked again soon (its requests keep waiting); false: it is answered as failed. */
  function retrySoon(n, now) {
    const x = again.get(n) || { n: 0, at: 0 };
    if (x.n >= 1 || !reqs.some((r) => r.kind === 'stock' && r.need.has(n) && r.stillActive())) { again.delete(n); return false; }
    again.set(n, { n: x.n + 1, at: now + AGAIN_MS });
    return true;
  }
  function wakeForAgain(now) {
    let at = Infinity;
    for (const x of again.values()) if (x.at > now) at = Math.min(at, x.at);
    if (at === Infinity || againTimer || typeof setTimeout !== 'function') return;
    againTimer = setTimeout(() => { againTimer = 0; pump(); }, at - now + 20);
  }
  // the article screen's stock (S.stock, app.js) is of the same store and goes with it; tests run this part alone
  const forgetItemStock = () => { if (typeof S !== 'undefined' && S && S.stock) S.stock.clear(); };
  // a StoreFront answer from another store (another sign-in): what was kept is of the old store and goes
  function storeIs(s) {
    s = String(s || '').slice(0, 12);
    if (!s || s === store) return;
    const other = !!store;
    if (other) { forgetItemStock(); cache.clear(); links.clear(); tried.clear(); ptried.clear(); log('zalihe planograma: druga prodavnica, zapamćene zalihe obrisane'); }
    store = s;
    save();
    // what was fresh for the old store is not asked by the requests waiting now: the screen asks again (viewer)
    if (other) { try { onStore(); } catch (e) { /* the viewer is not open */ } }
  }
  let onStore = () => {};
  /** Forgets everything kept (StoreFront sign-out): the next sign-in may be another store. */
  function forget() {
    forgetItemStock(); cache.clear(); links.clear(); tried.clear(); ptried.clear(); store = '';
    clearTimeout(saveTimer); saveTimer = 0;
    if (io) { try { io.write(FILE, { v: 1, s: {}, l: {} }); } catch (e) { /* kept in memory only */ } }
  }

  function enqueue(kind, nums, done, stillActive, force, opt) {
    if (isOffline()) { done(true); return; } // nothing can be read: the kept values stay, marked old
    const now = Date.now();
    if (opt.key) for (const r of reqs.filter((x) => x.key === opt.key && x.kind === kind)) reqs.splice(reqs.indexOf(r), 1); // superseded
    syncBusy();
    const want = kind === 'stock' ? expand(nums) : [...new Set(nums.map(String).filter(ok7))];
    const need = new Set(want.filter((n) => {
      if (kind === 'price') return !priceKnown(cache.get(n), now) && !(ptried.get(n) > now - RETRY);
      if (busy.has(n)) return true; // asked already: this request waits for that answer, nothing is read twice
      return force || (!freshStock(cache.get(n), now) && !(tried.get(n) > now - RETRY) && !goneNow(cache.get(n), now));
    }));
    if (!need.size) { done(true); return; }
    const r = { kind, key: opt.key || '', prio: opt.prio ?? 2, seq: ++seq, need, done, stillActive, force: new Set(force ? need : []) };
    if (kind === 'stock') { r.stat = { t: now, uniq: want.length, asked: need.size, read: 0, other: 0, failed: 0, gone: 0, req: 0, jobs: 0 }; r.counted = new Set(); }
    reqs.push(r);
    syncBusy();
    soon();
  }
  // the viewer asks for the screen and the page in one go: the job is filled once both are in (same turn of the loop)
  let soonAt = false;
  function soon() {
    if (soonAt) return;
    soonAt = true;
    Promise.resolve().then(() => { soonAt = false; pump(); });
  }
  // force: read again even when fresh (the employee asked); the linked codes of these articles are read with them.
  // opt: { key: a newer request with the same key replaces this one, prio: lower goes first (default 2) }
  function read(nums, done, stillActive = () => true, force = false, opt = {}) { enqueue('stock', nums, done, stillActive, force, opt); }
  /** The prices of these codes (shown at zoom): only those the stock reading does not bring (it brings most). */
  function prices(nums, done, stillActive = () => true, opt = {}) { enqueue('price', nums, done, stillActive, false, { prio: 1.5, ...opt }); }

  /**
   * A stock job runs while more urgent codes wait: what came on screen after a pan, a zoom or another page, or a
   * tapped code, and the job still carries codes that are less urgent than those (the page, a screen the employee
   * has left). It is asked to hand its page over (stYield, 1.76): it ends after the requests it already started, the
   * codes it did not ask come back to the queue (res.skipped: neither failed nor old; urgent ones keep their place)
   * and the next job is filled most urgent first. Once per job; codes that are only on their way do not count.
   */
  function yieldFor() {
    const j = running;
    if (!j || j.kind !== 'stock' || !j.stream || !j.id || j.yielded || typeof stYield !== 'function') return;
    let wait = Infinity;
    const best = new Map(); // code of this job -> the most urgent request still waiting for it
    for (const r of reqs) {
      if (r.kind !== 'stock' || !r.stillActive()) continue;
      for (const n of r.need) {
        if (!flying.has(n) && !held(n, Date.now())) wait = Math.min(wait, r.prio);
        else if (!j.got.has(n) && (!best.has(n) || r.prio < best.get(n))) best.set(n, r.prio);
      }
    }
    if (!(wait < 2)) return;
    let less = false;
    for (const n of j.batch) if (!j.got.has(n) && !(best.get(n) <= wait)) { less = true; break; }
    if (less) j.yielded = !!stYield(j.id);
  }
  function pump() {
    if (running) { yieldFor(); return; }
    const now = Date.now();
    for (const r of [...reqs]) if (!r.stillActive()) { reqs.splice(reqs.indexOf(r), 1); r.done(true); } // the employee moved on
    syncBusy();
    if (!reqs.length) return;
    if (isOffline()) { for (const r of [...reqs]) finishReq(r); syncBusy(); return; }
    const order = [...reqs].sort((a, b) => a.prio - b.prio || a.seq - b.seq);
    if (now < pauseUntil && !order.some((r) => r.force.size)) {
      if (!pauseTimer) pauseTimer = setTimeout(() => { pauseTimer = 0; pump(); }, pauseUntil - now + 20);
      return;
    }
    // a price is asked only when its stock is not on its way (the stock reading brings the price)
    for (const r of order) if (r.kind === 'price') for (const n of [...r.need]) if (priceKnown(cache.get(n), now)) r.need.delete(n);
    for (const r of [...reqs]) if (!r.need.size) finishReq(r);
    const can = (r, n) => (r.kind === 'stock' ? !held(n, now) : !busy.has(n));
    const first = order.find((r) => reqs.includes(r) && [...r.need].some((n) => can(r, n)));
    if (!first) { wakeForAgain(now); return; } // what is still wanted is on its way (or asked again a bit later)
    // the check job is small (8: one round), it passes nothing on before its end
    const kind = first.kind, size = kind === 'price' ? PJOB : first.prio < 2 ? JOB : verify > 0 ? 8 : BGJOB, batch = [];
    for (const r of order) {
      if (r.kind !== kind || !reqs.includes(r)) continue;
      for (const n of r.need) {
        if (batch.length >= size) break;
        if (can(r, n) && !batch.includes(n)) batch.push(n);
      }
    }
    if (kind === 'stock') stockJob(batch, order, first.prio >= 2); else priceJob(batch);
  }
  function stockJob(batch, order, background) {
    const t0 = Date.now();
    const soon = []; // failed, asked once more AGAIN_MS later: their requests hear now that it failed (shown "—" / "*")
    // the check (master data against the search, 1.73-test4) only in a background job: what is on screen streams
    const check = verify > 0 && background ? 4 : 0;
    if (check) verify--;
    const got = new Set();
    const job = { kind: 'stock', batch, got, stream: !check, id: null, yielded: false };
    running = job;
    batch.forEach((n) => flying.add(n));
    const mine = order.filter((r) => r.kind === 'stock' && batch.some((n) => r.need.has(n)));
    mine.forEach((r) => { r.stat.jobs++; r.stat.open = (r.stat.open || 0) + 1; });
    const stat = (k, v) => mine.forEach((r) => { r.stat[k] += v; });
    // 1.97: one code into each request of this job that asked for it, once (read or failed)
    const mark = (n, k) => { for (const q of mine) if (q.need.has(n) && !q.counted.has(n)) { q.counted.add(n); q.stat[k]++; } };
    // the codes answered so far (the Java side passes them on while the job runs; a check job only at its end)
    const part = (list) => {
      if (running !== job) return;
      // 22. 11. 2026 (audit, "podaci prethodne prodavnice"): each part says its store (store-task.js stockbatch): the
      // first part of another store makes the old store's kept values go NOW. Before, they stayed on the screen as
      // fresh until the job ended (seconds), and the end then also threw away what this job had just read.
      const w = Array.isArray(list) && list[0] && typeof list[0].w === 'string' ? list[0].w : '';
      if (w) storeIs(w);
      const now = Date.now(), ans = [];
      for (const x of list || []) {
        const n = String(x && x.num);
        if (!batch.includes(n) || got.has(n)) continue;
        if (put(x, now)) { got.add(n); ans.push(n); flying.delete(n); }
      }
      // 1.97: each request counts only ITS codes (before, every request of the job got the whole answer)
      if (ans.length) { for (const r of mine) for (const n of ans) if (r.need.has(n) && !r.counted.has(n)) { r.counted.add(n); r.stat.read++; } save(); answered(ans); }
    };
    const end = (r) => {
      if (running !== job) return;
      const now = Date.now();
      running = null;
      mine.forEach((q) => { q.stat.open = Math.max(0, (q.stat.open || 0) - 1); });
      if (r && r.how === 'ok' && r.res) {
        storeIs(r.res.store);
        const v = r.res.via, f = (r.res.failed || []).length, m = (r.res.missing || []).length;
        stat('req', v ? (v.md || 0) + (v.md2 || 0) + (v.search || 0) + ((r.res.verify && r.res.verify.asked) || 0) + 2 * f : batch.length);
        // 1.84: how long one StoreFront request took, with the chain and without it (the owner's phone compares them)
        if (v && (v.chainN || v.liteN)) log(`zalihe planograma: ${batch.length} šifri za ${((now - t0) / 1000).toFixed(1)} s, zahtjev prosječno: s lancem ${v.chainN ? Math.round(v.chainMs / v.chainN) + ' ms (' + v.chainN + ')' : '–'}, bez lanca ${v.liteN ? Math.round(v.liteMs / v.liteN) + ' ms (' + v.liteN + ')' : '–'}, ${r.res.par || par} odjednom`);
        if (!chainApart && v && v.chainN >= 4 && (v.md2 || 0) >= v.chainN * 0.75) {
          chainApart = true;
          log(`zalihe planograma: StoreFront uz lanac ne daje zalihu (${v.md2} od ${v.chainN} ponovo): zalihe se čitaju jednim zahtjevom, lanac poslije`);
        }
        if (v && (check || v.search || f || v.slow)) log(`zalihe planograma: ${batch.length} šifri za ${((now - t0) / 1000).toFixed(1)} s (master podaci ${(v.md || 0) + (v.md2 || 0)}${v.md2 ? `, od toga ponovo ${v.md2}` : ''}, pretraga ${v.search || 0}${f ? `, bez odgovora ${f}` : ''}${m ? `, nema u StoreFrontu ${m}` : ''}${v.slow ? `, sporo ${v.slow}, zatim ${r.res.par} odjednom` : ''})`);
        // StoreFront slowed down or failed: fewer requests at once in the next job; a clean job takes it back up
        par = Number.isFinite(+r.res.par) && +r.res.par < par ? Math.max(2, +r.res.par) : f || (v && v.slow) ? par : Math.min(8, par + 2);
        const c = r.res.verify;
        if (c && c.asked) {
          log(`provjera zalihe: master podaci i pretraga isto za ${c.same} od ${c.asked}${(c.diff || []).length ? `; razlika ${c.diff.map((d) => `${d.num}: ${d.md} / ${d.search == null ? '?' : d.search}`).join(', ')}` : ''}`);
          // a real difference (both known): this session reads as before (search), the values of this job are not kept
          if ((c.diff || []).some((d) => d.search != null && d.md !== d.search)) {
            searchOnly = true;
            log('zalihe planograma: master podaci se ne slažu sa pretragom; do ponovnog pokretanja čitam pretragom');
            // what this session read from the master data before the check is read again (with the search) when asked
            for (const n of viaMd) { const c = cache.get(n); if (c && Number.isFinite(c.at)) cache.set(n, { ...c, at: c.at - AGE }); }
            viaMd.clear();
            batch.forEach((n) => flying.delete(n));
            for (const q of mine) q.done(false);
            pump(); // the same codes once more, with the search (their requests still wait for them)
            return;
          }
        }
        const by = new Map((r.res.list || []).map((x) => [String(x.num), x]));
        // handed over (yield): not asked, so neither read nor failed; they wait in their requests for the next job
        const bad = new Set((r.res.failed || []).map(String));
        const none = new Set((r.res.missing || []).map(String)); // StoreFront: no such article
        const skip = job.yielded && Array.isArray(r.res.skipped) ? new Set(r.res.skipped.map(String).filter((n) => !by.has(n))) : null;
        for (const n of batch) {
          if (got.has(n)) continue;
          if (skip && skip.has(n)) { got.add(n); continue; }
          const x = by.get(n);
          if (x && put(x, now)) mark(n, 'read');
          else if (!x && none.has(n)) { gone(n, now); mark(n, 'gone'); }
          // its request failed (not: StoreFront answered it has no such article or no stock): asked once more soon
          else { failed(n, now); mark(n, 'failed'); if (bad.has(n) && retrySoon(n, now)) { got.add(n); soon.push(n); } }
        }
        if (skip && skip.size) log(`zalihe planograma: pozadinsko čitanje ustupilo mjesto vidljivim šiframa (${skip.size} kasnije)`);
      } else {
        // no answer for the codes not passed on yet: known values stay (old), nothing is asked again in a loop
        if (r && (r.how === 'login' || r.err === 'offline')) pauseUntil = now + PAUSE;
        if (r && r.err === 'timeout') par = Math.max(2, par >> 1);
        stat('req', batch.length - got.size);
        const login = r && (r.how === 'login' || r.err === 'offline'); // the queue pauses; no second try of its own
        for (const n of batch) if (!got.has(n)) { failed(n, now); mark(n, 'failed'); if (!login && retrySoon(n, now)) { got.add(n); soon.push(n); } }
      }
      batch.forEach((n) => flying.delete(n));
      save();
      answered(batch.filter((n) => !got.has(n)));
      if (soon.length) { syncBusy(); for (const q of [...reqs]) if (q.kind === 'stock' && soon.some((n) => q.need.has(n))) q.done(false); }
      pump();
    };
    // 1.84: codes whose chain is known and fresh are read without it (lighter request); a check job reads as before
    const lite = check || searchOnly ? [] : chainApart ? batch.slice() : batch.filter((n) => { const L = links.get(n); return L && !L.fail && Date.now() - L.at < LINK_AGE; });
    const ok = stCall({ mode: 'stockbatch', nums: batch, bg: true, par, ...(lite.length ? { lite } : {}), ...(check ? {} : { stream: true }),
      ...(searchOnly ? { via: 'search' } : check ? { verify: check } : {}) }, end, part);
    if (!ok) { end(null); return; }
    if (typeof ok === 'string' && running === job) { job.id = ok; yieldFor(); } // something on screen may wait already
  }
  function priceJob(batch) {
    const job = { kind: 'price', batch };
    running = job;
    const end = (r) => {
      if (running !== job) return;
      running = null;
      const now = Date.now();
      if (r && r.how === 'ok' && r.res) {
        storeIs(r.res.store);
        const by = new Map((r.res.list || []).map((p) => [String(p.num), p]));
        const bad = new Set((r.res.failed || []).map(String));
        for (const n of batch) {
          const p = by.get(n), prev = cache.get(n) || {};
          if (p && p.price != null && Number.isFinite(+p.price) && +p.price >= 0) cache.set(n, { ...prev, price: +p.price, cur: String(p.cur || 'BAM'), pAt: now, priceAt: now });
          else if (bad.has(n)) ptried.set(n, now); // no answer: a known price stays (its time too), asked again later
          else cache.set(n, { ...prev, priceAt: now }); // StoreFront has no price for it: none is shown (never 0 KM)
        }
      } else {
        if (r && (r.how === 'login' || r.err === 'offline')) pauseUntil = now + PAUSE;
        batch.forEach((n) => ptried.set(n, now));
      }
      // these codes are done for the price requests (answered, or failed: asked again after RETRY)
      for (const q of [...reqs]) if (q.kind === 'price') {
        let hit = false;
        for (const n of batch) if (q.need.delete(n)) hit = true;
        if (!q.need.size) finishReq(q); else if (hit) q.done(false);
      }
      save();
      pump();
    };
    if (!stCall({ mode: 'pricebatch', nums: batch, bg: true, par }, end)) end(null);
  }

  // One compact stock label just above the PDF's own article text box (the union of the code and description lines,
  // even for wrapped IDs such as "61363" + "18"), centred on it; no badge is attached to a product photograph.
  // Laid out for the WHOLE page at zoom z, in page units scaled by z (no screen position, no viewport): where the page
  // is on screen does not matter, so panning never changes the result. Never sent wandering to a neighbouring product:
  // a crowded spot gets a small dot, else nothing (better than covering a neighbour's article number).
  // Every spot: anchor (ax, ay) in page units (top centre of the code), its box offset (ox, oy) and size (w, h) in px.
  // 22. 11. 2026 (owner: "pri pomjeranju PDF-a se pomjeraju oznake cijena i zaliha"; #18 page 1: 4 of 5 badges moved
  // while the answers came in, no finger on the page): every new answer laid the whole page out again, in the order of
  // the values (0 first) and with the width of the new text, so badges that did not change took other places. prev: the
  // spots of the last layout at THIS zoom (the viewer passes them): a badge that had a place keeps it while it still
  // fits there, and is placed in the same order as then; only a badge that no longer fits (it grew) looks for another.
  function layout(rows, view, mode = 'all', prev = null) {
    const { z, fitZ } = view;
    if (!(z > 0)) return [];
    const spotKey = (num, b) => num + '|' + b.join(',');
    const before = new Map();
    if (Array.isArray(prev)) prev.forEach((p, i) => { if (p && Array.isArray(p.anchor)) before.set(spotKey(p.num, p.anchor), { i, ci: Number.isInteger(p.ci) ? p.ci : -1 }); });
    const now = Date.now();
    const compact = z < fitZ * 1.45;
    const all = rows.filter(r => r && Array.isArray(r.b) && r.b.length === 4 &&
      r.b.every(Number.isFinite)).map(r => ({
        ...r,
        box: { x: r.b[0] * z, y: r.b[1] * z,
          w: Math.max(1, (r.b[2] - r.b[0]) * z),
          h: Math.max(1, (r.b[3] - r.b[1]) * z) }
      }));
    // 1.80: the codes of one PDF label (STORFJELLET 4154550 + 4054650): one badge "3 / 0" in the PDF's order (top to
    // bottom, then left to right), one price, or both prices when they differ. Only the same label box joins codes: a
    // similar name or a neighbouring label never does.
    const groups = new Map();
    for (const r of all) if (r.g) { if (!groups.has(r.g)) groups.set(r.g, []); groups.get(r.g).push(r); }
    for (const rs0 of groups.values()) {
      const codes = [...new Set(rs0.map((r) => r.num))];
      if (codes.length < 2) continue;
      // 2.03 (owner's screen recording, 15. 11.: "8 / —" and "29,95 / ? KM"): a code of the label that StoreFront
      // does not have (an old number printed next to the new one) gets no part of the badge while the label has a
      // code StoreFront knows; the sheet of the code still explains it
      const live = codes.filter((n) => !goneNow(cache.get(n), now));
      if (live.length && live.length < codes.length) for (let i = all.length - 1; i >= 0; i--) if (rs0.includes(all[i]) && !live.includes(all[i].num)) all.splice(i, 1);
      const nums = live.length ? live : codes;
      const rs = rs0.filter((r) => nums.includes(r.num));
      if (nums.length < 2) continue;
      const first = (n) => rs.filter((r) => r.num === n).sort((a, b) => a.b[1] - b.b[1] || a.b[0] - b.b[0])[0];
      const ord = nums.map(first).sort((a, b) => (Math.abs(a.b[1] - b.b[1]) > 2 ? a.b[1] - b.b[1] : a.b[0] - b.b[0]));
      const u = ord.reduce((acc, r) => [Math.min(acc[0], r.b[0]), Math.min(acc[1], r.b[1]), Math.max(acc[2], r.b[2]), Math.max(acc[3], r.b[3])], [Infinity, Infinity, -Infinity, -Infinity]);
      const members = new Set(rs);
      for (let i = all.length - 1; i >= 0; i--) if (members.has(all[i]) && ord.indexOf(all[i]) !== 0) all.splice(i, 1);
      const head = ord[0];
      head.nums = ord.map((r) => r.num);
      head.b = u;
      head.box = { x: u[0] * z, y: u[1] * z, w: Math.max(1, (u[2] - u[0]) * z), h: Math.max(1, (u[3] - u[1]) * z) };
    }
    const collides = (a, b, pad = 0) => a.x < b.x + b.w + pad &&
      a.x + a.w + pad > b.x && a.y < b.y + b.h + pad &&
      a.y + a.h + pad > b.y;
    // what stands on this spot: the article and its linked codes (the same product on the shelf), each its own value:
    // the colour and the filters go by the largest one (22. 11. 2026: never by a sum, see standing())
    // one label of several codes: the same, over the codes of the label
    const totalOf = (r) => {
      if (!r.nums) return standing(r.num);
      const k = r.nums.map((n) => cache.get(n)).filter((c) => c && Number.isFinite(c.stock));
      const top = k.length ? Math.max(...k.map((c) => c.stock)) : null;
      // a code not read is not a 0: with one unknown the place is never "0" (red), only what is known and above 0
      return !k.length || (k.length < r.nums.length && top === 0) ? null : top;
    };
    const rank = r => { const t = totalOf(r); return t == null ? 4 : t === 0 ? 0 : t <= 3 ? 1 : 2; };
    const was = (r) => before.get(spotKey(r.num, r.b));
    const selected = all.filter(r => {
      const t = totalOf(r);
      return mode === 'zero' ? t === 0 : mode === 'low' ? t != null && t <= 3 : true;
    }).sort((a, b) => {
      // the badges laid out before first, in their order then; the new ones after them, the most urgent first
      const x = before.size ? was(a) : null, y = before.size ? was(b) : null;
      if (x || y) return x && y ? x.i - y.i : x ? -1 : 1;
      return rank(a) - rank(b);
    });
    const used = [], seen = [], out = [];
    for (const row of selected) {
      const b = row.box;
      if (seen.some(r => r.num === row.num && (
        collides(r.box, b, -Math.min(8, b.w * .2)) ||
        Math.hypot(r.box.x - b.x, r.box.y - b.y) < 12
      ))) continue;
      const c = cache.get(row.num);
      const sep = compact ? '/' : ' / ';
      const okPrice = (x) => x && x.price != null && Number.isFinite(+x.price) && +x.price >= 0;
      const fmtPrice = (x) => Number(x.price).toFixed(2).replace('.', ',');
      const cur = (x) => (x.cur === 'BAM' || !x.cur ? 'KM' : x.cur);
      let known, value, old, priceText = '';
      if (row.nums) {
        const cs = row.nums.map((n) => cache.get(n));
        known = cs.some((x) => x && Number.isFinite(x.stock));
        // each code's own value; one not read (yet, or failed) is "…" or "—", never 0
        // 1.83: "*" (old) on each code it belongs to ("4* / —"), not once at the end where it read as the last code's
        value = row.nums.map((n, i) => (cs[i] && Number.isFinite(cs[i].stock) ? String(cs[i].stock) + (oldOf(cs[i], now) ? '*' : '') : busy.has(n) ? '…' : '—')).join(sep);
        old = cs.some((x) => x && Number.isFinite(x.stock) && oldOf(x, now));
        const ps = cs.map((x) => (okPrice(x) ? fmtPrice(x) + '|' + cur(x) : ''));
        if (ps.some(Boolean)) {
          const same = ps.every((x) => x && x === ps[0]);
          const k = cs.find(okPrice);
          // 2.03 (owner: the codes of one article always have one price): only known prices, never "/ ? KM"
          const kp = ps.filter(Boolean);
          priceText = same || kp.every((x) => x === kp[0]) ? fmtPrice(k) + ' ' + cur(k) : kp.map((x) => x.split('|')[0]).join(' / ') + ' ' + cur(k);
        }
      } else {
        known = !!c && Number.isFinite(c.stock);
        const L = known ? linked(row.num) : null;
        // "5", with linked codes "5/3" (compact) or "5 / 3", two linked codes "5 / 3 / 4" (each its own, never added
        // up: 22. 11. 2026); "?" where a linked code's stock is not known; more than 3: "+"
        value = known ? String(c.stock) : busy.has(row.num) ? '…' : '—';
        if (L) value += sep + linkedText(L, sep);
        old = known && oldOf(c, now);
        if (okPrice(c)) priceText = fmtPrice(c) + ' ' + cur(c);
        // 1.85 (owner): in JYSK the codes of one article (substitution chain) always have the same price: one price
      }
      const text = value + (old && !row.nums ? '*' : '');
      const priceLabel = view.prices && !compact && z >= fitZ * 1.9 ? priceText : '';
      const w = Math.max(compact ? 20 : 24, (compact ? 11 : 13) + text.length * (compact ? 7 : 8),
        priceLabel ? 12 + priceLabel.length * 5.5 : 0);
      const h = priceLabel ? 32 : compact ? 15 : 18;
      const t = known ? totalOf(row) : null;
      const color = !known || t == null ? '#697581' : t === 0 ? '#b53246' : t <= 3 ? '#a86b0f' : '#0a795a';
      const center = b.x + b.w / 2;
      // Directly above the horizontal centre of the code; 1.77 (#18): when that covers another code or badge, right of
      // the code, left of it, below it (always touching its own code, never a neighbour's place)
      const cands = [
        { x: center - w / 2, y: b.y - h - 2, w, h },
        { x: b.x + b.w + 2, y: b.y + b.h / 2 - h / 2, w, h },
        { x: b.x - w - 2, y: b.y + b.h / 2 - h / 2, w, h },
        { x: center - w / 2, y: b.y + b.h + 2, w, h },
      ];
      const clear = p => !used.some(q => collides(p, q, 2)) && !all.some(r => r !== row && collides(p, r.box, .5));
      const pw = was(row);
      // a badge kept at the side of its code goes back above it once that place is free of EVERY badge as it was laid
      // out before (so no other badge has to move for it); otherwise it stays where it was
      const me = spotKey(row.num, row.b);
      const home = pw && pw.ci !== 0 && clear(cands[0]) &&
        !(prev || []).some((q) => q && Array.isArray(q.anchor) && spotKey(q.num, q.anchor) !== me && collides(cands[0], q, 2));
      const tryOrder = home ? [0, 1, 2, 3] : pw && pw.ci >= 0 ? [pw.ci, ...[0, 1, 2, 3].filter((i) => i !== pw.ci)] : [0, 1, 2, 3];
      let box = null, ci = -1, dot = false;
      for (const i of tryOrder) if (clear(cands[i])) { box = cands[i]; ci = i; break; }
      if (!box) {
        // Crowded PDF: a small dot on top of the same code. 1.77 (#18): never no mark at all (1.76 left codes without
        // one: "2351200", the second code of a cell), the dot still opens the code's stock
        const d = 8;
        box = { x: center - d / 2, y: b.y - d - 1, w: d, h: d };
        dot = true;
      }
      used.push(box); seen.push(row);
      out.push({ num: row.num, ...(row.nums ? { nums: row.nums } : {}), ax: center / z, ay: b.y / z, ox: box.x - center, oy: box.y - b.y,
        x: box.x, y: box.y, w: box.w, h: box.h, value, text, dot, ci, stale: old, color, priceLabel, anchor: row.b });
    }
    return out;
  }
  /** The badge under a finger at (x, y) px from the stage's top left, with the page at view { x, y, z }; or null. */
  // 14. 11. 2026: a badge the finger is ON wins over a nearer centre: before, a small dot (crowded spot, 8 px) next to a
  // wide badge took the tap that landed on the wide badge's edge, and the sheet opened for the neighbour's code
  function hit(spots, view, x, y) {
    let best = null;
    for (const p of spots) {
      const left = view.x + p.ax * view.z + p.ox, topY = view.y + p.ay * view.z + p.oy;
      const cx = left + p.w / 2, cy = topY + p.h / 2;
      if (Math.abs(x - cx) <= Math.max(16, p.w / 2 + 4) && Math.abs(y - cy) <= Math.max(16, p.h / 2 + 4)) {
        const on = x >= left - 1 && x <= left + p.w + 1 && y >= topY - 1 && y <= topY + p.h + 1;
        const distance = Math.hypot(x - cx, y - cy);
        if (!best || (on && !best.on) || (on === best.on && distance < best.distance)) best = { num: p.num, ...(p.nums ? { nums: p.nums } : {}), distance, on };
      }
    }
    if (best) delete best.on;
    return best;
  }
  return { cache, links, busy, labels, attach, read, prices, forget, layout, hit, linksOf, linked, standing, linkedText, needLinks, learnLinks, oldOf, AGE, OLD,
    isGone: (n) => goneNow(cache.get(String(n)), Date.now()),
    set onStore(f) { onStore = typeof f === 'function' ? f : () => {}; },
    get store() { return store; },
    get running() { return running; }, get queued() { return reqs.length; }, get version() { return ver; } };
})();

const viewer = (() => {
  const st = { id: null, plan: null, page: 0, focus: null, ready: false, z: 1, x: 0, y: 0, fitZ: 1, W: 0, H: 0, renderTask: null, detailTask: null, token: 0, pointers: new Map(), gesture: null, tap: null, lastTap: null };
  const stage = () => $('#stage');
  const base = () => $('#stageBase');
  const photo = () => $('#stagePhoto');
  const detail = () => $('#stageDetail');
  let photoUrl = null;
  const mark = () => $('#stageMark');
  let stocksVisible = true;
  let stockMode = 'all'; // all / zero / low
  let showPrices = true;
  let priceTimer = null;
  let focusStock = null;
  let relatedTimer = null, relatedRequest = false, relatedPause = 0;
  const relatedBusy = new Set();
  let lastSpots = [], spotsZ = 0, paintDirty = false;
  let tapTimer = 0, anim = 0, prefTimer = 0;
  let sheetNum = '';
  let detailView = null; // the view { x, y, z } the sharp layer was drawn for
  let resumes = 0, pdfDraws = 0, cacheDraws = 0; // 1.80, for the tests and the diagnostics: how a page came back
  const views = new Map(); // `${id}|${page}` -> where the employee was on that page (back from an article, page again)
  const TAP_MS = 350, TAP_MOVE = 10, DOUBLE_MS = 280, DOUBLE_DIST = 40;

  function openStockArticle(num) {
    if (S.index.byNum.has(num)) { openItem(num, { via: 'planogram' }); return; }
    // 14. 11. 2026 ("Artikal 4912439 nije u indeksu planograma", 05 Homeware str. 6): the badge is this page's code,
    // but the search index leaves out places of a section that a NEWER planogram on the phone covers too (core.
    // buildIndex: the newest PDF of a section wins). The code is real and on this page: say why, open StoreFront for it.
    const why = whyNotIndexed(num);
    openSheet({
      title: 'Artikal ' + num,
      body: `<p class="stk-name">${esc(nameOf(num) || (st.plan && st.plan.items[num] && st.plan.items[num].nm) || '')}</p><p>${esc(why)}</p>`,
      actions: [
        { label: 'Otvori u StoreFrontu', kind: 'btn-primary', onClick: () => { closeSheet(); try { A.storefront(num, 'view'); } catch (e) { toast('StoreFront se nije otvorio.'); } } },
        { label: 'Kopiraj šifru', onClick: () => { closeSheet(); copyCode(num); } },
        { label: 'Zatvori', kind: 'btn-quiet', onClick: closeSheet },
      ],
    });
  }
  /** Why a code of the open planogram is not in the search index (the text of the window above). */
  function whyNotIndexed(num) {
    const it = st.plan && st.plan.items[num];
    if (!it) return 'Ova šifra nije među artiklima ovog planograma (pročitana je samo iz napomene ili oznake). Otvori je u StoreFrontu.';
    const pg = st.plan.pages[st.page];
    const sec = pg && pg.sec >= 0 ? st.plan.meta.sections[pg.sec] : null;
    const owner = sec ? S.index.owner.get(sec.code) : null;
    const newer = owner && owner !== st.id ? S.plans.find((p) => p.id === owner) : null;
    if (newer) return `Dio ${sec.code} ${sec.name || ''} pokriva i noviji planogram „${newer.title || core.planTitle(newer.plan)}“ na telefonu, a u njemu ove šifre nema. Mjesto na ovoj stranici je iz starijeg PDF-a pa se ne nudi u pretrazi. Zalihu i status provjeri u StoreFrontu.`.replace(/\s+/g, ' ');
    return 'Ova šifra je na stranici, ali njeno mjesto nije potvrđeno u pretrazi artikala. Zalihu i status provjeri u StoreFrontu.';
  }
  const onScreen = (b) => b && st.x + b[2] * st.z > 0 && st.x + b[0] * st.z < st.W && st.y + b[3] * st.z > 65 && st.y + b[1] * st.z < st.H - 65;
  /** This page's codes, the ones on screen first (what the employee looks at is read first). */
  function pageNums() {
    const rows = stockLabels();
    const vis = new Set(rows.filter((r) => onScreen(r.b)).map((r) => r.num));
    return [...new Set([...rows.filter((r) => vis.has(r.num)), ...rows].map((r) => r.num))];
  }

  // ---- linked codes (StoreFront's substitution chain): asked for this page's codes, a few at a time, one job at a time
  function loadRelated(nums, onDone = () => {}) {
    const need = planogramStock.needLinks(nums).filter((n) => !relatedBusy.has(n)).slice(0, 6);
    if (!need.length || offline()) { onDone(); return; }
    need.forEach((n) => relatedBusy.add(n));
    relatedRequest = true;
    const finish = (r) => {
      need.forEach((n) => relatedBusy.delete(n));
      relatedRequest = false;
      if (r && r.how === 'ok' && r.res) planogramStock.learnLinks(r.res.list, need);
      else {
        planogramStock.learnLinks([], need); // asked again in 10 min, not in a loop
        if (r && (r.how === 'login' || r.err === 'offline')) relatedPause = Date.now() + 60000;
      }
      if (st.plan && top().id === 'viewer') { schedulePaint(true); refreshSheet(); }
      onDone();
    };
    if (!stCall({ mode: 'relatedstock', nums: need, bg: true }, finish)) finish(null);
  }
  // Low priority: after the page's stock is there, never during a gesture, one small job after the other.
  function scheduleRelated(delay = 1200) {
    clearTimeout(relatedTimer);
    relatedTimer = null;
    if (!st.plan || !st.ready || relatedRequest || top().id !== 'viewer' || !stocksVisible || offline() || Date.now() < relatedPause) return;
    const id = st.id, page = st.page;
    relatedTimer = setTimeout(() => {
      relatedTimer = null;
      if (!st.plan || st.id !== id || st.page !== page || top().id !== 'viewer' || relatedRequest || offline()) return;
      if (st.pointers.size || st.gesture || anim) { scheduleRelated(800); return; }
      // 2.02 (owner's phone, 15. 11.): the chain job waits until the stock reader has nothing running or waiting, and
      // asks only codes it has read already (the stock reading brings their chain itself). Before, it was sent while
      // a stock job ran; on the phone's one StoreFront page it then started before the next stock job, which waited
      // 2-5 s each time ("čekao u redu … radilo: relatedstock"; 20 visible codes in 52 s).
      if (planogramStock.running || planogramStock.queued) { scheduleRelated(800); return; }
      const now = Date.now();
      const rows = stockLabels();
      const zero = new Set(rows.filter((r) => { const c = planogramStock.cache.get(r.num); return c && c.stock === 0; }).map((r) => r.num));
      const read = (n) => { const c = planogramStock.cache.get(n); return !!c && Number.isFinite(c.stock) && Number.isFinite(c.at) && now - c.at < planogramStock.AGE; };
      const nums = pageNums().filter(read).sort((a, b) => (zero.has(b) ? 1 : 0) - (zero.has(a) ? 1 : 0)); // on screen first, at 0 first
      if (planogramStock.needLinks(nums).some((n) => !relatedBusy.has(n))) loadRelated(nums, () => scheduleRelated(600));
    }, delay);
  }

  // ---- the details of one code, opened by a tap on its badge: its stock, status and price, and those of its linked codes.
  // 1.73-test2: compact (half the screen with two linked codes): one line for the code, one per linked code's facts,
  // the actions in two rows of three; the planogram stays visible above it.
  const stShort = (st) => (st ? `<span class="pill ${st === '21' || st === '81' ? 'pill-warn' : 'pill-muted'}" title="${esc(stText(st) || '')}">${esc(st)}${ST_SHORT[st] ? ` ${ST_SHORT[st]}` : ''}</span>` : '');
  function stockSheetBody(num, showCode = true) {
    const c = planogramStock.cache.get(num);
    const item = st.plan && st.plan.items[num];
    const now = Date.now();
    const qty = (x) => (x && Number.isFinite(x.stock) ? `${whole(x.stock)} kom` : 'nepoznato');
    const price = (x) => (x && x.price != null && Number.isFinite(+x.price) && +x.price >= 0 ? `${money(x.price)} ${x.cur && x.cur !== 'BAM' ? esc(x.cur) : 'KM'}` : 'Cijena nije dostupna');
    const when = (x) => {
      if (!x || !Number.isFinite(x.stock)) return '';
      const t = new Date(x.at).toLocaleTimeString('bs-BA', { hour: '2-digit', minute: '2-digit' });
      if (offline()) return `Nema interneta: stanje od ${t}`;
      if (x.error) return `Čitanje nije uspjelo: stanje od ${t}`;
      const m = Math.round((now - x.at) / 60000);
      return m < 1 ? 'Očitano upravo' : `Očitano prije ${m} min (${t})${now - x.at >= planogramStock.OLD ? ', možda zastarjelo' : ''}`;
    };
    const L = planogramStock.linksOf(num), sum = planogramStock.linked(num);
    const known = c && Number.isFinite(c.stock);
    const own = known ? `${whole(c.stock)} kom` : planogramStock.busy.has(num) ? 'čitam…' : 'nepoznato';
    // 22. 11. 2026: each linked code its own number (the rows below say which is which), never one sum
    const rel = sum ? `<span class="stk-rel">· ${sum.count === 1 ? 'povezana' : 'povezane'} ${esc(planogramStock.linkedText(sum, ' / ', 5))}${sum.known ? ' kom' : ''}</span>` : '';
    const free = known && Number.isFinite(c.free) && c.free !== c.stock ? ` · za prodaju ${whole(c.free)}` : '';
    const places = stockLabels().filter((r) => r.num === num).length;
    let linkedHtml;
    if (L) {
      linkedHtml = L.l.length ? L.l.map((e) => {
        const x = planogramStock.cache.get(e.num);
        // 14. 11. 2026 (owner): the whole row is one button that opens StoreFront for THIS linked code (name and picture
        // can be the same as the planogram code's, stock and status are not); data-store is the one global handler
        return `<button class="stk-link" type="button" data-store="${esc(e.num)}" aria-label="Povezana šifra ${esc(e.num)}: otvori u StoreFrontu"><span class="stk-l1"><span class="code">${esc(e.num)}</span>${x && x.name ? `<span class="stk-ln">${esc(x.name)}</span>` : ''}<span class="stk-go">StoreFront ›</span></span>
          <span class="stk-l2"><b>${qty(x)}</b><span>${x && x.price != null ? price(x) : c && c.price != null ? price(c) : price(x)}</span>${stShort((x && x.st) || e.st)}${x && planogramStock.oldOf(x, now) ? '<span class="stk-old">*</span>' : ''}</span></button>`;
      }).join('') + (L.limited ? '<p class="stk-small">StoreFront ima još povezanih šifri; prikazano prvih 5.</p>' : '')
        : '<p class="stk-small">Nema povezanih (zamjenskih) šifri u StoreFrontu.</p>';
    } else if (relatedBusy.has(num)) linkedHtml = '<p class="stk-small"><i class="mj-busy"></i> Provjeravam zamjenske šifre…</p>';
    else linkedHtml = `<p class="stk-small">${offline() ? 'Nema interneta: povezane šifre nisu provjerene.' : 'Povezane šifre još nisu provjerene.'}</p>`;
    // data-sheet-num, never data-num: the global click handler opens the article of any [data-num] it is inside of,
    // so 1.73–1.94 turned a tap anywhere in this window (a linked code's row too) into the planogram code's article
    return `<div class="stk-sheet" data-sheet-num="${esc(num)}">
      <p class="stk-name">${esc((item && item.nm) || (c && c.name) || 'Bez naziva')}</p>
      <div class="stk-main">${showCode ? `<span class="code">${esc(num)}</span> ` : ''}<b class="stk-big">${own}</b>${rel}</div>
      <div class="stk-l2"><span>${price(c)}</span>${c && c.st ? stShort(c.st) : ''}</div>
      <p class="stk-small">${esc(when(c))}${esc(free)}</p>
      ${L && !L.l.length ? linkedHtml : `<p class="stk-h">Povezane šifre (StoreFront)</p>${linkedHtml}`}
      <p class="stk-small">Tvoja prodavnica · na ovoj stranici ${places} ${plural(places, 'mjesto', 'mjesta', 'mjesta')}</p>
    </div>`;
  }
  /**
   * 1.80: one badge of several codes (one label of the PDF): each code with its own stock, status and price, in the
   * PDF's order; different prices are said, never one of them as the price of the place.
   */
  function groupSheetBody(nums) {
    const cs = nums.map((n) => planogramStock.cache.get(n));
    const ok = (x) => x && x.price != null && Number.isFinite(+x.price) && +x.price >= 0;
    const ps = cs.filter(ok).map((x) => +x.price);
    const differ = ps.length > 1 && ps.some((x) => x !== ps[0]);
    const diff = differ ? `<p class="stk-line stk-stale">Cijene se razlikuju: ${nums.map((n, i) => `${esc(n)} ${ok(cs[i]) ? `${money(cs[i].price)} KM` : 'bez cijene'}`).join(' · ')}</p>` : '';
    return `<div class="stk-sheet stk-group" data-sheet-num="${esc(nums.join(','))}">
      <p class="stk-small">${nums.length} šifre na istom mjestu u planogramu (redoslijed kao u PDF-u).</p>${diff}
      ${nums.map((n) => `<p class="stk-h">Šifra ${esc(n)}</p>${stockSheetBody(n, false)}`).join('')}
    </div>`;
  }
  function refreshSheet() {
    if (!sheetNum || $('#sheet').hidden) return;
    const box = $('#sheetBody .stk-sheet');
    if (!box || box.dataset.sheetNum !== sheetNum) return;
    // 1.76: answers stream in now: the sheet is drawn again only when what it says changed, and it never gets lower
    // while it is open (a sheet that jumps under the finger is pressed or moved by mistake)
    const html = sheetNum.includes(',') ? groupSheetBody(sheetNum.split(',')) : stockSheetBody(sheetNum), body = $('#sheetBody');
    if (body.dataset.html === html) return;
    const sh = $('#sheet'), h = sh.offsetHeight, y = sh.scrollTop;
    if (h) sh.style.minHeight = Math.min(h, Math.round(window.innerHeight * 0.86)) + 'px';
    body.innerHTML = html;
    body.dataset.html = html;
    sh.scrollTop = y;
  }
  /** What the sheet needs and is not there yet: the chain (the employee asked: at once), fresh stock, missing prices. */
  function fillSheet(num, force = false, still = () => sheetNum === num) {
    if (offline()) return;
    if (planogramStock.needLinks([num]).length && !relatedBusy.has(num)) loadRelated([num], () => fillSheet(num));
    // the employee asked: before everything else (prio 0); the price the stock reading does not bring comes after it.
    // 14. 11. 2026: only the planogram code's price: the codes of one article cost the same in JYSK (owner, 13. 11.),
    // so the linked rows show it too; before, every first window also asked StoreFront for the linked codes' prices
    planogramStock.read([num], () => { refreshSheet(); schedulePaint(true); }, () => true, force, { key: 'sheet', prio: 0 });
    planogramStock.prices([num], () => refreshSheet(), still, { key: 'sheet', prio: 0.5 });
    refreshSheet();
  }
  function stockMenu(num, nums) {
    if (nums && nums.length > 1) {
      const key = nums.join(',');
      sheetNum = key;
      const still = () => sheetNum === key;
      openSheet({
        title: 'Artikli ' + nums.join(' / '),
        body: groupSheetBody(nums),
        cls: 'is-stock',
        actions: [
          ...nums.map((n, i) => ({ label: 'Otvori ' + n, ...(i ? {} : { kind: 'btn-primary' }), onClick: () => { closeSheet(); openStockArticle(n); } })),
          ...nums.map((n) => ({ label: 'Na punjenje ' + n, onClick: () => { closeSheet(); refillUi.openAdd(n); } })),
          { label: 'Osvježi', onClick: () => { if (offline()) { toast('Nema interneta.'); return; } nums.forEach((n) => fillSheet(n, true, still)); } },
          // 1.97 (owner): "Označi mjesta" removed from both windows (the article's places and the automatic highlight stay)
          { label: 'Zatvori', onClick: closeSheet },
        ],
      });
      nums.forEach((n) => fillSheet(n, false, still));
      return;
    }
    sheetNum = num;
    openSheet({
      title: 'Artikal ' + num,
      body: stockSheetBody(num),
      cls: 'is-stock',
      actions: [
        { label: 'Otvori artikal', kind: 'btn-primary', onClick: () => { closeSheet(); openStockArticle(num); } },
        { label: 'Dodaj na punjenje', onClick: () => { closeSheet(); refillUi.openAdd(num); } },
        { label: 'Osvježi', onClick: () => { if (offline()) { toast('Nema interneta.'); return; } fillSheet(num, true); } },
        { label: 'Kopiraj šifru', onClick: () => { closeSheet(); copyCode(num); } },
        { label: 'StoreFront', onClick: () => {
          closeSheet();
          try {
            if (!A.storefront) throw new Error('StoreFront nije dostupan');
            // Use the same native bridge as the existing article screen.
            A.storefront(num, 'view');
          } catch (e) { toast('StoreFront se nije otvorio. Pokušaj iz artikla u aplikaciji.'); }
        } },
        // "Dodaj na punjenje" took the place of "Zatvori": back or a tap outside closes the window; 1.97 (owner):
        // "Označi mjesta" removed (it took a whole row): two rows of actions
      ]
    });
    fillSheet(num);
  }
  function stockFilterMenu() {
    const names = { all: 'Sve zalihe', zero: 'Samo stanje 0', low: 'Stanje 0–3' };
    const rows = stockLabels();
    const ats = rows.map((r) => planogramStock.cache.get(r.num)).filter((c) => c && Number.isFinite(c.stock)).map((c) => c.at);
    const t = ats.length ? new Date(Math.min(...ats)).toLocaleTimeString('bs-BA', { hour: '2-digit', minute: '2-digit' }) : '';
    const info = offline() ? `<p class="ar-err">Nema interneta: prikazane su zadnje poznate zalihe${t ? ` (najstarija od ${t})` : ''}, označene sa *.</p>`
      : t ? `<p class="hint">Najstarija prikazana zaliha je od ${t}. Oznaka * znači zastarjelo ili neuspjelo čitanje.</p>` : '';
    openSheet({
      title: 'Prikaz zaliha na planogramu',
      body: `<p>Izaberi koje artikle želiš označiti. Originalni PDF ostaje nepromijenjen. Broj iza kose crte („5 / 3“) je zaliha povezanih (zamjenskih) šifri iz StoreFronta.</p>${info}`,
      actions: Object.entries(names).map(([mode, name]) => ({
        label: (stockMode === mode ? '✓ ' : '') + name,
        onClick: () => { stockMode = mode; closeSheet(); paintStocks(); schedulePrices(); }
      })).concat([
        { label: (showPrices ? '✓ ' : '') + 'Prikaži i cijene (pri uvećanju)', onClick: () => {
          showPrices = !showPrices; closeSheet(); paintStocks(); schedulePrices();
        } },
        { label: 'Osvježi zalihe na ovoj stranici', onClick: () => {
          closeSheet();
          if (offline()) { toast('Nema interneta: zalihe se ne mogu osvježiti.'); return; }
          fetchStocks(true);
        } },
        { label: 'Zatvori', onClick: closeSheet }
      ])
    });
  }
  function stockHit(cx, cy) {
    const rect = stage().getBoundingClientRect();
    return planogramStock.hit(lastSpots, { x: st.x, y: st.y, z: st.z }, cx - rect.left, cy - rect.top);
  }

  function stockLabels() {
    return st.plan ? planogramStock.labels(st.plan, st.page) : [];
  }
  let paintQueued = false;
  // force: new data (or a mode) to show; without it only a new zoom level lays the badges out again
  function schedulePaint(force = false) {
    if (!st.plan || top().id !== 'viewer') return;
    if (force) paintDirty = true;
    // Never reflow badge positions while fingers are panning/pinching:
    // the badges ride on the page through the stage transform; the end of the gesture lays them out.
    if (st.pointers.size || st.gesture || anim) return;
    if (!paintDirty && Math.abs(st.z - spotsZ) < 1e-9) return;
    if (paintQueued) return;
    paintQueued = true;
    requestAnimationFrame(() => { paintQueued = false; paintStocks(); });
  }
  function statusChip(rows) {
    const status = $('#viewerStockStatus');
    if (!status) return;
    if (!stocksVisible) { status.textContent = ''; return; }
    const now = Date.now();
    const shown = rows.filter(r => {
      const c = planogramStock.cache.get(r.num);
      if (!c || !Number.isFinite(c.stock)) return false;
      const t = planogramStock.standing(r.num); // 22. 11. 2026: the largest single value, never a sum
      return stockMode === 'zero' ? t === 0 : stockMode === 'low' ? t <= 3 : true;
    });
    const old = shown.some((r) => planogramStock.oldOf(planogramStock.cache.get(r.num), now));
    // 1.77 (#18): the chip says whether the page is complete: still reading (…), every code known and fresh (✓), or
    // finished with codes that have no value (the number of them; tap: the list). Never a green "done" for a page
    // with open or failed codes.
    // 2.03: codes StoreFront said it does not have are not "bez" (no answer): they are named apart ("· 41 nema")
    const codes = [...new Set(rows.map(r => r.num))];
    const goneN = codes.filter((n) => planogramStock.isGone(n)).length;
    const all = codes.filter((n) => !planogramStock.isGone(n));
    const known = (n) => { const c = planogramStock.cache.get(n); return !!c && Number.isFinite(c.stock); };
    const busyN = all.filter((n) => planogramStock.busy.has(n)).length;
    const lack = all.filter((n) => !known(n) && !planogramStock.busy.has(n)).length;
    const done = !busyN && !lack && !old && !offline() && all.length > 0;
    status.textContent = new Set(shown.map(r => r.num)).size + '/' + all.length +
      (offline() ? ' · offline' : busyN ? ' …' : lack ? ` · ${lack} bez` : old ? ' *' : done ? ' ✓' : '') + (goneN && !busyN ? ` · ${goneN} nema` : '') + ' ▾';
    status.classList.toggle('is-old', offline() || old);
    status.classList.toggle('is-done', done && stockMode === 'all');
    status.classList.toggle('is-lack', !busyN && lack > 0);
    status.title = (busyN ? `Čitam još ${busyN} šifri` : lack ? `${lack} šifri bez podatka iz StoreFronta` : done ? 'Sve šifre stranice pročitane' : '') +
      (goneN ? `${busyN || lack || done ? '. ' : ''}${goneN} šifri ove stranice StoreFront nema (stari ili povučeni brojevi)` : '');
  }
  function paintStocks() {
    if (!st.plan || top().id !== 'viewer') return;
    if (st.pointers.size || st.gesture) return;
    const m = mark();
    const previous = m.querySelector('#stockBadges');
    if (previous) previous.remove();
    stockVer = planogramStock.version;
    const rows = stocksVisible ? stockLabels() : [];
    statusChip(rows);
    // 22. 11. 2026: the same page at the same zoom: the badges keep their places (layout prev); a new page or zoom
    // (drawPage and a zoom reset spotsZ / change st.z) lays them out anew
    const keepFrom = spotsZ && Math.abs(st.z - spotsZ) < 1e-9 ? lastSpots : null;
    lastSpots = [];
    paintDirty = false;
    spotsZ = st.z;
    const oldFocus = m.querySelector('#stockFocus');
    if (oldFocus) oldFocus.remove();
    if (!stocksVisible || !rows.length || !st.ready) return;
    const spots = planogramStock.layout(rows, {
      z: st.z, fitZ: st.fitZ, prices: showPrices
    }, stockMode, keepFrom);
    lastSpots = spots;
    const ns = 'http://www.w3.org/2000/svg';
    if (focusStock) {
      const focus = document.createElementNS(ns, 'g');
      focus.setAttribute('id', 'stockFocus');
      rows.filter(r => r.num === focusStock).forEach(r => {
        const b = r.b;
        const outline = document.createElementNS(ns, 'rect');
        outline.setAttribute('x', String(b[0] - 2)); outline.setAttribute('y', String(b[1] - 2));
        outline.setAttribute('width', String(b[2] - b[0] + 4));
        outline.setAttribute('height', String(b[3] - b[1] + 4));
        outline.setAttribute('rx', '2');
        outline.setAttribute('class', 'stk-focus');
        focus.appendChild(outline);
      });
      m.appendChild(focus);
    }
    const group = document.createElementNS(ns, 'g');
    group.setAttribute('id', 'stockBadges');
    for (const p of spots) {
      // anchored in page units; the box is drawn in screen px and scaled by --k (1/zoom): one size on screen at any zoom
      const g = document.createElementNS(ns, 'g');
      g.setAttribute('class', p.stale ? 'sb is-old' : 'sb');
      g.setAttribute('style', `transform: translate(${p.ax.toFixed(2)}px, ${p.ay.toFixed(2)}px) scale(var(--k, 1))`);
      g.dataset.num = p.num;
      if (p.dot) {
        const dot = document.createElementNS(ns, 'circle');
        dot.setAttribute('cx', String(p.ox + p.w / 2)); dot.setAttribute('cy', String(p.oy + p.h / 2));
        dot.setAttribute('r', '3.5'); dot.setAttribute('fill', p.color);
        dot.setAttribute('stroke', '#fff'); dot.setAttribute('stroke-width', '1');
        g.appendChild(dot);
      } else {
        const rect = document.createElementNS(ns, 'rect');
        rect.setAttribute('x', String(p.ox)); rect.setAttribute('y', String(p.oy));
        rect.setAttribute('width', String(p.w));
        rect.setAttribute('height', String(p.h));
        rect.setAttribute('rx', '4');
        rect.setAttribute('fill', p.color);
        rect.setAttribute('stroke', '#fff');
        rect.setAttribute('stroke-width', '.8');
        if (p.stale) rect.setAttribute('stroke-dasharray', '2 1.5');
        const tx = document.createElementNS(ns, 'text');
        tx.setAttribute('x', String(p.ox + p.w / 2));
        tx.setAttribute('y', String(p.oy + (p.priceLabel ? 12 : p.h / 2 + 3.5)));
        tx.setAttribute('fill', '#fff');
        tx.setAttribute('text-anchor', 'middle');
        tx.setAttribute('font-size', p.h === 15 ? '10' : '11');
        tx.setAttribute('font-weight', '700');
        tx.textContent = p.text;
        if (p.priceLabel) {
          const white = document.createElementNS(ns, 'rect');
          white.setAttribute('x', String(p.ox + .8));
          white.setAttribute('y', String(p.oy + 17));
          white.setAttribute('width', String(p.w - 1.6));
          white.setAttribute('height', '14');
          white.setAttribute('rx', '3');
          white.setAttribute('fill', '#fff');
          const amount = document.createElementNS(ns, 'text');
          amount.setAttribute('x', String(p.ox + p.w / 2));
          amount.setAttribute('y', String(p.oy + 27));
          amount.setAttribute('fill', '#18202c');
          amount.setAttribute('text-anchor', 'middle');
          amount.setAttribute('font-size', '9.5');
          amount.setAttribute('font-weight', '700');
          amount.textContent = p.priceLabel;
          g.append(rect, tx, white, amount);
        } else g.append(rect, tx);
      }
      group.appendChild(g);
    }
    m.appendChild(group);
  }
  // Prices come with the stock (master data). Only the codes on screen at a zoom that shows prices, whose stock
  // reading did not bring one (read with the search, linked codes), are asked on their own (1.76: the scheduler in
  // planogramStock, after the stock on screen, never for a code whose stock is still on its way).
  function schedulePrices() {
    if (priceTimer) return; // 1.76: one waits already (was: put off again by every call)
    if (!showPrices || !st.plan || !st.ready || top().id !== 'viewer' ||
        st.pointers.size || offline() || st.z < st.fitZ * 1.9) return;
    const id = st.id, page = st.page;
    priceTimer = setTimeout(() => {
      priceTimer = null;
      if (!st.plan || st.id !== id || st.page !== page || st.pointers.size || top().id !== 'viewer' || st.z < st.fitZ * 1.9) return;
      // the codes on screen only: linked codes of an article have its price (owner, 1.85), not asked on their own
      const nums = [...new Set(stockLabels().filter((row) => onScreen(row.b)).map((row) => row.num))];
      if (!nums.length) return;
      planogramStock.prices(nums, () => { if (st.plan && st.id === id && st.page === page && top().id === 'viewer' && planogramStock.version !== stockVer) { stockVer = planogramStock.version; schedulePaint(true); } },
        () => !!st.plan && st.id === id && st.page === page && top().id === 'viewer' && showPrices, { key: 'prices', prio: 1.5 });
    }, 250);
  }
  // 1.76: what is on screen is read first (prio 1), then the rest of the page (2), then the pages before and after
  // (3, in the background, only while this page is open); a newer call replaces the older one of the same kind, so
  // after a pan or a zoom what is on screen now goes next. Every code shows the moment it is there.
  let stockPainted = 0, stockPaintTimer = 0, stockVer = -1; // stockVer: planogramStock.version of the last layout
  function stockArrived(id, page) {
    if (!st.plan || !stocksVisible || st.id !== id || st.page !== page) return;
    if (planogramStock.version === stockVer && !planogramStock.busy.size) return; // nothing new (fresh codes after a pan)
    // new values come in small groups while a job runs: one new layout at most every 150 ms (the page stays smooth)
    const wait = 150 - (Date.now() - stockPainted);
    if (wait > 0) { if (!stockPaintTimer) stockPaintTimer = setTimeout(() => { stockPaintTimer = 0; stockArrived(id, page); }, wait); return; }
    stockPainted = Date.now();
    stockVer = planogramStock.version;
    schedulePaint(true);
    schedulePrices();
  }
  function fetchVisible(force = false) {
    if (!stocksVisible || !st.plan || top().id !== 'viewer') return;
    const id = st.id, page = st.page;
    const vis = [...new Set(stockLabels().filter((r) => onScreen(r.b)).map((r) => r.num))];
    planogramStock.read(vis, () => stockArrived(id, page), () => !!st.plan && st.id === id && st.page === page && stocksVisible, force, { key: 'vis', prio: 1 });
  }
  function fetchStocks(force = false) {
    if (!stocksVisible || !st.plan || top().id !== 'viewer') return;
    const id = st.id, page = st.page;
    fetchVisible(force);
    planogramStock.read(pageNums(), (final) => {
      stockArrived(id, page);
      if (final && st.plan && stocksVisible && st.id === id && st.page === page) { scheduleRelated(); prefetchNeighbours(); }
    }, () => !!st.plan && st.id === id && st.page === page && stocksVisible, force, { key: 'page', prio: 2 });
    paintStocks();
  }
  // 1.73-test3: when this page is read, the pages before and after it are read in the background (what is fresh is
  // not asked again): turning the page shows its stock at once. Only those two, only while the viewer is open; 1.76:
  // with the lowest priority, so whatever this page needs goes first.
  function prefetchNeighbours() {
    clearTimeout(prefTimer); prefTimer = 0;
    if (!st.plan || !stocksVisible || offline()) return;
    const id = st.id, page = st.page;
    prefTimer = setTimeout(() => {
      prefTimer = 0;
      if (!st.plan || st.id !== id || st.page !== page || top().id !== 'viewer' || offline()) return;
      const nums = [];
      for (const p of [page + 1, page - 1]) if (p >= 0 && p < st.plan.pages.length) for (const r of planogramStock.labels(st.plan, p)) nums.push(r.num);
      if (nums.length) planogramStock.read([...new Set(nums)], () => {}, () => !!st.plan && st.id === id && top().id === 'viewer' && stocksVisible, false, { key: 'near', prio: 3 });
    }, 300);
  }

  function apply() {
    if (!st.plan || top().id !== 'viewer') return;
    const t = `translate(${st.x}px, ${st.y}px) scale(${st.z})`;
    base().style.transform = t;
    photo().style.transform = t;
    mark().style.transform = t;
    // keep the highlight lines and the stock badges the same size on screen at every zoom
    mark().style.setProperty('--k', String(1 / st.z));
  }

  function clamp() {
    if (!st.plan || top().id !== 'viewer') return;
    const pg = st.plan.pages[st.page];
    if (!pg) return;
    const W = st.W, H = st.H;
    st.z = Math.min(Math.max(st.z, st.fitZ * 0.9), st.fitZ * 14);
    const cw = pg.w * st.z, ch = pg.h * st.z;
    st.x = cw <= W ? (W - cw) / 2 : Math.min(0, Math.max(W - cw, st.x));
    st.y = ch <= H ? (H - ch) / 2 : Math.min(0, Math.max(H - ch, st.y));
  }

  function measure() {
    st.W = stage().clientWidth;
    st.H = stage().clientHeight;
  }
  function fit() {
    if (!st.plan || top().id !== 'viewer') return;
    const pg = st.plan.pages[st.page];
    if (!pg) return;
    measure();
    st.fitZ = Math.min(st.W / pg.w, st.H / pg.h);
    st.z = st.fitZ;
    clamp();
    apply();
  }
  /** The view kept for this page, on a screen of another size (turned phone): the same zoom relative to the whole
   *  page, the same page point in the middle. */
  function restoreView(v) {
    const pg = st.plan.pages[st.page];
    measure();
    st.fitZ = Math.min(st.W / pg.w, st.H / pg.h);
    if (v.W === st.W && v.H === st.H) { st.z = v.z; st.x = v.x; st.y = v.y; } else {
      const cx = (v.W / 2 - v.x) / v.z, cy = (v.H / 2 - v.y) / v.z;
      st.z = st.fitZ * (v.z / v.fitZ);
      st.x = st.W / 2 - cx * st.z;
      st.y = st.H / 2 - cy * st.z;
    }
    clamp();
    apply();
  }
  function remember() {
    if (!st.plan || !st.ready) return;
    const v = { x: st.x, y: st.y, z: st.z, fitZ: st.fitZ, W: st.W, H: st.H };
    views.set(st.id + '|' + st.page, v);
    // 1.80: also in this screen's own place in the stack, so the way back to it finds its plan, page and view even
    // after another planogram was opened and closed in between (A -> article -> B -> back -> back: A was black)
    const t = top();
    if (t.id === 'viewer' && t.state && t.state.id === st.id) { t.state.page = st.page; t.state.view = v; t.state.focus = st.focus; }
  }

  function focusOn(b) {
    if (!st.plan || top().id !== 'viewer') return;
    const W = st.W, H = st.H;
    const bw = b[2] - b[0], bh = b[3] - b[1];
    st.z = Math.min(W / (bw * 3.2), H / (bh * 3.2), st.fitZ * 6);
    st.z = Math.max(st.z, st.fitZ * 1.5);
    st.x = W / 2 - ((b[0] + b[2]) / 2) * st.z;
    st.y = H / 2 - ((b[1] + b[3]) / 2) * st.z;
    clamp();
    apply();
  }

  // Android WebView can discard a canvas' GPU backing bitmap under memory pressure.
  // Keep a decoded <img> of the current page as an independent stable display layer.
  function setPhoto(src, token, pg, ownUrl = false) {
    const p = photo();
    if (photoUrl) { URL.revokeObjectURL(photoUrl); photoUrl = null; }
    photoUrl = ownUrl ? src : null;
    p.hidden = true;
    p.onload = () => {
      if (token !== st.token || !st.plan || top().id !== 'viewer') return;
      p.hidden = false;
    };
    p.onerror = () => { p.hidden = true; };
    p.style.width = pg.w + 'px';
    p.style.height = pg.h + 'px';
    p.src = src;
  }
  function useBitmap(canvas, token, pg) {
    if (!canvas.toBlob) return;
    try {
      canvas.toBlob(blob => {
        if (!blob || token !== st.token || !st.plan || top().id !== 'viewer') return;
        setPhoto(URL.createObjectURL(blob), token, pg, true);
      }, 'image/jpeg', .85);
    } catch (e) { /* canvas fallback remains visible */ }
  }

  // Draw into an off-screen canvas first. The visible canvas is never resized or
  // cleared until a complete PDF page is available. A cancelled render cannot
  // leave stock badges floating on a black screen.
  // keepView: back from an article, or a page seen before: the employee is where they were (1.73)
  async function drawPage(attempt = 0, keepView = true) {
    if (!st.plan || top().id !== 'viewer') return;
    const token = ++st.token;
    st.ready = false;
    lastSpots = [];
    detailView = null;
    if (st.renderTask) {
      try { st.renderTask.cancel(); } catch (e) { /* already completed */ }
      st.renderTask = null;
    }
    if (st.detailTask) {
      try { st.detailTask.cancel(); } catch (e) { /* already completed */ }
      st.detailTask = null;
    }
    detail().hidden = true;
    photo().hidden = true;
    const id = st.id, page = st.page, pg = st.plan.pages[page];
    $('#viewerTitle').textContent = `${core.planTitle(st.plan)}${pg.sec >= 0 ? `, ${st.plan.meta.sections[pg.sec].code}` : ''}`;
    $('#pageNo').textContent = `${page + 1} / ${st.plan.pages.length}`;
    $('#pagePrev').disabled = page === 0;
    $('#pageNext').disabled = page >= st.plan.pages.length - 1;
    const b = base();
    const m = mark();
    m.setAttribute('width', pg.w);
    m.setAttribute('height', pg.h);
    m.setAttribute('viewBox', `0 0 ${pg.w} ${pg.h}`);
    m.style.width = pg.w + 'px';
    m.style.height = pg.h + 'px';
    const f = st.focus && st.focus.page === page ? st.focus.box : null;
    m.innerHTML = f ? `<rect class="mk-glow" x="${f[0] - 3}" y="${f[1] - 3}" width="${f[2] - f[0] + 6}" height="${f[3] - f[1] + 6}" rx="4"/><rect class="mk-in" x="${f[0] - 3}" y="${f[1] - 3}" width="${f[2] - f[0] + 6}" height="${f[3] - f[1] + 6}" rx="4"/>` : '';
    b.style.width = pg.w + 'px';
    b.style.height = pg.h + 'px';
    const msg = $('#stageMsg');
    msg.hidden = false;
    msg.textContent = attempt ? 'Ponovo učitavam PDF…' : 'Učitavam stranicu…';
    msg.onclick = null;
    const kept = keepView && views.get(id + '|' + page);
    if (kept) restoreView(kept);
    else { fit(); if (f) focusOn(f); }
    spotsZ = 0;
    fetchStocks(); // whole current page; in bounded chunks (30 IDs / 3 parallel requests), what is on screen first
    const active = () => token === st.token && st.id === id && st.page === page && !!st.plan && top().id === 'viewer';
    const commit = (source) => {
      if (!active()) return;
      const sw = source.naturalWidth || source.width;
      const sh = source.naturalHeight || source.height;
      if (!sw || !sh) throw new Error('Empty rendered PDF page');
      // The image was successfully painted before replacing the visible bitmap.
      b.width = sw;
      b.height = sh;
      const ctx = b.getContext('2d', { alpha: false });
      if (!ctx) throw new Error('PDF canvas unavailable');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, sw, sh);
      ctx.drawImage(source, 0, 0);
      b.style.width = pg.w + 'px';
      b.style.height = pg.h + 'px';
      st.ready = true;
      msg.hidden = true;
      paintStocks();
      schedulePrices();
      scheduleRelated();
      scheduleDetail();
      remember();
      afterPage(id, page);
    };
    try {
      let img = null;
      if (pageCache.has(id, page)) {
        try { img = await pageCache.load(id, page); } catch (e) { img = null; }
      }
      if (!active()) return;
      if (img && img.naturalWidth > 0) {
        cacheDraws++;
        commit(img);
        setPhoto(img.currentSrc || img.src, token, pg);
        return;
      }
      pageCache.holdOn();
      try {
        const doc = await docs.openPlan(id);
        if (!active()) return;
        pdfDraws++;
        const tmp = document.createElement('canvas');
        const cssW = pageCache.cssW();
        const cssH = (cssW * pg.h) / pg.w;
        await docs.renderRegion(doc, page + 1, [0, 0, pg.w, pg.h], tmp, cssW, cssH, { maxDpr: 2,
          onTask: t => { if (active()) st.renderTask = t; }
        });
        if (!active()) return;
        st.renderTask = null;
        commit(tmp);
        useBitmap(tmp, token, pg);
        // Cache only a completely rendered page; never save half-rendered data.
        try { pageCache.keep(id, page, b); } catch (e) { /* memory/cache error */ }
      } finally {
        pageCache.holdOff();
      }
    } catch (e) {
      if (!active()) return;
      st.renderTask = null;
      note('PDF render page ' + (page + 1) + ': ' + String(e && e.message || e).slice(0, 100));
      if (attempt < 1) {
        msg.hidden = false;
        msg.textContent = 'Obnavljam prikaz stranice…';
        setTimeout(() => { if (active()) drawPage(attempt + 1, keepView); }, 300);
      } else {
        msg.hidden = false;
        msg.innerHTML = '<button class="viewer-retry" type="button">PDF nije učitan — dodirni za ponovni pokušaj</button>';
        msg.onclick = ev => {
          ev.stopPropagation();
          if (active()) drawPage(0, keepView);
        };
      }
    }
  }

  /** The pages around this one are made ready while the employee looks at it. */
  function afterPage(id, page) {
    pageCache.warm(id, page + 1);
    pageCache.warm(id, page - 1);
    pageCache.around(id, page);
  }

  // The sharp layer (a drawing of just what is on screen) after the page stopped moving; drawn again only when the
  // view really changed (a tap or a finger resting on the page does not draw anything again).
  const scheduleDetail = debounce(async () => {
    if (!st.plan || !st.ready || top().id !== 'viewer' || st.pointers.size || anim) return;
    const pg = st.plan.pages[st.page];
    const W = st.W, H = st.H;
    const baseCss = base().width / Math.min(window.devicePixelRatio || 1, 2); // css px of the base render across pg.w
    if (st.z * pg.w <= baseCss * 1.05) { detail().hidden = true; detailView = null; return; }
    const view = { x: st.x, y: st.y, z: st.z };
    if (detailView && detailView.x === view.x && detailView.y === view.y && detailView.z === view.z) { detail().hidden = false; return; }
    const reg = [-st.x / st.z, -st.y / st.z, (W - st.x) / st.z, (H - st.y) / st.z];
    const token = st.token;
    try {
      const doc = await docs.openPlan(st.id);
      if (token !== st.token || !st.ready || !st.plan || top().id !== 'viewer') return;
      if (st.detailTask) st.detailTask.cancel();
      const d = detail();
      const tmp = document.createElement('canvas');
      await docs.renderRegion(doc, st.page + 1, reg, tmp, W, H, { transparent: true, maxDpr: 2, onTask: (t) => { st.detailTask = t; } });
      // moved meanwhile: this drawing is of another view (the next one comes after that gesture)
      if (token !== st.token || !st.ready || st.pointers.size || anim || st.x !== view.x || st.y !== view.y || st.z !== view.z) { tmp.width = 0; return; }
      d.width = tmp.width;
      d.height = tmp.height;
      const ctx = d.getContext('2d');
      ctx.clearRect(0, 0, d.width, d.height);
      // white page under the drawing, only where the page is
      const s = d.width / (reg[2] - reg[0]);
      ctx.fillStyle = '#fff';
      ctx.fillRect((0 - reg[0]) * s, (0 - reg[1]) * s, pg.w * s, pg.h * s);
      ctx.drawImage(tmp, 0, 0);
      tmp.width = 0; // its memory goes now, not whenever the WebView collects it
      d.hidden = false;
      d.style.zIndex = 1;
      mark().style.zIndex = 3;
      detailView = view;
    } catch (e) {
      // a newer gesture cancelled this drawing
    }
  }, 160);

  // ---- gestures. One finger moves the page at once (no dead zone); two zoom around the middle between them. A tap is
  // short and does not move: on a badge it opens that code's details (after the double-tap time, so a double tap on a
  // badge zooms and opens nothing); a double tap zooms in around the finger or back to the whole page.
  function stopAnim() { if (anim) { cancelAnimationFrame(anim); anim = 0; } }
  function zoomTo(nz, px, py, ms = 180) {
    stopAnim();
    const z0 = st.z, x0 = st.x, y0 = st.y;
    const ux = (px - x0) / z0, uy = (py - y0) / z0; // the page point under the finger stays under it
    st.z = nz; st.x = px - ux * nz; st.y = py - uy * nz;
    clamp();
    const z1 = st.z, x1 = st.x, y1 = st.y;
    st.z = z0; st.x = x0; st.y = y0;
    detail().hidden = true;
    const t0 = performance.now();
    const step = (t) => {
      const k = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - k, 3);
      st.z = z0 + (z1 - z0) * e; st.x = x0 + (x1 - x0) * e; st.y = y0 + (y1 - y0) * e;
      apply();
      if (k < 1 && st.plan && top().id === 'viewer') anim = requestAnimationFrame(step);
      else { anim = 0; st.z = z1; st.x = x1; st.y = y1; apply(); settle(); }
    };
    anim = requestAnimationFrame(step);
  }
  /** The page stopped: badges again only for a new zoom (or new data), the sharp layer only for a new view. */
  function settle() {
    if (!st.plan || top().id !== 'viewer' || anim) return;
    const dv = detailView;
    if (dv && dv.z === st.z && Math.abs(st.x - dv.x) <= 2 && Math.abs(st.y - dv.y) <= 2) {
      // a tap or a finger that rested: the few px it moved go back, the sharp drawing still fits exactly
      st.x = dv.x; st.y = dv.y; apply(); detail().hidden = false;
    } else scheduleDetail();
    schedulePaint();
    fetchVisible(); // 1.76: what is on screen now goes next (nothing is asked twice, nothing fresh again)
    schedulePrices();
    scheduleRelated();
    remember();
  }
  function onTap(cx, cy) {
    const now = Date.now(), last = st.lastTap;
    if (last && now - last.t <= DOUBLE_MS && Math.hypot(cx - last.x, cy - last.y) <= DOUBLE_DIST) {
      clearTimeout(tapTimer); tapTimer = 0; st.lastTap = null;
      const r = stage().getBoundingClientRect();
      const nz = st.z > st.fitZ * 1.8 ? st.fitZ : Math.min(st.z * 2.5, st.fitZ * 14);
      zoomTo(nz, cx - r.left, cy - r.top);
      return;
    }
    st.lastTap = { t: now, x: cx, y: cy };
    clearTimeout(tapTimer); tapTimer = 0;
    const hit = stocksVisible ? stockHit(cx, cy) : null;
    tapTimer = setTimeout(() => {
      tapTimer = 0;
      if (!st.plan || top().id !== 'viewer' || st.pointers.size || anim) return;
      if (hit) stockMenu(hit.num, hit.nums);
      else setBare(!bare); // 2.25: one tap beside the badges: the page alone on the whole screen; the next tap: back
    }, DOUBLE_MS);
  }

  // 2.25 (owner, 22. 11. 2026): the planogram turned sideways was framed by the bars (title, Zalihe, pages) and the
  // phone's own bars. One tap hides them all, the next brings them back; Back still closes. Only while the planogram
  // is the screen on top: an article opened from it, or Back, gives the normal screen; a new planogram starts with bars.
  let bare = false;
  function setBare(on) {
    bare = !!on;
    $('#viewer').classList.toggle('is-bare', bare);
    fullSync();
    if (bare && !(S.user && S.user.bareSeen)) {
      toast('Dodirni ponovo za traku i dugmad.', 2200);
      if (S.user) { S.user.bareSeen = 1; saveUser(); }
    }
  }
  function fullSync() {
    try { if (A.setFullscreen) A.setFullscreen(!!(bare && top().id === 'viewer')); } catch (e) { /* older shell */ }
  }

  function onDown(e) {
    if (!st.plan || top().id !== 'viewer' || !st.ready) return;
    if (e.target.closest('#stageMsg')) return;
    try { stage().setPointerCapture(e.pointerId); } catch (err) { /* the pointer is already gone */ }
    st.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (anim) { stopAnim(); clamp(); apply(); }
    if (st.pointers.size === 1) {
      st.tap = { id: e.pointerId, x: e.clientX, y: e.clientY, t: Date.now() };
      st.gesture = { kind: 'pan', x: st.x, y: st.y, px: e.clientX, py: e.clientY };
    } else {
      // a second finger: a pinch, never a tap
      st.tap = null;
      clearTimeout(tapTimer); tapTimer = 0; st.lastTap = null;
      if (st.pointers.size === 2) {
        const [a, b] = [...st.pointers.values()];
        const r = stage().getBoundingClientRect();
        st.gesture = {
          kind: 'pinch', z: st.z, x: st.x, y: st.y,
          d: Math.hypot(a.x - b.x, a.y - b.y) || 1,
          mx: (a.x + b.x) / 2 - r.left, my: (a.y + b.y) / 2 - r.top,
        };
        detail().hidden = true;
      }
    }
  }

  function onMove(e) {
    if (!st.plan || top().id !== 'viewer' || !st.pointers.has(e.pointerId)) return;
    st.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (st.tap && st.tap.id === e.pointerId && Math.hypot(e.clientX - st.tap.x, e.clientY - st.tap.y) > TAP_MOVE) st.tap = null;
    const g = st.gesture;
    if (!g) return;
    if (g.kind === 'pan' && st.pointers.size === 1) {
      st.x = g.x + (e.clientX - g.px);
      st.y = g.y + (e.clientY - g.py);
      if (!g.moved && Math.hypot(e.clientX - g.px, e.clientY - g.py) > 2) {
        g.moved = true; detail().hidden = true;
        clearTimeout(tapTimer); tapTimer = 0; // a badge tapped just before: no sheet over a page that is moving
      }
    } else if (g.kind === 'pinch' && st.pointers.size >= 2) {
      const [a, b] = [...st.pointers.values()];
      const r = stage().getBoundingClientRect();
      const d = Math.hypot(a.x - b.x, a.y - b.y) || 1;
      const mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
      const nz = Math.min(Math.max(g.z * (d / g.d), st.fitZ * 0.9), st.fitZ * 14);
      st.x = mx - ((g.mx - g.x) / g.z) * nz;
      st.y = my - ((g.my - g.y) / g.z) * nz;
      st.z = nz;
    }
    clamp();
    apply();
  }

  function onUp(e) {
    if (!st.plan || top().id !== 'viewer') { st.pointers.delete(e.pointerId); st.gesture = null; st.tap = null; return; }
    if (!st.pointers.has(e.pointerId)) return;
    const tap = st.tap && st.tap.id === e.pointerId && e.type === 'pointerup' && Date.now() - st.tap.t <= TAP_MS &&
      Math.hypot(e.clientX - st.tap.x, e.clientY - st.tap.y) <= TAP_MOVE ? st.tap : null;
    st.tap = null;
    st.pointers.delete(e.pointerId);
    if (st.pointers.size === 1 && st.gesture && st.gesture.kind === 'pinch') {
      // one finger stays: it goes on moving the page from where it is
      const [p] = [...st.pointers.values()];
      st.gesture = { kind: 'pan', x: st.x, y: st.y, px: p.x, py: p.y, moved: true };
      return;
    }
    if (st.pointers.size) return;
    st.gesture = null;
    if (tap) onTap(e.clientX, e.clientY);
    else st.lastTap = null; // a pan in between: the next tap starts anew (tap, swipe, tap is no double tap)
    settle();
  }

  /** The screen changed size (the phone was turned): the same part of the page stays in the middle. */
  function onResize() {
    if (!st.plan || top().id !== 'viewer') return;
    const pg = st.plan.pages[st.page];
    if (!pg) return;
    const W = stage().clientWidth, H = stage().clientHeight;
    if (!W || !H || (W === st.W && H === st.H)) return;
    restoreView({ x: st.x, y: st.y, z: st.z, fitZ: st.fitZ, W: st.W, H: st.H });
    detailView = null;
    schedulePaint(true);
    scheduleDetail();
    remember();
  }

  function bind() {
    // 22. 11. 2026: StoreFront answered for another store: the old store's values are gone, the open page asks again
    planogramStock.onStore = () => { if (st.plan && st.ready && top().id === 'viewer') setTimeout(() => fetchStocks(), 0); };
    const s = stage();
    s.addEventListener('pointerdown', onDown);
    s.addEventListener('pointermove', onMove);
    s.addEventListener('pointerup', onUp);
    s.addEventListener('pointercancel', onUp);
    $('#viewerFit').addEventListener('click', () => { if (!st.plan) return; fit(); settle(); });
    $('#viewerStockStatus').addEventListener('click', stockFilterMenu);
    $('#viewerStock').addEventListener('click', () => {
      stocksVisible = !stocksVisible;
      $('#viewerStock').setAttribute('aria-pressed', String(stocksVisible));
      $('#viewerStock').textContent = 'Zalihe'; // 1.77: on/off only (aria-pressed); whether it is complete: the chip
      if (stocksVisible) fetchStocks(); else paintStocks();
    });
    $('#pagePrev').addEventListener('click', () => { if (st.plan && st.page > 0) { remember(); docs.release(st.id, st.page + 1); st.page--; drawPage(); } });
    $('#pageNext').addEventListener('click', () => { if (st.plan && st.page < st.plan.pages.length - 1) { remember(); docs.release(st.id, st.page + 1); st.page++; drawPage(); } });
    window.addEventListener('resize', debounce(onResize, 120));
  }

  return {
    bind,
    open(id, page, focus) {
      const p = S.plans.find((x) => x.id === id);
      if (!p) return;
      if (st.id !== id) focusStock = null;
      views.clear(); // opened anew: the whole page (or the article asked for), not where one was last time
      // 1.80: until its page is drawn nothing of the planogram before is "ready" (its badges, a tap on them)
      st.ready = false; lastSpots = [];
      st.id = id;
      st.plan = p.plan;
      st.page = page;
      st.focus = focus ? { page, box: focus } : null;
      go('viewer', { id, page });
      const toggle = $('#viewerStock');
      toggle.setAttribute('aria-pressed', String(stocksVisible));
      toggle.textContent = 'Zalihe';
      requestAnimationFrame(() => drawPage(0, false));
    },
    resume() {
      if (top().id !== 'viewer') return;
      const t = top().state;
      // 1.80: the viewer is one screen for every planogram. Back from planogram B closed it (close(): no plan, a 1x1
      // canvas), so returning to planogram A further down the stack found nothing to draw and stayed black. It is
      // opened again from A's own place in the stack: same plan, page, view and marked article; the page comes from
      // the page cache (a kept picture), the PDF is drawn only when there is none.
      if (t && t.id && (!st.plan || st.id !== t.id || st.page !== (+t.page || 0))) {
        const p = S.plans.find((x) => x.id === t.id);
        if (!p) return;
        if (st.id !== t.id) focusStock = null;
        if (st.plan && st.id && st.id !== t.id) docs.release(st.id, st.page + 1);
        st.id = t.id;
        st.plan = p.plan;
        st.page = Math.min(Math.max(0, +t.page || 0), p.plan.pages.length - 1);
        st.focus = t.focus || null;
        if (t.view) views.set(st.id + '|' + st.page, t.view);
        resumes++;
      }
      if (!st.plan) return;
      // The original PDF and the selected page remain in memory while the article is open.
      // Repaint from the cached page if possible; otherwise render from PDF with retry.
      // requestAnimationFrame waits until the viewer has become visible again; the employee is back where they were.
      const id = st.id, page = st.page;
      requestAnimationFrame(() => {
        if (!st.plan || st.id !== id || st.page !== page || top().id !== 'viewer') return;
        drawPage(0, true).catch(e => {
          note('PDF resume: ' + String(e && e.message || e).slice(0, 100));
          const msg = $('#stageMsg');
          if (msg) { msg.hidden = false; msg.textContent = 'Prikaz se nije obnovio — pokušaj ponovo'; }
        });
      });
    },
    /** The network went or came back: badges and the status say it at once; back: what failed is read again. */
    netChanged(up) {
      if (!st.plan || top().id !== 'viewer') return;
      schedulePaint(true);
      refreshSheet();
      if (up) { relatedPause = 0; fetchStocks(); }
    },
    fullSync,
    setBare,
    close() {
      bare = false; $('#viewer').classList.remove('is-bare'); fullSync();
      clearTimeout(relatedTimer); relatedTimer = null;
      clearTimeout(priceTimer); priceTimer = null;
      clearTimeout(stockPaintTimer); stockPaintTimer = 0;
      clearTimeout(tapTimer); tapTimer = 0;
      clearTimeout(prefTimer); prefTimer = 0;
      stopAnim();
      st.token++;
      lastSpots = []; sheetNum = ''; detailView = null;
      for (const id of st.pointers.keys()) { try { stage().releasePointerCapture(id); } catch (e) { /* already released */ } }
      st.pointers.clear(); st.gesture = null; st.tap = null; st.lastTap = null;
      if (st.renderTask) { try { st.renderTask.cancel(); } catch (e) { /* finished */ } }
      if (st.detailTask) { try { st.detailTask.cancel(); } catch (e) { /* finished */ } }
      st.renderTask = null; st.detailTask = null;
      if (st.id && st.plan) docs.release(st.id, st.page + 1);
      st.plan = null;
      st.ready = false;
      photo().onload = null; photo().onerror = null;
      photo().hidden = true; photo().removeAttribute('src');
      if (photoUrl) { URL.revokeObjectURL(photoUrl); photoUrl = null; }
      $('#stageMsg').onclick = null;
      $('#viewerStockStatus').textContent = '';
      const b = base();
      b.width = 1;
      b.height = 1;
      const d = detail();
      d.width = 1;
      d.height = 1;
      d.hidden = true;
    },
    // tests only: the view, the badges as they are laid out now and the page's article codes
    __groupSheet: (nums) => groupSheetBody(nums),
    __stockMenu: (num, nums) => stockMenu(num, nums), // the window a tap on a badge opens
    __zoomTo: (nz, px = st.W / 2, py = st.H / 2) => zoomTo(nz, px, py, 0),
    __state: () => ({ resumes, pdfDraws, cacheDraws, id: st.id, x: st.x, y: st.y, z: st.z, fitZ: st.fitZ, W: st.W, H: st.H, page: st.page, ready: st.ready, spotsZ, anim: !!anim, focus: st.focus,
      pw: st.plan ? st.plan.pages[st.page].w : 0, ph: st.plan ? st.plan.pages[st.page].h : 0,
      spots: lastSpots.map((p) => ({ num: p.num, nums: p.nums, ax: p.ax, ay: p.ay, ox: p.ox, oy: p.oy, w: p.w, h: p.h, dot: p.dot, ci: p.ci, anchor: p.anchor, text: p.text, priceLabel: p.priceLabel })),
      labels: stockLabels() }),
  };
})();
// tests only (a page served from localhost): the viewer and its stock, to check what is drawn against what is laid out
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) { window.__viewer = viewer; window.__planogramStock = planogramStock; window.__S = S; window.__hotT = { tick: hotTick, idle: hotIdle, self: hotSelfCheck, input: (ms) => { hotInputAt = ms; }, hidden: (ms) => { hotHiddenAt = ms; }, errs: () => hotErrs }; window.__rebuildIndex = rebuildIndex; window.__substSync = () => substSync(); window.__repaintBars = () => { renderOrdersBar(); renderMinusBar(); renderClearBar(); renderStoreBars(); }; window.__rzTick = () => rzTick(); }

// ------------------------------------------------------------------- events

function bind() {
  $('#openPlans').addEventListener('click', () => { renderPlans(); go('plans'); });
  $('#clearRefresh').addEventListener('click', () => refreshClearance());
  $('#openSettings').addEventListener('click', () => { S.setGroup = null; renderSettings(); go('settings'); });
  $('#welcomeAdd').addEventListener('click', () => addPlanograms());
  $('#scanBtn').addEventListener('click', startScan);
  for (const b of $$('[data-scan]')) b.addEventListener('click', startScan);
  for (const b of $$('[data-back]')) b.addEventListener('click', () => back());
  $('#attachBody').addEventListener('click', onAttachClick);
  $('#minusRefresh').addEventListener('click', () => loadMinus());
  $('#minusBody').addEventListener('click', onMinusClick);
  // 2.28 Regulacija zalihe: its own buttons, and the sending's card (check / resolve / StoreFront page) as on Minus lista
  $('#regAdjBody').addEventListener('click', (ev) => {
    const t = ev.target.closest('[data-ra-add],[data-ra-scan],[data-ra-del],[data-ra-dir],[data-ra-send],[data-ra-clear]');
    if (t) { regAdjUi.onClick(t); return; }
    onMinusClick(ev);
  });
  $('#regAdjBody').addEventListener('input', (ev) => regAdjUi.onInput(ev));
  $('#regAdjBody').addEventListener('change', (ev) => { if (ev.target.matches('select,[type=checkbox]')) regAdjUi.onInput(ev); });
  $('#regAdjBody').addEventListener('keydown', (ev) => { if (ev.key === 'Enter' && ev.target.id === 'raQ') { ev.preventDefault(); regAdjUi.add(ev.target.value); } });
  $('#attachBack').addEventListener('click', () => { if (S.att && S.att.path) { try { A.myjyskOpen(S.att.path); } catch (e) { /* older shell */ } } else back(); });
  // 1.76: only a real tap on the dimmed part closes the sheet; a swipe that starts there (the employee moving the
  // planogram under a half-height stock sheet) leaves it open
  let scrimDown = null;
  $('#scrim').addEventListener('pointerdown', (e) => { scrimDown = { x: e.clientX, y: e.clientY, t: Date.now() }; });
  $('#scrim').addEventListener('click', (e) => {
    const d = scrimDown; scrimDown = null;
    if (d && (Math.hypot(e.clientX - d.x, e.clientY - d.y) > 12 || Date.now() - d.t > 700)) return;
    if (sheet.dismissible) closeSheet();
  });
  $('#itemViewer').addEventListener('click', openViewerForItem);
  $('#clearRecent').addEventListener('click', () => { S.user.recent = []; saveUser(); renderHome(); });

  const q = $('#q');
  q.addEventListener('input', debounce(runSearch, 40)); // a search takes a few ms: 40 ms is enough to let fast typing pass (1.68: 90)
  // typing an article: StoreFront is made ready meanwhile, its stock comes on a warm page (1.70; at most once a minute)
  q.addEventListener('input', () => { if ((S.mode === 'plan' || S.mode === 'sf') && q.value.trim().length >= 2) warmStore(S.mode === 'sf'); });
  $('#searchForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    if (S.mode === 'orders') { q.blur(); return; }
    const v = q.value.trim();
    const d = v.replace(/\s/g, '');
    if (searchUi.sfScope()) { // 2.15-pregled: a number opens its article from StoreFront (the planogram one if it has it)
      const n = searchUi.sfEnter(v);
      if (n) { q.blur(); if (S.index && S.index.byNum.has(n)) openItem(n); else openMissing(n); return; }
      searchUi.sfsNow(v); q.blur(); return; // 2.17: Enter asks StoreFront at once
    }
    if (/^\d{7,14}$/.test(d)) {
      const res = core.resolveCode(S.index, d, codes());
      if (res) { q.blur(); openItem(res.num, { via: res.via, code: d, from: res.from }); return; }
      if (d.length >= 8) { q.blur(); openMissing(d); return; }
    }
    const nums = core.search(S.index, v, 2);
    if (nums.length === 1) { q.blur(); openItem(nums[0]); return; }
    q.blur();
  });
  $('#clearQ').addEventListener('click', () => { q.value = ''; runSearch(); q.focus(); });

  // the words that hide Christmas / New Year articles: saved when the field is left; nothing typed brings back the usual ones
  // 1.98: OOPUS search field and the checks before the signature
  document.addEventListener('input', (ev) => { if (ev.target && ev.target.id === 'oopusQ') oopusUi.onChangeInput(ev.target); });
  document.addEventListener('change', (ev) => { if (ev.target && ev.target.dataset && ev.target.dataset.oopusTick) oopusUi.onChangeInput(ev.target); });
  document.addEventListener('change', (ev) => {
    const t = ev.target;
    if (t && t.id === 'mjMe') {
      setCfg({ mjMe: String(t.value || '').replace(/\s+/g, ' ').trim().slice(0, 120) });
      toast('Spremljeno.');
      return;
    }
    if (!t || t.id !== 'xmasWords') return;
    const words = String(t.value || '').replace(/\s+/g, ' ').trim().slice(0, 300);
    setCfg({ xmas: words || core.XMAS_WORDS });
    renderSettings();
    renderHome();
    toast(words ? 'Riječi su spremljene.' : 'Vraćene su zadane riječi.');
  });

  $('#auditBody').addEventListener('change', (ev) => {
    const n = ev.target.dataset.auIn;
    if (!n) return;
    S.au.edit[n] = { ...(S.au.edit[n] || {}), [ev.target.dataset.k === 'dm' ? 'dm' : 'sm']: Math.max(0, Math.min(9999, Math.round(+ev.target.value || 0))) };
    delete S.au.move[n];
    S.au.result = null;
    renderAudit();
  });

  // SM screen: a typed value is kept until saved (the list is drawn again only to show the save button)
  let smInTimer = 0;
  $('#smBody').addEventListener('change', (ev) => {
    const n = ev.target.dataset.smIn;
    if (!n || S.sm.scope === 'other') return;
    S.sm.edit[n] = { ...(S.sm.edit[n] || {}), [ev.target.dataset.k === 'dm' ? 'dm' : 'sm']: Math.max(0, Math.min(9999, Math.round(+ev.target.value || 0))) };
    S.sm.result = null;
    // 1.99: the list is drawn again a moment later: a tap that ended the typing (on a code) still reaches its button
    clearTimeout(smInTimer);
    smInTimer = setTimeout(() => { if (top().id === 'smdm') renderSm(); }, 350);
  });

  // AR screen: the comments are kept as they are typed, the form can be changed
  $('#arBody').addEventListener('input', (ev) => { const n = ev.target.dataset.arNote; if (n) S.ar.notes[n] = ev.target.value; });
  $('#arBody').addEventListener('change', (ev) => {
    if (ev.target.dataset.ar !== 'form') return;
    setCfg({ arForm: ev.target.value });
    arKept().form = null;
    S.ar.scores = {};
    S.ar.notes = {};
    saveUser();
    arLoad();
  });

  // the rows of Narudžbe are not <button>s (a code inside opens StoreFront on its own): Enter / space open them too
  document.addEventListener('keydown', (ev) => {
    const r = ev.target.closest && ev.target.closest('[role="button"][data-owait],[role="button"][data-oq]');
    if (r && ev.target === r && (ev.key === 'Enter' || ev.key === ' ')) { ev.preventDefault(); r.click(); }
  });
  // 2.08 (owner, phone): Skeniraj covered the cards while scrolling; moving down makes it smaller, up or at rest
  // on the top makes it full again (one tap always scans)
  let fabY = new WeakMap();
  document.addEventListener('scroll', (ev) => {
    const sc = ev.target;
    if (!sc || !sc.classList || !sc.classList.contains('scroll')) return;
    const y = sc.scrollTop, y0 = fabY.get(sc) || 0;
    if (Math.abs(y - y0) < 12) return;
    document.body.classList.toggle('fab-mini', y > y0 && y > 80);
    fabY.set(sc, y);
  }, true);
  // one listener for every list, button and link that carries data
  // 2.06: the history slider (stock box): the label follows the finger, the period changes when it is let go
  document.addEventListener('input', (ev) => {
    const r = ev.target.closest && ev.target.closest('[data-hist-range]');
    if (!r) return;
    const lab = r.closest('.stk-range') && r.closest('.stk-range').querySelector('[data-hist-label]');
    if (lab) lab.textContent = histShort(HIST_STOPS[+r.value] || 30);
  });
  document.addEventListener('change', (ev) => {
    const r = ev.target.closest && ev.target.closest('[data-hist-range]');
    if (!r) return;
    S.histDays = HIST_STOPS[+r.value] || 30;
    const num = r.dataset.histRange;
    histNeed(num, S.histDays);
    stockPaint(num);
  });
  document.addEventListener('click', (ev) => {
    const t = ev.target.closest('[data-st-info],[data-reg-guide],[data-reg-load],[data-reg-all],[data-reg-open],[data-reg-mj],[data-reg-check],[data-reg-seen],#regBar,#regAdjBar,[data-subst-open],[data-mode-q],[data-sf-st],[data-sf-sort],[data-miss],[data-sfs-retry],[data-hist-more],[data-refill-hide],[data-plan-server],#refillBar,[data-refill-add-here],[data-refill-add-new],[data-refill-scan],[data-refill-art-clear],[data-refill-max],[data-refill-info],[data-refill-del],[data-refill-undo],[data-refill-del-again],[data-refill-sf],[data-refill-reload],[data-refill-list],[data-refill-retry],[data-refill-pick],[data-refill-new],[data-refill-step],#oopusBar,[data-oopus],[data-oopus-reload],[data-oopus-sf],[data-oopus-filter],[data-oopus-find],[data-oopus-scan],[data-oopus-reorder],[data-oopus-hand],[data-oopus-cancel],[data-oopus-sign],[data-oopus-clear],[data-oopus-signoff],[data-oopus-save],[data-oopus-recheck],[data-owait],[data-ord-back],[data-ord-jump],[data-hist-all],[data-omain],[data-rz-tog],[data-rz-sub],[data-rz-info],[data-st-ord],[data-ocat],[data-oc-more],[data-ordsort-open],[data-ordsort-pick],[data-ordwait],[data-set-grp],[data-onplan],[data-onplan-at],[data-recent-all],[data-copy],[data-fav],[data-ovw],[data-num],[data-loc],[data-add],[data-replace],[data-delete],[data-changes],[data-unlink],[data-store],[data-orders],[data-oq],[data-mode],[data-set],[data-choice],[data-act],[data-tab],[data-cst],[data-sim],[data-sim-reset],[data-clr-st],[data-clr-sort],[data-clr-dept],[data-clr-pick],[data-clr-hier],[data-clr-pick-more],[data-clr-dm],[data-clr-xmas],[data-open-plan],[data-open-clear],[data-codes-more],[data-mj],[data-mj-open],[data-mj-x],[data-ar],[data-ar-sc],[data-ar-pick],[data-top],[data-top-days],[data-top-sort],[data-top-st],[data-top-pick],[data-top-hier],[data-top-sf],[data-sm],[data-sm-zero],[data-sm-plan],[data-sm-read],[data-sm-code],[data-sm-move],[data-sm-pick],[data-sm-hier],[data-au],[data-au-open],[data-au-go],[data-au-zero],[data-au-move],[data-au-master],[data-grp],[data-stock-retry],[data-plcheck],[data-ploff],[data-big],[data-soon],[data-soon-scope],[data-soon-grp],[data-soon-zero],#ordersBar,#clearBar,#minusBar,#tipsBar,#topBar,#smBar,#soonBar,[data-tip],[data-tip-go],#updateBar,#hotBar,#importBar,#crop,#openViewer');
    if (!t) return;
    if (regsUi.onClick(t)) return;
    if (t.id === 'regAdjBar') { regAdjUi.open(); return; }
    if (t.dataset.histMore) { const L = S.histLong && S.histLong.get(t.dataset.histMore); if (L) L.err = ''; histNeed(t.dataset.histMore, S.histDays || 30); return; }
    if (t.dataset.big) { sfBig(t.dataset.big, t); return; }
    if (t.dataset.planServer) { planServerOpen(t.dataset.planServer); return; }
    if (t.id === 'refillBar') { refillUi.open(); return; }
    if (refillUi.onClick(t)) return;
    if (oopusUi.onClick(t)) return;
    if (t.dataset.owait) {
      // the list stays as it was (filter, order, place): Natrag or "Svi artikli" returns to it
      S.ordBack = { scroll: $('#home .scroll').scrollTop };
      $('#q').value = t.dataset.owait;
      runOrdersSearch();
      showResultsTop();
      return;
    }
    if ('ordBack' in t.dataset) { ordersBackToList(); return; }
    if ('ordJump' in t.dataset) { const sc = t.closest('.scroll'), o = sc && sc.querySelector('.ord-hit'); if (o) sc.scrollTop += o.getBoundingClientRect().top - sc.getBoundingClientRect().top - 8; return; }
    if (t.dataset.histAll) { const n = t.dataset.histAll; if (histAllOpen.has(n)) histAllOpen.delete(n); else histAllOpen.add(n); stockPaint(n); return; }
    if (t.dataset.ordsortOpen) { openOrderSort(t.dataset.ordsortOpen); return; }
    if (t.dataset.ordsortPick) {
      const [w, k] = t.dataset.ordsortPick.split(':');
      if (w === 'cust' && !cfg().ordOrderSort) setCfg({ ordOrderSort: orderSort() }); // the list keeps its order
      setCfg(w === 'cust' ? { ordCustSort: k } : w === 'ord' ? { ordOrderSort: k } : w === 'res' ? { ordResSort: k } : { ordSort: k });
      closeSheet();
      if (top().id === 'home') runOrdersSearch(); else if (top().id === 'item' && S.item) renderItem(); else if (top().id === 'missing') renderMissing(top().state);
      return;
    }
    if ('ordwait' in t.dataset) { setCfg({ ordWaitOnly: cfg().ordWaitOnly === false }); runOrdersSearch(); return; }
    if (t.dataset.setGrp) { openSettingsGroup(t.dataset.setGrp); return; }
    if (t.dataset.onplan) { onPlanTap(t.dataset.onplan); return; }
    if (t.dataset.onplanAt) { const [n, i] = t.dataset.onplanAt.split('|'); openOnPlan(n, +i); return; }
    if ('recentAll' in t.dataset) { S.recentAll = !S.recentAll; renderHome(); return; }
    if (t.dataset.copy) { copyCode(t.dataset.copy); return; }
    if (t.dataset.fav) {
      toggleFav(t.dataset.fav);
      t.setAttribute('aria-pressed', String(isFav(t.dataset.fav)));
      t.textContent = isFav(t.dataset.fav) ? '★' : '☆';
      return;
    }
    if (t.dataset.ovw) { setCfg({ ordDetail: t.dataset.ovw !== 'compact' }); keepAnchor('#results .seg-mini', runOrdersSearch); return; }
    if (t.dataset.omain) { setCfg({ ordMain: t.dataset.omain }); keepAnchor('#results .ord-main', runOrdersSearch); return; }
    if (t.dataset.ocat) { setCfg({ ordCat: t.dataset.ocat }); keepAnchor('#results .ord-cats', runOrdersSearch); return; }
    // 25. 11. 2026: Rezervacije on / off, the kind of reservation, why an order is one
    if ('rzTog' in t.dataset) { setCfg({ ordRes: !resOn() }); keepAnchor('#results .ord-cats', runOrdersSearch); return; }
    if (t.dataset.rzSub) { setCfg({ ordResSub: t.dataset.rzSub }); keepAnchor('#results .rz-sum', runOrdersSearch); return; }
    if (t.dataset.rzInfo) { openRzInfo(t.dataset.rzInfo); return; }
    if (t.dataset.stOrd) { openStatusInfo(t.dataset.stOrd); return; }
    if (t.dataset.ocMore) {
      // 2.08: the other lines and the details of one order open in place (no re-render: the screen does not jump)
      const no = t.dataset.ocMore;
      const box = t.parentElement.querySelector('.oc-box');
      const open = !ocOpen.has(no);
      if (open) ocOpen.add(no); else ocOpen.delete(no);
      if (box) box.hidden = !open;
      t.setAttribute('aria-expanded', String(open));
      t.textContent = `${open ? 'Sakrij detalje' : t.dataset.more} ›`;
      // 2.08: what was just opened is brought into view, the card's top never pushed above the screen
      const card = t.closest('.oc');
      const sc = card && card.closest('.scroll');
      if (open && sc) {
        const v = sc.getBoundingClientRect(), c = card.getBoundingClientRect();
        const fab = 96; // the Skeniraj button over the bottom of the screen
        const need = c.bottom - (v.bottom - fab);
        if (need > 0) sc.scrollTop += Math.min(need, c.top - v.top - 12);
      }
      return;
    }
    if (t.dataset.sfSt) { searchUi.toggleSt(t.dataset.sfSt); return; }
    if (t.dataset.sfSort) { searchUi.toggleSort(); return; }
    if (t.dataset.modeQ) { const keep = $('#q').value; setMode(t.dataset.modeQ); $('#q').value = keep; runSearch(); return; } // 2.17: same text, StoreFront
    if (t.dataset.miss) { closeSheet(); openMissing(t.dataset.miss); return; } // 2.15-pregled: a StoreFront search hit
    if (t.dataset.sfsRetry) { searchUi.sfsRetry(); return; }
    if (t.dataset.num) { closeSheet(); openItem(t.dataset.num); return; }
    if (t.dataset.openPlan) { viewer.open(t.dataset.openPlan, +t.dataset.page || 0); return; }
    if (t.dataset.openClear) { openClearance(); return; }
    if (t.dataset.mj || t.dataset.mjOpen || t.dataset.mjX) { onNewsClick(t); return; }
    if (t.dataset.ar || t.dataset.arSc || t.dataset.arPick) { if (t.tagName !== 'SELECT') onArClick(t); return; }
    if (t.hasAttribute('data-plcheck')) { checkPlans(); return; }
    if (t.dataset.ploff) { const off = { ...planOff(), [t.dataset.ploff]: !planOff()[t.dataset.ploff] }; setCfg({ plOff: off }); renderSettings(); return; }
    if (t.dataset.codesMore) {
      if (!S.planMore.delete(t.dataset.codesMore)) S.planMore.add(t.dataset.codesMore);
      renderPlans();
      return;
    }
    if (t.dataset.set || t.dataset.choice || t.dataset.act || t.dataset.tab || t.dataset.cst || t.dataset.sim || 'simReset' in t.dataset) { onSettingsClick(t); return; }
    if (t.id === 'clearBar') { openClearance(); return; }
    if (t.id === 'minusBar') { openMinus(); return; }
    if (t.id === 'tipsBar') { openTips(); return; }
    if (t.dataset.tip || t.dataset.tipGo) { onTipClick(t); return; }
    if (t.id === 'topBar') { openTop(); return; }
    if (t.id === 'smBar') { openSm(); return; }
    if (t.id === 'soonBar') { openSoon(); return; }
    if (t.dataset.soon || t.dataset.soonScope || t.dataset.soonGrp || t.dataset.soonZero) { onSoonClick(t); return; }
    if ((t.dataset.top || t.dataset.topDays || t.dataset.topSort || t.dataset.topSt || t.dataset.topPick || t.dataset.topHier || t.dataset.topSf) && topSoonUi.onTopClick(t)) return;
    if (t.dataset.sm || t.dataset.smZero || t.dataset.smPlan || t.dataset.smRead || t.dataset.smCode || t.dataset.smMove || t.dataset.smPick || 'smHier' in t.dataset) { onSmClick(t); return; }
    if (t.hasAttribute('data-au-master')) { openAudit(); return; }
    if (t.dataset.grp) {
      const off = { ...(cfg().grpOff || {}) };
      if (off[t.dataset.grp]) delete off[t.dataset.grp]; else off[t.dataset.grp] = true;
      setCfg({ grpOff: off });
      const sc = t.dataset.grpScreen;
      if (sc === 'top') loadTop(); else if (sc === 'audit') loadAudit(); else loadSm();
      return;
    }
    if (t.dataset.au || t.dataset.auOpen || t.dataset.auGo || t.dataset.auZero || t.dataset.auMove) { onAuClick(t); return; }
    if (t.dataset.stockRetry) { stockLoad(t.dataset.stockRetry, true); return; }
    if ('clrMore' in t.dataset) { clearanceUi.showMoreClearance(); return; }
    if (t.dataset.clrDept || t.dataset.clrPick || 'clrHier' in t.dataset || 'clrPickMore' in t.dataset) { onClearDept(t); return; }
    if (t.dataset.clrDm) { clrDmOff(t.dataset.clrDm); return; }
    if (t.dataset.clrSt) { S.clr.st = t.dataset.clrSt; renderClearance(); return; }
    if (t.dataset.clrSort) { S.clr.sort = t.dataset.clrSort; renderClearance(); return; }
    if (t.dataset.clrXmas) { S.clr.peek = !S.clr.peek; renderClearance(); return; }
    if (t.id === 'updateBar') { installUpdate(); return; }
    if (t.id === 'hotBar') { applyHot('manual'); return; }
    if (t.id === 'importBar') { S.importBg = false; importBar(); toast('Uvoz se nastavlja…'); return; }
    if (t.dataset.mode) { setMode(t.dataset.mode); return; }
    if (t.dataset.oq) {
      // 2.08: from the list into one order; back returns to the same group and place
      if (!$('#q').value.trim()) S.ordBack = { scroll: $('#home .scroll').scrollTop };
      $('#q').value = t.dataset.oq; runOrdersSearch(); showResultsTop(); return;
    }
    if (t.dataset.orders || t.id === 'ordersBar') { refreshOrders(); return; }
    if (t.dataset.store) { A.storefront(t.dataset.store, 'view'); return; }
    if (t.dataset.substOpen) { const n = t.dataset.substOpen; if (S.index && S.index.byNum.has(n)) openItem(n); else openMissing(n); return; } // 21. 11.: the other article of a Zamjena
    if (t.dataset.unlink) {
      delete S.user.learned[t.dataset.unlink];
      if (S.shared && S.shared[t.dataset.unlink]) S.user.noShared = { ...(S.user.noShared || {}), [t.dataset.unlink]: 1 }; // 2.05
      S.missLinked = null;
      saveUser();
      openMissing(t.dataset.unlink, { replace: true });
      return;
    }
    if (t.dataset.loc !== undefined) { S.item.loc = +t.dataset.loc; S.item.focus = null; renderItem(); return; }
    if (t.hasAttribute('data-add')) { addPlanograms(); return; }
    if (t.dataset.replace) { if (S.busy) { toast('Sačekaj da se završi uvoz planograma.'); return; } addPlanograms(t.dataset.replace); return; }
    if (t.dataset.delete) { deletePlan(t.dataset.delete); return; }
    if (t.dataset.changes) { closeSheet(); renderChanges(t.dataset.changes); go('changes', t.dataset.changes); return; }
    if (t.id === 'crop' || t.id === 'openViewer') openViewerForItem();
  });

  viewer.bind();
  // the stock read before (last known, marked old when it is) shows at once; TEST builds check the faster reading
  planogramStock.attach(store, offline, note, sandboxOn());
}

window.appResume = () => {
  appShown = true;
  if (hotResume()) return; // 2.25: a ready fix starts now (the page loads again, quiet home screen)
  if (autoSync) setTimeout(() => autoSync.foreground(true), 2000); // 2.15: after the phone's own work of coming back
  // back from another app (e.g. the install permission screen) or after a while: look for updates, at most every 3 h
  if (S.update && S.update.state === 'permission') { renderUpdate(); return; }
  checkOnline();
  if (!S.updChecked || Date.now() - S.updChecked > 3 * 3600 * 1000) checkUpdate(false);
  pickupMyjysk();
  pageCache.start(); // stopped while the app was in the background
  setTimeout(warmStore, 1500); // back to the app (phone unlocked): StoreFront ready for the first article (1.70)
  if (S.mode === 'news') freshenMyjysk();
  else renderHome();
};
const applyTheme = () => {
  const t = cfg().theme;
  try { A.setTheme(t); } catch (e) { /* older shell */ }
  document.documentElement.dataset.theme = t === 'dark' ? 'dark' : t === 'light' ? 'light' : (A.isDark() ? 'dark' : 'light');
};
window.themeChanged = () => applyTheme();
// 2.15 (MainActivity.onPause): the app went to the background: no automatic look (the phone's own job takes over)
window.appPause = () => { appShown = false; hotHiddenAt = Date.now(); if (autoSync) autoSync.foreground(false); };
// 2.15: a tap on a notification: the screen it is about, with fresh data; nothing is sent anywhere
window.openFrom = (what) => {
  while (S.stack.length > 1) back();
  if (what === 'minus') { openMinus(); if (!S.minusBusy && !(minusop.locks && minusop.locks(S.minusOp)) && !S.minusApplying) loadMinus(); return; }
  if (what === 'orders') { if (S.mode !== 'orders') setMode('orders'); if (autoSync) autoSync.wake('notify-orders'); }
};

function boot() {
  load();
  S.smLog = store.read(SMLOG, null);
  if (S.smLog && S.smLog.state === 'sending') { S.smLog.state = 'interrupted'; store.write(SMLOG, S.smLog); }
  applyTheme();
  // a data file of the app could not be read: it was kept beside, nothing written over it unseen; say so once
  if (store.damaged.length) {
    const NAMES = { 'user.json': 'tvoje postavke, povezani barkodovi, Minus lista (Čeka Regulaciju)', 'plans.json': 'spisak planograma' };
    setTimeout(() => openSheet({ title: 'Dio podataka se nije mogao pročitati',
      body: `<p>${store.damaged.map((d) => `<b>${esc(d.name)}</b> (${esc(NAMES[d.name] || 'podaci')})${d.copy ? `, oštećena kopija je sačuvana kao ${esc(d.copy)}` : ''}`).join('<br>')}.</p>
        <p>Aplikacija radi dalje s praznim podacima za taj dio. Ako ti nešto nedostaje, Postavke → Podaci → vrati kopiju napravljenu pri zadnjem ažuriranju.</p>`,
      actions: [{ label: 'U redu', onClick: closeSheet }] }), 800);
  }
  S.mode = cfg().mode === 'orders' ? 'orders' : cfg().mode === 'sf' && A.storeTask ? 'sf' : cfg().mode === 'news' && mjOn() ? 'news' : 'plan';
  // 1.97: list deletions asked before the app was closed are sent once there is a network and a sign-in
  setTimeout(() => { if (refillUi && (S.user.refillDel || []).length) refillUi.drainDeletes(); }, 6000);
  pickupMyjysk();
  bind();
  checkOnline();
  // the app stopped working last time: write down which crash it was, switch the background look off once, and show the cause in the settings
  try { S.crash = (A.lastCrash && A.lastCrash()) || ''; } catch (e) { S.crash = ''; }
  if (S.crash) {
    const stamp = S.crash.split('\n')[0];
    if (S.user.crashSeen !== stamp) {
      S.user.crashSeen = stamp;
      // 1.97: the Java crash of the last run into the flow log: version, class and location (Diag already cleaned it)
      try { const at = (S.crash.match(/at ba\.polica\.[A-Za-z0-9_$.]+\(([A-Za-z0-9_]+\.java:\d+)\)/) || [])[1] || ''; flow.one('app', 'Neočekivana greška', 'Java (prethodno pokretanje)', 'app_error', { why: errWhy((S.crash.split('\n').find((l) => /Exception|Error/.test(l)) || stamp).slice(0, 80), at) }); } catch (e) { /* ignore */ }
      if (cfg().watch) setCfg({ watch: false }); else saveUser();
      setTimeout(() => toast('Aplikacija je prošli put prestala raditi. Pozadinska provjera je isključena.'), 1200);
    }
  }
  syncWatch();
  syncMyjysk(false);
  minusOpNow();
  if (sandboxOn()) document.body.classList.add('is-sandbox');
  renderHome();
  if (gateNeeded()) showGate();
  else if (!S.user.welcomeSetup?.done && (!A.loginState || A.loginState() === 'ok')) setTimeout(() => { if (!$('#gate').hidden || !$('#sheet').hidden) return; if (welcomeSetup) welcomeSetup.start(); }, 1800);
  else { try { if (A.loginState && A.loginState() === 'refused') setTimeout(() => toast('StoreFront nije prihvatio sačuvanu lozinku. Upiši je ponovo u Postavke → Prijava.'), 1500); } catch (e) { /* older shell */ } }
  setTimeout(() => tmAutoOn(), 6000); // 2.09: on by default, a notice once (was: a question)
  syncShareCodes(); // 2.08 (#22): Java holds the choice (2.07 kept it only in the page)
  setTimeout(() => pullShared(), 4000); // 2.05: shared barcodes, at most every 6 h
  setTimeout(() => shareLearned(), 6000); // 2.21: links kept on the phone go up once sharing is on (Java decides)
  if (S.mode === 'news') freshenMyjysk();
  setTimeout(() => checkUpdate(false), 1500);
  setTimeout(refreshOld, 400);
  setTimeout(() => { if (autoSync) autoSync.start(); }, 5000); // 2.15: after the start's own StoreFront work
  syncWatchMinus();
  restoreScreen();
  // 2.24: the start got this far: a bundle of screens on trial is a good one (MainActivity's watchdog waits for this)
  // 2.25: only when the main parts of the page are there (hotSelfCheck); then a ready fix starts on a quiet home screen
  hotReport();
  setInterval(hotTick, 15000);
  setTimeout(repairPictures, 6000); // pictures lost to a power cut right after an import: cut again from the PDF
  setTimeout(() => pageCache.start(), 6000); // pages of all planograms, after the start has settled
  // 27. 11. 2026: pdf.js is no longer loaded before the first screen (js/docs.js pdfLib); it is loaded quietly now, so
  // the first planogram or article picture does not wait for it
  (window.requestIdleCallback || ((f) => setTimeout(f, 600)))(() => { docs.pdfLib().catch(() => {}); }, { timeout: 1500 });
  setTimeout(fillMe, 4000);
}

/**
 * Who the employee is in MYJYSK (name, number), for the tasks that name him. It is never built into the app any more:
 * when the settings have nothing yet (a new install, or the update from a build that carried it), it is asked once
 * from StoreFront's own user details and kept on the phone. What the employee typed in Postavke is never replaced.
 */
function fillMe() {
  if (cfg().mjMe != null || !mjOn() || S.meAsked) return;
  S.meAsked = true;
  stCall({ mode: 'me', bg: true }, (r) => {
    if (r.how !== 'ok' || !r.res || cfg().mjMe != null) return;
    const v = [r.res.name, r.res.num].map((x) => String(x || '').replace(/\s+/g, ' ').trim()).filter(Boolean).join(', ').slice(0, 120);
    if (!v) return;
    setCfg({ mjMe: v });
    if ($('#settings').classList.contains('is-active')) renderSettings();
    renderHome();
  });
}

minusUi = createMinusUi({ $, A, S, SIMS, ageText, ask, esc, go, icon, itemRow, minusop, nameOf, openItem, ordersOf, plural, renderHome, sandboxOn, saveUser, sfThumb, simNow, stCall, toast, top, flow, ordersBlock, openSheet, closeSheet,
  onOp: () => { if (regAdjUi && top().id === 'regAdj') regAdjUi.render(); }, // 2.28: the sending's card is on Regulacija zalihe too
  onMinusRead: (prev, next) => { if (autoSync) autoSync.minusRead(prev, next); },
  minusMark: (num) => { const k = autoSync ? autoSync.mark('minusMarks', num) : ''; return k ? `<span class="ord-chip is-mark is-${k}">${k === 'new' ? 'Novo' : 'Promijenjeno'}</span>` : ''; },
  autoNote: () => (autoSync ? autoSync.note('minus') : '') });
autoSync = createAutoSync({ S, A, cfg, stCall, saveUser, toast, top, plural, orderTime, minusop, loadMinus, syncWatch, syncWatchMinus,
  tabs: () => TABS_ALL.filter((k) => cfg().tabs[k]),
  ageChanged: autoAgeChanged, redraw: autoRedraw });
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__auto = autoSync; // tests only (the phone page is file:// / appassets)
chainUi = createChainUi({ S, esc, stCall, offline, whole, storeNow: substStore,
  repaint: (num) => { for (const el of document.querySelectorAll(`[data-chain="${num}"]`)) el.innerHTML = chainUi.html(num); } });
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__chainUi = chainUi; // tests only
regsUi = createRegsUi({ S, A, esc, icon, openSheet, closeSheet, stCall, offline, whole, ageText, saveUser, mjOn, toast, storeNow: substStore,
  money: (x) => money(x),
  openArticle: (n) => { if (S.index && S.index.byNum.has(n)) openItem(n); else openMissing(n); },
  repaint: () => { for (const el of document.querySelectorAll('[data-stock]')) el.innerHTML = stockHtml(el.dataset.stock); } });
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__regsUi = regsUi; // tests only
regAdjUi = createRegAdjustUi({ $, A, S, esc, icon, go, top, toast, saveUser, plural, stCall, offline, thumb, minusop,
  artOf: (code) => artFromCode(code),
  scanFor: (cb) => { S.scanFor = cb; startScan(true); },
  opNow: () => minusUi.minusOpNow(), opCard: () => minusUi.minusOpCard(), onChange: () => renderStoreBars() });
if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) window.__regAdjUi = regAdjUi; // tests only
smdmUi = createSmdmUi({ flow, openSheet, closeSheet, planSpots, onPlanTap, $, A, S, SMLOG, ageText, ask, cfg, deptArg, deptChips, deptGroups, deptName, deptSig, esc, go, icon, plural, saveUser, smcheck, stCall, stPill, stText, store, toast, top, whole, withDept });
importUi = createImportUi({ $, A, S, afterAutoImport, artikala, ask, blobToBase64, closeSheet, core, docs, dropFiles, esc, icon, note, openSheet, pageCache, plural, progress, pruneSuperseded, queue, rebuildIndex, renderHome, renderItem, renderPlans, savePlansList, saveUser, store, toast, top });
oopusUi = createOopusUi({ $, A, S, esc, icon, go, top, back, ageText, toast, plural, whole, stCall, offline, flow, thumb, sfCode,
  scanFor: (cb) => { S.scanFor = cb; startScan(true); }, onChange: () => renderStoreBars() });
/** A scanned or typed code -> the article number (planogram, linked barcode, shared barcode); '' when not known. */
function artFromCode(code) {
  const c = String(code || '').replace(/\s+/g, '');
  const known = codes();
  let r = core.resolveCode(S.index, c, known);
  if (!r && eanOf(c)) r = core.resolveCode(S.index, c, { [c]: eanOf(c) });
  if (r) return r.num;
  if (known[c] && /^\d{7}$/.test(known[c])) return known[c];
  return /^\d{7}$/.test(c) ? c : '';
}
refillUi = createRefillUi({ $, A, S, esc, icon, go, top, back, thumb, nameOf, planSpots, onPlanTap, sfCode, ageText, toast, openSheet, closeSheet, saveUser, plural, whole, copyCode, stCall, offline, planServerBtn, cfg, setCfg,
  // 1.96: Punjenje adds articles itself: a scanned or typed code -> the article number; the scanner answers to it
  artOf: (code) => artFromCode(code),
  scanFor: (cb) => { S.scanFor = cb; startScan(true); }, flow });
searchUi = createSearchUi({ cfg, setCfg, chev: icon('chev', 'chev'), stCall, offline, thumb, ST_SHORT, money: (x) => `${money(x)} KM`, $, $$, S, artikala, core, esc, itemRow, itemSummaryRow, placeHomeBars, mjOn, newsWaiting, ordersBlock, plural, renderClearBar, renderMinusBar, renderNews, renderOrdersBar, renderStoreBars, runOrdersSearch });
// 1.73-test4: an article in no planogram on the phone gets its department's planogram next to it (download + read)
const planGet = createPlanGet({
  S, esc, stCall, news, toast,
  planList: () => mjPlansUi.planList(), planOnPhone: (p) => mjPlansUi.planOnPhone(p), busy: () => mjPlansUi.busy(),
  startPlanDownload: (o) => mjPlansUi.startPlanDownload(o), cancel: () => mjPlansUi.cancelPlans(), refreshList: () => refreshMyjysk(false),
  loadDepts: (done) => loadWelcomeHierarchy({ S, stCall, saveUser, toast: () => {}, done }),
  // read: an article number that is in a planogram now opens with its place; a barcode's screen shows StoreFront's
  // answer again (one article in a planogram now opens with its place)
  onReady: () => {
    const t = top();
    if (t.id !== 'missing') return;
    if (/^\d{7}$/.test(String(t.state))) {
      if (S.index.byNum.has(t.state)) openItem(t.state, { via: 'planogram' }, { replace: true });
      else renderMissing(t.state);
      return;
    }
    if (S.storeCb && S.storeLast) S.storeCb(S.storeLast);
  },
});
missingUi = createMissingUi({ $, A, S, cfg, core, chainBox, planServerBtn, debounce, esc, go, icon, itemRow, money, openItem, ordersBlock, ordersOf, planGet, saveUser, sfThumb, stCall, stPill, stockHtml, stockLoad, toast, top, whole, offline: () => offline(), note });
articleUi = createArticleUi({ $, S, core, chainBox, createCropCache, dateBs, docs, esc, fixtureText, go, icon, isBar, isFav, locationsOf, note, ordersBlock, ordersHint, pills, rememberRecent, stockHtml, stockLoad, thumb, viewer, whole, substNote,
  namesOf: (n) => [nameOf(n), (S.stock.get(n) || {}).name, (planogramStock.cache.get(n) || {}).name].filter(Boolean).join(' · ') });
mjPlansUi = createMjPlansUi({ A, S, ageText, cfg, closeSheet, core, drainImports, esc, mjOn, news, openSheet, plural, progress, queue, refreshMyjysk, renderPlans, renderSettings, saveUser, setCfg, showResults, toast, top });
let welcomeSetup = createWelcomeSetup({ S, $, esc, stCall, saveUser, setCfg, openSheet, closeSheet, toast,
  planList: () => mjPlansUi.planList(), checkPlans: () => mjPlansUi.checkPlans(),
  loadHierarchy: ({ S, stCall, saveUser, toast, done }) => loadWelcomeHierarchy({ S, stCall, saveUser, toast, done }),
  refreshMyjysk: visible => refreshMyjysk(visible), getSide: () => cfg().plSide, canMyjysk: mjOn, deptNo: news.deptNo });
arUi = createArUi({ $, A, S, ar, cfg, esc, go, icon, mjOn, note, refreshMyjysk, renderNews, saveUser, toast, top });
tipsUi = createTipsUi({ $, A, S, ar, arKept, deptName, esc, go, icon, loadAudit, loadClr2, loadTop, mjMe, mjOn, news, openAr, openAudit, openClearance, openTop, setMode, smcheck, tips, top });
topSoonUi = createTopSoonUi({ store, note, openMissing, pickerHtml, validGroup, loadHierarchy: loadWelcomeHierarchy, $, A, S, ageText, ask, cfg, deptArg, deptChips, deptGroups, deptKey, deptName, deptNums, deptSig, dm, esc, go, icon, itemRow, money, plural, saveUser, sfThumb, smJob, stCall, toast, top, whole, withDept });
newsUi = createNewsUi({ $, A, NEWS_SHOWN, S, ageText, arBar, cfg, debounce, esc, go, icon, itemRow, mjMe, mjOn, news, newsRow, openAr, openItem, ordersOf, refreshMyjysk, sfThumb, taskRow, toast });
clearanceUi = createClearanceUi({ $, A, CLR_ST, S, ageText, ask, cfg, core, deptUsed, esc, go, icon, norm, plural, renderPlans, saveUser, smJob, stCall, thumb, toast, top, withDept });
myjyskUi = createMyjyskUi({ $, A, MJ_FILE, S, arLoad, ask, back, cfg, closeSheet, esc, icon, impItems, mjOn, news, openSheet, plural, renderHome, renderNews, renderSettings, saveUser, setMode, startPlanDownload, store, toast, top });
// The native MYJYSK callback updates existing planogram metadata first,
// then refreshes the optional setup chooser. It never triggers a download.
const previousMyjyskResult = window.onMyjysk;
window.onMyjysk = result => {
  previousMyjyskResult(result);
  if (welcomeSetup) welcomeSetup.refreshed(result);
};
boot();
