// Narudžbe: value in KM and Rezervacije (owner, 25. 11. 2026). Pure functions over the orders the phone already has,
// no StoreFront call, nothing sent anywhere (the order descriptions, names and amounts never leave the phone).
// Used by app.js; tests/reservations.test.mjs. Research and sources: docs/NARUDZBE-REZERVACIJE-2026-11-25.md.
//
// Where the data comes from (StoreFront, read only, 25. 11. 2026):
//   value        the order's totalAmount: StoreFront's own "Cijena" column and the total of its order sheet. The lines
//                carry no prices, discounts or paid amounts (nor does the order's detail), so the value is never
//                computed from today's article prices.
//   description  the order's internal text that the till (GK) writes when the order is made ("avansna", "predračun",
//                "rez", "klik", "plaćena rez" ...): the only place where the store says it is a reservation and how it
//                is paid. StoreFront has no field for a reservation; its only payment field is
//                additionalStorePaymentRequired ("Čeka se plaćanje").
//   created      the oldest entry of the order's history (owner, 14. 11. 2026): when the order was made.
import { orderState } from './order-waiting.js';

/**
 * Every rule of this screen in one place, each with its source. confirmed: false means the app does not know when the
 * 14 days of a reservation start, so it shows how old the reservation is and never says "istekla".
 */
export const RULES = {
  version: 3,
  // owner, 26. 11. 2026 (after the check on the store's real orders, replaces the store's 48 h of 25. 11.): an ordinary
  // reservation ("rez", "rezz", "rezervacija", however written) is held as MYJYSK 3.03.2 says: at most 14 days in the
  // BO, then the store calls the customer (who does not want it: cancel, back to the free stock, return the avans).
  // Paid or not. Counted from the moment it was made at the till (the oldest entry of the order's history in
  // StoreFront): StoreFront does not say when the goods went into the BO. A refresh, a restart or a new order status
  // never starts it again. (Internal Audit, October 2026: "10 rezervacija starijih od 14 dana".)
  hold: { days: 14, from: 'created', confirmed: true, src: 'MYJYSK 3.03.2' },
  // owner, 26. 11. 2026 + MYJYSK 3.10: Click & Collect ("klik" / "click") is never paid in advance, and the customer
  // picks it up by the end of the day it was made + 48 hours (made on Monday at 10:00: until Wednesday at midnight)
  cc: { hours: 48, from: 'dayEnd', src: 'MYJYSK 3.10' },
  soonHours: 12, // owner: orange when less than 12 h are left
  urgentHours: 3, // owner: red when less than 3 h are left or it has run out
};

// ------------------------------------------------------------------------------------------------- value in KM

/** The value StoreFront keeps for an order, in whole fenings (1,00 KM = 100), or null when it did not give one. */
export function fenings(v, currency) {
  if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 1e8) return null;
  // another currency is never added to KM (in BiH StoreFront leaves the code empty: the store's own, KM)
  if (currency != null && currency !== '' && !/^(BAM|KM)$/i.test(String(currency))) return null;
  return Math.round(v * 100);
}
/** The order's value in fenings, or null (unknown is never 0). */
export const amountOf = (ord) => (ord && Number.isInteger(ord.amt) && ord.amt >= 0 ? ord.amt : null);
/** "1.299,00 KM" (the Bosnian way; the phone's own locale data is not trusted for it). */
export function money(fen) {
  if (!Number.isInteger(fen)) return '? KM';
  const neg = fen < 0, a = Math.abs(fen);
  const kmPart = String(Math.floor(a / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${neg ? '−' : ''}${kmPart},${String(a % 100).padStart(2, '0')} KM`;
}

// ------------------------------------------------------------------------------------------------- the words

/** Lower case, no č ć š ž (đ is dj), links and e-mail addresses left out: the description as words. */
export function normText(s) {
  return String(s == null ? '' : s).toLowerCase().replace(/đ/g, 'dj').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/https?:\/\/\S+|www\.\S+|[^\s@:;,()]+@[^\s@]+\.[a-z]{2,}/g, ' ')
    // words written together: "placenarezervacija", "rezplacena"
    .replace(/\b((?:ne)?u?placen[aoi]?)(rez)/g, '$1 $2').replace(/\b(rez+)((?:ne)?u?placen[aoi]?)\b/g, '$1 $2');
}
export const tokens = (norm) => norm.split(/[^a-z0-9]+/).filter(Boolean);
// the parts of a sentence ("kupac nije došao, rezervacija": the "nije" is not about the reservation)
const CLAUSE = /([,;.!?+()/\\|:\n–—·]+|\s+-+\s+|\s+i\s+|\s+a\s+)/; // a dash only between spaces ("ne-plaćeno" stays one)
/** Words, for each the part of the sentence it is in, and the parts that are questions ("da li je plaćeno?"). */
function words(norm) {
  const tk = [], part = [], ask = [], texts = [];
  const bits = norm.split(CLAUSE); // the parts and, between them, what split them
  for (let k = 0; k < bits.length; k += 2) {
    const c = k / 2;
    texts[c] = bits[k];
    ask[c] = (bits[k + 1] || '').includes('?') || /\b(?:li|provjer\w*|pitati|pitaj)\b/.test(bits[k]);
    for (const t of tokens(bits[k])) { tk.push(t); part.push(c); }
  }
  return { tk, part, ask, texts };
}

/** Damerau-Levenshtein distance (optimal string alignment), or max + 1 as soon as it is surely more than max. */
export function dl(a, b, max = 2) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let p2 = null, p = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const c = [i];
    let low = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let v = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + cost);
      if (p2 && i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, p2[j - 2] + 1);
      c[j] = v;
      if (v < low) low = v;
    }
    if (low > max) return max + 1;
    p2 = p; p = c;
  }
  return p[b.length];
}

// A reservation, said in full or the usual short ways (owner's list). "rezervni" (a spare part, code 81) is not one.
const RES_EXACT = new Set(['rezerv', 'rezerva', 'reservation', 'reserved']);
const REZ = /^rez+$/; // rez, rezz, rezzz ...
const SPARE = /^(?:dio|dijel(?:a|ovi|ove|u)?|djel(?:a|ovi|ove)?)$/; // "rez. dio" = rezervni dio, a spare part (not "djelimično")
const RES_STEM = /^rezerv(?:ac|is|ir)/; // rezervacija, -e, -u, -om; rezervisano, rezervirano, rezervisati ...
const RES_LONG = ['rezervacija', 'rezervacije', 'rezervaciju', 'rezervisano', 'rezervirano', 'rezervisana', 'rezervirana', 'rezervisati', 'rezervirati'];
// "klik" / "click": a reservation (owner, 25. 11. 2026, confirmed); only as a word of its own, in a description that
// is not technical text (links, code). It says nothing about payment.
const CLICK = new Set(['klik', 'click', 'klick', 'clik']);
// code, not words (links are left out by normText already): "id=click", "on_click", "<a>"
const TECH = /[<>{}\\|`]|\w=\w|\w_\w|\.(?:js|html?)\b/;
const NEG = new Set(['nije', 'nisu', 'bez', 'ne', 'nema', 'ni', 'nikakva', 'nikakve', 'nikakvu']);
// the reservation is over (cancelled, no longer valid, ran out): never an active one
const OVER = /^(otkaz|ponist|storn|istekl|nevaz|nevazec|odusta)/;
// what one is told to do is not what happened ("ako ne dođe, otkazati")
const OVER_TODO = /^(?:otkazati|otkazuj\w*|otkazivati|otkazi|otkazite|ponistiti|ponisti)$/;
const OVER_TWO = /\b(?:vise|vec)?\s*ne\s+(?:vrijedi|vazi|vazeca|vrijede)\b|\bnije\s+(?:vise\s+)?vazec\w*|\bvise\s+nije\s+vazec\w*/;
// a part of a sentence that says only that it is over ("rezervacija, otkazana" / "kupac odustao")
const OVER_ONLY = /^(?:je|su|se|vise|vec|ne|nije|vrijedi|vazi|vazeca|vrijede|kupac|kupca|kupcu|od|rezervacije)$/;
// a deadline written by hand: the app never computes it, a colleague checks it
const TEXT_DUE = /\b(do\s+(?:ponedj?eljk\w*|ponedj?eljak|utor\w*|sri?jed\w*|sred\w*|cetvrt\w*|petk\w*|petak|subot\w*|nedj?elj\w*|sutra|prekosutra|kraja\s+\w+|\d{1,2}\s*[./]\s*\d{1,2}\.?(?:\s*\d{2,4})?|\d{1,2}(?:[:.]\d{2})?\s*h\b|\d{1,2}:\d{2})|rok\s+\d{1,2}\s*[./]\s*\d{1,2}\.?|produz\w*|produlj\w*|prolong\w*)/;

/** A misspelt reservation: '' (no), 'sure' (one letter off a long word), 'likely' (two letters, or a shorter word). */
function fuzzyRes(t) {
  if (t.length < 7 || /^rezervn/.test(t)) return '';
  if (t[0] !== 'r') {
    // a typo in the first letter ("erzervacija", "ezervacija"): one letter off a long word, never sure
    if (t.length < 9 || !/^[ez]/.test(t)) return '';
    return RES_LONG.some((w) => dl(t, w, 1) <= 1) ? 'likely' : '';
  }
  const max = t.length >= 9 ? 2 : 1;
  let best = max + 1;
  for (const w of RES_LONG) best = Math.min(best, dl(t, w, max));
  if (best > max) return '';
  return best === 1 && t.length >= 9 ? 'sure' : 'likely';
}
// "nije rezervacija", "bez rezervacije", "nije to rez" (but "nije plaćena rezervacija" is a reservation, not paid);
// only within the same part of the sentence
const NEG_FILL = new Set(['to', 'ovo', 'bila', 'bio', 'bilo', 'vise', 'jos', 'ni']);
const negated = (tk, i, part) => (i > 0 && part[i - 1] === part[i] && NEG.has(tk[i - 1]))
  || (i > 1 && part[i - 2] === part[i] && part[i - 1] === part[i] && NEG.has(tk[i - 2]) && NEG_FILL.has(tk[i - 1]));

// Payment words. "neplaćena" holds "plaćena" but is a word of its own.
const PAID = /^(?:u?placen[aoi]?|platio|platila|platili|uplatio|uplatila|uplatili|paid|prepaid)$/;
const UNPAID = /^(?:neplacen[aoi]?|neuplacen[aoi]?|unpaid)$/;
// owner, 25. 11. 2026 (from the store's own work): "avansna", "avansno", "avansa" is how an order for a customer is
// written, and in about 99 % of them the whole price is paid: "Vjerovatno plaćena" (from the description, never a
// payment system's confirmation). A kapara is a part. A polog says no amount. Something more exact wins (a part, a
// percentage, an amount, "ostatak").
const DEPOSIT = /^(?:avans\w*|kapar\w*|polog\w*)$/;
// 27. 11. 2026 (owner's BackOffice list): the till's typos of „avansna“ („AVAVNSA“, „AVNSA“) are the same word
const DEP_WORDS = ['avans', 'avansa', 'avansna', 'avansno'];
const isDeposit = (t) => DEPOSIT.test(t) || (/^av/.test(t) && t.length >= 5 && t.length <= 9 && t.includes('n') && t.includes('s')
  && DEP_WORDS.some((w) => dl(t, w, 2) <= (t.length <= 5 ? 1 : 2)));
const KAPARA = /^kapar/;
// only these say that a part is paid and a part is not
const PART = /^(?:djelimicn\w*|djelomicn\w*|delimicn\w*|dijelom|ostatak|doplat\w*|duguje|dug|pola|polovin\w*)$/;
// words that may stand between a "nije" and what it says no to ("nije još plaćeno", "nije ništa uplaćeno")
const FILL = new Set(['jos', 'nista', 'se', 'mu', 'joj', 'im', 'ga', 'to', 'bas', 'uopce', 'uopste', 'sve', 'kupac', 'kupca', 'jos']);
// "plaćeno u cijelosti", "sve plaćeno", "cijeli iznos": all of it, said next to the payment (never "komplet kreveta")
const FULL = /\bu\s+(?:cijelosti|cjelosti|potpunosti)\b|\bcijeli\s+iznos\b|\bsve\s+(?:je\s+)?u?placen\w*|\bu?placen\w*\s+(?:je\s+)?sve\b|\bkompletno\s+u?placen\w*|\bu?placen\w*\s+kompletno\b/;
const PRE = /^predracun/;
// an amount written by hand: "avans 50 %", "avans 200 KM", "kapara 150,00 km"
const PCT = /(\d{1,3})\s*%/;
const KM = /(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?\s*(?:km|kmf|bam)\b/;
const LATER = /\b(?:plac\w*|plati\w*|platit\w*)\s+(?:\w+\s+)?(?:pri|kod|na)\s+preuz\w*/; // "plaća pri preuzimanju"

const memo = new Map();
/**
 * What the description says: { level: 'sure' | 'likely' | 'none', words, why, over, due, pay: { cat, src, conflict,
 * words, why } }. level 'none' also when the reservation is negated ("nije rezervacija") or over ("otkazana").
 * sf: StoreFront's own "Čeka se plaćanje" (additionalStorePaymentRequired). Memoised by text (a reading is
 * classified once, never again while scrolling or drawing).
 */
export function classify(note, sf = false) {
  const key = `${sf ? 1 : 0}\u0001${note || ''}`;
  const hit = memo.get(key);
  if (hit) return hit;
  if (memo.size > 4000) memo.clear();
  const r = classifyNow(note, sf);
  memo.set(key, r);
  return r;
}
export const classifyCacheSize = () => memo.size;

function classifyNow(note, sf) {
  const n = normText(note).replace(/\s+/g, ' ').trim();
  const { tk, part, ask, texts } = words(n);
  const found = [], foundAt = [], foundIdx = [], why = [];
  let sure = false, likely = false, neg = false;
  for (let i = 0; i < tk.length; i++) {
    const t = tk[i];
    let kind = '';
    if (REZ.test(t) && SPARE.test(tk[i + 1] || '')) continue; // "rez. dio": a spare part
    if (RES_EXACT.has(t) || REZ.test(t) || RES_STEM.test(t)) kind = 'sure';
    else if ((kind = fuzzyRes(t))) { /* misspelt */ }
    else if (CLICK.has(t) && !TECH.test(String(note || '').toLowerCase())) kind = 'sure'; // owner: klik = rezervacija
    if (!kind) continue;
    if (negated(tk, i, part)) { neg = true; why.push(`„${tk.slice(Math.max(0, i - 2), i + 1).join(' ')}“: nije rezervacija`); continue; }
    found.push(t);
    foundAt.push(part[i]);
    foundIdx.push(i);
    if (kind === 'sure') sure = true; else likely = true;
  }
  // over (cancelled, gave up, no longer valid): only in the part of the sentence with the reservation word, or in a
  // part that says nothing else; never "nije otkazana", never an instruction ("ako ne dođe, otkazati")
  const resParts = new Set(foundAt);
  const onlyOver = (c) => tk.every((t, k) => part[k] !== c || OVER.test(t) || OVER_ONLY.test(t));
  let over = false;
  if (sure || likely) {
    tk.forEach((t, k) => {
      if (!OVER.test(t) || OVER_TODO.test(t)) return;
      if ((k > 0 && part[k - 1] === part[k] && NEG.has(tk[k - 1])) || (k > 1 && part[k - 2] === part[k] && NEG.has(tk[k - 2]) && NEG_FILL.has(tk[k - 1]))) return;
      if (onlyOver(part[k])) { over = true; return; }
      if (!resParts.has(part[k])) return;
      const next = tk[k + 1];
      if (next !== undefined && part[k + 1] === part[k] && !OVER_ONLY.test(next) && !foundIdx.includes(k + 1) && !NEG_FILL.has(next)) return; // "otkazao dostavu"
      const near = foundIdx.some((r) => part[r] === part[k] && Math.abs(r - k) <= 3
        && tk.slice(Math.min(r, k) + 1, Math.max(r, k)).every((w) => OVER_ONLY.test(w) || NEG_FILL.has(w)));
      if (near) over = true;
    });
    texts.forEach((x, c) => { if (OVER_TWO.test(x) && (resParts.has(c) || onlyOver(c))) over = true; });
  }
  const dueM = TEXT_DUE.exec(n);
  const level = over || !(sure || likely) ? 'none' : sure ? 'sure' : 'likely';
  if (over) why.push('opis kaže da rezervacija više ne vrijedi (otkazana, poništena ili istekla)');
  else if (level === 'sure') why.push(`u opisu: „${found.join(', ')}“`);
  else if (level === 'likely') why.push(`u opisu: „${found.join(', ')}“ (liči na rezervaciju, nije sigurno)`);
  else if (!neg) why.push('u opisu nema riječi rezervacije');
  // owner, 25. 11. 2026: "klik" / "click" = the customer ordered on the web (Click & Collect) and the store reserved the
  // goods in the BO; one of the reservations, told apart only by this mark (no system of its own)
  const cc = level !== 'none' && found.some((w) => CLICK.has(w));
  return { level, words: found, why, over, neg, cc, due: level !== 'none' && dueM ? dueM[1] : '', pay: payment(n, tk, part, ask, sf, level === 'none' ? '' : cc ? 'cc' : 'res') };
}

/**
 * How the order is paid, as the description (and StoreFront's one field) says. cat:
 *   paid      all of it ("plaćena", "uplaćeno", "plaćeno u cijelosti", "avans 100 %")
 *   unpaid    nothing ("neplaćena", "nije plaćeno", "bez avansa", "plaća pri preuzimanju"; StoreFront "Čeka se plaćanje")
 *   partial   confirmed only a part ("djelimično plaćeno", "ostatak", "doplata", "avans 50 %", an avans in KM below
 *             the order's value: see reservationOf)
 *   deposit   an avans / kapara / polog of an amount not known (it may be all of it)
 *   unknown   nothing about payment (also "predračun" by itself, and an ordinary "rez": only the back office knows)
 *   conflict  the description against itself, or against StoreFront
 * src: 'text' (from the description: never a payment system's confirmation), 'sf', 'both', 'cc' (MYJYSK 3.10: Click &
 * Collect is never paid in advance). km: an avans in KM. kind: '' (no reservation), 'res', 'cc'.
 */
function payment(n, tk, cl, ask, sf, kind = '') {
  const paid = [], unpaid = [], part = [], dep = [], asked = [];
  let pre = false;
  // a "nije" / "bez" up to three words before, in the same part, with only small words between
  const negAt = (i) => {
    for (let j = i - 1; j >= 0 && j >= i - 3 && cl[j] === cl[i]; j--) {
      if (NEG.has(tk[j])) return j;
      if (!FILL.has(tk[j]) && !PAID.test(tk[j])) return -1;
    }
    return -1;
  };
  for (let i = 0; i < tk.length; i++) {
    const t = tk[i];
    const j = negAt(i);
    const said = j >= 0 ? tk.slice(j, i + 1).join(' ') : t;
    if (UNPAID.test(t)) unpaid.push(t);
    else if (PAID.test(t)) {
      if (ask[cl[i]]) asked.push(t); // a question is not an answer
      else (j >= 0 ? unpaid : paid).push(said);
    } else if (isDeposit(t)) { if (ask[cl[i]]) asked.push(t); else (j >= 0 ? unpaid : dep).push(said); }
    else if (PART.test(t)) { if (ask[cl[i]]) asked.push(t); else (j >= 0 ? unpaid : part).push(said); }
    else if (PRE.test(t)) pre = true;
  }
  if (LATER.test(n)) unpaid.push('plaća pri preuzimanju');
  // "nije uplatio" inside "nije uplatio avans" is said once
  for (let i = unpaid.length - 1; i >= 0; i--) if (unpaid.some((w, k) => k !== i && w !== unpaid[i] && w.includes(unpaid[i]))) unpaid.splice(i, 1);
  // "avans nije plaćen", "neplaćen avans": an avans said not to be paid, in the same part of the sentence, is no avans
  const depParts = new Set(), unpaidParts = new Set();
  tk.forEach((t, i) => { if (isDeposit(t)) depParts.add(cl[i]); if (UNPAID.test(t) || (PAID.test(t) && negAt(i) >= 0)) unpaidParts.add(cl[i]); });
  if ([...depParts].some((c) => unpaidParts.has(c))) dep.length = 0;
  // "nije sve plaćeno", "nije u cijelosti plaćeno": a part
  const fullM = FULL.exec(n);
  const fullNeg = fullM && /\b(?:nije|ne|nisu)\s+(?:\w+\s+)?$/.test(n.slice(Math.max(0, fullM.index - 14), fullM.index));
  if (fullNeg) { part.push(`nije ${fullM[0]}`); for (let i = unpaid.length - 1; i >= 0; i--) if (/placen|uplacen/.test(unpaid[i])) unpaid.splice(i, 1); }
  const full = !!fullM && !fullNeg;
  // an amount paid, written by hand: a percentage, or KM (with an avans or a "plaćeno"/"uplaćeno")
  const money0 = dep.length || paid.length;
  const pm = money0 ? PCT.exec(n) : null;
  const pct = pm ? +pm[1] : null;
  const km = money0 && !pm ? KM.exec(n) : null;
  const kmFen = km ? Number(km[1].replace(/\./g, '')) * 100 + (km[2] ? Number(km[2].padEnd(2, '0')) : 0) : null;
  const avans = dep.some((w) => /^avans/.test(w) || (/^av/.test(w) && isDeposit(w))); // and its typos (AVNSA)
  const kapara = dep.some((w) => KAPARA.test(w));
  // all of it: "plaćeno u cijelosti", "avans u cijelosti", "avans 100 %" (a kapara or a polog is never all of it)
  const allPaid = (full && (paid.length > 0 || avans) && !dep.some((w) => /^(kapar|polog)/.test(w))) || (pct !== null && pct >= 100 && (paid.length > 0 || avans));
  let cat = 'unknown', why = '', likely = false, byRule = '';
  const said = (a) => a.join(', ');
  if (allPaid && unpaid.length) { cat = 'conflict'; why = `opis kaže i „${paid[0] || dep[0]}“ i „${unpaid[0]}“`; }
  else if (allPaid) { cat = 'paid'; why = `u opisu: „${said([...paid, ...dep])}“, ${pct !== null ? `${pct} %` : 'u cijelosti'}`; }
  else if (part.length || (pct !== null && pct > 0 && pct < 100)) { cat = 'partial'; why = `u opisu: „${said([...part, ...paid, ...dep])}“${pct !== null ? `, ${pct} %` : ''}: plaćen je samo dio`; }
  else if (paid.length && unpaid.length) { cat = 'conflict'; why = `opis kaže i „${paid[0]}“ i „${unpaid[0]}“`; }
  else if (kmFen === 0) { cat = 'unpaid'; why = `u opisu: „${said([...paid, ...dep])}“ 0,00 KM`; }
  else if (kmFen !== null && kmFen > 0) { cat = 'deposit'; why = `u opisu: „${said([...paid, ...dep])}“ ${money(kmFen)}`; }
  else if (kapara) { cat = 'partial'; why = `u opisu: „${said(dep)}“: kapara je dio cijene`; }
  else if (avans) { cat = 'paid'; likely = true; why = `u opisu: „${said([...dep, ...paid])}“: u ovoj prodavnici to skoro uvijek znači da je plaćen cijeli iznos (vlasnik), ali nije potvrda iz sistema plaćanja`; }
  else if (dep.length) { cat = 'deposit'; why = `u opisu: „${said(dep)}“: iznos nije poznat`; }
  else if (paid.length) { cat = 'paid'; why = `u opisu: „${said(paid)}“`; }
  else if (unpaid.length) { cat = 'unpaid'; why = `u opisu: „${said(unpaid)}“`; }
  else if (asked.length) why = `u opisu je pitanje („${said(asked)}?“), ne odgovor`;
  else if (pre) why = 'predračun: ne kaže je li plaćeno';
  else {
    // the description says nothing about payment. Owner, 26. 11. 2026: an ordinary "rez" is not paid in about 80 % of
    // the cases, but only the back office shows it (the 14 days run either way); MYJYSK 3.10: a Click & Collect order
    // is never paid in advance. StoreFront's own "Čeka se plaćanje" (below) says more than both.
    if (!sf && kind === 'cc') { cat = 'unpaid'; byRule = 'cc'; why = 'Click & Collect se ne plaća unaprijed (MYJYSK 3.10)'; }
    else why = kind === 'res' ? 'opis ne kaže je li plaćeno: vidi se samo u back officeu (u ovoj prodavnici oko 80 % takvih rezervacija nije plaćeno)' : 'opis ne kaže je li plaćeno';
  }
  let src = cat === 'unknown' ? '' : byRule || 'text', sfWait = false;
  if (sf) {
    // StoreFront's own field: the order must still be paid before it is handed out ("Čeka se plaćanje")
    const sfWhy = 'StoreFront: „Čeka se plaćanje“';
    if (cat === 'paid' || cat === 'conflict') { cat = 'conflict'; why = `${sfWhy}, a ${why}`; src = 'both'; }
    else if (cat === 'deposit' && kmFen !== null) { src = 'both'; why = `${sfWhy}; ${why}`; sfWait = true; }
    else if (cat === 'partial' || cat === 'deposit' || cat === 'unpaid') { src = 'both'; why = `${sfWhy}; ${why}`; if (cat === 'deposit') cat = 'partial'; }
    else { cat = 'unpaid'; src = 'sf'; why = sfWhy; }
  }
  return { cat, src, conflict: cat === 'conflict', why, words: [...paid, ...unpaid, ...part, ...dep], ...(likely && cat === 'paid' ? { likely: true } : {}), ...(kmFen !== null && cat === 'deposit' ? { km: kmFen } : {}), ...(sfWait ? { sfWait: true } : {}) };
}

// ------------------------------------------------------------------------------------------------- time

const lastSunday = (y, m) => { const d = new Date(Date.UTC(y, m + 1, 0)); return d.getUTCDate() - d.getUTCDay(); };
/** Europe/Sarajevo summer time of a year in UTC: from the last Sunday of March 01:00 to the last Sunday of October 01:00. */
export const summerUtc = (y) => ({ start: Date.UTC(y, 2, lastSunday(y, 2), 1), end: Date.UTC(y, 9, lastSunday(y, 9), 1) });
const isSummer = (ms) => { const { start, end } = summerUtc(new Date(ms).getUTCFullYear()); return ms >= start && ms < end; };
/** A Sarajevo wall-clock time as a moment. The autumn hour that happens twice is taken the later time (a deadline is
 * never earlier than it may be); the spring hour that does not exist moves forward. */
export function sarajevoMs(y, mo, d, h = 0, mi = 0, s = 0) {
  const wall = Date.UTC(y, mo - 1, d, h, mi, s);
  const cet = wall - 3600e3, cest = wall - 7200e3;
  if (!isSummer(cet)) return cet;
  if (isSummer(cest)) return cest;
  return cet;
}
/** "24.11.2026 14:05" in Sarajevo time, whatever the phone's own zone. */
export function sarajevoText(ms) {
  if (!Number.isFinite(ms)) return '';
  const d = new Date(ms + (isSummer(ms) ? 7200e3 : 3600e3));
  const two = (x) => String(x).padStart(2, '0');
  return `${two(d.getUTCDate())}.${two(d.getUTCMonth() + 1)}.${d.getUTCFullYear()} ${two(d.getUTCHours())}:${two(d.getUTCMinutes())}`;
}
/**
 * When the order was made, as a moment, or null: the oldest history entry (mk, from StoreFront's own milliseconds) or
 * its text in the store's clock ("dd.mm.yyyy hh:mm:ss"). Not when that entry is a message to the customer (the
 * history may be incomplete: approximate, never a deadline's start).
 */
/**
 * 27. 11. 2026 (owner, BackOffice „Specijalne narudžbe“): the till's order number carries when it was made:
 * 7X704 · 1 · till (01, 02) · DDMMYY · HHMMSS, e.g. 7X704 1 02 231126 160755 = till 2, 23.11.2026 16:07:55 (Sarajevo).
 * The ms of that moment, or null for a number of another shape or an impossible date.
 */
export function numberMs(no) {
  const m = /^#?\d?X\d{3}1(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/.exec(String(no || '').trim());
  if (!m) return null;
  const [, , d, mo, yy, h, mi, s] = m.map((x) => +x);
  const y = 2000 + yy;
  const day = new Date(Date.UTC(y, mo - 1, d));
  if (day.getUTCFullYear() !== y || day.getUTCMonth() !== mo - 1 || day.getUTCDate() !== d || h > 23 || mi > 59 || s > 59) return null;
  return sarajevoMs(y, mo, d, h, mi, s);
}

export function createdMs(ord) {
  if (!ord) return null;
  const kind = typeof ord.madeType === 'string' ? ord.madeType : '';
  // the oldest history note (the owner confirmed it is the making); without one, the time in the order number
  if (kind && !/INTERNAL/.test(kind)) return numberMs(ord.no);
  if (Number.isFinite(ord.mk) && ord.mk > 1e12 && ord.mk < 1e13) return ord.mk;
  const m = /^(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2})(?::(\d{2}))?$/.exec(String(ord.made || '').trim());
  if (!m) return numberMs(ord.no);
  const [, d, mo, y, h, mi, s] = m.map((x) => +x || 0);
  const day = new Date(Date.UTC(y, mo - 1, d));
  if (day.getUTCFullYear() !== y || day.getUTCMonth() !== mo - 1 || day.getUTCDate() !== d || h > 23 || mi > 59 || s > 59) return null;
  return sarajevoMs(y, mo, d, h, mi, s);
}

const plural = (n, one, few, many) => { const a = n % 10, b = n % 100; return a === 1 && b !== 11 ? one : a >= 2 && a <= 4 && (b < 12 || b > 14) ? few : many; };
/** "12 h", "2 h 15 min", "45 min"; from a day on "1 dan i 13 h", "13 dana" (never more than is left: cut, not rounded). */
export function leftText(ms) {
  const m = Math.max(0, Math.floor(ms / 60000)), h = Math.floor(m / 60), mm = m % 60;
  if (!h) return mm ? `${mm} min` : 'manje od 1 min';
  if (h < 24) return mm ? `${h} h ${mm} min` : `${h} h`;
  const d = Math.floor(h / 24), hh = h % 24;
  return `${d} ${plural(d, 'dan', 'dana', 'dana')}${hh ? ` i ${hh} h` : ''}`;
}
/** "3 h", "1 dan i 5 h", "4 dana", "40 min": how long ago (or how old). */
export function agoText(ms) {
  const m = Math.max(0, Math.floor(ms / 60000));
  if (m < 60) return m < 1 ? 'manje od 1 min' : `${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} h`;
  const d = Math.floor(h / 24), hh = h % 24;
  return `${d} ${plural(d, 'dan', 'dana', 'dana')}${hh ? ` i ${hh} h` : ''}`;
}

/**
 * The end of a Click & Collect pick-up, MYJYSK 3.10 "tekući dan + 48 sati": the midnight that ends the day it was made,
 * plus two days, on the store's clock (made on Monday at 10:00 or at 23:00: until Wednesday 24:00).
 */
export function ccEnd(created, rules = RULES) {
  const d = wallOf(created);
  return sarajevoMs(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate() + 1 + Math.round(rules.cc.hours / 24), 0, 0, 0);
}
/** The same clock time `days` calendar days later in Sarajevo (14 days from 28.03. 12:00 is 11.04. 12:00, summer time or not). */
export function plusDays(created, days) {
  const d = wallOf(created);
  return sarajevoMs(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate() + days, d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds()) + d.getUTCMilliseconds();
}
// a moment as the Sarajevo wall clock (read with the getUTC* methods)
const wallOf = (ms) => new Date(ms + (isSummer(ms) ? 7200e3 : 3600e3));
/**
 * How long an active reservation is held (owner, 26. 11. 2026): an ordinary one 14 days from its creation at the till
 * (MYJYSK 3.03.2), paid or not; a Click & Collect one until the end of its day + 48 h (MYJYSK 3.10). Payment only
 * changes what the card says, never the deadline.
 *   kind 'clock'  left (ms), end, due (ran out), near (< 12 h), urgent (< 3 h or ran out), tone. It runs from the
 *                 creation whatever the order's status (also "Kreirano", also while the goods are not here: away says it)
 *   kind 'age'    while the start is not confirmed (RULES.hold.confirmed false): only its age, never "istekla"
 *   kind 'none'   the creation time is not known (or is after the phone's clock): no deadline is made up
 * away: StoreFront says the goods (or a part) are not received in the store yet. cc: the Click & Collect deadline.
 */
export function holdOf(pay, goods, created, now, rules = RULES, cc = false) {
  const H = rules.hold;
  const away = goods === 'wait' || goods === 'part';
  const age = created != null ? now - created : null;
  if (age !== null && age < -60000) return { kind: 'none', tone: 'unknown', why: 'vrijeme kreiranja je poslije sata telefona', away, cc };
  if (created == null) return { kind: 'none', tone: 'unknown', why: 'vrijeme kreiranja nije poznato', away, cc };
  const end = cc ? ccEnd(created, rules) : plusDays(created, H.days), left = end - now;
  const due = left <= 0, near = !due && left <= rules.soonHours * 3600e3;
  if (!H.confirmed && !cc) return { kind: 'age', tone: 'unknown', age, end, left, due, near, away, cc, limit: `${H.days} dana` };
  const urgent = due || left <= rules.urgentHours * 3600e3;
  return { kind: 'clock', tone: urgent ? 'urgent' : near ? 'soon' : 'neutral', age, end, left, due, near, urgent, away, cc };
}
/** How old, in hours up to 99 h, then in days: "45 min", "51 h", "6 dana". */
export function ageText(ms) {
  const m = Math.max(0, Math.floor(ms / 60000));
  if (m < 60) return m < 1 ? 'manje od 1 min' : `${m} min`;
  const h = Math.floor(m / 60);
  if (h < 100) return `${h} h`;
  const d = Math.floor(h / 24);
  return `${d} ${plural(d, 'dan', 'dana', 'dana')}`;
}
/** The short time text of a reservation card (also what the one-minute tick writes). */
export function holdText(h) {
  if (!h) return '';
  if (h.kind === 'clock') return h.due ? (h.left > -60000 ? 'Istekla upravo' : `Istekla prije ${agoText(-h.left)}`) : `Preostalo ${leftText(h.left)}`;
  if (h.kind === 'age') return `${ageText(h.age)} od kreiranja${h.due ? ` · preko ${h.limit}` : ''}`;
  return 'Vrijeme kreiranja nepoznato';
}

export const PAY_WORD = { paid: 'Plaćena', unpaid: 'Neplaćena', partial: 'Djelimično plaćena', deposit: 'Uplata, iznos nepoznat',
  unknown: 'Plaćanje nepoznato', conflict: 'Plaćanje kontradiktorno' };
/** The payment chip: the kind and where it comes from ("iz opisa" is never a payment system's confirmation). */
export function payText(pay) {
  if (pay.cat === 'unknown' || pay.cat === 'conflict') return PAY_WORD[pay.cat];
  if (pay.cat === 'paid' && pay.likely) return 'Vjerovatno plaćena (avans u opisu)';
  return `${PAY_WORD[pay.cat]} (${pay.src === 'sf' ? 'StoreFront' : pay.src === 'both' ? 'StoreFront i opis' : pay.src === 'cc' ? 'Click & Collect' : 'iz opisa'})`;
}
/**
 * An avans or a payment written in KM: set against the order's value (StoreFront's totalAmount) it is all of it or a
 * part; without the value it stays "Avans, iznos nepoznat".
 */
function payWithValue(pay, amt) {
  if (pay.cat !== 'deposit' || !Number.isInteger(pay.km) || amt === null) return pay;
  if (pay.km >= amt && pay.sfWait) return { ...pay, cat: 'conflict', conflict: true, why: `${pay.why}: opis kaže da je plaćeno sve (${money(amt)}), StoreFront čeka plaćanje` };
  if (pay.km >= amt) return { ...pay, cat: 'paid', why: `${pay.why}, a vrijednost narudžbe je ${money(amt)}: plaćeno sve` };
  return { ...pay, cat: 'partial', why: `${pay.why} od ${money(amt)}: plaćen je samo dio` };
}

/**
 * The reservation of an order, or null when it is not one (or the history with its description is not read yet:
 * that is said by noteKnown()). { level, words, why, pay, hold, goods, created, due, check: [reasons], amt }.
 */
// What does not change with the clock, kept per order object (a reading makes new objects; a field changed in place,
// e.g. a merged reading, is noticed): the screen and the minute tick only add the time.
const statics = new WeakMap();
function staticOf(ord) {
  const s = statics.get(ord);
  if (s && s.note === ord.note && s.pay === ord.pay && s.items === ord.items && s.n === ord.n && s.made === ord.made && s.mk === ord.mk && s.madeType === ord.madeType && s.amt === ord.amt) return s;
  const c0 = classify(ord.note, ord.pay === true);
  const c = c0.pay.cat === 'deposit' ? { ...c0, pay: payWithValue(c0.pay, amountOf(ord)) } : c0;
  const fresh = { note: ord.note, pay: ord.pay, items: ord.items, n: ord.n, made: ord.made, mk: ord.mk, madeType: ord.madeType, amt: ord.amt, c,
    goods: c.level === 'none' ? '' : orderState(ord).key, created: c.level === 'none' ? null : createdMs(ord) };
  statics.set(ord, fresh);
  return fresh;
}
export function reservationOf(ord, now = Date.now(), rules = RULES) {
  if (!ord || !noteKnown(ord)) return null;
  const { c, goods, created } = staticOf(ord);
  if (c.level === 'none') return null;
  const st = { key: goods };
  if (st.key === 'done') return null; // handed out: the reservation is over
  const hold = holdOf(c.pay, st.key, created, now, rules, c.cc);
  const check = [];
  if (c.level === 'likely') check.push('nije sigurno da je rezervacija');
  // owner, 26. 11. 2026: the payment no longer changes the deadline, so an unknown one is no reason by itself (only the
  // back office shows it); what the description says against itself or about a part still is
  if (c.pay.cat === 'conflict') check.push('kontradiktorni podaci o plaćanju');
  else if (c.pay.cat === 'partial') check.push('plaćen je samo dio');
  else if (c.pay.cat === 'deposit') check.push('uplata: koliko je plaćeno nije poznato');
  // (a deadline written in the description, "do petka", is only a note: owner, 26. 11. 2026; it stays in `due`)
  if (hold.kind === 'none') check.push(hold.why);
  if (hold.kind === 'age' && hold.due) check.push(`preko ${hold.limit} od kreiranja (početak roka nije potvrđen)`);
  // MYJYSK 3.03.2: a reservation is only for an active article that is in stock. Internal Audit, October 2026: reservations
  // of goods that were not in stock, without an avans. Goods not received yet were not in stock when it was made.
  if (hold.away && !c.cc && c.pay.cat !== 'paid') check.push('roba nije bila na zalihi, a rezervacija nije plaćena avansom: po MYJYSK 3.03.2 rezervacija je samo za artikal koji je na zalihi (nalaz interne revizije, oktobar 2026)');
  else if (hold.away && c.pay.cat !== 'paid') check.push('roba još nije stigla u prodavnicu, a rok teče od kreiranja');
  return { level: c.level, words: c.words, why: c.why, cc: c.cc, pay: c.pay, hold, goods: st.key, created, due: c.due, check, amt: amountOf(ord) };
}
/** Is the order an active reservation? (Only the kept part: no time, no new objects; for counting many orders.) */
export function isReservation(ord) {
  if (!ord || !noteKnown(ord)) return false;
  const s = staticOf(ord);
  return s.c.level !== 'none' && s.goods !== 'done';
}
/** Was the order's history (with the description) read? An order read before it has neither made nor note. */
export const noteKnown = (ord) => !!(ord && (ord.made || ord.note || ord.madeType || Number.isFinite(ord.mk)));

// --------------------------------------------------------------------------------------- filters, sorts, sums

/**
 * Within Rezervacije (owner's order). expired and soon are parts of all of them, paid or not (owner, 26. 11. 2026: the
 * deadline does not depend on the payment), never an extra order.
 */
export const RES_FILTERS = ['all', 'paid', 'unpaid', 'partial', 'expired', 'soon', 'check'];
export function filterLabel(k, rules = RULES) {
  const c = rules.hold.confirmed;
  return { all: 'Sve', unpaid: 'Neplaćene', paid: 'Plaćene', partial: 'Djelimično plaćene', expired: c ? 'Istekle' : `Preko ${rules.hold.days} dana`, soon: c ? 'Ističu uskoro' : `Blizu ${rules.hold.days} dana`, check: 'Potrebna provjera' }[k] || k;
}
const timed = (r) => r.hold.kind === 'clock' || r.hold.kind === 'age';
const isDue = (r) => timed(r) && r.hold.due;
const isNear = (r) => timed(r) && r.hold.near;
export function inFilter(r, k) {
  if (k === 'unpaid' || k === 'paid' || k === 'partial') return r.pay.cat === k;
  if (k === 'expired') return isDue(r);
  if (k === 'soon') return isNear(r);
  if (k === 'check') return r.check.length > 0;
  return true;
}

/** The sums over rows { ord, r }: counts, the known value, how many have no value (each order once). */
export function sums(rows) {
  const s = { all: 0, paid: 0, paidLikely: 0, unpaid: 0, partial: 0, deposit: 0, unknown: 0, conflict: 0, cc: 0, expired: 0, soon: 0, check: 0, sum: 0, noAmt: 0, sumExpired: 0, noAmtExpired: 0 };
  const seen = new Set();
  for (const { ord, r } of rows) {
    if (seen.has(ord.no)) continue;
    seen.add(ord.no);
    s.all++;
    s[r.pay.cat]++;
    if (r.pay.cat === 'paid' && r.pay.likely) s.paidLikely++;
    if (r.cc) s.cc++;
    const a = amountOf(ord);
    if (a == null) s.noAmt++; else s.sum += a;
    if (isDue(r)) { s.expired++; if (a == null) s.noAmtExpired++; else s.sumExpired += a; }
    if (isNear(r)) s.soon++;
    if (r.check.length) s.check++;
  }
  return s;
}
/** The value of a set of orders (each once): { n, sum, noAmt }. */
export function valueOf(list) {
  const seen = new Set();
  let n = 0, sum = 0, noAmt = 0;
  for (const ord of list || []) {
    if (!ord || seen.has(ord.no)) continue;
    seen.add(ord.no);
    n++;
    const a = amountOf(ord);
    if (a == null) noAmt++; else sum += a;
  }
  return { n, sum, noAmt };
}

const noNum = (ord) => { const d = String(ord.no || '').replace(/\D/g, ''); return d ? Number(d) : 0; };
const byAmt = (dir) => (a, b) => {
  const x = amountOf(a.ord), y = amountOf(b.ord);
  if (x == null || y == null) return (x == null ? 1 : 0) - (y == null ? 1 : 0); // unknown always last
  return dir * (x - y);
};
const byCreated = (dir) => (a, b) => {
  const x = a.r.created, y = b.r.created;
  if (x == null || y == null) return (x == null ? 1 : 0) - (y == null ? 1 : 0);
  return dir * (x - y);
};
// the end of its deadline (for sorting also while the start is not confirmed); one without a known start goes after them
const endOf = (r) => (timed(r) ? r.hold.end : null);
export const RES_SORTS = {
  // still running, the nearest end first; then the ones that ran out (the latest first); then the rest
  soonest: (a, b) => {
    const x = endOf(a.r), y = endOf(b.r), now = a.now;
    const g = (e) => (e == null ? 2 : e > now ? 0 : 1);
    return g(x) - g(y) || (g(x) === 0 ? x - y : g(x) === 1 ? y - x : 0) || byCreated(1)(a, b);
  },
  // the longest run out first, then the ones still running (nearest end first), then the rest
  longest: (a, b) => {
    const x = endOf(a.r), y = endOf(b.r), now = a.now;
    const g = (e) => (e == null ? 2 : e <= now ? 0 : 1);
    return g(x) - g(y) || (g(x) < 2 ? x - y : 0) || byCreated(1)(a, b);
  },
  valueDesc: (a, b) => byAmt(-1)(a, b) || byCreated(1)(a, b),
  valueAsc: (a, b) => byAmt(1)(a, b) || byCreated(1)(a, b),
  oldest: (a, b) => byCreated(1)(a, b) || noNum(a.ord) - noNum(b.ord),
  newest: (a, b) => byCreated(-1)(a, b) || noNum(b.ord) - noNum(a.ord),
};
export const RES_SORT_LIST = [['valueDesc', 'Najveća vrijednost (KM)'], ['valueAsc', 'Najmanja vrijednost (KM)'], ['soonest', 'Najbliže isteku'], ['longest', 'Najduže istekle'], ['oldest', 'Najstarije rezervacije'], ['newest', 'Najnovije rezervacije']];
export function sortRes(rows, how, now = Date.now()) {
  const f = RES_SORTS[how] || RES_SORTS.soonest;
  return rows.map((x) => ({ ...x, now })).sort(f);
}
