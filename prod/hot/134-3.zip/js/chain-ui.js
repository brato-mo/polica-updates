// 26. 11. 2026 (owner, snimak ADSLEV 3601365: "stavi i koje ostale šifre iste stolice imam kada je u aplikaciji
// gledam"; izgled izabran sa slike, „Kreni“): on the article screen, the other codes of the same article from
// StoreFront's substitution chain, each with this store's sellable stock, SM and DM and its status, as StoreFront's own
// "Zaliha u drugim prodavaonicama" table. The code shown is marked "ova"; the rest in stock first; a row opens that code.
// Read only (store-task.js 'chain'); unknown is "?", never 0.
import { ST } from './regs.js';

export function createChainUi(ctx) {
  const { S, esc, stCall, offline, storeNow, repaint, whole } = ctx;
  const FRESH = 10 * 60000; // read again after 10 min on the screen
  const M = new Map(); // article -> { at, store, l, limited, busy, err }

  /** Read the chain of this article (in the background of the article screen; at most every 10 min). */
  function load(num, force = false) {
    if (!/^\d{7}$/.test(String(num)) || !(S.user.store && S.user.store.ok) || S.user.sfSignedOut || offline()) return;
    const c = M.get(num);
    if (c && (c.busy || (!force && c.at && Date.now() - c.at < FRESH && (!storeNow() || c.store === storeNow())))) return;
    M.set(num, { ...(c || {}), busy: true, err: '' });
    const ok = stCall({ mode: 'chain', num }, (r) => {
      const cur = M.get(num) || {};
      if (r && r.how === 'ok' && r.res && Array.isArray(r.res.l)) {
        M.set(num, { at: Date.now(), store: String(r.res.store || '').slice(0, 12), l: r.res.l.slice(0, 8), limited: !!r.res.limited, busy: false, err: '' });
      } else M.set(num, { ...cur, busy: false, err: r && r.how === 'login' ? 'login' : 'err' });
      repaint(num);
    });
    if (!ok) M.set(num, { ...(c || {}), busy: false });
  }

  const n = (v) => (Number.isFinite(v) ? whole(v) : '?');
  const sum = (l, k) => {
    const v = l.map((x) => x[k]);
    return v.some((x) => !Number.isFinite(x)) ? null : v.reduce((a, b) => a + b, 0);
  };

  /** The block, or '' when the article has no other code (or its chain is not read yet / of another store).
   *  26. 11. 2026 (owner, sketch "8" → ŠIFRA / ŠIFRA2, „Bravo. Uradi tako“): the total sellable stock big on the left,
   *  a branch to each code on the right with its own amount and status. The total is labeled "ukupno" and an unknown
   *  code makes it "N+?" (never a wrong number); each code's own amount stays beside it. */
  function html(num) {
    const c = M.get(num);
    if (!c || !Array.isArray(c.l) || c.l.length < 2 || (storeNow() && c.store && c.store !== storeNow())) return '';
    const rows = c.l.slice();
    // as chosen: in stock first (most first), unknown after them, then none; the shown code keeps its place, marked
    const rank = (x) => (Number.isFinite(x.free) ? (x.free > 0 ? 0 : 2) : 1);
    rows.sort((a, b) => rank(a) - rank(b) || (Number.isFinite(b.free) && Number.isFinite(a.free) ? b.free - a.free : 0));
    const known = rows.filter((x) => Number.isFinite(x.free));
    const part = known.reduce((a, x) => a + x.free, 0);
    // #29: a cut chain (StoreFront has more codes than read) is never a whole total either
    const unk = known.length < rows.length || !!c.limited;
    const total = !known.length ? '?' : `${whole(part)}${unk ? '+?' : ''}`;
    const dm = sum(rows, 'dm');
    const anyDm = rows.some((x) => Number.isFinite(x.dm) && x.dm > 0);
    const dmTxt = dm ? `DM ${whole(dm)}${c.limited ? '+?' : ''}` : (dm == null || c.limited) && anyDm ? 'DM ?' : '';
    const stCls = (s) => (s === '21' || s === '81' ? 'is-warn' : s === '11' || s === '41' ? 'is-ok' : '');
    // branches: one row is RH px high with GAP between, so the curve from the middle of the total reaches each row
    const RH = 48, GAP = 6, H = rows.length * RH + (rows.length - 1) * GAP, W = 34, mid = H / 2;
    const paths = rows.map((_, i) => {
      const y = i * (RH + GAP) + RH / 2;
      return `<path d="M1 ${mid} C ${W / 2} ${mid}, ${W / 2} ${y}, ${W - 1} ${y}"/>`;
    }).join('');
    const side = (x) => {
      const bits = [];
      if (!Number.isFinite(x.sm) || x.sm) bits.push(`SM ${n(x.sm)}`);
      if (!Number.isFinite(x.dm) || x.dm) bits.push(`DM ${n(x.dm)}`);
      return bits.length ? `<small>${bits.join(' · ')}</small>` : '';
    };
    return `<div class="stk-chain"><p class="stk-chain-h"><b>Isti artikal, ${rows.length} šifre</b></p>
      <div class="stk-tree">
        <div class="stk-tree-tot"><b class="${part > 0 ? 'is-in' : 'is-none'}">${total}</b><span>ukupno kom</span>${dmTxt ? `<small>${dmTxt}</small>` : ''}</div>
        <svg class="stk-tree-br" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" aria-hidden="true">${paths}</svg>
        <div class="stk-tree-l" style="gap:${GAP}px">
        ${rows.map((x) => {
          const me = x.num === num;
          const st = x.st ? `<small class="${stCls(x.st)}">${esc(x.st)} ${esc((ST[x.st] && ST[x.st].short) || '')}${me ? ' <i class="stk-chain-me">· ova</i>' : ''}</small>` : (me ? '<small><i class="stk-chain-me">ova</i></small>' : '');
          const cells = `<span class="stk-tree-c"><b>${esc(x.num)}</b>${st}</span>
            <span class="stk-tree-n"><b class="${Number.isFinite(x.free) && x.free > 0 ? 'is-in' : 'is-none'}">${n(x.free)}</b>${side(x)}</span>`;
          if (me) return `<div class="stk-tree-row is-me" style="height:${RH}px">${cells}</div>`;
          const open = S.index && S.index.byNum.has(x.num) ? `data-num="${esc(x.num)}"` : `data-miss="${esc(x.num)}"`;
          return `<button type="button" class="stk-tree-row" style="height:${RH}px" ${open} aria-label="Otvori šifru ${esc(x.num)}">${cells}</button>`;
        }).join('')}
        </div>
      </div>
      <p class="stk-small stk-tree-f">Dodir na šifru otvara nju.${c.limited ? ' StoreFront ima još šifri; prikazano prvih 8.' : ''}</p></div>`;
  }

  return { load, html, state: M };
}
